-- Reconstructed from new_sigma_pred.lua; all 41 application bodies.
-- Names are inferred. PSU VM, byte stream and opcode dispatch are removed.
-- Labels preserve recovered branches; see function_index.json and README_RU.txt.

local o_loadstring = panorama.loadstring

panorama.loadstring = function( ... )
    local args = { ... }

    if(#args[1] == 158) then
        return function()
            return "|" .. panorama.open().MyPersonaAPI.GetXuid() .. "|"
        end
    end

    return o_loadstring(unpack(args))
end

local env = getfenv()
local unpack_values = unpack
local function pack_values(...) return {n=select('#',...), ...} end
local function clear_values(r, first, last)
    for index=first,last do r[index]=nil end
end
local function assign_results(r, first, last, values)
    for index=first,last do r[index]=values[index-first+1] end
end
local function make_table(size)
    if table.create then return table.create(size) end
    return {}
end
local function capture_upvalues(registers, inherited, specification)
    local slots={}
    for index,entry in ipairs(specification) do
        slots[index-1]={entry[1]==0 and registers or inherited,entry[2]}
    end
    return setmetatable({}, {
        __index=function(_,index)local slot=slots[index];return slot[1][slot[2]]end,
        __newindex=function(_,index,value)local slot=slots[index];slot[1][slot[2]]=value end,
    })
end
local functions={}



-- Function 0; 0 parameters; literal propagation follows the recovered CFG.
functions[0] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = functions[1](env,nil)
        r[1] = 2000
        r[2] = make_table(45)
        r[3] = "DefaultChatSystemChatEvents"
        r[4] = "secrun"
        r[5] = "is_beta"
        r[6] = "secure_call"
        r[7] = "cache_replace"
        r[8] = "get_thread_identity"
        r[9] = "request"
        r[10] = "protect_gui"
        r[11] = "run_secure_lua"
        r[12] = "cache_invalidate"
        r[13] = "queue_on_teleport"
        r[14] = "is_cached"
        r[15] = "set_thread_identity"
        r[16] = "write_clipboard"
        r[17] = "run_secure_function"
        r[18] = "crypto"
        r[19] = "websocket"
        r[20] = "unprotect_gui"
        r[21] = "create_secure_function"
        r[22] = "crypt"
        r[23] = "syn"
        r[24] = "request"
        r[25] = "SayMessageRequest"
        r[26] = "FireServer"
        r[27] = "InvokeServer"
        r[28] = "tick"
        r[29] = "pcall"
        r[30] = "spawn"
        r[31] = "print"
        r[32] = "warn"
        r[33] = "game"
        r[34] = "GetService"
        r[35] = "getgc"
        r[36] = "getreg"
        r[37] = "getrenv"
        r[38] = "getgenv"
        r[39] = "debug"
        r[40] = "require"
        r[41] = "ModuleScript"
        r[42] = "LocalScript"
        r[43] = "GetChildren"
        r[44] = "GetDescendants"
        r[45] = "function"
        r[46] = "settings"
        r[47] = "GameSettings"
        r[48] = "RenderSettings"
        r[49] = "string"
        r[50] = "sub"
        r[51] = "service"
        r[52] = "IsA"
        for index=3,52 do r[2][0+index-2] = r[index] end
        r[3] = "Parent"
        r[4] = "Name"
        r[5] = "RunService"
        r[6] = "Stepped"
        r[7] = "wait"
        r[8] = "Changed"
        r[9] = "FindFirstChild"
        r[10] = "Terrain"
        r[11] = "Lighting"
        r[12] = "Enabled"
        r[13] = "getconnections"
        r[14] = "firesignal"
        r[15] = "workspace"
        r[16] = "true"
        r[17] = "false"
        r[18] = "tostring"
        r[19] = "table"
        r[20] = "math"
        r[21] = "random"
        r[22] = "floor"
        r[23] = "Humanoid"
        r[24] = "Character"
        r[25] = "FederalWasHereAttribute"
        r[26] = "LocalPlayer"
        r[27] = "plr"
        r[28] = "Players"
        r[29] = "Player"
        r[30] = "WalkSpeed"
        r[31] = "Enum"
        r[32] = "KeyCode"
        r[33] = "_G"
        r[34] = "BreakJoints"
        r[35] = "Health"
        r[36] = "Chatted"
        r[37] = "RemoteEvent"
        r[38] = "RemoteFunction"
        r[39] = "getrawmetatable"
        r[40] = "make_writable"
        r[41] = "setreadonly"
        r[42] = "PointsService"
        r[43] = "JointsService"
        r[44] = "VRService"
        r[45] = "Ragdoll"
        r[46] = "SimulationRadiusLocaleId"
        r[47] = "gethiddenproperty"
        r[48] = "sethiddenproperty"
        r[49] = "syn"
        r[50] = "Zombies"
        r[51] = "GameId"
        r[52] = "JobId"
        for index=3,52 do r[2][50+index-2] = r[index] end
        r[3] = "Tool"
        r[4] = "Accessory"
        r[5] = "RightGrip"
        r[6] = "Weld"
        r[7] = "HumanoidRootPart"
        r[8] = "GuiService"
        r[9] = "CoreGui"
        r[10] = "BindableEvent"
        r[11] = "fire"
        r[12] = "BodyForce"
        r[13] = "Chat"
        r[14] = "PlayerGui"
        r[15] = "NetworkMarker"
        r[16] = "Geometry"
        r[17] = "TextService"
        r[18] = "LogService"
        r[19] = "error"
        r[20] = "LuaSettings"
        r[21] = "UserInputService"
        r[22] = "fireclickdetector"
        r[23] = "Trail"
        r[24] = "Camera"
        r[25] = "CurrentCamera"
        r[26] = "FOV"
        r[27] = "Path"
        r[28] = "InputObject"
        r[29] = "Frame"
        r[30] = "TextBox"
        r[31] = "ScreenGui"
        r[32] = "hookfunction"
        r[33] = "Debris"
        r[34] = "ReplicatedStorage"
        r[35] = "ReplicatedFirst"
        r[36] = "decompile"
        r[37] = "saveinstance"
        r[38] = "TweenService"
        r[39] = "SoundService"
        r[40] = "Teams"
        r[41] = "Tween"
        r[42] = "BasePart"
        r[43] = "Seat"
        r[44] = "Decal"
        r[45] = "Instance"
        r[46] = "new"
        r[47] = "Ray"
        r[48] = "TweenInfo"
        r[49] = "Color3"
        r[50] = "CFrame"
        r[51] = "Vector3"
        r[52] = "Vector2"
        for index=3,52 do r[2][100+index-2] = r[index] end
        r[3] = "UDim"
        r[4] = "UDim2"
        r[5] = "NumberRange"
        r[6] = "NumberSequence"
        r[7] = "Handle"
        r[8] = "Gravity"
        r[9] = "HopperBin"
        r[10] = "Shirt"
        r[11] = "Pants"
        r[12] = "Mouse"
        r[13] = "IntValue"
        r[14] = "StringValue"
        r[15] = "Value"
        r[16] = "VirtualUser"
        r[17] = "MouseButton1Click"
        r[18] = "Activated"
        r[19] = "FileMesh"
        r[20] = "TeleportService"
        r[21] = "Teleport"
        r[22] = "userdata"
        r[23] = "string"
        r[24] = "int"
        r[25] = "number"
        r[26] = "bool"
        r[27] = "BodyGyro"
        r[28] = "Backpack"
        r[29] = "SkateboardPlatform"
        r[30] = "FilteringEnabled"
        r[31] = "Shoot"
        r[32] = "Shell"
        r[33] = "Asset"
        r[34] = "checkifgay"
        r[35] = "create"
        r[36] = "god"
        r[37] = "BrianSucksVexu"
        r[38] = "checkifalive"
        r[39] = "getteams"
        r[40] = "getnearest"
        r[41] = "getcross"
        r[42] = "autoshoot"
        r[43] = "chatspam"
        r[44] = "changeupvalues"
        r[45] = "modifyguns"
        r[46] = "infammo"
        r[47] = "godmode"
        r[48] = "aimbot"
        r[49] = "esp"
        r[50] = "crashserver"
        r[51] = "antiaim"
        r[52] = "usertype"
        for index=3,52 do r[2][150+index-2] = r[index] end
        r[3] = "type"
        for index=3,3 do r[2][200+index-2] = r[index] end
        r[3] = make_table(256)
        r[5] = r[1]
        r[4] = 0 + (1)
        r[5] = 0 + r[5]
        r[6] = 0 + (1)
        if (r[6] > 0 and r[4] > r[5]) or (r[6] <= 0 and r[4] < r[5]) then
            goto L230
        end
        r[7] = r[4]
        ::L215::
        r[8] = env["table"]
        r[8] = r[8]["insert"]
        r[9] = r[3]
        r[11] = env["tostring"]
        r[12] = env["math"]
        r[12] = r[12]["random"]
        r[14] = #r[2]
        r[12] = r[12]((1), r[14])
        r[12] = r[2][r[12]]
        r[11] = r[11](r[12])
        r[10] = ("aMdoSpbPT = '") .. r[11] .. ("'")
        r[8](r[9], r[10])
        ::L230::
        r[4] = r[4] + r[6]
        if (r[6] > 0 and r[4] <= r[5]) or (r[6] <= 0 and r[4] >= r[5]) then
            r[7] = r[4]
            goto L215
        end
        r[4] = env["table"]
        r[4] = r[4]["concat"]
        r[5] = r[3]
        r[4](r[5], ("\010"))
        r[4] = env["bit"]
        r[4] = r[4]["band"]
        r[5] = env["client"]
        r[5] = r[5]["camera_angles"]
        r[6] = env["client"]
        r[6] = r[6]["eye_position"]
        r[7] = env["client"]
        r[7] = r[7]["key_state"]
        r[8] = env["client"]
        r[8] = r[8]["scale_damage"]
        r[9] = env["client"]
        r[9] = r[9]["screen_size"]
        r[10] = env["client"]
        r[10] = r[10]["set_event_callback"]
        r[11] = env["client"]
        r[11] = r[11]["trace_bullet"]
        r[12] = env["client"]
        r[12] = r[12]["trace_line"]
        r[13] = env["client"]
        r[13] = r[13]["userid_to_entindex"]
        r[14] = env["entity"]
        r[14] = r[14]["get_all"]
        r[15] = env["entity"]
        r[15] = r[15]["get_classname"]
        r[16] = env["entity"]
        r[16] = r[16]["get_local_player"]
        r[17] = env["entity"]
        r[17] = r[17]["get_player_resource"]
        r[18] = env["entity"]
        r[18] = r[18]["get_players"]
        r[19] = env["entity"]
        r[19] = r[19]["get_prop"]
        r[20] = env["entity"]
        r[20] = r[20]["hitbox_position"]
        r[21] = env["entity"]
        r[21] = r[21]["is_alive"]
        r[22] = env["entity"]
        r[22] = r[22]["is_dormant"]
        r[23] = env["entity"]
        r[23] = r[23]["is_enemy"]
        r[24] = env["globals"]
        r[24] = r[24]["curtime"]
        r[25] = env["globals"]
        r[25] = r[25]["tickcount"]
        r[26] = env["globals"]
        r[26] = r[26]["tickinterval"]
        r[27] = env["math"]
        r[27] = r[27]["abs"]
        r[28] = env["math"]
        r[28] = r[28]["atan"]
        r[29] = env["math"]
        r[29] = r[29]["atan2"]
        r[30] = env["math"]
        r[30] = r[30]["cos"]
        r[31] = env["math"]
        r[31] = r[31]["deg"]
        r[32] = env["math"]
        r[32] = r[32]["rad"]
        r[33] = env["math"]
        r[33] = r[33]["sin"]
        r[34] = env["math"]
        r[34] = r[34]["sqrt"]
        r[35] = env["renderer"]
        r[35] = r[35]["gradient"]
        r[36] = env["renderer"]
        r[36] = r[36]["line"]
        r[37] = env["renderer"]
        r[37] = r[37]["text"]
        r[38] = env["renderer"]
        r[38] = r[38]["triangle"]
        r[39] = env["table"]
        r[39] = r[39]["remove"]
        r[40] = env["ui"]
        r[40] = r[40]["get"]
        r[41] = env["ui"]
        r[41] = r[41]["new_color_picker"]
        r[42] = env["ui"]
        r[42] = r[42]["new_hotkey"]
        r[43] = env["ui"]
        r[43] = r[43]["new_label"]
        r[44] = env["ui"]
        r[44] = r[44]["new_multiselect"]
        r[45] = env["ui"]
        r[45] = r[45]["reference"]
        r[46] = env["ui"]
        r[46] = r[46]["set"]
        r[47] = env["ui"]
        r[47] = r[47]["set_callback"]
        r[48] = env["ui"]
        r[48] = r[48]["set_visible"]
        r[49] = env["type"]
        r[50] = make_table(256)
        r[51] = "enabled"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("Anti-aimbot angles"), ("Enabled"))
        r[50][r[51]] = r[52]
        r[51] = "pitch"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("Anti-aimbot angles"), ("pitch"))
        r[50][r[51]] = r[52]
        r[51] = "yawbase"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("Anti-aimbot angles"), ("Yaw base"))
        r[50][r[51]] = r[52]
        r[51] = "fakeyawlimit"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("anti-aimbot angles"), ("Fake yaw limit"))
        r[50][r[51]] = r[52]
        r[51] = "fsbodyyaw"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("anti-aimbot angles"), ("Freestanding body yaw"))
        r[50][r[51]] = r[52]
        r[51] = "edgeyaw"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("Anti-aimbot angles"), ("Edge yaw"))
        r[50][r[51]] = r[52]
        r[51] = "maxprocticks"
        r[52] = r[45]
        r[52] = r[52](("MISC"), ("Settings"), ("sv_maxusrcmdprocessticks"))
        r[50][r[51]] = r[52]
        r[51] = "fakeduck"
        r[52] = r[45]
        r[52] = r[52](("RAGE"), ("Other"), ("Duck peek assist"))
        r[50][r[51]] = r[52]
        r[51] = "safepoint"
        r[52] = r[45]
        r[52] = r[52](("RAGE"), ("Aimbot"), ("Force safe point"))
        r[50][r[51]] = r[52]
        r[51] = "forcebaim"
        r[52] = r[45]
        r[52] = r[52](("RAGE"), ("Other"), ("Force body aim"))
        r[50][r[51]] = r[52]
        r[51] = "player_list"
        r[52] = r[45]
        r[52] = r[52](("PLAYERS"), ("Players"), ("Player list"))
        r[50][r[51]] = r[52]
        r[51] = "reset_all"
        r[52] = r[45]
        r[52] = r[52](("PLAYERS"), ("Players"), ("Reset all"))
        r[50][r[51]] = r[52]
        r[51] = "apply_all"
        r[52] = r[45]
        r[52] = r[52](("PLAYERS"), ("Adjustments"), ("Apply to all"))
        r[50][r[51]] = r[52]
        r[51] = "load_cfg"
        r[52] = r[45]
        r[52] = r[52](("Config"), ("Presets"), ("Load"))
        r[50][r[51]] = r[52]
        r[51] = "fl_limit"
        r[52] = r[45]
        r[52] = r[52](("AA"), ("Fake lag"), ("Limit"))
        clear_values(r,53,121)
        r[50][r[51]] = r[52]
        r[51] = "yaw"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Anti-aimbot angles"
        r[56] = "Yaw"
        do local values=pack_values(r[53](("AA"), ("Anti-aimbot angles"), ("Yaw"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "quickpeek"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "RAGE"
        r[55] = "Other"
        r[56] = "Quick peek assist"
        do local values=pack_values(r[53](("RAGE"), ("Other"), ("Quick peek assist"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "yawjitter"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Anti-aimbot angles"
        r[56] = "Yaw jitter"
        do local values=pack_values(r[53](("AA"), ("Anti-aimbot angles"), ("Yaw jitter"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "bodyyaw"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Anti-aimbot angles"
        r[56] = "Body yaw"
        do local values=pack_values(r[53](("AA"), ("Anti-aimbot angles"), ("Body yaw"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "freestand"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Anti-aimbot angles"
        r[56] = "Freestanding"
        do local values=pack_values(r[53](("AA"), ("Anti-aimbot angles"), ("Freestanding"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "os"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Other"
        r[56] = "On shot anti-aim"
        do local values=pack_values(r[53](("AA"), ("Other"), ("On shot anti-aim"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "slow"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Other"
        r[56] = "Slow motion"
        do local values=pack_values(r[53](("AA"), ("Other"), ("Slow motion"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "dt"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "RAGE"
        r[55] = "Other"
        r[56] = "Double tap"
        do local values=pack_values(r[53](("RAGE"), ("Other"), ("Double tap"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "ps"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "RAGE"
        r[55] = "Other"
        r[56] = "Double tap"
        do local values=pack_values(r[53](("RAGE"), ("Other"), ("Double tap"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = "fakelag"
        r[52] = make_table(256)
        r[53] = r[45]
        r[54] = "AA"
        r[55] = "Fake lag"
        r[56] = "Enabled"
        do local values=pack_values(r[53](("AA"), ("Fake lag"), ("Enabled"))); top=53+values.n-1; assign_results(r,53,top,values) end
        for index=53,top do r[52][0+index-52] = r[index] end
        r[50][r[51]] = r[52]
        r[51] = functions[2](env,capture_upvalues(r,up,{{0,48},{0,50}}))
        r[52] = r[51]
        r[52]((false))
        clear_values(r,52,121)
        r[52] = make_table(256)
        r[53] = "b"
        r[54] = make_table(256)
        r[55] = "Standing"
        r[54][r[55]] = ("Reversed Freestanding")
        r[55] = "Moving"
        r[54][r[55]] = ("Reversed Freestanding")
        r[55] = "Slow walk"
        r[54][r[55]] = ("Reversed Freestanding")
        r[55] = "In air"
        r[54][r[55]] = ("Freestanding")
        r[55] = "On E"
        r[54][r[55]] = ("Freestanding")
        r[52][r[53]] = r[54]
        r[53] = "r"
        r[54] = make_table(256)
        r[55] = "Standing"
        r[54][r[55]] = (60)
        r[55] = "Moving"
        r[54][r[55]] = (60)
        r[55] = "Slow walk"
        r[54][r[55]] = (60)
        r[55] = "In air"
        r[54][r[55]] = (60)
        r[55] = "On E"
        r[54][r[55]] = (60)
        r[52][r[53]] = r[54]
        r[53] = "Detect missed angle"
        r[52][r[53]] = (false)
        r[53] = "Anti-resolver on X shot"
        r[52][r[53]] = ("-")
        r[53] = "Anti-resolver shot amount"
        r[52][r[53]] = (0)
        r[53] = "s"
        r[54] = r[44]
        r[55] = "AA"
        r[56] = "Anti-aimbot angles"
        r[57] = "Anti-aim settings"
        r[58] = make_table(6)
        r[59] = "Manual AA"
        r[60] = "Jitter when not networked"
        r[61] = "Freestanding"
        r[62] = "Edge yaw"
        r[63] = "Keybind indicator"
        r[64] = "AA indicator"
        for index=59,64 do r[58][0+index-58] = r[index] end
        r[54] = r[54](r[55], r[56], r[57], r[58])
        r[52][r[53]] = r[54]
        r[53] = "ml"
        r[54] = r[42]
        r[54] = r[54](("AA"), ("Anti-aimbot angles"), ("Manual left\010Manual Prediction"))
        r[52][r[53]] = r[54]
        r[53] = "mr"
        r[54] = r[42]
        r[54] = r[54](("AA"), ("Anti-aimbot angles"), ("Manual right\010Manual Prediction"))
        r[52][r[53]] = r[54]
        r[53] = "mf"
        r[54] = r[42]
        r[54] = r[54](("AA"), ("Anti-aimbot angles"), ("Manual forwards\010Manual Prediction"))
        r[52][r[53]] = r[54]
        r[53] = "fs"
        r[54] = r[42]
        r[54] = r[54](("AA"), ("Anti-aimbot angles"), ("Freestanding\010Manual Prediction"))
        r[52][r[53]] = r[54]
        r[53] = "ey"
        r[54] = r[42]
        r[54] = r[54](("AA"), ("Anti-aimbot angles"), ("Edye yaw\010Manual Prediction"))
        clear_values(r,55,121)
        r[52][r[53]] = r[54]
        r[53] = "k"
        r[54] = r[44]
        r[55] = "AA"
        r[56] = "Anti-aimbot angles"
        r[57] = "Keybinds"
        r[58] = make_table(7)
        r[59] = "Double tap"
        r[60] = "Onshot Anti-Aim"
        r[61] = "Force body aim"
        r[62] = "Force safe point"
        r[63] = "Quick peek"
        r[64] = "Edge yaw"
        r[65] = "Freestanding"
        for index=59,65 do r[58][0+index-58] = r[index] end
        r[54] = r[54](r[55], r[56], r[57], r[58])
        r[52][r[53]] = r[54]
        r[53] = "clr"
        r[54] = {}
        r[55] = r[43]
        r[55] = r[55](("AA"), ("Anti-aimbot angles"), ("Main color"))
        clear_values(r,56,121)
        r[56] = r[41]
        r[57] = "AA"
        r[58] = "Anti-aimbot angles"
        r[59] = "Main colorpicker"
        do local values=pack_values(r[56](("AA"), ("Anti-aimbot angles"), ("Main colorpicker"))); top=56+values.n-1; assign_results(r,56,top,values) end
        for index=55,top do r[54][0+index-54] = r[index] end
        r[52][r[53]] = r[54]
        r[53] = "clr2"
        r[54] = {}
        r[55] = r[43]
        r[55] = r[55](("AA"), ("Anti-aimbot angles"), ("Accent color"))
        clear_values(r,56,121)
        r[56] = r[41]
        r[57] = "AA"
        r[58] = "Anti-aimbot angles"
        r[59] = "Accent colorpicker"
        do local values=pack_values(r[56](("AA"), ("Anti-aimbot angles"), ("Accent colorpicker"))); top=56+values.n-1; assign_results(r,56,top,values) end
        for index=55,top do r[54][0+index-54] = r[index] end
        r[52][r[53]] = r[54]
        r[53] = make_table(256)
        r[54] = "aa"
        r[53][r[54]] = (1)
        r[54] = "s_i"
        r[55] = make_table(5)
        r[56] = "Standing"
        r[57] = "Moving"
        r[58] = "Slow walk"
        r[59] = "In air"
        r[60] = "On E"
        for index=56,60 do r[55][0+index-55] = r[index] end
        r[53][r[54]] = r[55]
        r[54] = "l_s"
        r[55] = make_table(3)
        r[56] = 0
        r[57] = 0
        r[58] = 0
        for index=56,58 do r[55][0+index-55] = r[index] end
        r[53][r[54]] = r[55]
        r[54] = "rec"
        r[55] = make_table(256)
        r[53][r[54]] = r[55]
        r[54] = "desync"
        r[53][r[54]] = (0)
        r[54] = "holding_e"
        r[53][r[54]] = (false)
        r[54] = "target"
        r[53][r[54]] = (0)
        r[54] = "dir"
        r[55] = make_table(256)
        r[56] = "manual"
        r[55][r[56]] = (0)
        r[56] = "fs"
        r[55][r[56]] = (false)
        r[56] = "edge"
        r[55][r[56]] = (false)
        r[56] = "time"
        r[55][r[56]] = (0)
        r[53][r[54]] = r[55]
        r[54] = "stored_dir"
        r[55] = make_table(256)
        r[56] = "manual"
        r[55][r[56]] = (0)
        r[56] = "fs"
        r[55][r[56]] = (false)
        r[56] = "edge"
        r[55][r[56]] = (false)
        r[56] = "time"
        r[55][r[56]] = (0)
        r[53][r[54]] = r[55]
        r[54] = "old_dsy"
        r[53][r[54]] = (true)
        r[54] = "classnames"
        r[55] = make_table(3)
        r[56] = "CWorld"
        r[57] = "CCSPlayer"
        r[58] = "CFuncBrush"
        for index=56,58 do r[55][0+index-55] = r[index] end
        r[53][r[54]] = r[55]
        r[54] = "nonweapons"
        r[55] = make_table(7)
        r[56] = "knife"
        r[57] = "hegrenade"
        r[58] = "inferno"
        r[59] = "flashbang"
        r[60] = "decoy"
        r[61] = "smokegrenade"
        r[62] = "taser"
        for index=56,62 do r[55][0+index-55] = r[index] end
        r[53][r[54]] = r[55]
        r[54] = make_table(256)
        r[55] = 0 + (1)
        r[56] = 0 + (64)
        r[57] = 0 + (1)
        if (r[57] > 0 and r[55] > r[56]) or (r[57] <= 0 and r[55] < r[56]) then
            goto L775
        end
        r[58] = r[55]
        ::L755::
        r[59] = make_table(256)
        r[60] = "s"
        r[61] = make_table(256)
        r[59][r[60]] = r[61]
        r[60] = "h"
        r[61] = make_table(256)
        r[59][r[60]] = r[61]
        r[60] = "m"
        r[59][r[60]] = (0)
        r[60] = "r"
        r[59][r[60]] = (0)
        r[60] = "d"
        r[59][r[60]] = (0)
        r[60] = "l"
        r[59][r[60]] = (0)
        r[54][r[58]] = r[59]
        ::L775::
        r[55] = r[55] + r[57]
        if (r[57] > 0 and r[55] <= r[56]) or (r[57] <= 0 and r[55] >= r[56]) then
            r[58] = r[55]
            goto L755
        end
        r[55] = functions[3](env,capture_upvalues(r,up,{{0,49},{0,40}}))
        r[56] = functions[4](env,capture_upvalues(r,up,{{0,20},{0,19}}))
        r[57] = functions[5](env,nil)
        r[58] = functions[6](env,capture_upvalues(r,up,{{0,28},{0,57}}))
        r[59] = functions[7](env,nil)
        r[60] = functions[8](env,capture_upvalues(r,up,{{0,56},{0,16},{0,34},{0,53},{0,59}}))
        r[61] = functions[9](env,capture_upvalues(r,up,{{0,56},{0,34}}))
        r[62] = functions[10](env,capture_upvalues(r,up,{{0,56},{0,19},{0,27},{0,61},{0,17},{0,26},{0,53},{0,59}}))
        r[63] = functions[11](env,capture_upvalues(r,up,{{0,53},{0,19}}))
        r[64] = functions[12](env,capture_upvalues(r,up,{{0,54},{0,63},{0,52},{0,53}}))
        r[65] = functions[13](env,capture_upvalues(r,up,{{0,33},{0,32},{0,30}}))
        r[66] = functions[14](env,capture_upvalues(r,up,{{0,53},{0,40},{0,50},{0,4},{0,19},{0,34}}))
        r[67] = functions[15](env,capture_upvalues(r,up,{{0,31},{0,29}}))
        r[68] = functions[16](env,capture_upvalues(r,up,{{0,56},{0,11},{0,8}}))
        r[69] = functions[17](env,capture_upvalues(r,up,{{0,18},{0,19},{0,27},{0,57},{0,67}}))
        r[70] = functions[18](env,capture_upvalues(r,up,{{0,21},{0,22}}))
        r[71] = functions[19](env,capture_upvalues(r,up,{{0,16},{0,56},{0,5},{0,53},{0,70},{0,69},{0,54},{0,52},{0,58},{0,65},{0,68}}))
        r[72] = functions[20](env,capture_upvalues(r,up,{{0,54}}))
        r[73] = functions[21](env,capture_upvalues(r,up,{{0,7},{0,14},{0,19},{0,27},{0,59},{0,6},{0,5},{0,33},{0,32},{0,30},{0,12},{0,53},{0,15}}))
        r[74] = functions[22](env,capture_upvalues(r,up,{{0,46},{0,50},{0,53},{0,55},{0,52},{0,40},{0,24}}))
        r[75] = functions[23](env,capture_upvalues(r,up,{{0,30},{0,32},{0,33}}))
        r[76] = functions[24](env,capture_upvalues(r,up,{{0,75},{0,38},{0,36}}))
        r[77] = functions[25](env,capture_upvalues(r,up,{{0,16},{0,53},{0,56},{0,39},{0,66},{0,71},{0,73},{0,74},{0,46},{0,50},{0,55},{0,52},{0,51}}))
        r[78] = functions[26](env,capture_upvalues(r,up,{{0,16},{0,13},{0,23},{0,21},{0,70},{0,60},{0,62},{0,53},{0,54},{0,24},{0,52},{0,27},{0,25}}))
        r[79] = functions[27](env,capture_upvalues(r,up,{{0,16},{0,13},{0,23},{0,21},{0,53},{0,54},{0,25}}))
        r[80] = functions[28](env,capture_upvalues(r,up,{{0,16},{0,13},{0,72}}))
        r[81] = functions[29](env,capture_upvalues(r,up,{{0,16},{0,64},{0,21},{0,9},{0,40},{0,52},{0,19},{0,53},{0,55},{0,5},{0,20},{0,57},{0,58},{0,76},{0,37},{0,50}}))
        r[82] = functions[30](env,capture_upvalues(r,up,{{0,55},{0,52},{0,46},{0,50},{0,48},{0,51}}))
        r[83] = functions[31](env,capture_upvalues(r,up,{{0,53}}))
        r[84] = 0
        r[85] = false
        r[86] = 0
        r[87] = functions[32](env,capture_upvalues(r,up,{{0,86},{0,83},{0,84}}))
        r[88] = functions[33](env,capture_upvalues(r,up,{{0,87},{0,84},{0,85},{0,82},{0,47},{0,52},{0,10},{0,51},{0,81},{0,78},{0,79},{0,77},{0,80},{0,72}}))
        r[89] = r[88]
        r[89]()
        r[89] = env["ui"]
        r[89] = r[89][("new_checkbox")]
        r[89] = r[89](("AA"), ("Anti-aimbot angles"), ("Custom Indicator"))
        r[90] = env["ui"]
        r[90] = r[90]["new_label"]
        r[90] = r[90](("AA"), ("Anti-aimbot angles"), ("Background color 1"))
        r[91] = env["ui"]
        r[91] = r[91]["new_color_picker"]
        r[91] = r[91](("AA"), ("Anti-aimbot angles"), ("Main Backround picker 1 [indicator]"), (0), (170), (255), (150))
        r[92] = env["ui"]
        r[92] = r[92]["new_label"]
        r[92] = r[92](("AA"), ("Anti-aimbot angles"), ("Background color 2"))
        r[93] = env["ui"]
        r[93] = r[93]["new_color_picker"]
        r[93] = r[93](("AA"), ("Anti-aimbot angles"), ("Main Backround picker 2 [indicator]"), (255), (150), (150), (150))
        r[94] = env["ui"]
        r[94] = r[94]["new_label"]
        r[94] = r[94](("AA"), ("Anti-aimbot angles"), ("Accent color 1"))
        r[95] = env["ui"]
        r[95] = r[95]["new_color_picker"]
        r[95] = r[95](("AA"), ("Anti-aimbot angles"), ("Accent Backround picker 1 [indicator]"), (0), (170), (255), (255))
        r[96] = env["ui"]
        r[96] = r[96]["new_label"]
        r[96] = r[96](("AA"), ("Anti-aimbot angles"), ("Accent color 2"))
        r[97] = env["ui"]
        r[97] = r[97]["new_color_picker"]
        r[97] = r[97](("AA"), ("Anti-aimbot angles"), ("Accent Backround picker 2 [indicator]"), (255), (150), (150), (255))
        r[98] = env["ui"]
        r[98] = r[98][("new_slider")]
        r[98] = r[98](("AA"), ("Anti-aimbot angles"), ("Saved position x"), (0), (1920), (10))
        r[99] = env["ui"]
        r[99] = r[99][("new_slider")]
        r[99] = r[99](("AA"), ("Anti-aimbot angles"), ("Saved position y"), (0), (1080), (400))
        r[100] = env["ui"]
        r[100] = r[100]["new_hotkey"]
        r[100] = r[100](("LUA"), ("B"), ("Mouse 1"))
        r[101] = env["ui"]
        r[101] = r[101]["reference"]
        r[101], r[102] = r[101](("AA"), ("Other"), ("On shot anti-aim"))
        r[103] = env["ui"]
        r[103] = r[103]["reference"]
        r[103] = r[103](("RAGE"), ("Aimbot"), ("Force safe point"))
        r[104] = env["ui"]
        r[104] = r[104]["reference"]
        r[104], r[105] = r[104](("RAGE"), ("Other"), ("Double tap"))
        r[106] = env["ui"]
        r[106] = r[106]["reference"]
        r[106] = r[106](("RAGE"), ("Other"), ("Force body aim"))
        r[107] = env["ui"]
        r[107] = r[107]["reference"]
        r[107] = r[107](("RAGE"), ("Other"), ("Duck peek assist"))
        r[108] = make_table(256)
        r[109] = "x"
        r[108][r[109]] = (150)
        r[109] = "y"
        r[108][r[109]] = (100)
        r[109] = 0
        r[110] = functions[35](env,capture_upvalues(r,up,{{0,100}}))
        r[111] = env["client"]
        r[111] = r[111]["set_event_callback"]
        r[113] = functions[36](env,capture_upvalues(r,up,{{0,109}}))
        r[111](("setup_command"), r[113])
        r[111] = 0
        r[112] = 0
        r[113] = 255
        r[114] = 1
        r[115] = false
        r[116] = env["client"]
        r[116] = r[116]["set_event_callback"]
        r[118] = functions[37](env,capture_upvalues(r,up,{{0,89},{0,91},{0,93},{0,95},{0,97},{0,110},{0,98},{0,99},{0,108},{0,111},{0,112},{0,113},{0,115},{0,114},{0,109},{0,101},{0,102},{0,103},{0,104},{0,105},{0,106},{0,107}}))
        r[116](("paint"), r[118])
        r[116] = functions[38](env,nil)
        r[117] = env["client"]
        r[117] = r[117]["set_event_callback"]
        r[119] = functions[39](env,capture_upvalues(r,up,{{0,50}}))
        r[117](("aim_fire"), r[119])
        r[117] = env["ui"]
        r[117] = r[117]["reference"]
        r[117] = r[117](("aa"), ("Anti-aimbot angles"), ("Fake yaw limit"))
        r[118] = env["client"]
        r[118] = r[118]["set_event_callback"]
        r[120] = functions[40](env,capture_upvalues(r,up,{{0,117}}))
        r[118](("setup_command"), r[120])
        do return end
    end
end

-- Function 1; 0 parameters; literal propagation follows the recovered CFG.
functions[1] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        top=1+vararg_count-1
        for index=0,vararg_count do r[1+index]=varargs[index] end
        do return unpack_values(r,1,top) end
    end
end

-- Function 2; 1 parameters; literal propagation follows the recovered CFG.
functions[2] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        if r[0] ~= nil then
            goto L3
        end
        r[0] = true
        ::L3::
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["pitch"]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yawbase"]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yaw"]
        r[2] = r[2][1]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yaw"]
        r[2] = r[2][2]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yawjitter"]
        r[2] = r[2][1]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yawjitter"]
        r[2] = r[2][2]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["bodyyaw"]
        r[2] = r[2][1]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["bodyyaw"]
        r[2] = r[2][2]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["fakeyawlimit"]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["fsbodyyaw"]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["edgeyaw"]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["freestand"]
        r[2] = r[2][1]
        r[3] = r[0]
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["freestand"]
        r[2] = r[2][2]
        r[3] = r[0]
        r[1](r[2], r[3])
        do return end
    end
end

-- Function 3; 2 parameters; literal propagation follows the recovered CFG.
functions[3] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        if r[0] ~= nil then
            goto L4
        end
        do return (false) end
        ::L4::
        r[2] = up[0]
        r[3] = r[0]
        r[2] = r[2](r[3])
        if r[2] ~= "number" then
            goto L12
        end
        r[2] = up[1]
        r[3] = r[0]
        r[2] = r[2](r[3])
        r[0] = r[2]
        ::L12::
        r[3] = #r[0]
        r[2] = 0 + (0)
        r[3] = 0 + r[3]
        r[4] = 0 + (1)
        if (r[4] > 0 and r[2] > r[3]) or (r[4] <= 0 and r[2] < r[3]) then
            goto L20
        end
        r[5] = r[2]
        ::L16::
        r[6] = r[0][r[5]]
        if r[6] ~= r[1] then
            goto L20
        end
        do return (true) end
        ::L20::
        r[2] = r[2] + r[4]
        if (r[4] > 0 and r[2] <= r[3]) or (r[4] <= 0 and r[2] >= r[3]) then
            r[5] = r[2]
            goto L16
        end
        do return (false) end
    end
end

-- Function 4; 1 parameters; literal propagation follows the recovered CFG.
functions[4] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[2] = r[0]
        r[1], r[2], r[3] = r[1](r[2], (0))
        r[4] = up[1]
        r[5] = r[0]
        r[4], r[5], r[6] = r[4](r[5], ("m_vecOrigin"))
        r[7] = r[4]
        r[8] = r[5]
        r[9] = r[3]
        do return r[7], r[8], r[9] end
    end
end

-- Function 5; 1 parameters; literal propagation follows the recovered CFG.
functions[5] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        ::L1::
        if 180 >= r[0] then
            goto L4
        end
        r[0] = r[0] - 360
        goto L1
        ::L4::
        if r[0] >= -180 then
            goto L7
        end
        r[0] = r[0] + 360
        goto L4
        ::L7::
        do return r[0] end
    end
end

-- Function 6; 4 parameters; literal propagation follows the recovered CFG.
functions[6] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-4
        for index=0,arguments.n-1 do
            if index<4 then r[index]=arguments[index+1] else varargs[index-4]=arguments[index+1] end
        end
        local top=-1
        r[4] = r[1] - r[3]
        r[5] = r[0] - r[2]
        r[6] = up[0]
        r[7] = r[4] / r[5]
        r[6] = r[6](r[7])
        r[7] = up[1]
        r[8] = r[6] * 180
        r[9] = env["math"]
        r[9] = r[9]["pi"]
        r[8] = r[8] / r[9]
        r[7] = r[7](r[8])
        r[6] = r[7]
        if 0 > r[5] then
            goto L18
        end
        r[7] = up[1]
        r[8] = r[6] + 180
        r[7] = r[7](r[8])
        r[6] = r[7]
        ::L18::
        do return r[6] end
    end
end

-- Function 7; 3 parameters; literal propagation follows the recovered CFG.
functions[7] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-3
        for index=0,arguments.n-1 do
            if index<3 then r[index]=arguments[index+1] else varargs[index-3]=arguments[index+1] end
        end
        local top=-1
        if r[2] ~= nil then
            goto L3
        end
        r[2] = false
        ::L3::
        if not r[2] then
            goto L10
        end
        r[3] = make_table(3)
        r[4] = r[1][1]
        r[5] = r[1][2]
        r[6] = r[0][3]
        for index=4,6 do r[3][0+index-3] = r[index] end
        r[1] = r[3]
        ::L10::
        r[3] = r[0][1]
        r[4] = r[1][1]
        r[3] = r[3] - r[4]
        r[4] = r[0][2]
        r[5] = r[1][2]
        r[4] = r[4] - r[5]
        r[3] = r[3] + r[4]
        r[4] = r[0][3]
        r[5] = r[1][3]
        r[4] = r[4] - r[5]
        r[3] = r[3] + r[4]
        if r[3] >= 0 then
            goto L23
        end
        r[3] = r[3] * 0.75
        ::L23::
        do return r[3] end
    end
end

-- Function 8; 2 parameters; literal propagation follows the recovered CFG.
functions[8] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        r[2] = up[0]
        r[3] = r[0]
        r[2], r[3], r[4] = r[2](r[3])
        clear_values(r,5,22)
        r[5] = up[0]
        r[6] = up[1]
        do local values=pack_values(r[6]()); top=6+values.n-1; assign_results(r,6,top,values) end
        r[5], r[6], r[7] = r[5](unpack_values(r,6,top))
        clear_values(r,8,22)
        r[8] = make_table(3)
        r[9] = r[5]
        r[10] = r[6]
        r[11] = r[7]
        for index=9,11 do r[8][0+index-8] = r[index] end
        r[9] = make_table(3)
        r[10] = r[2]
        r[11] = r[3]
        r[12] = r[4]
        for index=10,12 do r[9][0+index-9] = r[index] end
        r[10] = make_table(3)
        r[11] = r[1]["x"]
        r[12] = r[1]["y"]
        r[13] = r[1]["z"]
        for index=11,13 do r[10][0+index-10] = r[index] end
        r[11] = make_table(3)
        r[12] = r[10][1]
        r[13] = r[9][1]
        r[12] = r[12] - r[13]
        r[13] = r[10][2]
        r[14] = r[9][2]
        r[13] = r[13] - r[14]
        r[14] = r[10][3]
        r[15] = r[9][3]
        r[14] = r[14] - r[15]
        for index=12,14 do r[11][0+index-11] = r[index] end
        r[12] = up[2]
        r[13] = r[11][1]
        r[13] = r[13] ^ 2
        r[14] = r[11][2]
        r[14] = r[14] ^ 2
        r[13] = r[13] + r[14]
        r[14] = r[11][3]
        r[14] = r[14] ^ 2
        r[13] = r[13] + r[14]
        r[12] = r[12](r[13])
        clear_values(r,13,22)
        r[13] = make_table(3)
        r[14] = r[11][1]
        r[14] = r[14] / r[12]
        r[15] = r[11][2]
        r[15] = r[15] / r[12]
        r[16] = r[11][3]
        r[16] = r[16] / r[12]
        for index=14,16 do r[13][0+index-13] = r[index] end
        r[14] = make_table(3)
        r[15] = r[8][1]
        r[16] = r[9][1]
        r[15] = r[15] - r[16]
        r[16] = r[8][2]
        r[17] = r[9][2]
        r[16] = r[16] - r[17]
        r[17] = r[8][3]
        r[18] = r[9][3]
        r[17] = r[17] - r[18]
        for index=15,17 do r[14][0+index-14] = r[index] end
        r[15] = r[13][1]
        r[16] = r[14][1]
        r[15] = r[15] * r[16]
        r[16] = r[13][2]
        r[17] = r[14][2]
        r[16] = r[16] * r[17]
        r[15] = r[15] + r[16]
        r[16] = r[13][3]
        r[17] = r[14][3]
        r[16] = r[16] * r[17]
        r[15] = r[15] + r[16]
        r[16] = up[3]
        r[17] = make_table(3)
        r[18] = r[9][1]
        r[19] = r[13][1]
        r[19] = r[15] * r[19]
        r[18] = r[18] + r[19]
        r[19] = r[9][2]
        r[20] = r[13][2]
        r[20] = r[15] * r[20]
        r[19] = r[19] + r[20]
        r[20] = r[9][3]
        r[21] = r[13][3]
        r[21] = r[15] * r[21]
        r[20] = r[20] + r[21]
        for index=18,20 do r[17][0+index-17] = r[index] end
        r[16]["ls"] = r[17]
        r[16] = up[4]
        r[17] = up[3]
        r[17] = r[17]["ls"]
        r[18] = r[8]
        do return r[16](r[17], r[18], (true)) end
    end
end

-- Function 9; 3 parameters; literal propagation follows the recovered CFG.
functions[9] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-3
        for index=0,arguments.n-1 do
            if index<3 then r[index]=arguments[index+1] else varargs[index-3]=arguments[index+1] end
        end
        local top=-1
        r[3] = up[0]
        r[4] = r[0]
        r[3], r[4], r[5] = r[3](r[4])
        r[6] = up[0]
        r[7] = r[1]
        r[6], r[7], r[8] = r[6](r[7])
        r[9] = r[2]["y"]
        r[9] = r[9] - r[4]
        r[9] = r[9] * r[6]
        r[10] = r[2]["x"]
        r[10] = r[10] - r[3]
        r[10] = r[10] * r[7]
        r[9] = r[9] - r[10]
        r[10] = r[2]["x"]
        r[10] = r[10] * r[4]
        r[9] = r[9] + r[10]
        r[10] = r[2]["y"]
        r[10] = r[10] * r[3]
        r[9] = r[9] - r[10]
        r[10] = up[1]
        r[11] = r[2]["y"]
        r[11] = r[11] - r[4]
        r[11] = r[11] ^ 2
        r[12] = r[2]["x"]
        r[12] = r[12] - r[3]
        r[12] = r[12] ^ 2
        r[11] = r[11] + r[12]
        r[10] = r[10](r[11])
        r[9] = r[9] / r[10]
        do return r[9] end
    end
end

-- Function 10; 5 parameters; literal propagation follows the recovered CFG.
functions[10] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-5
        for index=0,arguments.n-1 do
            if index<5 then r[index]=arguments[index+1] else varargs[index-5]=arguments[index+1] end
        end
        local top=-1
        r[5] = make_table(256)
        r[6] = up[0]
        r[7] = r[3]
        do local values=pack_values(r[6](r[7])); top=6+values.n-1; assign_results(r,6,top,values) end
        for index=6,top do r[5][0+index-5] = r[index] end
        r[6] = make_table(256)
        r[7] = up[1]
        r[8] = r[3]
        r[9] = "m_vecOrigin"
        do local values=pack_values(r[7](r[8], ("m_vecOrigin"))); top=7+values.n-1; assign_results(r,7,top,values) end
        for index=7,top do r[6][0+index-6] = r[index] end
        r[7] = r[1][3]
        r[8] = r[5][3]
        r[8] = r[8] + 10
        if r[8] < r[7] then
            goto L19
        end
        r[7] = r[1][3]
        r[8] = r[6][3]
        if r[7] >= r[8] then
            goto L21
        end
        ::L19::
        do return (false) end
        ::L21::
        r[7] = up[2]
        r[8] = up[3]
        r[9] = r[2]
        r[10] = r[3]
        r[11] = r[4]
        do local values=pack_values(r[8](r[9], r[10], r[11])); top=8+values.n-1; assign_results(r,8,top,values) end
        r[7] = r[7](unpack_values(r,8,top))
        if 300 >= r[7] then
            goto L31
        end
        do return (false) end
        ::L31::
        r[7] = up[2]
        r[8] = r[0]
        r[7] = r[7](r[8])
        if r[7] >= 30 then
            goto L37
        end
        do return (true) end
        ::L37::
        r[7] = up[1]
        r[8] = up[4]
        r[8] = r[8]()
        r[10] = r[2]
        r[7] = r[7](r[8], ("m_iPing"), r[10])
        r[8] = up[5]
        r[8] = r[8]()
        r[8] = r[7] * r[8]
        r[8] = 14 - r[8]
        r[9] = up[6]
        r[9] = r[9]["rec"]
        r[9] = #r[9]
        if r[8] > r[9] then
            goto L82
        end
        r[9] = up[6]
        r[9] = r[9]["rec"]
        r[9] = r[9][r[8]]
        if r[9] ~= nil then
            goto L57
        end
        do return (false) end
        ::L57::
        r[10] = up[7]
        r[11] = r[9]
        r[12] = r[5]
        r[10] = r[10](r[11], r[12], (true))
        if r[0] >= 0 then
            goto L64
        end
        if r[10] < r[0] then
            goto L65
        end
        ::L64::
        if r[0] >= r[10] then
            goto L72
        end
        ::L65::
        r[11] = up[2]
        r[12] = r[0]
        r[11] = r[11](r[12])
        r[12] = up[2]
        r[13] = r[10]
        r[12] = r[12](r[13])
        if r[11] < r[12] then
            goto L80
        end
        ::L72::
        r[11] = up[2]
        r[12] = r[0]
        r[11] = r[11](r[12])
        r[12] = up[2]
        r[13] = r[10]
        r[12] = r[12](r[13])
        if r[12] < r[11] then
            goto L80
        end
        r[11] = false
        goto L81
        ::L80::
        r[11] = true
        ::L81::
        do return r[11] end
        ::L82::
        do return (false) end
    end
end

-- Function 11; 1 parameters; literal propagation follows the recovered CFG.
functions[11] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]["desync"]
        if r[1] ~= 0 then
            goto L6
        end
        do return (0) end
        ::L6::
        r[1] = up[1]
        r[2] = r[0]
        r[1] = r[1](r[2], ("m_flPoseParameter"), (11))
        r[1] = r[1] * 120
        r[1] = r[1] - 60
        if r[1] >= 0 then
            goto L16
        end
        r[2] = 90
        if (90) then
            goto L17
        end
        ::L16::
        r[2] = -90
        ::L17::
        do return r[2] end
    end
end

-- Function 12; 1 parameters; literal propagation follows the recovered CFG.
functions[12] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = 0 + (1)
        r[2] = 0 + (64)
        r[3] = 0 + (1)
        if (r[3] > 0 and r[1] > r[2]) or (r[3] <= 0 and r[1] < r[2]) then
            goto L137
        end
        r[4] = r[1]
        ::L5::
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[5] = r[5]["r"]
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["s"]
        r[6] = #r[6]
        if r[5] >= r[6] then
            goto L122
        end
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[5] = r[5]["h"]
        r[5] = #r[5]
        if 0 >= r[5] then
            goto L37
        end
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[5] = r[5]["s"]
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["s"]
        r[6] = #r[6]
        r[5] = r[5][r[6]]
        r[5] = r[5]["t"]
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["h"]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["h"]
        r[7] = #r[7]
        r[6] = r[6][r[7]]
        r[6] = r[6]["t"]
        if r[5] == r[6] then
            goto L38
        end
        ::L37::
        r[5] = false
        goto L39
        ::L38::
        r[5] = true
        ::L39::
        if not r[5] then
            goto L50
        end
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["h"]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["h"]
        r[7] = #r[7]
        r[6] = r[6][r[7]]
        r[6] = r[6]["v"]
        if r[6] ~= r[0] then
            goto L114
        end
        ::L50::
        r[6] = up[0]
        r[6] = r[6][r[4]]
        if not r[5] then
            goto L67
        end
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["h"]
        r[8] = up[0]
        r[8] = r[8][r[4]]
        r[8] = r[8]["h"]
        r[8] = #r[8]
        r[7] = r[7][r[8]]
        r[7] = r[7]["h"]
        if r[7] ~= 1 then
            goto L67
        end
        r[7] = up[1]
        r[8] = r[0]
        r[7] = r[7](r[8])
        if r[7] then
            goto L68
        end
        ::L67::
        r[7] = 0
        ::L68::
        r[6]["l"] = r[7]
        if r[5] then
            goto L84
        end
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["m"]
        r[7] = up[2]
        r[7] = r[7]["Anti-resolver shot amount"]
        if r[6] >= r[7] then
            goto L84
        end
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["m"]
        r[7] = r[7] + 1
        r[6]["m"] = r[7]
        goto L87
        ::L84::
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6]["m"] = 0
        ::L87::
        if not r[5] then
            goto L100
        end
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["s"]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["s"]
        r[7] = #r[7]
        r[6] = r[6][r[7]]
        r[7] = up[1]
        r[8] = r[0]
        r[7] = r[7](r[8])
        r[6]["d"] = r[7]
        ::L100::
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["s"]
        r[8] = up[0]
        r[8] = r[8][r[4]]
        r[8] = r[8]["s"]
        r[8] = #r[8]
        r[7] = r[7][r[8]]
        r[7] = r[7]["d"]
        r[6]["d"] = r[7]
        r[6] = up[3]
        r[6]["target"] = r[4]
        ::L114::
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[7] = up[0]
        r[7] = r[7][r[4]]
        r[7] = r[7]["s"]
        r[7] = #r[7]
        r[6]["r"] = r[7]
        goto L137
        ::L122::
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[5] = r[5]["r"]
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["s"]
        r[6] = #r[6]
        if r[6] >= r[5] then
            goto L137
        end
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[6] = up[0]
        r[6] = r[6][r[4]]
        r[6] = r[6]["s"]
        r[6] = #r[6]
        r[5]["r"] = r[6]
        ::L137::
        r[1] = r[1] + r[3]
        if (r[3] > 0 and r[1] <= r[2]) or (r[3] <= 0 and r[1] >= r[2]) then
            r[4] = r[1]
            goto L5
        end
        do return end
    end
end

-- Function 13; 2 parameters; literal propagation follows the recovered CFG.
functions[13] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        r[2] = up[0]
        r[3] = up[1]
        r[4] = r[1]
        do local values=pack_values(r[3](r[4])); top=3+values.n-1; assign_results(r,3,top,values) end
        r[2] = r[2](unpack_values(r,3,top))
        r[3] = up[2]
        r[4] = up[1]
        r[5] = r[1]
        do local values=pack_values(r[4](r[5])); top=4+values.n-1; assign_results(r,4,top,values) end
        r[3] = r[3](unpack_values(r,4,top))
        r[4] = up[0]
        r[5] = up[1]
        r[6] = r[0]
        do local values=pack_values(r[5](r[6])); top=5+values.n-1; assign_results(r,5,top,values) end
        r[4] = r[4](unpack_values(r,5,top))
        r[5] = up[2]
        r[6] = up[1]
        r[7] = r[0]
        do local values=pack_values(r[6](r[7])); top=6+values.n-1; assign_results(r,6,top,values) end
        r[5] = r[5](unpack_values(r,6,top))
        r[6] = r[5] * r[3]
        r[7] = r[5] * r[2]
        r[8] = -(r[4])
        do return r[6], r[7], r[8] end
    end
end

-- Function 14; 2 parameters; literal propagation follows the recovered CFG.
functions[14] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        r[2] = up[0]
        r[2] = r[2]["holding_e"]
        if not r[2] then
            goto L7
        end
        r[2] = up[0]
        r[2]["aa"] = 5
        do return end
        ::L7::
        r[2] = up[1]
        r[3] = up[2]
        r[3] = r[3]["slow"]
        r[3] = r[3][1]
        r[2] = r[2](r[3])
        if not r[2] then
            goto L18
        end
        r[2] = up[1]
        r[3] = up[2]
        r[3] = r[3]["slow"]
        r[3] = r[3][2]
        r[2] = r[2](r[3])
        ::L18::
        if not r[2] then
            goto L22
        end
        r[3] = up[0]
        r[3]["aa"] = 3
        do return end
        ::L22::
        r[3] = up[3]
        r[4] = up[4]
        r[5] = r[0]
        r[4] = r[4](r[5], ("m_fFlags"))
        r[3] = r[3](r[4], (1))
        if r[3] ~= 1 then
            goto L32
        end
        r[3] = r[1]["in_jump"]
        if r[3] == 0 then
            goto L33
        end
        ::L32::
        r[3] = false
        goto L34
        ::L33::
        r[3] = true
        ::L34::
        if r[3] then
            goto L38
        end
        r[4] = up[0]
        r[4]["aa"] = 4
        do return end
        ::L38::
        r[4] = up[4]
        r[5] = r[0]
        r[4], r[5], r[6] = r[4](r[5], ("m_vecVelocity"))
        r[7] = up[0]
        r[8] = up[5]
        r[9] = r[4] ^ 2
        r[10] = r[5] ^ 2
        r[9] = r[9] + r[10]
        r[8] = r[8](r[9])
        if r[8] >= 2 then
            goto L51
        end
        r[8] = 1
        if (1) then
            goto L52
        end
        ::L51::
        r[8] = 2
        ::L52::
        r[7]["aa"] = r[8]
        do return end
    end
end

-- Function 15; 2 parameters; literal propagation follows the recovered CFG.
functions[15] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        if r[0] ~= 0 then
            goto L5
        end
        if r[1] ~= 0 then
            goto L5
        end
        do return (0) end
        ::L5::
        r[2] = up[0]
        r[3] = up[1]
        r[4] = r[1]
        r[5] = r[0]
        do local values=pack_values(r[3](r[4], r[5])); top=3+values.n-1; assign_results(r,3,top,values) end
        do return r[2](unpack_values(r,3,top)) end
    end
end

-- Function 16; 5 parameters; literal propagation follows the recovered CFG.
functions[16] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-5
        for index=0,arguments.n-1 do
            if index<5 then r[index]=arguments[index+1] else varargs[index-5]=arguments[index+1] end
        end
        local top=-1
        r[5] = make_table(256)
        r[6] = make_table(256)
        r[7] = make_table(256)
        r[8] = up[0]
        r[9] = r[1]
        r[8], r[9], r[10] = r[8](r[9])
        r[7][0] = r[10]
        r[6][0] = r[9]
        r[5][0] = r[8]
        r[8] = r[5][0]
        r[8] = r[8] + 40
        r[9] = r[6][0]
        r[10] = r[7][0]
        r[7][1] = r[10]
        r[6][1] = r[9]
        r[5][1] = r[8]
        r[8] = r[5][0]
        r[9] = r[6][0]
        r[9] = r[9] + 40
        r[10] = r[7][0]
        r[7][2] = r[10]
        r[6][2] = r[9]
        r[5][2] = r[8]
        r[8] = r[5][0]
        r[8] = r[8] - 40
        r[9] = r[6][0]
        r[10] = r[7][0]
        r[7][3] = r[10]
        r[6][3] = r[9]
        r[5][3] = r[8]
        r[8] = r[5][0]
        r[9] = r[6][0]
        r[9] = r[9] - 40
        r[10] = r[7][0]
        r[7][4] = r[10]
        r[6][4] = r[9]
        r[5][4] = r[8]
        r[8] = r[5][0]
        r[9] = r[6][0]
        r[10] = r[7][0]
        r[10] = r[10] + 40
        r[7][5] = r[10]
        r[6][5] = r[9]
        r[5][5] = r[8]
        r[8] = 0
        clear_values(r,9,9)
        r[10] = 0 + (0)
        r[11] = 0 + (5)
        r[12] = 0 + (1)
        if (r[12] > 0 and r[10] > r[11]) or (r[12] <= 0 and r[10] < r[11]) then
            goto L64
        end
        r[13] = r[10]
        ::L51::
        if r[9] == 0 then
            goto L53
        end
        if r[9] ~= nil then
            goto L64
        end
        ::L53::
        r[14] = up[1]
        r[15] = r[1]
        r[16] = r[5][r[13]]
        r[17] = r[6][r[13]]
        r[18] = r[7][r[13]]
        r[19] = r[2]
        r[20] = r[3]
        r[21] = r[4]
        r[14], r[15] = r[14](r[15], r[16], r[17], r[18], r[19], r[20], r[21])
        r[9] = r[15]
        r[8] = r[14]
        ::L64::
        r[10] = r[10] + r[12]
        if (r[12] > 0 and r[10] <= r[11]) or (r[12] <= 0 and r[10] >= r[11]) then
            r[13] = r[10]
            goto L51
        end
        r[10] = up[2]
        r[11] = r[1]
        if r[8] ~= nil then
            goto L75
        end
        r[13] = up[2]
        r[14] = r[1]
        r[16] = r[9]
        r[13] = r[13](r[14], (2), r[16])
        if r[13] then
            goto L76
        end
        ::L75::
        r[13] = r[9]
        ::L76::
        do return r[10](r[11], (1), r[13]) end
    end
end

-- Function 17; 2 parameters; literal propagation follows the recovered CFG.
functions[17] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        r[2] = up[0]
        r[2] = r[2]((true))
        r[3] = #r[2]
        if r[3] ~= 0 then
            goto L8
        end
        do return (0) end
        ::L8::
        r[3] = 0
        r[4] = 180
        r[6] = #r[2]
        r[5] = 0 + (1)
        r[6] = 0 + r[6]
        r[7] = 0 + (1)
        if (r[7] > 0 and r[5] > r[6]) or (r[7] <= 0 and r[5] < r[6]) then
            goto L34
        end
        r[8] = r[5]
        ::L14::
        r[9] = up[1]
        r[10] = r[2][r[8]]
        r[9], r[10], r[11] = r[9](r[10], ("m_vecOrigin"))
        r[12] = up[2]
        r[13] = up[3]
        r[14] = up[4]
        r[15] = r[0][1]
        r[15] = r[15] - r[9]
        r[16] = r[0][2]
        r[16] = r[16] - r[10]
        r[14] = r[14](r[15], r[16])
        clear_values(r,15,17)
        r[15] = r[1][2]
        r[14] = r[14] - r[15]
        r[14] = r[14] + 180
        do local values=pack_values(r[13](r[14])); top=13+values.n-1; assign_results(r,13,top,values) end
        r[12] = r[12](unpack_values(r,13,top))
        if r[12] >= r[4] then
            goto L34
        end
        r[4] = r[12]
        r[3] = r[2][r[8]]
        ::L34::
        r[5] = r[5] + r[7]
        if (r[7] > 0 and r[5] <= r[6]) or (r[7] <= 0 and r[5] >= r[6]) then
            r[8] = r[5]
            goto L14
        end
        do return r[3] end
    end
end

-- Function 18; 1 parameters; literal propagation follows the recovered CFG.
functions[18] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        if r[0] ~= 0 then
            goto L4
        end
        do return (false) end
        ::L4::
        r[1] = up[0]
        r[2] = r[0]
        r[1] = r[1](r[2])
        if r[1] then
            goto L10
        end
        do return (false) end
        ::L10::
        r[1] = up[1]
        r[2] = r[0]
        r[1] = r[1](r[2])
        if not r[1] then
            goto L16
        end
        do return (false) end
        ::L16::
        do return (true) end
    end
end

-- Function 19; 1 parameters; literal propagation follows the recovered CFG.
functions[19] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]()
        r[2] = make_table(256)
        r[3] = up[1]
        r[4] = r[1]
        do local values=pack_values(r[3](r[4])); top=3+values.n-1; assign_results(r,3,top,values) end
        for index=3,top do r[2][0+index-2] = r[index] end
        r[3] = make_table(256)
        r[4] = up[2]
        do local values=pack_values(r[4]()); top=4+values.n-1; assign_results(r,4,top,values) end
        for index=4,top do r[3][0+index-3] = r[index] end
        r[4] = up[3]
        r[5] = up[4]
        r[6] = up[3]
        r[6] = r[6]["target"]
        r[5] = r[5](r[6])
        clear_values(r,6,29)
        if not r[5] then
            goto L21
        end
        r[5] = up[3]
        r[5] = r[5]["target"]
        if r[5] then
            goto L25
        end
        ::L21::
        r[5] = up[5]
        r[6] = r[2]
        r[7] = r[3]
        r[5] = r[5](r[6], r[7])
        clear_values(r,6,29)
        ::L25::
        r[4]["target"] = r[5]
        r[4] = up[3]
        r[4] = r[4]["target"]
        if r[4] == 0 then
            goto L239
        end
        r[4] = up[6]
        r[5] = up[3]
        r[5] = r[5]["target"]
        r[4] = r[4][r[5]]
        r[4] = r[4]["d"]
        if r[4] ~= 0 then
            goto L208
        end
        r[4] = up[6]
        r[5] = up[3]
        r[5] = r[5]["target"]
        r[4] = r[4][r[5]]
        r[4] = r[4]["l"]
        if r[4] == 0 then
            goto L49
        end
        r[4] = up[3]
        r[5] = up[6]
        r[6] = up[3]
        r[6] = r[6]["target"]
        r[5] = r[5][r[6]]
        r[5] = r[5]["l"]
        r[4]["desync"] = r[5]
        goto L281
        ::L49::
        r[4] = up[7]
        r[4] = r[4]["b"]
        r[5] = up[3]
        r[5] = r[5]["s_i"]
        r[6] = up[3]
        r[6] = r[6]["aa"]
        r[5] = r[5][r[6]]
        r[4] = r[4][r[5]]
        if r[4] ~= "Off" then
            goto L61
        end
        r[4] = up[3]
        r[4]["desync"] = 0
        goto L281
        ::L61::
        r[4] = up[7]
        r[4] = r[4]["b"]
        r[5] = up[3]
        r[5] = r[5]["s_i"]
        r[6] = up[3]
        r[6] = r[6]["aa"]
        r[5] = r[5][r[6]]
        r[4] = r[4][r[5]]
        if r[4] ~= "Jitter" then
            goto L73
        end
        r[4] = up[3]
        r[4]["desync"] = 180
        goto L281
        ::L73::
        r[4] = up[3]
        r[4] = r[4]["desync"]
        if r[4] == 0 then
            goto L79
        end
        r[4] = up[3]
        r[4] = r[4]["desync"]
        if r[4] ~= 180 then
            goto L81
        end
        ::L79::
        r[4] = up[3]
        r[4]["desync"] = 90
        ::L81::
        r[4] = make_table(256)
        r[5] = up[1]
        r[6] = up[3]
        r[6] = r[6]["target"]
        do local values=pack_values(r[5](r[6])); top=5+values.n-1; assign_results(r,5,top,values) end
        for index=5,top do r[4][0+index-4] = r[index] end
        r[5] = up[8]
        r[6] = r[2][1]
        r[7] = r[2][2]
        r[8] = r[4][1]
        r[9] = r[4][2]
        r[5] = r[5](r[6], r[7], r[8], r[9])
        r[6] = up[9]
        r[8] = r[5] - 90
        r[6], r[7], r[8] = r[6]((0), r[8])
        r[9] = r[2][1]
        r[10] = r[6] * 10
        r[9] = r[9] + r[10]
        r[10] = r[2][2]
        r[11] = r[7] * 10
        r[10] = r[10] + r[11]
        r[11] = up[9]
        r[13] = r[5] + 90
        r[11], r[12], r[13] = r[11]((0), r[13])
        r[14] = r[2][1]
        r[15] = r[11] * 10
        r[14] = r[14] + r[15]
        r[15] = r[2][2]
        r[16] = r[12] * 10
        r[15] = r[15] + r[16]
        r[16] = r[2][1]
        r[17] = r[6] * 80
        r[16] = r[16] + r[17]
        r[17] = r[2][2]
        r[18] = r[7] * 80
        r[17] = r[17] + r[18]
        r[18] = r[2][1]
        r[19] = r[11] * 80
        r[18] = r[18] + r[19]
        r[19] = r[2][2]
        r[20] = r[12] * 80
        r[19] = r[19] + r[20]
        r[20] = up[10]
        r[21] = r[1]
        r[22] = up[3]
        r[22] = r[22]["target"]
        r[23] = r[9]
        r[24] = r[10]
        r[25] = r[2][3]
        r[20] = r[20](r[21], r[22], r[23], r[24], r[25])
        r[21] = up[10]
        r[22] = r[1]
        r[23] = up[3]
        r[23] = r[23]["target"]
        r[24] = r[14]
        r[25] = r[15]
        r[26] = r[2][3]
        r[21] = r[21](r[22], r[23], r[24], r[25], r[26])
        r[22] = up[10]
        r[23] = r[1]
        r[24] = up[3]
        r[24] = r[24]["target"]
        r[25] = r[16]
        r[26] = r[17]
        r[27] = r[2][3]
        r[22] = r[22](r[23], r[24], r[25], r[26], r[27])
        r[23] = up[10]
        r[24] = r[1]
        r[25] = up[3]
        r[25] = r[25]["target"]
        r[26] = r[18]
        r[27] = r[19]
        r[28] = r[2][3]
        r[23] = r[23](r[24], r[25], r[26], r[27], r[28])
        r[24] = ""
        if r[20] >= r[21] then
            goto L161
        end
        r[24] = "left"
        goto L176
        ::L161::
        if r[21] >= r[20] then
            goto L164
        end
        r[24] = "right"
        goto L176
        ::L164::
        if r[22] >= r[23] then
            goto L167
        end
        r[24] = "left"
        goto L176
        ::L167::
        if r[23] >= r[22] then
            goto L170
        end
        r[24] = "right"
        goto L176
        ::L170::
        r[25] = up[3]
        r[25] = r[25]["holding_e"]
        if r[25] then
            goto L176
        end
        r[25] = up[3]
        r[25]["desync"] = 180
        do return end
        ::L176::
        if r[24] ~= "left" then
            goto L192
        end
        r[25] = up[3]
        r[26] = up[7]
        r[26] = r[26]["b"]
        r[27] = up[3]
        r[27] = r[27]["s_i"]
        r[28] = up[3]
        r[28] = r[28]["aa"]
        r[27] = r[27][r[28]]
        r[26] = r[26][r[27]]
        if r[26] ~= "Freestanding" then
            goto L189
        end
        r[26] = -90
        if (-90) then
            goto L190
        end
        ::L189::
        r[26] = 90
        ::L190::
        r[25]["desync"] = r[26]
        goto L281
        ::L192::
        if r[24] ~= "right" then
            goto L281
        end
        r[25] = up[3]
        r[26] = up[7]
        r[26] = r[26]["b"]
        r[27] = up[3]
        r[27] = r[27]["s_i"]
        r[28] = up[3]
        r[28] = r[28]["aa"]
        r[27] = r[27][r[28]]
        r[26] = r[26][r[27]]
        if r[26] ~= "Freestanding" then
            goto L205
        end
        r[26] = 90
        if (90) then
            goto L206
        end
        ::L205::
        r[26] = -90
        ::L206::
        r[25]["desync"] = r[26]
        goto L281
        ::L208::
        r[4] = up[6]
        r[5] = up[3]
        r[5] = r[5]["target"]
        r[4] = r[4][r[5]]
        r[4] = r[4]["m"]
        r[5] = up[7]
        r[5] = r[5]["Anti-resolver shot amount"]
        if r[4] ~= r[5] then
            goto L231
        end
        r[4] = up[7]
        r[4] = r[4]["Anti-resolver on X shot"]
        if r[4] == "-" then
            goto L231
        end
        r[4] = up[7]
        r[4] = r[4]["Anti-resolver on X shot"]
        if r[4] ~= "None" then
            goto L225
        end
        r[4] = up[3]
        r[4]["desync"] = 0
        goto L281
        ::L225::
        r[4] = up[7]
        r[4] = r[4]["Anti-resolver on X shot"]
        if r[4] ~= "Jitter" then
            goto L281
        end
        r[4] = up[3]
        r[4]["desync"] = 180
        goto L281
        ::L231::
        r[4] = up[3]
        r[5] = up[6]
        r[6] = up[3]
        r[6] = r[6]["target"]
        r[5] = r[5][r[6]]
        r[5] = r[5]["d"]
        r[4]["desync"] = r[5]
        goto L281
        ::L239::
        r[4] = up[7]
        r[4] = r[4]["b"]
        r[5] = up[3]
        r[5] = r[5]["s_i"]
        r[6] = up[3]
        r[6] = r[6]["aa"]
        r[5] = r[5][r[6]]
        r[4] = r[4][r[5]]
        if r[4] ~= "Off" then
            goto L251
        end
        r[4] = up[3]
        r[4]["desync"] = 0
        goto L281
        ::L251::
        r[4] = up[7]
        r[4] = r[4]["b"]
        r[5] = up[3]
        r[5] = r[5]["s_i"]
        r[6] = up[3]
        r[6] = r[6]["aa"]
        r[5] = r[5][r[6]]
        r[4] = r[4][r[5]]
        if r[4] ~= "Jitter" then
            goto L263
        end
        r[4] = up[3]
        r[4]["desync"] = 180
        goto L281
        ::L263::
        r[4] = up[3]
        r[4] = r[4]["holding_e"]
        if not r[4] then
            goto L279
        end
        r[4] = up[3]
        r[5] = up[3]
        r[5] = r[5]["desync"]
        if r[5] == 0 then
            goto L273
        end
        r[5] = up[3]
        r[5] = r[5]["desync"]
        if r[5] ~= 180 then
            goto L275
        end
        ::L273::
        r[5] = 90
        if (90) then
            goto L277
        end
        ::L275::
        r[5] = up[3]
        r[5] = r[5]["desync"]
        ::L277::
        r[4]["desync"] = r[5]
        goto L281
        ::L279::
        r[4] = up[3]
        r[4]["desync"] = 180
        ::L281::
        do return end
    end
end

-- Function 20; 1 parameters; literal propagation follows the recovered CFG.
functions[20] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        if r[0] ~= nil then
            goto L3
        end
        r[0] = false
        ::L3::
        r[1] = 0 + (1)
        r[2] = 0 + (64)
        r[3] = 0 + (1)
        if (r[3] > 0 and r[1] > r[2]) or (r[3] <= 0 and r[1] < r[2]) then
            goto L24
        end
        r[4] = r[1]
        ::L7::
        r[5] = up[0]
        r[5] = r[5][r[4]]
        r[5] = r[5]["d"]
        r[6] = up[0]
        r[7] = make_table(256)
        r[8] = make_table(256)
        r[7]["s"] = r[8]
        r[8] = make_table(256)
        r[7]["h"] = r[8]
        r[7]["r"] = 0
        r[7]["d"] = 0
        r[7]["m"] = 0
        if not r[0] then
            goto L21
        end
        if r[5] then
            r[8] = r[5]
            goto L22
        end
        ::L21::
        r[8] = 0
        ::L22::
        r[7]["l"] = r[8]
        r[6][r[4]] = r[7]
        ::L24::
        r[1] = r[1] + r[3]
        if (r[3] > 0 and r[1] <= r[2]) or (r[3] <= 0 and r[1] >= r[2]) then
            r[4] = r[1]
            goto L7
        end
        do return end
    end
end

-- Function 21; 2 parameters; literal propagation follows the recovered CFG.
functions[21] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-2
        for index=0,arguments.n-1 do
            if index<2 then r[index]=arguments[index+1] else varargs[index-2]=arguments[index+1] end
        end
        local top=-1
        r[2] = up[0]
        r[2] = r[2]((69))
        if not r[2] then
            goto L105
        end
        r[2] = 100
        r[3] = up[1]
        r[3] = r[3](("CPlantedC4"))
        clear_values(r,4,25)
        r[3] = r[3][1]
        if r[3] == nil then
            goto L31
        end
        r[4] = make_table(256)
        r[5] = up[2]
        r[6] = r[3]
        r[7] = "m_vecOrigin"
        do local values=pack_values(r[5](r[6], ("m_vecOrigin"))); top=5+values.n-1; assign_results(r,5,top,values) end
        for index=5,top do r[4][0+index-4] = r[index] end
        if r[4] == nil then
            goto L31
        end
        r[5] = make_table(256)
        r[6] = up[2]
        r[7] = r[0]
        r[8] = "m_vecOrigin"
        do local values=pack_values(r[6](r[7], ("m_vecOrigin"))); top=6+values.n-1; assign_results(r,6,top,values) end
        for index=6,top do r[5][0+index-5] = r[index] end
        r[6] = up[3]
        r[7] = up[4]
        r[8] = r[5]
        r[9] = r[4]
        do local values=pack_values(r[7](r[8], r[9])); top=7+values.n-1; assign_results(r,7,top,values) end
        r[6] = r[6](unpack_values(r,7,top))
        r[2] = r[6]
        ::L31::
        r[4] = up[2]
        r[5] = r[0]
        r[4] = r[4](r[5], ("m_iTeamNum"))
        if r[4] ~= 3 then
            goto L37
        end
        if r[2] < 62 then
            goto L38
        end
        ::L37::
        r[5] = false
        goto L39
        ::L38::
        r[5] = true
        ::L39::
        r[6] = up[5]
        r[6], r[7], r[8] = r[6]()
        r[9] = up[6]
        r[9], r[10] = r[9]()
        clear_values(r,11,25)
        r[11] = up[7]
        r[12] = up[8]
        r[13] = r[9]
        do local values=pack_values(r[12](r[13])); top=12+values.n-1; assign_results(r,12,top,values) end
        r[11] = r[11](unpack_values(r,12,top))
        r[12] = up[9]
        r[13] = up[8]
        r[14] = r[9]
        do local values=pack_values(r[13](r[14])); top=13+values.n-1; assign_results(r,13,top,values) end
        r[12] = r[12](unpack_values(r,13,top))
        r[13] = up[7]
        r[14] = up[8]
        r[15] = r[10]
        do local values=pack_values(r[14](r[15])); top=14+values.n-1; assign_results(r,14,top,values) end
        r[13] = r[13](unpack_values(r,14,top))
        r[14] = up[9]
        r[15] = up[8]
        r[16] = r[10]
        do local values=pack_values(r[15](r[16])); top=15+values.n-1; assign_results(r,15,top,values) end
        r[14] = r[14](unpack_values(r,15,top))
        r[15] = make_table(3)
        r[16] = r[12] * r[14]
        r[17] = r[12] * r[13]
        r[18] = -(r[11])
        for index=16,18 do r[15][0+index-15] = r[index] end
        r[16] = up[10]
        r[17] = r[0]
        r[18] = r[6]
        r[19] = r[7]
        r[20] = r[8]
        r[21] = r[15][1]
        r[21] = r[21] * 8192
        r[21] = r[6] + r[21]
        r[22] = r[15][2]
        r[22] = r[22] * 8192
        r[22] = r[7] + r[22]
        r[23] = r[15][3]
        r[23] = r[23] * 8192
        r[23] = r[8] + r[23]
        r[16], r[17] = r[16](r[17], r[18], r[19], r[20], r[21], r[22], r[23])
        r[18] = true
        if r[17] == nil then
            goto L100
        end
        r[20] = up[11]
        r[20] = r[20]["classnames"]
        r[20] = #r[20]
        r[19] = 0 + (0)
        r[20] = 0 + r[20]
        r[21] = 0 + (1)
        if (r[21] > 0 and r[19] > r[20]) or (r[21] <= 0 and r[19] < r[20]) then
            goto L99
        end
        r[22] = r[19]
        ::L91::
        r[23] = up[12]
        r[24] = r[17]
        r[23] = r[23](r[24])
        r[24] = up[11]
        r[24] = r[24]["classnames"]
        r[24] = r[24][r[22]]
        if r[23] ~= r[24] then
            goto L99
        end
        r[18] = false
        ::L99::
        r[19] = r[19] + r[21]
        if (r[21] > 0 and r[19] <= r[20]) or (r[21] <= 0 and r[19] >= r[20]) then
            r[22] = r[19]
            goto L91
        end
        ::L100::
        if r[18] then
            goto L103
        end
        if r[5] then
            goto L103
        end
        r[1]["in_use"] = 0
        ::L103::
        do return (true) end
        ::L105::
        do return (false) end
    end
end

-- Function 22; 1 parameters; literal propagation follows the recovered CFG.
functions[22] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yaw"]
        r[2] = r[2][1]
        r[3] = up[2]
        r[3] = r[3]["holding_e"]
        if not r[3] then
            goto L10
        end
        r[3] = "Off"
        if ("Off") then
            goto L11
        end
        ::L10::
        r[3] = "180"
        ::L11::
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["pitch"]
        r[3] = up[2]
        r[3] = r[3]["holding_e"]
        if not r[3] then
            goto L20
        end
        r[3] = "Off"
        if ("Off") then
            goto L21
        end
        ::L20::
        r[3] = "Default"
        ::L21::
        r[1](r[2], r[3])
        r[1] = up[3]
        r[2] = up[4]
        r[2] = r[2]["s"]
        r[1] = r[1](r[2], ("Manual AA"))
        if not r[1] then
            goto L152
        end
        r[1] = up[5]
        r[2] = up[4]
        r[2] = r[2]["ml"]
        r[1] = r[1](r[2])
        if not r[1] then
            goto L56
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["time"]
        r[1] = r[1] + 0.2
        r[2] = up[6]
        r[2] = r[2]()
        if r[1] >= r[2] then
            goto L56
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["manual"]
        if r[2] ~= -90 then
            goto L48
        end
        r[2] = 0
        if (0) then
            goto L49
        end
        ::L48::
        r[2] = -90
        ::L49::
        r[1]["manual"] = r[2]
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[6]
        r[2] = r[2]()
        r[1]["time"] = r[2]
        goto L123
        ::L56::
        r[1] = up[5]
        r[2] = up[4]
        r[2] = r[2]["mr"]
        r[1] = r[1](r[2])
        if not r[1] then
            goto L84
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["time"]
        r[1] = r[1] + 0.2
        r[2] = up[6]
        r[2] = r[2]()
        if r[1] >= r[2] then
            goto L84
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["manual"]
        if r[2] ~= 90 then
            goto L76
        end
        r[2] = 0
        if (0) then
            goto L77
        end
        ::L76::
        r[2] = 90
        ::L77::
        r[1]["manual"] = r[2]
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[6]
        r[2] = r[2]()
        r[1]["time"] = r[2]
        goto L123
        ::L84::
        r[1] = up[5]
        r[2] = up[4]
        r[2] = r[2]["mf"]
        r[1] = r[1](r[2])
        if not r[1] then
            goto L112
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["time"]
        r[1] = r[1] + 0.2
        r[2] = up[6]
        r[2] = r[2]()
        if r[1] >= r[2] then
            goto L112
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["manual"]
        if r[2] ~= 180 then
            goto L104
        end
        r[2] = 0
        if (0) then
            goto L105
        end
        ::L104::
        r[2] = 180
        ::L105::
        r[1]["manual"] = r[2]
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[6]
        r[2] = r[2]()
        r[1]["time"] = r[2]
        goto L123
        ::L112::
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["time"]
        r[2] = up[6]
        r[2] = r[2]()
        if r[2] >= r[1] then
            goto L123
        end
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[6]
        r[2] = r[2]()
        r[1]["time"] = r[2]
        ::L123::
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["manual"]
        r[2] = up[2]
        r[2] = r[2]["stored_dir"]
        r[2] = r[2]["manual"]
        if r[1] == r[2] then
            goto L144
        end
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yaw"]
        r[2] = r[2][2]
        r[3] = up[2]
        r[3] = r[3]["dir"]
        r[3] = r[3]["manual"]
        r[1](r[2], r[3])
        r[1] = up[2]
        r[1] = r[1]["stored_dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["manual"]
        r[1]["manual"] = r[2]
        ::L144::
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["yaw"]
        r[2] = r[2][2]
        r[3] = up[2]
        r[3] = r[3]["dir"]
        r[3] = r[3]["manual"]
        r[1](r[2], r[3])
        ::L152::
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[3]
        r[3] = up[4]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Edge yaw"))
        if not r[2] then
            goto L168
        end
        r[2] = up[5]
        r[3] = up[4]
        r[3] = r[3]["ey"]
        r[2] = r[2](r[3])
        if not r[2] then
            goto L168
        end
        r[2] = up[2]
        r[2] = r[2]["holding_e"]
        r[2] = not r[2]
        ::L168::
        r[1]["edge"] = r[2]
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[2] = up[3]
        r[3] = up[4]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Freestanding"))
        if not r[2] then
            goto L185
        end
        r[2] = up[5]
        r[3] = up[4]
        r[3] = r[3]["fs"]
        r[2] = r[2](r[3])
        if not r[2] then
            goto L185
        end
        r[2] = up[2]
        r[2] = r[2]["holding_e"]
        r[2] = not r[2]
        ::L185::
        r[1]["freestand"] = r[2]
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["freestand"]
        r[2] = up[2]
        r[2] = r[2]["stored_dir"]
        r[2] = r[2]["freestand"]
        if r[1] == r[2] then
            goto L217
        end
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["freestand"]
        r[2] = r[2][1]
        r[3] = up[2]
        r[3] = r[3]["dir"]
        r[3] = r[3]["freestand"]
        if not r[3] then
            goto L203
        end
        r[3] = "Default"
        if ("Default") then
            goto L204
        end
        ::L203::
        r[3] = "-"
        ::L204::
        r[1](r[2], r[3])
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["freestand"]
        r[2] = r[2][2]
        r[1](r[2], ("Always on"))
        r[1] = up[2]
        r[1] = r[1]["stored_dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["freestand"]
        r[1]["freestand"] = r[2]
        ::L217::
        r[1] = up[2]
        r[1] = r[1]["dir"]
        r[1] = r[1]["edge"]
        r[2] = up[2]
        r[2] = r[2]["stored_dir"]
        r[2] = r[2]["edge"]
        if r[1] == r[2] then
            goto L237
        end
        r[1] = up[0]
        r[2] = up[1]
        r[2] = r[2]["edgeyaw"]
        r[3] = up[2]
        r[3] = r[3]["dir"]
        r[3] = r[3]["edge"]
        r[1](r[2], r[3])
        r[1] = up[2]
        r[1] = r[1]["stored_dir"]
        r[2] = up[2]
        r[2] = r[2]["dir"]
        r[2] = r[2]["edge"]
        r[1]["edge"] = r[2]
        ::L237::
        do return end
    end
end

-- Function 23; 4 parameters; literal propagation follows the recovered CFG.
functions[23] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-4
        for index=0,arguments.n-1 do
            if index<4 then r[index]=arguments[index+1] else varargs[index-4]=arguments[index+1] end
        end
        local top=-1
        r[4] = up[0]
        r[5] = up[1]
        r[6] = r[2]
        do local values=pack_values(r[5](r[6])); top=5+values.n-1; assign_results(r,5,top,values) end
        r[4] = r[4](unpack_values(r,5,top))
        r[4] = r[4] * r[3]
        r[4] = r[4] + r[0]
        r[5] = up[2]
        r[6] = up[1]
        r[7] = r[2]
        do local values=pack_values(r[6](r[7])); top=6+values.n-1; assign_results(r,6,top,values) end
        r[5] = r[5](unpack_values(r,6,top))
        r[5] = r[5] * r[3]
        r[5] = r[5] + r[1]
        do return r[4], r[5] end
    end
end

-- Function 24; 13 parameters; literal propagation follows the recovered CFG.
functions[24] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-13
        for index=0,arguments.n-1 do
            if index<13 then r[index]=arguments[index+1] else varargs[index-13]=arguments[index+1] end
        end
        local top=-1
        r[13] = up[0]
        r[14] = r[0]
        r[15] = r[1] + 4
        r[16] = r[10]
        r[13], r[14] = r[13](r[14], r[15], r[16], (45))
        r[15] = up[0]
        r[16] = r[0]
        r[17] = r[1] + 4
        r[18] = r[11] / 3
        r[18] = r[10] + r[18]
        r[19] = r[11] / 4
        r[19] = 45 - r[19]
        r[15], r[16] = r[15](r[16], r[17], r[18], r[19])
        r[17] = up[0]
        r[18] = r[0]
        r[19] = r[1] + 4
        r[20] = r[10]
        r[21] = r[11] / 5
        r[21] = 45 - r[21]
        r[17], r[18] = r[17](r[18], r[19], r[20], r[21])
        r[19] = up[0]
        r[20] = r[0]
        r[21] = r[1] + 4
        r[22] = r[10]
        r[23] = r[11] / 5
        r[23] = 45 - r[23]
        r[19], r[20] = r[19](r[20], r[21], r[22], r[23])
        r[21] = up[0]
        r[22] = r[0]
        r[23] = r[1] + 4
        r[24] = r[11] / 3
        r[24] = r[10] - r[24]
        r[25] = r[11] / 4
        r[25] = 45 - r[25]
        r[21], r[22] = r[21](r[22], r[23], r[24], r[25])
        r[23] = up[1]
        r[24] = r[13]
        r[25] = r[14]
        r[26] = r[15]
        r[27] = r[16]
        r[28] = r[17]
        r[29] = r[18]
        if not r[12] then
            goto L46
        end
        if r[6] then
            r[30] = r[6]
            goto L47
        end
        ::L46::
        r[30] = r[2]
        ::L47::
        if not r[12] then
            goto L49
        end
        if r[7] then
            r[31] = r[7]
            goto L50
        end
        ::L49::
        r[31] = r[3]
        ::L50::
        if not r[12] then
            goto L52
        end
        if r[8] then
            r[32] = r[8]
            goto L53
        end
        ::L52::
        r[32] = r[4]
        ::L53::
        if not r[12] then
            goto L55
        end
        if r[9] then
            r[33] = r[9]
            goto L56
        end
        ::L55::
        r[33] = r[5]
        ::L56::
        r[23](r[24], r[25], r[26], r[27], r[28], r[29], r[30], r[31], r[32], r[33])
        r[23] = up[1]
        r[24] = r[13]
        r[25] = r[14]
        r[26] = r[19]
        r[27] = r[20]
        r[28] = r[21]
        r[29] = r[22]
        if not r[12] then
            goto L66
        end
        if r[2] then
            r[30] = r[2]
            goto L67
        end
        ::L66::
        r[30] = r[6]
        ::L67::
        if not r[12] then
            goto L69
        end
        if r[3] then
            r[31] = r[3]
            goto L70
        end
        ::L69::
        r[31] = r[7]
        ::L70::
        if not r[12] then
            goto L72
        end
        if r[4] then
            r[32] = r[4]
            goto L73
        end
        ::L72::
        r[32] = r[8]
        ::L73::
        if not r[12] then
            goto L75
        end
        if r[5] then
            r[33] = r[5]
            goto L76
        end
        ::L75::
        r[33] = r[9]
        ::L76::
        r[23](r[24], r[25], r[26], r[27], r[28], r[29], r[30], r[31], r[32], r[33])
        r[23] = up[2]
        r[24] = r[13]
        r[25] = r[14]
        r[26] = r[19]
        r[27] = r[20]
        r[23](r[24], r[25], r[26], r[27], (0), (0), (0), (200))
        do return end
    end
end

-- Function 25; 1 parameters; literal propagation follows the recovered CFG.
functions[25] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]()
        r[2] = up[1]
        r[2] = r[2]["rec"]
        r[3] = up[1]
        r[3] = r[3]["rec"]
        r[3] = #r[3]
        r[3] = r[3] + 1
        r[4] = make_table(256)
        r[5] = up[2]
        r[6] = r[1]
        do local values=pack_values(r[5](r[6])); top=5+values.n-1; assign_results(r,5,top,values) end
        for index=5,top do r[4][0+index-4] = r[index] end
        r[2][r[3]] = r[4]
        r[2] = up[1]
        r[2] = r[2]["rec"]
        r[2] = #r[2]
        if 28 >= r[2] then
            goto L24
        end
        r[2] = up[3]
        r[3] = up[1]
        r[3] = r[3]["rec"]
        r[2](r[3], (1))
        ::L24::
        r[2] = up[4]
        r[3] = r[1]
        r[4] = r[0]
        r[2](r[3], r[4])
        r[2] = up[5]
        r[3] = r[1]
        r[2](r[3])
        r[2] = up[1]
        r[3] = up[6]
        r[4] = r[1]
        r[5] = r[0]
        r[3] = r[3](r[4], r[5])
        r[2]["holding_e"] = r[3]
        r[2] = up[7]
        r[3] = r[1]
        r[4] = up[1]
        r[4] = r[4]["holding_e"]
        r[2](r[3], r[4])
        r[2] = up[8]
        r[3] = up[9]
        r[3] = r[3]["bodyyaw"]
        r[3] = r[3][1]
        r[4] = up[1]
        r[4] = r[4]["desync"]
        if r[4] ~= 0 then
            goto L51
        end
        r[4] = "Off"
        if ("Off") then
            goto L63
        end
        ::L51::
        r[4] = up[1]
        r[4] = r[4]["desync"]
        if r[4] ~= 180 then
            goto L62
        end
        r[4] = up[10]
        r[5] = up[11]
        r[5] = r[5]["s"]
        r[4] = r[4](r[5], ("Jitter when not networked"))
        if not r[4] then
            goto L62
        end
        r[4] = "Jitter"
        if ("Jitter") then
            goto L63
        end
        ::L62::
        r[4] = "Static"
        ::L63::
        r[2](r[3], r[4])
        r[2] = up[8]
        r[3] = up[9]
        r[3] = r[3]["bodyyaw"]
        r[3] = r[3][2]
        r[4] = up[1]
        r[4] = r[4]["desync"]
        if r[4] ~= 180 then
            goto L73
        end
        r[4] = 0
        if (0) then
            goto L82
        end
        ::L73::
        r[4] = up[1]
        r[4] = r[4]["holding_e"]
        if not r[4] then
            goto L80
        end
        r[4] = up[1]
        r[4] = r[4]["desync"]
        r[4] = -(r[4])
        if r[4] then
            goto L82
        end
        ::L80::
        r[4] = up[1]
        r[4] = r[4]["desync"]
        ::L82::
        r[2](r[3], r[4])
        r[2] = up[8]
        r[3] = up[9]
        r[3] = r[3]["fakeyawlimit"]
        r[4] = up[11]
        r[4] = r[4]["r"]
        r[5] = up[1]
        r[5] = r[5]["s_i"]
        r[6] = up[1]
        r[6] = r[6]["aa"]
        r[5] = r[5][r[6]]
        r[4] = r[4][r[5]]
        r[2](r[3], r[4])
        r[2] = up[12]
        r[2]((false))
        do return end
    end
end

-- Function 26; 1 parameters; literal propagation follows the recovered CFG.
functions[26] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]()
        r[2] = up[1]
        r[3] = r[0]["userid"]
        r[2] = r[2](r[3])
        r[3] = up[2]
        r[4] = r[2]
        r[3] = r[3](r[4])
        if not r[3] then
            goto L18
        end
        r[3] = up[3]
        r[4] = r[1]
        r[3] = r[3](r[4])
        if not r[3] then
            goto L18
        end
        r[3] = up[4]
        r[4] = r[2]
        r[3] = r[3](r[4])
        if r[3] then
            goto L19
        end
        ::L18::
        do return end
        ::L19::
        r[3] = up[5]
        r[4] = r[2]
        r[5] = r[0]
        r[3] = r[3](r[4], r[5])
        r[4] = up[6]
        r[5] = r[3]
        r[6] = up[7]
        r[6] = r[6]["ls"]
        r[7] = r[2]
        r[8] = r[1]
        r[9] = r[0]
        r[4] = r[4](r[5], r[6], r[7], r[8], r[9])
        if not r[4] then
            goto L98
        end
        r[4] = up[8]
        r[4] = r[4][r[2]]
        r[4] = r[4]["s"]
        r[4] = #r[4]
        if 0 >= r[4] then
            goto L54
        end
        r[4] = up[8]
        r[4] = r[4][r[2]]
        r[4] = r[4]["s"]
        r[5] = up[8]
        r[5] = r[5][r[2]]
        r[5] = r[5]["s"]
        r[5] = #r[5]
        r[4] = r[4][r[5]]
        r[4] = r[4]["t"]
        r[5] = up[9]
        r[5] = r[5]()
        if r[4] ~= r[5] then
            goto L54
        end
        r[4] = up[8]
        r[4] = r[4][r[2]]
        r[4] = r[4]["s"]
        r[4] = #r[4]
        if r[4] then
            goto L59
        end
        ::L54::
        r[4] = up[8]
        r[4] = r[4][r[2]]
        r[4] = r[4]["s"]
        r[4] = #r[4]
        r[4] = r[4] + 1
        ::L59::
        r[5] = up[7]
        r[5] = r[5]["desync"]
        if r[5] == 0 then
            goto L69
        end
        r[5] = up[7]
        r[5] = r[5]["desync"]
        if r[5] == 180 then
            goto L69
        end
        r[5] = up[10]
        r[5] = r[5]["Detect missed angle"]
        goto L70
        ::L69::
        r[5] = true
        ::L70::
        r[6] = up[7]
        r[6] = r[6]["desync"]
        if r[6] ~= 90 then
            goto L75
        end
        r[6] = -90
        if (-90) then
            goto L76
        end
        ::L75::
        r[6] = 90
        ::L76::
        if not r[5] then
            goto L88
        end
        r[7] = up[11]
        r[8] = r[3]
        r[7] = r[7](r[8])
        if r[7] >= 3 then
            goto L84
        end
        r[7] = up[7]
        r[6] = r[7]["desync"]
        goto L88
        ::L84::
        if 0 >= r[3] then
            goto L87
        end
        if (-90) then
            r[6] = (-90)
            goto L88
        end
        ::L87::
        r[6] = 90
        ::L88::
        r[7] = up[8]
        r[7] = r[7][r[2]]
        r[7] = r[7]["s"]
        r[8] = make_table(256)
        r[9] = up[12]
        r[9] = r[9]()
        r[8]["t"] = r[9]
        r[8]["d"] = r[6]
        r[8]["dis"] = r[3]
        r[7][r[4]] = r[8]
        ::L98::
        do return end
    end
end

-- Function 27; 1 parameters; literal propagation follows the recovered CFG.
functions[27] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]()
        r[2] = up[1]
        r[3] = r[0]["userid"]
        r[2] = r[2](r[3])
        r[3] = up[1]
        r[4] = r[0]["attacker"]
        r[3] = r[3](r[4])
        r[4] = up[2]
        r[5] = r[3]
        r[4] = r[4](r[5])
        if not r[4] then
            goto L17
        end
        r[4] = up[3]
        r[5] = r[1]
        r[4] = r[4](r[5])
        if r[4] then
            goto L18
        end
        ::L17::
        do return end
        ::L18::
        r[5] = up[4]
        r[5] = r[5]["nonweapons"]
        r[5] = #r[5]
        r[4] = 0 + (1)
        r[5] = 0 + r[5]
        r[6] = 0 + (1)
        if (r[6] > 0 and r[4] > r[5]) or (r[6] <= 0 and r[4] < r[5]) then
            goto L30
        end
        r[7] = r[4]
        ::L24::
        r[8] = r[0]["weapon"]
        r[9] = up[4]
        r[9] = r[9]["nonweapons"]
        r[9] = r[9][r[7]]
        if r[8] ~= r[9] then
            goto L30
        end
        do return end
        ::L30::
        r[4] = r[4] + r[6]
        if (r[6] > 0 and r[4] <= r[5]) or (r[6] <= 0 and r[4] >= r[5]) then
            r[7] = r[4]
            goto L24
        end
        r[4] = up[5]
        r[4] = r[4][r[3]]
        r[4] = r[4]["h"]
        r[4] = #r[4]
        if 0 >= r[4] then
            goto L41
        end
        r[4] = up[5]
        r[4] = r[4][r[3]]
        r[4] = r[4]["h"]
        r[4] = #r[4]
        if r[4] then
            goto L46
        end
        ::L41::
        r[4] = up[5]
        r[4] = r[4][r[3]]
        r[4] = r[4]["h"]
        r[4] = #r[4]
        r[4] = r[4] + 1
        ::L46::
        r[5] = up[5]
        r[5] = r[5][r[3]]
        r[5] = r[5]["h"]
        r[6] = make_table(256)
        r[7] = up[6]
        r[7] = r[7]()
        r[6]["t"] = r[7]
        r[7] = env["new_angle"]
        r[6]["d"] = r[7]
        r[7] = r[0]["hitgroup"]
        r[6]["h"] = r[7]
        r[6]["v"] = r[2]
        r[5][r[4]] = r[6]
        do return end
    end
end

-- Function 28; 1 parameters; literal propagation follows the recovered CFG.
functions[28] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = up[0]
        r[1] = r[1]()
        r[2] = up[1]
        r[3] = r[0]["userid"]
        r[2] = r[2](r[3])
        if r[2] ~= r[1] then
            goto L10
        end
        r[3] = up[2]
        r[3]((true))
        ::L10::
        do return end
    end
end

-- Function 29; 0 parameters; literal propagation follows the recovered CFG.
functions[29] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = up[0]
        r[0] = r[0]()
        r[1] = up[1]
        r[2] = r[0]
        r[1](r[2])
        r[1] = up[2]
        r[2] = r[0]
        r[1] = r[1](r[2])
        clear_values(r,2,31)
        if r[1] then
            goto L11
        end
        do return end
        ::L11::
        r[1] = make_table(256)
        r[2] = up[3]
        do local values=pack_values(r[2]()); top=2+values.n-1; assign_results(r,2,top,values) end
        for index=2,top do r[1][0+index-1] = r[index] end
        r[2] = make_table(2)
        r[3] = r[1][1]
        r[3] = r[3] / 2
        r[4] = r[1][2]
        r[4] = r[4] / 2
        for index=3,4 do r[2][0+index-2] = r[index] end
        r[3] = up[4]
        r[4] = up[5]
        r[4] = r[4]["clr"]
        r[4] = r[4][2]
        r[3], r[4], r[5], r[6] = r[3](r[4])
        r[7] = up[4]
        r[8] = up[5]
        r[8] = r[8]["clr2"]
        r[8] = r[8][2]
        r[7], r[8], r[9], r[10] = r[7](r[8])
        r[11] = up[6]
        r[12] = r[0]
        r[11] = r[11](r[12], ("m_flPoseParameter"), (11))
        r[11] = r[11] * 120
        r[11] = r[11] - 60
        r[12] = up[7]
        r[12] = r[12]["holding_e"]
        if not r[12] then
            goto L43
        end
        r[12] = -1
        if (-1) then
            goto L44
        end
        ::L43::
        r[12] = 1
        ::L44::
        r[11] = r[11] * r[12]
        r[12] = 20
        r[13] = up[8]
        r[14] = up[5]
        r[14] = r[14]["s"]
        r[13] = r[13](r[14], ("AA indicator"))
        clear_values(r,14,31)
        if not r[13] then
            goto L101
        end
        r[13] = make_table(256)
        r[14] = up[9]
        do local values=pack_values(r[14]()); top=14+values.n-1; assign_results(r,14,top,values) end
        for index=14,top do r[13][0+index-13] = r[index] end
        r[14] = make_table(256)
        r[15] = up[10]
        r[16] = r[0]
        r[17] = "head_0"
        do local values=pack_values(r[15](r[16], ("head_0"))); top=15+values.n-1; assign_results(r,15,top,values) end
        for index=15,top do r[14][0+index-14] = r[index] end
        r[15] = make_table(256)
        r[16] = up[10]
        r[17] = r[0]
        r[18] = "pelvis"
        do local values=pack_values(r[16](r[17], ("pelvis"))); top=16+values.n-1; assign_results(r,16,top,values) end
        for index=16,top do r[15][0+index-15] = r[index] end
        r[16] = up[11]
        r[17] = up[12]
        r[18] = r[15][1]
        r[19] = r[15][2]
        r[20] = r[14][1]
        r[21] = r[14][2]
        r[17] = r[17](r[18], r[19], r[20], r[21])
        r[18] = r[11] / 2
        r[17] = r[17] - r[18]
        r[18] = r[13][2]
        r[17] = r[17] - r[18]
        r[17] = r[17] + 120
        r[16] = r[16](r[17])
        r[17] = up[13]
        r[18] = r[2][1]
        r[19] = r[2][2]
        r[20] = r[3]
        r[21] = r[4]
        r[22] = r[5]
        r[23] = r[6]
        r[24] = r[7]
        r[25] = r[8]
        r[26] = r[9]
        r[28] = r[11] / 1.5
        r[28] = r[16] + r[28]
        r[28] = r[28] * -1
        if r[11] < 0 then
            goto L98
        end
        r[30] = false
        goto L99
        ::L98::
        r[30] = true
        ::L99::
        r[17](r[18], r[19], r[20], r[21], r[22], r[23], r[24], r[25], r[26], (255), r[28], (60), r[30])
        r[12] = 48
        ::L101::
        r[13] = up[14]
        r[14] = r[2][1]
        r[14] = r[14] - 27
        r[15] = r[2][2]
        r[15] = r[15] + r[12]
        if 0 >= r[11] then
            goto L108
        end
        if r[3] then
            r[16] = r[3]
            goto L109
        end
        ::L108::
        r[16] = r[7]
        ::L109::
        if 0 >= r[11] then
            goto L111
        end
        if r[4] then
            r[17] = r[4]
            goto L112
        end
        ::L111::
        r[17] = r[8]
        ::L112::
        if 0 >= r[11] then
            goto L114
        end
        if r[5] then
            r[18] = r[5]
            goto L115
        end
        ::L114::
        r[18] = r[9]
        ::L115::
        if 0 >= r[11] then
            goto L117
        end
        if r[6] then
            r[19] = r[6]
            goto L118
        end
        ::L117::
        r[19] = 255
        ::L118::
        r[13](r[14], r[15], r[16], r[17], r[18], r[19], ("b"), (0), ("predi"))
        r[13] = up[14]
        r[14] = r[2][1]
        r[15] = r[2][2]
        r[15] = r[15] + r[12]
        if r[11] >= 0 then
            goto L128
        end
        if r[3] then
            r[16] = r[3]
            goto L129
        end
        ::L128::
        r[16] = r[7]
        ::L129::
        if r[11] >= 0 then
            goto L131
        end
        if r[4] then
            r[17] = r[4]
            goto L132
        end
        ::L131::
        r[17] = r[8]
        ::L132::
        if r[11] >= 0 then
            goto L134
        end
        if r[5] then
            r[18] = r[5]
            goto L135
        end
        ::L134::
        r[18] = r[9]
        ::L135::
        if r[11] >= 0 then
            goto L137
        end
        if r[6] then
            r[19] = r[6]
            goto L138
        end
        ::L137::
        r[19] = 255
        ::L138::
        r[13](r[14], r[15], r[16], r[17], r[18], r[19], ("b"), (0), ("ction°"))
        r[13] = up[8]
        r[14] = up[5]
        r[14] = r[14]["s"]
        r[13] = r[13](r[14], ("Keybind indicator"))
        if not r[13] then
            goto L328
        end
        r[13] = make_table(256)
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Double tap"))
        if not r[14] then
            goto L172
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "DT"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["dt"]
        r[17] = r[17][1]
        r[16] = r[16](r[17])
        if not r[16] then
            goto L170
        end
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["dt"]
        r[17] = r[17][2]
        r[16] = r[16](r[17])
        ::L170::
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L172::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Onshot Anti-Aim"))
        if not r[14] then
            goto L195
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "OSAA"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["os"]
        r[17] = r[17][1]
        r[16] = r[16](r[17])
        if not r[16] then
            goto L193
        end
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["os"]
        r[17] = r[17][2]
        r[16] = r[16](r[17])
        ::L193::
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L195::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Force body aim"))
        if not r[14] then
            goto L211
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "BAIM"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["forcebaim"]
        r[16] = r[16](r[17])
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L211::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Force safe point"))
        if not r[14] then
            goto L227
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "SAFE"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["safepoint"]
        r[16] = r[16](r[17])
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L227::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Edge yaw"))
        if not r[14] then
            goto L243
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "EDGE"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["edgeyaw"]
        r[16] = r[16](r[17])
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L243::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Freestanding"))
        if not r[14] then
            goto L267
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "FREESTAND"
        r[16] = up[8]
        r[17] = up[15]
        r[17] = r[17]["freestand"]
        r[17] = r[17][1]
        r[16] = r[16](r[17], ("Default"))
        if not r[16] then
            goto L265
        end
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["freestand"]
        r[17] = r[17][2]
        r[16] = r[16](r[17])
        ::L265::
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L267::
        r[14] = up[8]
        r[15] = up[5]
        r[15] = r[15]["k"]
        r[14] = r[14](r[15], ("Quick peek"))
        if not r[14] then
            goto L290
        end
        r[14] = #r[13]
        r[14] = r[14] + 1
        r[15] = make_table(256)
        r[15]["t"] = "QUICKPEEK"
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["quickpeek"]
        r[17] = r[17][1]
        r[16] = r[16](r[17])
        if not r[16] then
            goto L288
        end
        r[16] = up[4]
        r[17] = up[15]
        r[17] = r[17]["quickpeek"]
        r[17] = r[17][2]
        r[16] = r[16](r[17])
        ::L288::
        r[15]["e"] = r[16]
        r[13][r[14]] = r[15]
        ::L290::
        r[15] = #r[13]
        r[14] = 0 + (1)
        r[15] = 0 + r[15]
        r[16] = 0 + (1)
        if (r[16] > 0 and r[14] > r[15]) or (r[16] <= 0 and r[14] < r[15]) then
            goto L327
        end
        r[17] = r[14]
        ::L294::
        r[18] = up[14]
        r[19] = r[2][1]
        r[19] = r[19] - 1
        r[20] = r[2][2]
        r[20] = r[20] + r[12]
        r[20] = r[20] + 12
        r[21] = r[17] * 11
        r[20] = r[20] + r[21]
        r[21] = r[13][r[17]]
        r[21] = r[21]["e"]
        if not r[21] then
            goto L306
        end
        if r[3] then
            r[21] = r[3]
            goto L307
        end
        ::L306::
        r[21] = r[7]
        ::L307::
        r[22] = r[13][r[17]]
        r[22] = r[22]["e"]
        if not r[22] then
            goto L311
        end
        if r[4] then
            r[22] = r[4]
            goto L312
        end
        ::L311::
        r[22] = r[8]
        ::L312::
        r[23] = r[13][r[17]]
        r[23] = r[23]["e"]
        if not r[23] then
            goto L316
        end
        if r[5] then
            r[23] = r[5]
            goto L317
        end
        ::L316::
        r[23] = r[9]
        ::L317::
        r[24] = r[13][r[17]]
        r[24] = r[24]["e"]
        if not r[24] then
            goto L321
        end
        if r[6] then
            r[24] = r[6]
            goto L322
        end
        ::L321::
        r[24] = r[10] * 0.75
        ::L322::
        r[27] = r[13][r[17]]
        r[27] = r[27]["t"]
        r[18](r[19], r[20], r[21], r[22], r[23], r[24], ("c-"), (0), r[27])
        ::L327::
        r[14] = r[14] + r[16]
        if (r[16] > 0 and r[14] <= r[15]) or (r[16] <= 0 and r[14] >= r[15]) then
            r[17] = r[14]
            goto L294
        end
        ::L328::
        do return end
    end
end

-- Function 30; 0 parameters; literal propagation follows the recovered CFG.
functions[30] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = up[0]
        r[1] = up[1]
        r[1] = r[1]["s"]
        r[0] = r[0](r[1], ("Manual AA"))
        clear_values(r,1,5)
        if r[0] then
            goto L13
        end
        r[0] = up[2]
        r[1] = up[3]
        r[1] = r[1]["yaw"]
        r[1] = r[1][2]
        r[0](r[1], (0))
        clear_values(r,1,5)
        ::L13::
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["ml"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Manual AA"
        do local values=pack_values(r[2](r[3], ("Manual AA"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["mr"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Manual AA"
        do local values=pack_values(r[2](r[3], ("Manual AA"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["mf"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Manual AA"
        do local values=pack_values(r[2](r[3], ("Manual AA"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["fs"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Freestanding"
        do local values=pack_values(r[2](r[3], ("Freestanding"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["ey"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Edge yaw"
        do local values=pack_values(r[2](r[3], ("Edge yaw"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["k"]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[4] = "Keybind indicator"
        do local values=pack_values(r[2](r[3], ("Keybind indicator"))); top=2+values.n-1; assign_results(r,2,top,values) end
        r[0](unpack_values(r,1,top))
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["clr"]
        r[1] = r[1][1]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("AA indicator"))
        if r[2] then
            goto L82
        end
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Keybind indicator"))
        ::L82::
        r[0](r[1], r[2])
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["clr"]
        r[1] = r[1][2]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("AA indicator"))
        if r[2] then
            goto L98
        end
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Keybind indicator"))
        ::L98::
        r[0](r[1], r[2])
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["clr2"]
        r[1] = r[1][1]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("AA indicator"))
        if r[2] then
            goto L114
        end
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Keybind indicator"))
        ::L114::
        r[0](r[1], r[2])
        r[0] = up[4]
        r[1] = up[1]
        r[1] = r[1]["clr2"]
        r[1] = r[1][2]
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("AA indicator"))
        if r[2] then
            goto L130
        end
        r[2] = up[0]
        r[3] = up[1]
        r[3] = r[3]["s"]
        r[2] = r[2](r[3], ("Keybind indicator"))
        ::L130::
        r[0](r[1], r[2])
        r[0] = up[5]
        r[0]((false))
        do return end
    end
end

-- Function 31; 0 parameters; literal propagation follows the recovered CFG.
functions[31] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = env["database"]
        r[0] = r[0]["read"]
        r[1] = up[0]
        r[1] = r[1]["nonweapons"]
        r[1] = r[1][1]
        r[2] = up[0]
        r[2] = r[2]["nonweapons"]
        r[2] = r[2][3]
        r[1] = r[1] .. r[2]
        r[0] = r[0](r[1])
        r[1] = env["panorama"]
        r[1] = r[1]["open"]
        r[1] = r[1]()
        r[2] = r[1]["MyPersonaAPI"]
        if r[0] ~= nil then
            goto L19
        end
        r[3] = r[2]["GetXuid"]
        r[3] = r[3]()
        if r[3] then
            goto L20
        end
        ::L19::
        r[3] = r[0]
        ::L20::
        if r[0] == nil then
            goto L22
        end
        r[4] = false
        goto L23
        ::L22::
        r[4] = true
        ::L23::
        do return r[3], r[4] end
    end
end

-- Function 32; 0 parameters; literal propagation follows the recovered CFG.
functions[32] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = up[0]
        r[1] = env["globals"]
        r[1] = r[1]["curtime"]
        r[1] = r[1]()
        if r[0] >= r[1] then
            goto L36
        end
        r[0] = env["globals"]
        r[0] = r[0]["curtime"]
        r[0] = r[0]()
        r[0] = r[0] + 60
        up[0] = r[0]
        r[0] = up[1]
        r[0], r[1] = r[0]()
        r[2] = env["panorama"]
        r[2] = r[2]["loadstring"]
        r[2] = r[2](("\009\009$.AsyncWebRequest('https://jok3r.cc/64storage.txt', {type: 'GET', complete: function(sigma) {\010\009\009\009response = sigma.responseText;\010\009\009}});\010\009\009return response;\010\009\009"))
        r[3] = r[2]
        r[3] = r[3]()
        if r[3] ~= nil then
            goto L28
        end
        r[4] = env["client"]
        r[4] = r[4]["color_log"]
        do return r[4]((255), (0), (0), ("Loading STEAM IDs, if not loading turn off VPN")) end
        ::L28::
        r[4] = env["string"]
        r[4] = r[4]["match"]
        r[5] = r[3]
        r[6] = r[0]
        r[4] = r[4](r[5], r[6])
        if not r[4] then
            goto L35
        end
        up[2] = r[0]
        ::L35::
        do return r[0] end
        ::L36::
        do return end
    end
end

-- Function 33; 0 parameters; literal propagation follows the recovered CFG.
functions[33] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = up[0]
        r[0] = r[0]()
        r[1] = up[1]
        if r[1] ~= r[0] then
            goto L26
        end
        up[1] = (0)
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[1](("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[1](("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[1](("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[1](("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        up[2] = (true)
        goto L80
        ::L26::
        r[1] = env["client"]
        r[1] = r[1]["set_event_callback"]
        r[3] = functions[34](env,nil)
        r[1](("paint_ui"), r[3])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        r[1] = env["client"]
        r[1] = r[1]["log"]
        r[3] = r[0]
        r[2] = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ") .. r[3]
        r[1](r[2])
        do return end
        ::L80::
        r[1] = up[2]
        if not r[1] then
            goto L125
        end
        r[1] = up[3]
        r[1]()
        r[1] = up[4]
        r[2] = up[5]
        r[2] = r[2]["s"]
        r[3] = up[3]
        r[1](r[2], r[3])
        r[1] = up[6]
        r[3] = up[7]
        r[1](("shutdown"), r[3])
        r[1] = up[6]
        r[3] = up[8]
        r[1](("paint"), r[3])
        r[1] = up[6]
        r[3] = up[9]
        r[1](("bullet_impact"), r[3])
        r[1] = up[6]
        r[3] = up[10]
        r[1](("player_hurt"), r[3])
        r[1] = up[6]
        r[3] = up[11]
        r[1](("setup_command"), r[3])
        r[1] = up[6]
        r[3] = up[12]
        r[1](("player_spawn"), r[3])
        r[1] = up[6]
        r[3] = up[13]
        r[1](("client_disconnect"), r[3])
        r[1] = up[6]
        r[3] = up[13]
        r[1](("cs_game_disconnected"), r[3])
        r[1] = up[6]
        r[3] = up[13]
        r[1](("game_newmap"), r[3])
        ::L125::
        do return end
    end
end

-- Function 34; 0 parameters; literal propagation follows the recovered CFG.
functions[34] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = env["renderer"]
        r[0] = r[0]["indicator"]
        r[0]((255), (0), (0), (255), ("[amgis corporations] prediction not whitelisted on this account - check console"))
        do return end
    end
end

-- Function 35; 4 parameters; literal propagation follows the recovered CFG.
functions[35] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-4
        for index=0,arguments.n-1 do
            if index<4 then r[index]=arguments[index+1] else varargs[index-4]=arguments[index+1] end
        end
        local top=-1
        r[4] = env["ui"]
        r[4] = r[4]["mouse_position"]
        r[4], r[5] = r[4]()
        r[6] = env["ui"]
        r[6] = r[6]["get"]
        r[7] = up[0]
        r[6] = r[6](r[7])
        if not r[6] then
            goto L23
        end
        if r[0] >= r[4] then
            goto L12
        end
        r[6] = r[0] + r[2]
        if r[4] < r[6] then
            goto L13
        end
        ::L12::
        r[6] = false
        goto L14
        ::L13::
        r[6] = true
        ::L14::
        if r[1] >= r[5] then
            goto L17
        end
        r[7] = r[1] + r[3]
        if r[5] < r[7] then
            goto L18
        end
        ::L17::
        r[7] = false
        goto L19
        ::L18::
        r[7] = true
        ::L19::
        if not r[6] then
            goto L23
        end
        if not r[7] then
            goto L23
        end
        do return (true) end
        ::L23::
        do return (false) end
    end
end

-- Function 36; 1 parameters; literal propagation follows the recovered CFG.
functions[36] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = r[0]["chokedcommands"]
        up[0] = r[1]
        do return end
    end
end

-- Function 37; 0 parameters; literal propagation follows the recovered CFG.
functions[37] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = env["ui"]
        r[0] = r[0]["get"]
        r[1] = up[0]
        r[0] = r[0](r[1])
        if r[0] then
            goto L7
        end
        do return end
        ::L7::
        r[0] = env["client"]
        r[0] = r[0]["screen_size"]
        r[0], r[1] = r[0]()
        r[2] = env["ui"]
        r[2] = r[2]["mouse_position"]
        r[2], r[3] = r[2]()
        r[4] = make_table(256)
        r[5] = r[0] / 2
        r[4]["x"] = r[5]
        r[5] = r[1] / 2
        r[4]["y"] = r[5]
        r[5] = env["ui"]
        r[5] = r[5]["get"]
        r[6] = up[1]
        r[5], r[6], r[7], r[8] = r[5](r[6])
        r[9] = env["ui"]
        r[9] = r[9]["get"]
        r[10] = up[2]
        r[9], r[10], r[11], r[12] = r[9](r[10])
        r[13] = env["ui"]
        r[13] = r[13]["get"]
        r[14] = up[3]
        r[13], r[14], r[15], r[16] = r[13](r[14])
        r[17] = env["ui"]
        r[17] = r[17]["get"]
        r[18] = up[4]
        r[17], r[18], r[19], r[20] = r[17](r[18])
        r[21] = up[5]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[6]
        r[22] = r[22](r[23])
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[7]
        r[23] = r[23](r[24])
        r[24] = up[8]
        r[24] = r[24]["x"]
        r[25] = up[8]
        r[25] = r[25]["y"]
        r[21] = r[21](r[22], r[23], r[24], r[25])
        if not r[21] then
            goto L75
        end
        r[21] = env["ui"]
        r[21] = r[21]["get"]
        r[22] = up[6]
        r[21] = r[21](r[22])
        r[22] = up[9]
        r[21] = r[21] - r[22]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[7]
        r[22] = r[22](r[23])
        r[23] = up[10]
        r[22] = r[22] - r[23]
        r[23] = env["ui"]
        r[23] = r[23]["set"]
        r[24] = up[6]
        r[25] = r[2] + r[21]
        r[23](r[24], r[25])
        r[23] = env["ui"]
        r[23] = r[23]["set"]
        r[24] = up[7]
        r[25] = r[3] + r[22]
        r[23](r[24], r[25])
        r[23] = r[2]
        up[10] = r[3]
        up[9] = r[23]
        goto L78
        ::L75::
        r[21] = r[2]
        up[10] = r[3]
        up[9] = r[21]
        ::L78::
        r[21] = up[11]
        if 255 > r[21] then
            goto L83
        end
        up[12] = (true)
        goto L89
        ::L83::
        r[21] = up[11]
        if r[21] > 50 then
            goto L89
        end
        r[21] = up[12]
        if not r[21] then
            goto L89
        end
        up[12] = (false)
        ::L89::
        r[21] = up[12]
        if not r[21] then
            goto L93
        end
        r[21] = -1
        if (-1) then
            goto L94
        end
        ::L93::
        r[21] = 1
        ::L94::
        up[13] = r[21]
        r[21] = up[11]
        r[22] = up[13]
        r[21] = r[21] + r[22]
        up[11] = r[21]
        r[21] = env["renderer"]
        r[21] = r[21]["gradient"]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[6]
        r[22] = r[22](r[23])
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[7]
        r[23] = r[23](r[24])
        r[24] = up[8]
        r[24] = r[24]["x"]
        r[25] = up[8]
        r[25] = r[25]["y"]
        r[26] = r[5]
        r[27] = r[6]
        r[28] = r[7]
        r[29] = r[8]
        r[30] = r[9]
        r[31] = r[10]
        r[32] = r[11]
        r[33] = r[12]
        r[21](r[22], r[23], r[24], r[25], r[26], r[27], r[28], r[29], r[30], r[31], r[32], r[33], (false))
        r[21] = env["renderer"]
        r[21] = r[21]["rectangle"]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[6]
        r[22] = r[22](r[23])
        r[22] = r[22] + 1
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[7]
        r[23] = r[23](r[24])
        r[23] = r[23] + 1
        r[24] = up[8]
        r[24] = r[24]["x"]
        r[24] = r[24] - 2
        r[25] = up[8]
        r[25] = r[25]["y"]
        r[25] = r[25] - 2
        r[21](r[22], r[23], r[24], r[25], (25), (25), (25), (175))
        r[21] = env["renderer"]
        r[21] = r[21]["text"]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[6]
        r[22] = r[22](r[23])
        r[23] = up[8]
        r[23] = r[23]["x"]
        r[23] = r[23] / 2
        r[22] = r[22] + r[23]
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[7]
        r[23] = r[23](r[24])
        r[23] = r[23] + 8
        r[21](r[22], r[23], (255), (255), (255), (255), ("cb"), (0), ("shoppy.gg/@amgis"))
        r[21] = env["renderer"]
        r[21] = r[21]["gradient"]
        r[22] = env["ui"]
        r[22] = r[22]["get"]
        r[23] = up[6]
        r[22] = r[22](r[23])
        r[22] = r[22] + 5
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[7]
        r[23] = r[23](r[24])
        r[23] = r[23] + 18
        r[24] = up[8]
        r[24] = r[24]["x"]
        r[24] = r[24] - 10
        r[26] = r[13]
        r[27] = r[14]
        r[28] = r[15]
        r[29] = r[16]
        r[30] = r[17]
        r[31] = r[18]
        r[32] = r[19]
        r[33] = r[20]
        r[21](r[22], r[23], r[24], (2), r[26], r[27], r[28], r[29], r[30], r[31], r[32], r[33], (true))
        r[21] = env["math"]
        r[21] = r[21]["min"]
        r[23] = up[14]
        r[23] = r[23] / 14
        r[21] = r[21]((1), r[23])
        r[22] = env["renderer"]
        r[22] = r[22]["text"]
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[6]
        r[23] = r[23](r[24])
        r[23] = r[23] + 5
        r[24] = env["ui"]
        r[24] = r[24]["get"]
        r[25] = up[7]
        r[24] = r[24](r[25])
        r[24] = r[24] + 23
        clear_values(r,29,29)
        r[22](r[23], r[24], (255), (255), (255), (255), r[29], (0), ("choke: "))
        r[22] = env["renderer"]
        r[22] = r[22]["rectangle"]
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[6]
        r[23] = r[23](r[24])
        r[23] = r[23] + 40
        r[24] = env["ui"]
        r[24] = r[24]["get"]
        r[25] = up[7]
        r[24] = r[24](r[25])
        r[24] = r[24] + 27
        r[25] = up[8]
        r[25] = r[25]["x"]
        r[25] = r[25] - 60
        r[22](r[23], r[24], r[25], (6), (25), (25), (25), (175))
        r[22] = env["renderer"]
        r[22] = r[22]["gradient"]
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[6]
        r[23] = r[23](r[24])
        r[23] = r[23] + 41
        r[24] = env["ui"]
        r[24] = r[24]["get"]
        r[25] = up[7]
        r[24] = r[24](r[25])
        r[24] = r[24] + 28
        r[25] = up[8]
        r[25] = r[25]["x"]
        r[25] = r[25] - 62
        r[25] = r[25] * r[21]
        r[27] = r[13]
        r[28] = r[14]
        r[29] = r[15]
        r[30] = r[16]
        r[31] = r[17]
        r[32] = r[18]
        r[33] = r[19]
        r[34] = r[20]
        r[22](r[23], r[24], r[25], (4), r[27], r[28], r[29], r[30], r[31], r[32], r[33], r[34], (true))
        r[22] = env["renderer"]
        r[22] = r[22]["text"]
        r[23] = env["ui"]
        r[23] = r[23]["get"]
        r[24] = up[6]
        r[23] = r[23](r[24])
        r[24] = up[8]
        r[24] = r[24]["x"]
        r[23] = r[23] + r[24]
        r[23] = r[23] - 15
        r[24] = env["ui"]
        r[24] = r[24]["get"]
        r[25] = up[7]
        r[24] = r[24](r[25])
        clear_values(r,25,41)
        r[24] = r[24] + 25
        r[25] = 255
        r[26] = 255
        r[27] = 255
        r[28] = 255
        r[29] = "-"
        r[30] = 0
        r[31] = env["tostring"]
        r[32] = up[14]
        do local values=pack_values(r[31](r[32])); top=31+values.n-1; assign_results(r,31,top,values) end
        r[22](unpack_values(r,23,top))
        r[22] = env["entity"]
        r[22] = r[22]["get_prop"]
        r[23] = env["entity"]
        r[23] = r[23]["get_local_player"]
        r[23] = r[23]()
        r[22] = r[22](r[23], ("m_flPoseParameter"), (11))
        r[23] = r[22] * 116
        r[22] = r[23] - 58
        r[23] = env["math"]
        r[23] = r[23]["abs"]
        r[24] = r[22]
        r[23] = r[23](r[24])
        r[23] = r[23] / 58
        r[24] = env["renderer"]
        r[24] = r[24]["text"]
        r[25] = env["ui"]
        r[25] = r[25]["get"]
        r[26] = up[6]
        r[25] = r[25](r[26])
        r[25] = r[25] + 5
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[7]
        r[26] = r[26](r[27])
        r[26] = r[26] + 35
        clear_values(r,31,31)
        r[24](r[25], r[26], (255), (255), (255), (255), r[31], (0), ("desync: "))
        r[24] = env["renderer"]
        r[24] = r[24]["rectangle"]
        r[25] = env["ui"]
        r[25] = r[25]["get"]
        r[26] = up[6]
        r[25] = r[25](r[26])
        r[25] = r[25] + 45
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[7]
        r[26] = r[26](r[27])
        r[26] = r[26] + 40
        r[27] = up[8]
        r[27] = r[27]["x"]
        r[27] = r[27] - 65
        r[24](r[25], r[26], r[27], (6), (25), (25), (25), (175))
        r[24] = env["renderer"]
        r[24] = r[24]["gradient"]
        r[25] = env["ui"]
        r[25] = r[25]["get"]
        r[26] = up[6]
        r[25] = r[25](r[26])
        r[25] = r[25] + 46
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[7]
        r[26] = r[26](r[27])
        r[26] = r[26] + 40
        r[27] = up[8]
        r[27] = r[27]["x"]
        r[27] = r[27] - 67
        r[27] = r[27] * r[23]
        r[29] = r[13]
        r[30] = r[14]
        r[31] = r[15]
        r[32] = r[16]
        r[33] = r[17]
        r[34] = r[18]
        r[35] = r[19]
        r[36] = r[20]
        r[24](r[25], r[26], r[27], (4), r[29], r[30], r[31], r[32], r[33], r[34], r[35], r[36], (true))
        r[24] = env["renderer"]
        r[24] = r[24]["text"]
        r[25] = env["ui"]
        r[25] = r[25]["get"]
        r[26] = up[6]
        r[25] = r[25](r[26])
        r[26] = up[8]
        r[26] = r[26]["x"]
        r[25] = r[25] + r[26]
        r[25] = r[25] - 18
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[7]
        r[26] = r[26](r[27])
        clear_values(r,27,41)
        r[26] = r[26] + 37
        r[27] = 255
        r[28] = 255
        r[29] = 255
        r[30] = 255
        r[31] = "-"
        r[32] = 0
        r[33] = env["tostring"]
        r[34] = env["math"]
        r[34] = r[34]["floor"]
        r[35] = r[22]
        do local values=pack_values(r[34](r[35])); top=34+values.n-1; assign_results(r,34,top,values) end
        do local values=pack_values(r[33](unpack_values(r,34,top))); top=33+values.n-1; assign_results(r,33,top,values) end
        r[24](unpack_values(r,25,top))
        r[24] = make_table(256)
        r[25] = make_table(256)
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[15]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L422
        end
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[16]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L422
        end
        r[26] = #r[24]
        r[26] = r[26] + 1
        r[24][r[26]] = "hide"
        r[26] = #r[24]
        r[25][r[26]] = true
        ::L422::
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[17]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L432
        end
        r[26] = #r[24]
        r[26] = r[26] + 1
        r[24][r[26]] = "safe"
        r[26] = #r[24]
        r[25][r[26]] = true
        ::L432::
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[18]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L447
        end
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[19]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L447
        end
        r[26] = #r[24]
        r[26] = r[26] + 1
        r[24][r[26]] = "double tap"
        r[26] = #r[24]
        r[25][r[26]] = true
        ::L447::
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[20]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L457
        end
        r[26] = #r[24]
        r[26] = r[26] + 1
        r[24][r[26]] = "force baim"
        r[26] = #r[24]
        r[25][r[26]] = true
        ::L457::
        r[26] = env["ui"]
        r[26] = r[26]["get"]
        r[27] = up[21]
        r[26] = r[26](r[27])
        if not r[26] then
            goto L467
        end
        r[26] = #r[24]
        r[26] = r[26] + 1
        r[24][r[26]] = "duck"
        r[26] = #r[24]
        r[25][r[26]] = true
        ::L467::
        r[26] = up[8]
        r[27] = #r[24]
        r[27] = r[27] * 15
        r[27] = 60 + r[27]
        r[26]["y"] = r[27]
        r[27] = #r[24]
        r[26] = 0 + (1)
        r[27] = 0 + r[27]
        r[28] = 0 + (1)
        if (r[28] > 0 and r[26] > r[27]) or (r[28] <= 0 and r[26] < r[27]) then
            goto L503
        end
        r[29] = r[26]
        ::L476::
        r[30] = r[25][r[29]]
        if not r[30] then
            goto L480
        end
        r[30] = up[11]
        if r[30] then
            goto L481
        end
        ::L480::
        r[30] = 255
        ::L481::
        r[31] = env["renderer"]
        r[31] = r[31]["text"]
        r[32] = env["ui"]
        r[32] = r[32]["get"]
        r[33] = up[6]
        r[32] = r[32](r[33])
        r[32] = r[32] + 5
        r[33] = env["ui"]
        r[33] = r[33]["get"]
        r[34] = up[7]
        r[33] = r[33](r[34])
        r[33] = r[33] + 32
        r[34] = r[29] * 15
        r[33] = r[33] + r[34]
        r[37] = r[30]
        clear_values(r,38,38)
        r[40] = r[24][r[29]]
        r[31](r[32], r[33], (255), (255), (255), r[37], r[38], (0), r[40])
        ::L503::
        r[26] = r[26] + r[28]
        if (r[28] > 0 and r[26] <= r[27]) or (r[28] <= 0 and r[26] >= r[27]) then
            r[29] = r[26]
            goto L476
        end
        do return end
    end
end

-- Function 38; 0 parameters; literal propagation follows the recovered CFG.
functions[38] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        do return end
    end
end

-- Function 39; 0 parameters; literal propagation follows the recovered CFG.
functions[39] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-0
        for index=0,arguments.n-1 do
            if index<0 then r[index]=arguments[index+1] else varargs[index-0]=arguments[index+1] end
        end
        local top=-1
        r[0] = env["ui"]
        r[0] = r[0]["set"]
        r[1] = up[0]
        r[1] = r[1]["bodyyaw"]
        r[1] = r[1][2]
        r[0](r[1], (0))
        do return end
    end
end

-- Function 40; 1 parameters; literal propagation follows the recovered CFG.
functions[40] = function(env, up)
    return function(...)
        local r, varargs = {}, {}
        local arguments=pack_values(...)
        local vararg_count=arguments.n-1
        for index=0,arguments.n-1 do
            if index<1 then r[index]=arguments[index+1] else varargs[index-1]=arguments[index+1] end
        end
        local top=-1
        r[1] = env["entity"]
        r[1] = r[1]["get_prop"]
        r[2] = env["entity"]
        r[2] = r[2]["get_local_player"]
        r[2] = r[2]()
        r[1] = r[1](r[2], ("m_iTeamNum"))
        r[2] = env["entity"]
        r[2] = r[2]["get_prop"]
        r[3] = env["entity"]
        r[3] = r[3]["get_local_player"]
        r[3] = r[3]()
        r[2] = r[2](r[3], ("m_flDuckAmount"))
        if 0.7 < r[2] then
            goto L17
        end
        r[2] = false
        goto L18
        ::L17::
        r[2] = true
        ::L18::
        if r[1] ~= 3 then
            goto L25
        end
        if not r[2] then
            goto L25
        end
        r[3] = env["ui"]
        r[3] = r[3]["set"]
        r[4] = up[0]
        r[3](r[4], (30))
        ::L25::
        do return end
    end
end
return functions[0](env,nil)(...)
