-- Reconstructed editable Lua; inferred names. See README_EDITABLE_RU.txt.
local environment = getfenv()
local unpack_results = unpack
local function pack_results(...)
    return {
        n = select("#", ...),
        ...,
    }
end
local function new_table(size)
    if table.create then
        return table.create(size)
    end
    return {
    }
end
local helpers = {
}
helpers[1] = function(environment, test_up)
    return function(...)
        return ...
    end
end
helpers[3] = function(environment, test_up)
    return function(values, wanted)
        if values == nil then
            return false
        end
        if test_up[0](values) == "number" then
            values = test_up[1](values)
        end
        for index = 0, #values do
            if values[index] == wanted then
                return true
            end
        end
        return false
    end
end
helpers[5] = function(environment, test_up)
    return function(yaw)
        while yaw > 180 do
            yaw = yaw - 360
        end
        while yaw < -180 do
            yaw = yaw + 360
        end
        return yaw
    end
end
helpers[6] = function(environment, test_up)
    return function(from_x, from_y, to_x, to_y)
        local delta_y, delta_x = from_y - to_y, from_x - to_x
        local angle = test_up[1](test_up[0](delta_y / delta_x) * 180 / environment.math.pi)
        if delta_x >= 0 then
            angle = test_up[1](angle + 180)
        end
        return angle
    end
end
helpers[7] = function(environment, test_up)
    return function(position, target_position, flatten_height)
        if flatten_height then
            target_position = {
                target_position[1],
                target_position[2],
                position[3],
            }
        end
        local delta = (position[1] - target_position[1]) + (position[2] - target_position[2]) + (position[3] - target_position[3])
        if delta < 0 then
            delta = delta * 0.75
        end
        return delta
    end
end
helpers[9] = function(environment, test_up)
    return function(line_start, line_end, point)
        local ax, ay = test_up[0](line_start)
        local bx, by = test_up[0](line_end)
        local numerator = (point.y - ay) * bx - (point.x - ax) * by + point.x * ay - point.y * ax
        local denominator = test_up[1]((point.y - ay) ^ 2 + (point.x - ax) ^ 2)
        return numerator / denominator
    end
end
helpers[11] = function(environment, test_up)
    return function(player)
        if test_up[0].desync == 0 then
            return 0
        end
        local pose_yaw = test_up[1](player, "m_flPoseParameter", 11) * 120 - 60
        if pose_yaw < 0 then
            return 90
        end
        return -90
    end
end
helpers[13] = function(environment, test_up)
    return function(pitch, yaw)
        local yaw_sin = test_up[0](test_up[1](yaw))
        local yaw_cos = test_up[2](test_up[1](yaw))
        local pitch_sin = test_up[0](test_up[1](pitch))
        local pitch_cos = test_up[2](test_up[1](pitch))
        return pitch_cos * yaw_cos, pitch_cos * yaw_sin, -pitch_sin
    end
end
helpers[15] = function(environment, test_up)
    return function(x, y)
        if x == 0 and y == 0 then
            return 0
        end
        return test_up[0](test_up[1](y, x))
    end
end
helpers[18] = function(environment, test_up)
    return function(player)
        if player == 0 then
            return false
        end
        if not test_up[0](player) then
            return false
        end
        if test_up[1](player) then
            return false
        end
        return true
    end
end
helpers[23] = function(environment, test_up)
    return function(center_x, center_y, angle, radius)
        local x = test_up[0](test_up[1](angle)) * radius + center_x
        local y = test_up[2](test_up[1](angle)) * radius + center_y
        return x, y
    end
end
helpers[35] = function(environment, test_up)
    return function(x, y, width, height)
        local mouse_x, mouse_y = environment.ui.mouse_position()
        if not environment.ui.get(test_up[0]) then
            return false
        end
        return x < mouse_x and mouse_x < x + width and y < mouse_y and mouse_y < y + height
    end
end
helpers[36] = function(environment, test_up)
    return function(command)
        test_up[0] = command.chokedcommands
    end
end
return helpers
