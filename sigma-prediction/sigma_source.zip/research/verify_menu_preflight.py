"""Use a closed menu registry; never invent handles for unknown references."""
from pathlib import Path
import json,hashlib,os
ROOT=Path(__file__).resolve().parent
os.environ['SIGMA_SOURCE']='sigma_source.lua'
import verify_sigma as V
from lupa import lua51,luajit21
source=(ROOT/'sigma_source.lua').read_bytes()
previous=(ROOT/'sigma_source.ui_compat.lua').read_bytes()
audit=json.loads((ROOT/'menu_dependency_audit.json').read_text())
paths=[(s['tab'],s['container'],s['name'])for s in audit['used_references']]
paths += [('AA','Anti-aimbot angles','Enabled'),('MISC','Settings','sv_maxusrcmdprocessticks'),('PLAYERS','Players','Player list'),('PLAYERS','Players','Reset all'),('PLAYERS','Adjustments','Apply to all'),('Config','Presets','Load'),('AA','Fake lag','Limit'),('AA','Fake lag','Enabled')]
registry='\n'.join('add(%s,%s,%s)'%tuple(json.dumps(x)for x in row)for row in paths)
SETUP=('''
local base=ui.reference
local function pack(...)return {n=select('#',...),...}end
local function key(tab,group,name)return tab:lower()..'/'..group:lower()..'/'..name:lower()end
local registry={}
local function add(tab,group,name)registry[key(tab,group,name)]=pack(base(tab,group,name))end
'''+registry+'''
trace={}; reference_requests={}; rng_draws=0
initial_control_count=fixture_stats()
initial_panorama_loadstring=panorama.loadstring
local random=math.random
math.random=function(...)rng_draws=rng_draws+1;return random(...)end
ui.reference=function(tab,group,name)
 local path=key(tab,group,name)
 reference_requests[#reference_requests+1]=path
 if missing_paths[path]then error('not found: '..path)end
 if api_error_path==path then error('UI engine unavailable')end
 local handles=registry[path]
 if handles==nil then error('not found: '..path)end
 if short_path==path then return handles[1]end
 return unpack(handles,1,handles.n)
end
''').encode()
def path(s):return (s['tab']+'/'+s['container']+'/'+s['name']).lower()
def setup(missing=(),short=None,api=None):
 args='missing_paths={'+','.join('[%s]=true'%json.dumps(x)for x in missing)+'}\n'
 args+='short_path='+('nil'if short is None else json.dumps(short))+'\n'
 args+='api_error_path='+('nil'if api is None else json.dumps(api))+'\n'
 return args.encode()+SETUP
for module in [lua51,luajit21]:
 lua=module.LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
 assert lua.eval(b'function(s)local f,e=loadstring(s);return f~=nil,e end')(source)==(True,None)
def execute(data,old=False):
 V.source=previous if old else source
 return V.run(True,data)[0]
def logs(lua):
 return [r['args'].get(1,'')for r in V.plain(lua.globals().trace).values()if r['module']=='client'and r['name']=='log']
def exercise(lua):
 outcomes=V.plain(lua.execute(V.EXERCISE));assert all(r['ok']for r in outcomes.values()),outcomes
 return len(outcomes)
report={'source_sha256':hashlib.sha256(source).hexdigest(),'syntax_checked':['Lua 5.1','LuaJIT 2.1'],'closed_registry':True,'scenarios':{}}
# Reproduce the exact reported lookup on the previous release.
max_path='misc/settings/sv_maxusrcmdprocessticks'
try:execute(setup([max_path]),True)
except Exception as e:assert 'not found'in str(e)and max_path in str(e)
else:raise AssertionError('Reported old lookup did not fail')
unused_paths=[(tab+'/'+group+'/'+name).lower()for tab,group,name in paths[len(audit['used_references']):]]
for mode,missing in [('reported_max_ticks',[max_path]),('all_unused',unused_paths),('all_optional',[path(s)for s in audit['used_references']if not s['required']]),('screenshot_missing_indicators',['rage/other/double tap','rage/other/force body aim'])]:
 lua=execute(setup(missing));cases=exercise(lua)
 requests=V.plain(lua.globals().reference_requests)
 assert not set(unused_paths)&set(requests.values()),requests
 report['scenarios'][mode]={'callback_cases':cases,'callback_failures':[],'unused_references_not_queried':True}
 if mode=='all_optional':assert any('Optional:'in m for m in logs(lua))
# Compare actual API effects with the previous release when all controls exist.
traces=[]
for old in [True,False]:
 lua=execute(setup(),old);assert exercise(lua)==42
 rows=V.plain(lua.globals().trace)
 traces.append([r for r in rows.values()if not(r['module']=='ui'and r['name']=='reference')])
assert traces[0]==traces[1], 'Supported-build non-lookup effects differ'
report['supported_build_effects_match_previous_release']=True
required=[s for s in audit['used_references']if s['required']]
# Missing requirements are checked as a group, including references after the
# first failed lookup. No original prefix, RNG, UI writes or events may run.
for mode,data,expected in [
 ('three_required',setup([path(s)for s in required[-3:]]),[s['name']for s in required[-3:]]),
 ('all_required',setup([path(s)for s in required]),[s['name']for s in required]),
 ('missing_second_handle',setup(short='aa/anti-aimbot angles/yaw'),['Yaw','expected at least 2']),
 ('optional_api_error',setup(api='aa/anti-aimbot angles/fake yaw limit'),['UI engine unavailable'])]:
 lua=execute(data);messages=logs(lua)
 assert any('Not started:'in m for m in messages),messages
 for name in expected:assert any(name in m for m in messages),(name,messages)
 assert lua.eval(b'panorama.loadstring==initial_panorama_loadstring')
 stats=lua.eval(b'fixture_stats')()
 assert stats[0]==lua.globals().initial_control_count and stats[1]==0,stats
 assert lua.globals().rng_draws==0
 rows=V.plain(lua.globals().trace)
 assert not any(r['module']=='ui'and r['name']!='reference'for r in rows.values()),rows
 report['scenarios'][mode]={'all_expected_issues_reported':True,'callbacks_registered':0,'rng_draws':0,'original_panorama_override_not_run':True,'ui_mutations':0}
# A build with both exact controls relocated into RAGE/Aimbot.
relocated=setup().replace(b'trace={}; reference_requests={}; rng_draws=0',b"for _,name in ipairs({'Double tap','Force body aim'})do local old=key('RAGE','Other',name);registry[key('RAGE','Aimbot',name)]=registry[old];registry[old]=nil end;trace={}; reference_requests={}; rng_draws=0")
lua=execute(relocated);assert exercise(lua)==42
assert not any('Not started:'in m for m in logs(lua))
report['scenarios']['relocated_to_aimbot']={'callback_cases':42,'callback_failures':[]}
report['gameplay_tested']=False
(ROOT/'menu_preflight_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Passed closed-registry menu preflight and callback scenarios')
