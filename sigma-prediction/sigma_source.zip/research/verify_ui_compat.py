"""Exercise missing/available controls and compare existing-control effects."""
from pathlib import Path
import os,json,hashlib
ROOT=Path(__file__).resolve().parent
os.environ['SIGMA_SOURCE']='sigma_source.lua'
from verify_sigma import run,EXERCISE,plain
from lupa import lua51,luajit21
source=(ROOT/'sigma_source.lua').read_bytes()
for module in [lua51,luajit21]:
 lua=module.LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
 assert lua.eval(b'function(s)local f,e=loadstring(s);return f~=nil,e end')(source)==(True,None)
SETUP=b'''
local reference=ui.reference
ui.reference=function(tab,container,name)
 if name=='Fake yaw limit' then
  if UI_MODE=='missing' then error('not found') end
  if UI_MODE=='api_error' then error('UI engine unavailable') end
  if UI_MODE=='canonical' and (tab~='AA' or container~='Anti-aimbot angles')then error('not found')end
  if UI_MODE=='legacy' and container~='anti-aimbot angles'then error('not found')end
 end
 if UI_MODE=='required_missing' and name=='Yaw base'then error('not found')end
 -- Resolve equivalent native paths to the same control, as an actual registry
 -- would, instead of creating arbitrary handles for every requested spelling.
 if name:lower()=='pitch'then name='Pitch'end
 return reference(tab:upper(),container:lower(),name)
end
'''
def setup(mode):return ('UI_MODE="'+mode+'"\n').encode()+SETUP
report={'syntax_checked':['Lua 5.1','LuaJIT 2.1'],'source_sha256':hashlib.sha256(source).hexdigest(),'scenarios':{}}
# The former failing lookup is reproduced, rather than accepting every string.
for mode in ['missing','canonical']:
 try:run(False,setup(mode))
 except Exception as e:assert 'not found'in str(e)
 else:raise AssertionError('Original unexpectedly accepted '+mode)
for mode in ['canonical','legacy','missing']:
 lua,_=run(True,setup(mode));stats=lua.eval(b'fixture_stats')()
 outcomes=plain(lua.execute(EXERCISE));failures=[r for r in outcomes.values()if not r['ok']]
 assert not failures,(mode,failures)
 trace=plain(lua.globals().trace)
 logs=[r for r in trace.values()if r['module']=='client'and r['name']=='log'and str(r['args'].get(1,'')).startswith('[sigma]')]
 assert len(logs)==(1 if mode=='missing'else 0),(mode,logs)
 assert stats[1]==(12 if mode=='missing'else 13),stats
 report['scenarios'][mode]={'startup_stats':stats,'callback_cases':len(outcomes),'callback_failures':failures,'missing_control_warning':len(logs)==1}
# On a build exposing the old control, the only intended startup differences
# are UI lookup spelling and reusing the already resolved control handle.
traces=[]
for recovered in [False,True]:
 lua,_=run(recovered,setup('present'));outcomes=plain(lua.execute(EXERCISE))
 assert all(r['ok']for r in outcomes.values())
 rows=plain(lua.globals().trace)
 traces.append([r for r in rows.values()if not(r['module']=='ui'and r['name']=='reference')])
assert traces[0]==traces[1], 'Non-lookup API effects changed on supported build'
report['existing_control_api_effects_match_original']=True
for mode,expected in [('api_error','UI engine unavailable'),('required_missing','not found')]:
 try:run(True,setup(mode))
 except Exception as e:assert expected in str(e)
 else:raise AssertionError('Unexpected error suppressed: '+mode)
 report['scenarios'][mode]={'unexpected_failure_propagated':True}
report['gameplay_tested']=False
(ROOT/'ui_compat_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Passed UI compatibility scenarios; available-control effects match original')
