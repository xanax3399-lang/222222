"""Validate the actual final file, including removed padding's RNG effect."""
from pathlib import Path
import os,json,hashlib,contextlib,io,re
ROOT=Path(__file__).resolve().parent
os.environ['SIGMA_SOURCE']='sigma_source.lua'
from verify_sigma import run
from lupa import lua51,luajit21
source=(ROOT/'sigma_source.lua').read_bytes()
syntax=[]
for module,label in [(lua51,'Lua 5.1'),(luajit21,'LuaJIT 2.1')]:
 lua=module.LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
 assert lua.eval(b'function(s)local fn,err=loadstring(s);return fn~=nil,err end')(source)==(True,None)
 syntax.append(label)
SETUP=b'''
math.randomseed(927511)
padding_draws={};padding_text=nil
local random,concat=math.random,table.concat
math.random=function(a,b)
 local value=random(a,b)
 padding_draws[#padding_draws+1]={a,b,value}
 return value
end
table.concat=function(values,separator,...)
 local text=concat(values,separator,...)
 if #values==2000 then padding_text=text end
 return text
end
'''
results=[]
for recovered in [False,True]:
 lua,_=run(recovered,SETUP)
 draws=lua.globals().padding_draws
 assert len(draws)==2000
 records=[tuple(draws[i][k]for k in [1,2,3])for i in range(1,2001)]
 assert all(a==1 and b==201 for a,b,_ in records)
 text=lua.globals().padding_text
 assert (isinstance(text,bytes)if not recovered else text is None)
 following=lua.execute(b'return math.random(1,1000000)')
 results.append((records,following))
assert results[0]==results[1]
text=source.decode()
assert not re.search(r'\b(?:goto|padding_words|loop_has_value_\d+|capture_upvalues)\b|\br\[\d+\]|\bup\[\d+\]|\bfunctions\[\d+\]',text)
report={'final_source_sha256':hashlib.sha256(source).hexdigest(),'syntax_checked':syntax,'padding_data_removed':True,'preserved_random_draws':2000,'same_next_random_value':results[0][1],'virtualization_scaffolding_absent':True,'gameplay_tested':False}
(ROOT/'editable_file_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Final syntax passed in Lua 5.1 / LuaJIT; 2000 RNG draws and next result matched')
