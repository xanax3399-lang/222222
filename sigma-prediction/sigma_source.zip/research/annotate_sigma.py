from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
names={0:'main',1:'return_varargs',2:'set_native_ui_visible',3:'contains_value',
4:'head_and_origin_coordinates',5:'normalize_yaw',6:'yaw_between_points',7:'signed_coordinate_delta',
8:'function_8',9:'signed_line_distance',10:'function_10',11:'pose_desync_side',12:'update_shot_history',
13:'angles_to_direction',14:'classify_movement',15:'vector_yaw',16:'estimate_damage_at_offsets',
17:'select_nearest_player',18:'is_valid_player',19:'update_target_anti_aim',20:'reset_player_state',
21:'handle_use_key',22:'update_manual_and_freestanding',23:'point_on_circle',24:'draw_indicator_triangle',
25:'apply_body_yaw',26:'on_bullet_impact',27:'on_player_hurt',28:'on_player_spawn',29:'draw_keybind_indicators',
30:'update_ui_visibility',31:'get_steam_identity',32:'update_whitelist',33:'register_events_if_whitelisted',
34:'draw_not_whitelisted',35:'is_mouse_in_rectangle',36:'track_choked_commands',37:'draw_custom_indicator',
38:'empty_callback',39:'reset_body_yaw',40:'adjust_crouching_ct_setting'}
index=json.loads((ROOT/'function_index.json').read_text())
for entry in index:entry['inferred_name']=names[entry['function']]
(ROOT/'function_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
for filename in ['new_sigma_pred.source.lua','new_sigma_pred.readable.lua']:
 p=ROOT/filename;s=p.read_text()
 s=re.sub(r'(-- Function (\d+);[^\n]*)',lambda m:m[1].split(' | Inferred name:')[0]+' | Inferred name: '+names[int(m[2])],s)
 p.write_text(s)
(ROOT/'function_names.json').write_text(json.dumps(names,indent=2)+'\n')
embedded=ROOT/'embedded_sources';embedded.mkdir(exist_ok=True)
graph=json.loads((ROOT/'application.graph.json').read_text());strings=set()
for obj in graph['objects']:
 for _,value in obj['items']:
  if isinstance(value,str)and '$.AsyncWebRequest'in value:strings.add(value)
for i,value in enumerate(sorted(strings)):(embedded/('whitelist_request_%d.js'%i)).write_text(value)
print('Annotated',len(names),'functions; JavaScript bodies',len(strings))
