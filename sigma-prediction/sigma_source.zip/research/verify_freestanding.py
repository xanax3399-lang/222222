from pathlib import Path
import os,json,hashlib
ROOT=Path(__file__).resolve().parent
os.environ['SIGMA_SOURCE']='sigma_source.lua'
from verify_sigma import run,EXERCISE,plain
from lupa import lua51,luajit21
source=(ROOT/'sigma_source.lua').read_bytes()
for m in [lua51,luajit21]:
 l=m.LuaRuntime(encoding=None);assert l.eval(b'function(s)return assert(loadstring(s))end')(source)
report={'source_sha256':hashlib.sha256(source).hexdigest(),'gameplay_tested':False,'scenarios':{}}
for mode in ['checkbox','multiselect']:
 setup=('''
local original_reference=ui.reference
ui.reference=function(tab,group,name)
 local a,b=original_reference(tab,group,name)
 if name=='Freestanding'then
  local control=sigma_controls()[a]
  control.kind='%s';control.value=%s
 end
 return a,b
end
local original_set=ui.set
ui.set=function(id,value,...)
 local c=assert(sigma_controls()[id])
 if c.name=='Freestanding'then
  if c.kind=='checkbox'then assert(type(value)=='boolean','boolean expected, got '..type(value))
  else assert(type(value)=='string','legacy selection expected')end
 end
 return original_set(id,value,...)
end
'''%(mode,'false'if mode=='checkbox'else '{}')).encode()
 lua,_=run(True,setup)
 # Force the stored state to change, including enabling the freestanding hotkey.
 controls=lua.globals().sigma_controls()
 for _,c in controls.items():
  if c[b'kind']==b'multiselect':
   c[b'value']=lua.table_from([b'Manual AA',b'Freestanding',b'Keybind indicator',b'AA indicator'])
  if c[b'kind']==b'hotkey':c[b'value']=True
 lua.globals().fixture_world=True
 outcomes=plain(lua.execute(EXERCISE))
 assert all(r['ok']for r in outcomes.values()),outcomes
 report['scenarios'][mode]={'callback_cases':len(outcomes),'failures':[]}
(ROOT/'freestanding_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Passed checkbox and legacy multiselect callbacks')
