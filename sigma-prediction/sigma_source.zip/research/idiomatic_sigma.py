"""Restore direct helper bodies and source-level UI reference groups."""
from pathlib import Path
import re,json,io,contextlib,copy
from luaparser import ast,astnodes as N
import polish_full_source as H
ROOT=Path(__file__).resolve().parent
CAPTURES={item['function']:{int(k):v for k,v in item['captured_bindings'].items()}for item in json.loads((ROOT/'lexical_recovery.json').read_text())}
BODIES={
3:'''if values == nil then return false end
if C0(values) == "number" then values = C1(values) end
for index = 0, #values do if values[index] == wanted then return true end end
return false''',
4:'''local _, _, head_z = C0(player, 0)
local origin_x, origin_y = C1(player, "m_vecOrigin")
return origin_x, origin_y, head_z''',
5:'''while yaw > 180 do yaw = yaw - 360 end
while yaw < -180 do yaw = yaw + 360 end
return yaw''',
6:'''local delta_y, delta_x = from_y - to_y, from_x - to_x
local angle = C1(C0(delta_y / delta_x) * 180 / environment.math.pi)
if delta_x >= 0 then angle = C1(angle + 180) end
return angle''',
7:'''if flatten_height then target_position = {target_position[1], target_position[2], position[3]} end
local delta = (position[1] - target_position[1]) + (position[2] - target_position[2]) + (position[3] - target_position[3])
if delta < 0 then delta = delta * 0.75 end
return delta''',
9:'''local ax, ay = C0(line_start)
local bx, by = C0(line_end)
local numerator = (point.y - ay) * bx - (point.x - ax) * by + point.x * ay - point.y * ax
local denominator = C1((point.y - ay)^2 + (point.x - ax)^2)
return numerator / denominator''',
11:'''if C0.desync == 0 then return 0 end
local pose_yaw = C1(player, "m_flPoseParameter", 11) * 120 - 60
if pose_yaw < 0 then return 90 end
return -90''',
13:'''local yaw_sin = C0(C1(yaw))
local yaw_cos = C2(C1(yaw))
local pitch_sin = C0(C1(pitch))
local pitch_cos = C2(C1(pitch))
return pitch_cos * yaw_cos, pitch_cos * yaw_sin, -pitch_sin''',
15:'''if x == 0 and y == 0 then return 0 end
return C0(C1(y, x))''',
18:'''if player == 0 then return false end
if not C0(player) then return false end
if C1(player) then return false end
return true''',
23:'''local x = C0(C1(angle)) * radius + center_x
local y = C2(C1(angle)) * radius + center_y
return x, y''',
35:'''local mouse_x, mouse_y = environment.ui.mouse_position()
if not environment.ui.get(C0) then return false end
return x < mouse_x and mouse_x < x + width and y < mouse_y and mouse_y < y + height''',
36:'''C0 = command.chokedcommands''',
}
def parse(text):
 with contextlib.redirect_stdout(io.StringIO()):return ast.parse(text)
def process(path,destination,helper=False):
 raw=path.read_text();preserved={}
 def protect(m):
  value=m[0]
  if '\\'not in value and all(ord(c)<128 for c in value):return value
  marker='__SIGMA_RAW_%d__'%len(preserved);preserved[marker]=value;return marker
 tree=parse(re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',protect,raw))
 replacements=0
 def replace_body(fid,fn,captures):
  nonlocal replacements
  if fid not in BODIES:return
  text=re.sub(r'\bC(\d+)\b',lambda m:captures[int(m[1])],BODIES[fid])
  fn.body=parse(text).body;replacements+=1
 if helper:
  for stmt in tree.body.body:
   if isinstance(stmt,N.Assign)and isinstance(stmt.targets[0],N.Index)and isinstance(stmt.targets[0].idx,N.Number):
    fid=int(stmt.targets[0].idx.n);wrapper=stmt.values[0]
    if fid in BODIES:
     fn=wrapper.body.body[0].values[0]
     replace_body(fid,fn,{k:'test_up[%d]'%k for k in CAPTURES.get(fid,{})})
 else:
  main=next(stmt for stmt in tree.body.body if isinstance(stmt,N.LocalFunction)and stmt.name.id=='main')
  funcs=[main]
  def collect(node):
   if isinstance(node,N.AnonymousFunction):funcs.append(node)
   for _,_,child in H.children(node):collect(child)
  collect(main.body)
  assert len(funcs)==41,len(funcs)
  for fid,fn in enumerate(funcs):replace_body(fid,fn,CAPTURES.get(fid,{}))
  # This routine has no data flow into the application. Retain its random
  # draws, but remove the unused vocabulary, generated strings and allocations.
  padding=next(stmt for stmt in main.body.body if isinstance(stmt,N.Do)and any(isinstance(child,N.LocalAssign)and any(isinstance(t,N.Name)and t.id=='padding_words'for t in child.targets)for child in stmt.body.body))
  padding.body=parse('for index = 1, 2000 do environment.math.random(1, 201) end').body
  # Source-level multi-reference groups preserve the original allocation before
  # calling ui.reference. No knowledge of the number of returned handles is used.
  rewritten=[];pos=0;statements=main.body.body;group_count=0
  while pos<len(statements):
   seq=statements[pos:pos+4]
   if len(seq)==4 and isinstance(seq[0],N.Assign)and isinstance(seq[0].targets[0],N.Name)and seq[0].targets[0].id=='script_controls'and isinstance(seq[0].values[0],N.Call)and isinstance(seq[0].values[0].func,N.Name)and seq[0].values[0].func.id=='new_table'and isinstance(seq[1],N.LocalAssign)and isinstance(seq[2],N.Fornum)and isinstance(seq[3],N.Assign):
    packed=seq[1].values[0]
    if isinstance(packed,N.Call)and isinstance(packed.func,N.Name)and packed.func.id=='pack_results'and len(packed.args)==1 and isinstance(packed.args[0],N.Call):
     call=packed.args[0]
     if isinstance(call.func,N.Name)and call.func.id=='ui_reference':
      store=copy.deepcopy(seq[3]);store.values=[N.Call(func=N.Name('reference_group'),args=copy.deepcopy(call.args))]
      rewritten.append(store);pos+=4;group_count+=1;continue
   rewritten.append(statements[pos]);pos+=1
  assert group_count==10,group_count
  # Define this after the API alias has been assigned, before creating controls.
  insertion=next(i for i,stmt in enumerate(rewritten)if isinstance(stmt,N.Assign)and isinstance(stmt.targets[0],N.Name)and stmt.targets[0].id=='native_controls')
  helper_definition=parse('''local function reference_group(...)
 local controls = new_table(256)
 local values = pack_results(ui_reference(...))
 for index = 1, values.n do controls[index] = values[index] end
 return controls
end''').body.body[0]
  rewritten.insert(insertion,helper_definition);main.body.body=rewritten
  # Give event closures their role names instead of temporary slot names.
  role_names={34:'draw_not_whitelisted',36:'track_choked_commands',37:'draw_custom_indicator',39:'reset_body_yaw',40:'adjust_crouching_ct_setting'}
  roles={id(funcs[fid]):name for fid,name in role_names.items()}
  def split_callback_temporaries(block):
   for i,stmt in enumerate(block.body):
    for _,_,child in H.children(stmt):
     if isinstance(child,N.Block):split_callback_temporaries(child)
     elif isinstance(child,N.AnonymousFunction):split_callback_temporaries(child.body)
    if not isinstance(stmt,N.Assign)or len(stmt.targets)!=len(stmt.values)or len(stmt.targets)!=1:continue
    value=stmt.values[0]
    if id(value)not in roles or not isinstance(stmt.targets[0],N.Name):continue
    old=stmt.targets[0].id;new=roles[id(value)]
    stmt.targets[0]=N.Name(new)
    block.body[i]=N.LocalAssign(targets=[N.Name(new)],values=[value])
    def use(node):
     if isinstance(node,FUNCTION_TYPES):return node
     if isinstance(node,N.Name)and node.id==old:return N.Name(new)
     for field,index,child in list(H.children(node)):
      if isinstance(node,N.Index)and field=='idx'and node.notation==N.IndexNotation.DOT:continue
      replacement=use(child)
      if index is None:setattr(node,field,replacement)
      else:getattr(node,field)[index]=replacement
     return node
    for following in block.body[i+1:]:
     if isinstance(following,(N.Assign,N.LocalAssign))and any(isinstance(t,N.Name)and t.id==old for t in following.targets):break
     use(following)
  FUNCTION_TYPES=(N.AnonymousFunction,N.Function,N.LocalFunction)
  split_callback_temporaries(main.body)
 def restore_lists(node):
  if isinstance(node,N.Field)and isinstance(node.key,N.Number)and node._first_token is not None and node._first_token.text!='[':
   node.key=N.Name('__SIGMA_LIST_FIELD__');node.between_brackets=True
  for _,_,child in H.children(node):restore_lists(child)
 restore_lists(tree)
 with contextlib.redirect_stdout(io.StringIO()):text=ast.to_lua_source(tree)
 text=re.sub(r'\[__SIGMA_LIST_FIELD__\]\s*=\s*','',text)
 text=re.sub(r'\b__SIGMA_RAW_\d+__\b',lambda m:preserved[m[0]],text)
 destination.write_text('-- Editable reconstructed source; see README_EDITABLE_RU.txt.\n'+text+'\n')
 return replacements
if __name__=='__main__':
 count=process(ROOT/'new_sigma_pred.editable.lua',ROOT/'new_sigma_pred.idiomatic.lua')
 process(ROOT/'editable_test_factories.lua',ROOT/'idiomatic_test_factories.lua',True)
 print('Direct helper bodies:',count,'; UI reference groups: 10; unused padding data removed')
