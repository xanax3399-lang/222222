"""Replace proven dead numeric-loop slots with native numeric for loops."""
from pathlib import Path
import re,io,contextlib,json,copy
from luaparser import ast,astnodes as N
import polish_full_source as H
ROOT=Path(__file__).resolve().parent
report=[]
def parse(s):
 with contextlib.redirect_stdout(io.StringIO()):return ast.parse(s)
def transfer(block,after):
 live=set(after)
 for stmt in reversed(block.body):
  stmt._live_after=live.copy()
  if isinstance(stmt,(N.Assign,N.LocalAssign)):
   defs={t.id for t in stmt.targets if isinstance(t,N.Name)}
   reads=set().union(*(H.references(v)for v in stmt.values))if stmt.values else set()
   for target in stmt.targets:
    if not isinstance(target,N.Name):reads|=H.references(target)
   live=(live-defs)|reads
  elif isinstance(stmt,N.If):
   live=transfer(stmt.body,live)|(transfer(stmt.orelse,live)if isinstance(stmt.orelse,N.Block)else transfer(N.Block([stmt.orelse]),live)if stmt.orelse is not None else live)|H.references(stmt.test)
  elif isinstance(stmt,N.Do):live=transfer(stmt.body,live)
  elif isinstance(stmt,(N.While,N.Repeat,N.Fornum,N.Forin)):
   demand=H.references(stmt)|live;transfer(stmt.body,demand);live|=demand
  elif isinstance(stmt,N.Return):live=set().union(*(H.references(v)for v in stmt.values))if stmt.values else set()
  else:live|=H.references(stmt)
 return live

def process(path,output):
 raw=path.read_text();preserved={}
 def protect(m):
  value=m[0]
  if '\\'not in value and all(ord(c)<128 for c in value):return value
  marker='__SIGMA_RAW_%d__'%len(preserved);preserved[marker]=value;return marker
 tree=parse(re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',protect,raw))
 def function(fn):
  # Existing closures can observe captured bindings during body calls. The
  # startup loop precedes all captures of its controller names; all other
  # accepted loops use uncaptured local slots.
  transfer(fn.body,H.creations(fn.body)&H.declarations(fn))
  def block(b,previous_captures=None):
   captured=set(previous_captures or set());out=[]
   for stmt in b.body:
    replacement=stmt
    if isinstance(stmt,N.Do)and len(stmt.body.body)==6:
     seq=stmt.body.body
     if isinstance(seq[0],N.LocalAssign)and len(seq[0].targets)==1 and seq[0].targets[0].id.startswith('loop_has_value_')and all(isinstance(s,N.Assign)and len(s.targets)==len(s.values)==1 for s in seq[1:4])and isinstance(seq[4],N.If)and isinstance(seq[5],N.While):
      flag=seq[0].targets[0].id;loop=seq[5];tail=loop.body.body[-3:]
      assert isinstance(tail[2],N.If)and len(tail[2].body.body)==1
      visible_assign=tail[2].body.body[0];visible=visible_assign.targets[0].id
      controls={s.targets[0].id for s in seq[1:4]}|{visible}
      body=N.Block(loop.body.body[:-3]);refs=H.references(body)
      reason=None
      if controls&stmt._live_after:reason='live after loop'
      elif controls&captured:reason='captured before loop'
      elif (refs&controls)-{visible}:reason='reads hidden control slots'
      elif H.writes(body)&controls:reason='writes controller'
      elif H.creations(body)&controls:reason='captures controller'
      if reason:report.append({'flag':flag,'converted':False,'reason':reason,'live':sorted(controls&stmt._live_after)})
      else:
       # Every recovered loop has step 1 and integer starts 0 or 1. Empty ranges
       # perform no body calls; their private control-slot differences are dead.
       starts=[s.values[0]for s in seq[1:4]]
       assert all(isinstance(v,N.AddOp)and isinstance(v.left,N.Number)and v.left.n==0 for v in starts)
       assert isinstance(starts[0].right,N.Number)and starts[0].right.n in (0,1)
       assert isinstance(starts[2].right,N.Number)and starts[2].right.n==1
       names={'754':'player_index','4':'player_index','50':'offset_index','13':'enemy_index','6':'player_index','90':'class_index','23':'weapon_index','293':'bind_index','475':'label_index'}
       name=names[flag.rsplit('_',1)[1]];assert name not in H.all_names(fn.body)
       def rename(node):
        if isinstance(node,H.FUNCTIONS):return
        for field,index,child in list(H.children(node)):
         if isinstance(node,N.Index)and field=='idx'and node.notation==N.IndexNotation.DOT:continue
         if isinstance(child,N.Name)and child.id==visible:
          if index is None:setattr(node,field,N.Name(name))
          else:getattr(node,field)[index]=N.Name(name)
         else:rename(child)
       rename(body)
       replacement=N.Fornum(target=N.Name(name),start=copy.deepcopy(starts[0]),stop=copy.deepcopy(starts[1]),step=copy.deepcopy(starts[2]),body=body)
       report.append({'flag':flag,'converted':True,'index':name,'dead_controllers':sorted(controls)})
    for _,_,child in H.children(replacement):
     if isinstance(child,N.Block):block(child,captured)
     elif isinstance(child,H.FUNCTIONS):function(child)
    captured|=H.creations(replacement)
    out.append(replacement)
   b.body=out
  block(fn.body)
  # Remove declarations of slots eliminated by conversion. Other transformations
  # intentionally leave ambiguous names untouched.
  def uses(node):
   if isinstance(node,N.LocalAssign):return set().union(*(uses(v)for v in node.values))if node.values else set()
   if isinstance(node,N.Index)and node.notation==N.IndexNotation.DOT:return uses(node.value)
   if isinstance(node,N.Name):return {node.id}
   return set().union(*(uses(c)for _,_,c in H.children(node)))if list(H.children(node))else set()
  used=uses(fn.body)
  def trim(b):
   out=[]
   for s in b.body:
    if isinstance(s,N.LocalAssign)and not s.values:
     s.targets=[t for t in s.targets if t.id in used]
     if not s.targets:continue
    for _,_,c in H.children(s):
     if isinstance(c,N.Block):trim(c)
    out.append(s)
   b.body=out
  trim(fn.body)
 def functions(node):
  if isinstance(node,H.FUNCTIONS):function(node);return
  for _,_,c in H.children(node):functions(c)
 functions(tree)
 def clean(node):
  for field,index,child in list(H.children(node)):
   cleaned=clean(child)
   if index is None:setattr(node,field,cleaned)
   else:getattr(node,field)[index]=cleaned
  if isinstance(node,(N.Name,N.String,N.Number,N.Nil,N.TrueExpr,N.FalseExpr,N.Index)):node.wrapped=False
  if isinstance(node,N.Index)and isinstance(node.idx,N.String):
   s=node.idx.s.decode()if isinstance(node.idx.s,bytes)else node.idx.s
   if re.fullmatch(r'[A-Za-z_]\w*',s)and s not in {'and','break','do','else','elseif','end','false','for','function','if','in','local','nil','not','or','repeat','return','then','true','until','while'}:node.idx=N.Name(s);node.notation=N.IndexNotation.DOT
  if isinstance(node,N.ULNotOp)and isinstance(node.operand,(N.EqToOp,N.NotEqToOp)):
   return (N.NotEqToOp if isinstance(node.operand,N.EqToOp)else N.EqToOp)(left=node.operand.left,right=node.operand.right)
  if isinstance(node,N.Field)and isinstance(node.key,N.Number)and node._first_token is not None and node._first_token.text!='[':
   node.key=N.Name('__SIGMA_LIST_FIELD__');node.between_brackets=True
  return node
 clean(tree)
 with contextlib.redirect_stdout(io.StringIO()):text=ast.to_lua_source(tree)
 text=re.sub(r'\[__SIGMA_LIST_FIELD__\]\s*=\s*','',text)
 text=re.sub(r'\b__SIGMA_RAW_\d+__\b',lambda m:preserved[m[0]],text)
 text=re.sub(r'(?m)^(\s*return)[ \t]+$',r'\1',text)
 output.write_text('-- Reconstructed editable Lua; inferred names. See README_EDITABLE_RU.txt.\n'+text+'\n')
if __name__=='__main__':
 process(ROOT/'new_sigma_pred.idiomatic.lua',ROOT/'sigma_source.lua')
 process(ROOT/'idiomatic_test_factories.lua',ROOT/'final_test_factories.lua')
 (ROOT/'loop_reconstruction.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report,indent=2))
