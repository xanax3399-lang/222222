"""Reproduce sigma_source.lua from the SHA-pinned original, then check it."""
from pathlib import Path
import os,subprocess,sys
ROOT=Path(__file__).resolve().parent
steps=['unpack_sigma.py','normalize_sigma.py','opcode_map.py','recover_sigma.py','optimize_sigma.py','optimize_lexical.py','annotate_sigma.py','structure_sigma.py','build_full_source.py','polish_full_source.py','clean_padding.py','reconstruct_outlaw_style.py','idiomatic_sigma.py','finalize_sigma.py','validate_jump.py','verify_helpers.py','verify_editable.py','verify_sigma.py','apply_ui_compat.py','verify_ui_compat.py','apply_menu_preflight.py','apply_indicator_compat.py','verify_menu_preflight.py','apply_freestanding_compat.py','verify_freestanding.py']
for script in steps:
 env=os.environ.copy()
 if script=='verify_sigma.py':env['SIGMA_SOURCE']='sigma_source.lua'
 with (ROOT/(script+'.log')).open('w')as log:
  result=subprocess.run([sys.executable,str(ROOT/script)],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit('Failed: '+script+'; see '+script+'.log')
 print('Passed:',script,flush=True)
