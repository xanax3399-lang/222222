from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=ROOT/'sigma_source.lua';s=p.read_text()
a='''        for index = 0, #values do'''
assert s.count(a)==1
s=s.replace(a,'''        if get_value_type(values) ~= "table" then
            return values == wanted
        end
'''+a)
a='''            ui_set(value_2, value_3)
            value_2 = native_controls.freestand[2]'''
assert s.count(a)==1
s=s.replace(a,'''            if get_value_type(ui_get(value_2)) == "boolean" then
                ui_set(value_2, not not anti_aim_state.dir.freestand)
            else
                ui_set(value_2, value_3)
            end
            value_2 = native_controls.freestand[2]''')
a='''                    value_16 = contains_value(value_17, "Default")'''
assert s.count(a)==1
s=s.replace(a,'''                    local freestanding_value = ui_get(value_17)
                    if get_value_type(freestanding_value) == "boolean" then
                        value_16 = freestanding_value
                    else
                        value_16 = contains_value(freestanding_value, "Default")
                    end''')
p.write_text(s)
