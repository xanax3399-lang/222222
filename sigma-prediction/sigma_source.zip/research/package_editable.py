from pathlib import Path
import hashlib,json,shutil,zipfile,re
ROOT=Path(__file__).resolve().parent
FRESH=Path('/workspace/sigma-editable-reproduction')
STAGE=Path('/workspace/sigma-editable-package');STAGE.mkdir(exist_ok=True)
REPO=Path('/workspace/222222/sigma-prediction');OUT=Path('/workspace/artifacts')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(ROOT/'sigma_source.lua')==sha(FRESH/'sigma_source.lua')
callbacks=json.loads((FRESH/'structured_callback_validation.json').read_text());helpers=json.loads((FRESH/'helper_validation.json').read_text());checks=json.loads((FRESH/'editable_file_validation.json').read_text())
assert callbacks['matched']and callbacks['callback_cases']==42 and callbacks['host_calls']==449
assert helpers['matched_original_vm']and helpers['cases_per_variant']==344
assert len(json.loads((ROOT/'function_index.json').read_text()))==41
report={
 'input_sha256':sha(ROOT/'new_sigma_pred.original.lua'),
 'source_sha256':sha(ROOT/'sigma_source.lua'),
 'source_lines':len((ROOT/'sigma_source.lua').read_text().splitlines()),
 'recovered_application_function_bodies':41,
 'direct_helper_reconstructions':13,
 'numeric_loop_scaffolds_replaced':9,
 'source_has_native_lexical_closures':True,
 'virtual_machine_and_register_scaffolding_removed':True,
 'author_names_or_comments_recovered':False,
 'remaining_ambiguous_identifiers':['value_N','argument_N'],
 'helper_comparisons':helpers,
 'callback_comparisons':callbacks,
 'reconstruction_file_checks_before_ui_patch':checks,
 'intermediate_fake_yaw_fix_checks':json.loads((FRESH/'ui_compat_validation.json').read_text()),
 'final_menu_preflight_checks':json.loads((FRESH/'menu_preflight_validation.json').read_text()),
 'native_menu_dependency_audit':json.loads((FRESH/'menu_dependency_audit.json').read_text()),
 'compatibility_change':'Remove 9 unused references; preflight all 16 used dependencies before original side effects; cache handles; report every required/API failure together and do not start if any are missing. Six optional controls are guarded; DT/BAIM try the Aimbot container and are only used by indicators.',
 'reconstruction_tests_apply_before_ui_compatibility_patch':True,
 'fresh_reconstruction_and_compatibility_patch_matched_sha256':True,
 'all_paths_proven_equivalent':False,
 'gameplay_tested':False,
 'real_network_requests_or_remote_javascript_executed_in_tests':False,
 'original_steam_id_check_and_panorama_override_preserved':True,
}
(ROOT/'editable_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
map_lines=['КАРТА ОСНОВНОГО ФАЙЛА sigma_source.lua','Строки и имена реконструированных функций; имена определены по использованию.','']
for i,line in enumerate((ROOT/'sigma_source.lua').read_text().splitlines(),1):
 m=re.match(r'\s*(?:local\s+)?(\w+)\s*=\s*function\s*\(',line)or re.match(r'\s*local function (\w+)\(',line)
 if m:map_lines.append('%4d  %s'%(i,m[1]))
(ROOT/'SOURCE_MAP.txt').write_text('\n'.join(map_lines)+'\n')
for name in ['sigma_source.lua','README_EDITABLE_RU.txt','SOURCE_MAP.txt','editable_verification.json','menu_dependency_audit.json','menu_preflight_validation.json']:shutil.copy2(ROOT/name,STAGE/name)
research=STAGE/'research';research.mkdir(exist_ok=True)
for path in ROOT.glob('*.py'):shutil.copy2(path,research/path.name)
# All required inputs, intermediate stages and test fixtures. No host paths,
# credentials, Python caches or execution logs are included.
for name in ['requirements-full.txt','gamesense_fixture.lua','new_sigma_pred.original.lua','function_names.json','function_index.json','lexical_recovery.json','loop_reconstruction.json','editable_transform.json','jump_validation.json']:
 shutil.copy2(ROOT/name,research/name)
for name in ['application.graph.json','application.ir.json','optimized.ir.json','optimized_lexical.ir.json','new_sigma_pred.source.lua','new_sigma_pred.readable.lua','new_sigma_pred.lexical_ready.lua','new_sigma_pred.structured.lua','new_sigma_pred.full_source.lua','new_sigma_pred.editable.lua','new_sigma_pred.idiomatic.lua','native_test_factories.lua','editable_test_factories.lua','idiomatic_test_factories.lua','final_test_factories.lua','helper_validation.json','structured_callback_validation.json','editable_file_validation.json','sigma_source.recovered.lua','ui_compat_validation.json','sigma_source.ui_compat.lua','menu_dependency_audit.json','menu_preflight_validation.json','sigma_source.menu_preflight.lua']:
 path=FRESH/name
 assert path.is_file(),name
 shutil.copy2(path,research/name)
manifest={str(p.relative_to(STAGE)):sha(p)for p in sorted(STAGE.rglob('*'))if p.is_file()and p.name!='SHA256SUMS.json'}
(STAGE/'SHA256SUMS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
zip_path=OUT/'sigma_source.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(STAGE.rglob('*')):
  if p.is_file():z.write(p,str(p.relative_to(STAGE)))
with zipfile.ZipFile(zip_path)as z:
 assert z.testzip()is None
 for name,digest in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==digest
 assert z.read('sigma_source.lua')==(ROOT/'sigma_source.lua').read_bytes()
for name in ['sigma_source.lua','README_EDITABLE_RU.txt','SOURCE_MAP.txt','editable_verification.json','menu_dependency_audit.json','menu_preflight_validation.json']:shutil.copy2(STAGE/name,REPO/name)
shutil.copy2(zip_path,REPO/zip_path.name)
shutil.copy2(STAGE/'sigma_source.lua',OUT/'sigma_source.lua')
repo_manifest=json.loads((REPO/'SHA256SUMS.json').read_text())
for name in ['sigma_source.lua','sigma_source.zip','README_EDITABLE_RU.txt','SOURCE_MAP.txt','editable_verification.json','menu_dependency_audit.json','menu_preflight_validation.json']:repo_manifest[name]=sha(REPO/name)
(REPO/'SHA256SUMS.json').write_text(json.dumps(repo_manifest,ensure_ascii=False,indent=2)+'\n')
print('Packaged',len(manifest),'files;',zip_path.stat().st_size,'bytes; source',sha(ROOT/'sigma_source.lua'))
