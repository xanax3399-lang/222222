"""Apply a narrow runtime compatibility fix after faithful reconstruction tests."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=ROOT/'sigma_source.lua';source=p.read_text()
marker='    -- Compatibility: some GameSense builds do not expose Fake yaw limit.\n'
if marker in source:raise SystemExit('UI compatibility patch already applied')
(ROOT/'sigma_source.recovered.lua').write_text(source)
def replace(old,new):
 global source
 assert source.count(old)==1,(old,source.count(old))
 source=source.replace(old,new)
replace('    local function reference_group(...)',marker+'''    local function optional_ui_reference(tab, container, name)
        local result = pack_results(pcall(ui_reference, tab, container, name))
        if result[1] then
            return unpack_results(result, 2, result.n)
        end
        local message = environment.tostring(result[2])
        if not environment.string.find(message, "not found", 1, true) then
            environment.error(message, 0)
        end
        return nil
    end
    local function find_fake_yaw_limit()
        local handle = optional_ui_reference("AA", "Anti-aimbot angles", "Fake yaw limit")
        if handle ~= nil then
            return handle
        end
        return optional_ui_reference("AA", "anti-aimbot angles", "Fake yaw limit")
    end
    local function reference_group(...)''')
replace('native_controls.pitch = ui_reference("AA", "Anti-aimbot angles", "pitch")','native_controls.pitch = ui_reference("AA", "Anti-aimbot angles", "Pitch")')
replace('native_controls.fakeyawlimit = ui_reference("AA", "anti-aimbot angles", "Fake yaw limit")','''native_controls.fakeyawlimit = find_fake_yaw_limit()
    if native_controls.fakeyawlimit == nil then
        environment.client.log("[sigma] Fake yaw limit is unavailable in this GameSense build; limit writes and the crouching CT limit override are disabled.")
    end''')
replace('native_controls.fsbodyyaw = ui_reference("AA", "anti-aimbot angles", "Freestanding body yaw")','native_controls.fsbodyyaw = ui_reference("AA", "Anti-aimbot angles", "Freestanding body yaw")')
replace('''        value_2 = native_controls.fakeyawlimit
        ui_set_visible(value_2, visible)''','''        value_2 = native_controls.fakeyawlimit
        if value_2 ~= nil then
            ui_set_visible(value_2, visible)
        end''')
replace('''        value_4 = value_4[value_5]
        ui_set(value_3, value_4)
        set_native_ui_visible(false)''','''        value_4 = value_4[value_5]
        if value_3 ~= nil then
            ui_set(value_3, value_4)
        end
        set_native_ui_visible(false)''')
replace('crouching_ct_fake_yaw = environment.ui.reference("aa", "Anti-aimbot angles", "Fake yaw limit")','crouching_ct_fake_yaw = native_controls.fakeyawlimit')
replace('''    value_118("setup_command", adjust_crouching_ct_setting)''','''    if crouching_ct_fake_yaw ~= nil then
        value_118("setup_command", adjust_crouching_ct_setting)
    end''')
p.write_text(source)
print('Applied Fake yaw limit UI compatibility patch')
