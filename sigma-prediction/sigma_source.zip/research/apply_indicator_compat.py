from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
p=ROOT/'sigma_source.lua';s=p.read_text();(ROOT/'sigma_source.menu_preflight.lua').write_text(s)
for key,name,count in [('forcebaim','Force body aim',1),('dt','Double tap',2)]:
 old='{"%s", "RAGE", "Other", "%s", %d, true}'%(key,name,count)
 assert old in s;s=s.replace(old,old.replace('true}','false}'))
needle='        local valid = result[1] == true'
s=s.replace(needle,'''        -- These indicators moved between native RAGE containers across builds.
        if not result[1] and (spec[1] == "dt" or spec[1] == "forcebaim") and tostring(result[2]):find("not found", 1, true) then
            result = pack(pcall(ui.reference, "RAGE", "Aimbot", spec[4]))
        end
'''+needle)
for label,check in [('Double tap','native_controls.dt[1] ~= nil and native_controls.dt[2] ~= nil'),('Force body aim','native_controls.forcebaim ~= nil')]:
 old='''                value_14 = contains_value(value_15, "%s")
                if not (not value_14) then'''%label
 assert s.count(old)==1;s=s.replace(old,old.replace('if not (not value_14) then','if value_14 and '+check+' then'))
s=s.replace('value_26 = environment.ui.get(double_tap_enabled)','value_26 = double_tap_enabled ~= nil and double_tap_key ~= nil and environment.ui.get(double_tap_enabled)')
s=s.replace('value_26 = environment.ui.get(force_body_aim)','value_26 = force_body_aim ~= nil and environment.ui.get(force_body_aim)')
p.write_text(s)
p=ROOT/'menu_dependency_audit.json';audit=json.loads(p.read_text())
for spec in audit['used_references']:
 if spec['key']in ['dt','forcebaim']:
  spec['required']=False;spec['alternate_container']='Aimbot';spec['absence_behavior']='Omit this indicator; it does not control gameplay.'
p.write_text(json.dumps(audit,indent=2)+'\n')
