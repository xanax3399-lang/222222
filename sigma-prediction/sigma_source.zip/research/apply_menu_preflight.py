"""Audit native dependencies and validate them before application side effects."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
p=ROOT/'sigma_source.lua';source=p.read_text()
assert 'local function preflight_native_menu()'not in source
(ROOT/'sigma_source.ui_compat.lua').write_text(source)
# Only these references have readers in the reconstructed program. Counts are
# the handles actually indexed, rather than guessed replacements for controls.
specs=[
 ('pitch','AA','Anti-aimbot angles','Pitch',1,True),
 ('yawbase','AA','Anti-aimbot angles','Yaw base',1,False),
 ('fakeyawlimit','AA','Anti-aimbot angles','Fake yaw limit',1,False),
 ('fsbodyyaw','AA','Anti-aimbot angles','Freestanding body yaw',1,False),
 ('edgeyaw','AA','Anti-aimbot angles','Edge yaw',1,True),
 ('fakeduck','RAGE','Other','Duck peek assist',1,True),
 ('safepoint','RAGE','Aimbot','Force safe point',1,True),
 ('forcebaim','RAGE','Other','Force body aim',1,True),
 ('yaw','AA','Anti-aimbot angles','Yaw',2,True),
 ('quickpeek','RAGE','Other','Quick peek assist',2,True),
 ('yawjitter','AA','Anti-aimbot angles','Yaw jitter',2,False),
 ('bodyyaw','AA','Anti-aimbot angles','Body yaw',2,True),
 ('freestand','AA','Anti-aimbot angles','Freestanding',2,True),
 ('os','AA','Other','On shot anti-aim',2,True),
 ('slow','AA','Other','Slow motion',2,True),
 ('dt','RAGE','Other','Double tap',2,True),
]
unused=['enabled','maxprocticks','player_list','reset_all','apply_all','load_cfg','fl_limit','ps','fakelag']
for name in unused:
 pattern=r'(?m)^    native_controls\.'+name+r' = .*\n'
 source,count=re.subn(pattern,'',source);assert count==1,(name,count)
 assert not re.search(r'\bnative_controls\.'+name+r'\b',source),name
source=source.replace('environment.ui.reference','cached_native_reference')
# The preflight reports all optional controls, replacing the earlier per-control warning.
old='''    if native_controls.fakeyawlimit == nil then
        environment.client.log("[sigma] Fake yaw limit is unavailable in this GameSense build; limit writes and the crouching CT limit override are disabled.")
    end
'''
assert source.count(old)==1;source=source.replace(old,'')
start=source.index('    set_native_ui_visible = function(visible)')
finish=source.index('    set_native_ui_visible(false)',start)
source=source[:start]+'''    set_native_ui_visible = function(visible)
        if visible == nil then
            visible = true
        end
        local names = {"pitch", "yawbase", "yaw", "yawjitter", "bodyyaw", "fakeyawlimit", "fsbodyyaw", "edgeyaw", "freestand"}
        for _, name in ipairs(names) do
            local control = native_controls[name]
            if type(control) == "table" then
                for index = 1, #control do
                    ui_set_visible(control[index], visible)
                end
            elseif control ~= nil then
                ui_set_visible(control, visible)
            end
        end
    end
'''+source[finish:]
rows=[]
for key,tab,group,name,count,required in specs:
 rows.append('        {%s, %s, %s, %s, %d, %s},'%(json.dumps(key),json.dumps(tab),json.dumps(group),json.dumps(name),count,str(required).lower()))
prefix='''-- Validate every used native menu dependency before changing the UI or callbacks.
local function preflight_native_menu()
    local specs = {
'''+ '\n'.join(rows)+'''
    }
    local function pack(...)
        return {n = select("#", ...), ...}
    end
    local function path_key(tab, container, name)
        return tab:lower() .. "/" .. container:lower() .. "/" .. name:lower()
    end
    local cache, failures, optional = {}, {}, {}
    for _, spec in ipairs(specs) do
        local result = pack(pcall(ui.reference, spec[2], spec[3], spec[4]))
        if not result[1] and spec[1] == "fakeyawlimit" and tostring(result[2]):find("not found", 1, true) then
            result = pack(pcall(ui.reference, "AA", "anti-aimbot angles", spec[4]))
        end
        local valid = result[1] == true
        if valid then
            for index = 1, spec[5] do
                if result[index + 1] == nil then valid = false end
            end
        end
        local label = spec[2] .. " / " .. spec[3] .. " / " .. spec[4]
        if valid then
            local handles = {n = result.n - 1}
            for index = 2, result.n do handles[index - 1] = result[index] end
            cache[path_key(spec[2], spec[3], spec[4])] = handles
        else
            local lookup_missing = not result[1] and tostring(result[2]):find("not found", 1, true)
            local reason = result[1] and ("expected at least " .. spec[5] .. " non-nil handle(s)") or tostring(result[2])
            if spec[6] or (not result[1] and not lookup_missing) then
                failures[#failures + 1] = label .. " (" .. reason .. ")"
            else
                optional[#optional + 1] = label
            end
            -- Known optional absence is represented by an empty result list.
            cache[path_key(spec[2], spec[3], spec[4])] = {n = 0}
        end
    end
    if #failures > 0 then
        client.log("[sigma] Not started: incompatible GameSense menu (" .. #failures .. " required/API issue(s)).")
        for _, message in ipairs(failures) do client.log("[sigma] Required/API: " .. message) end
    end
    if #optional > 0 then
        client.log("[sigma] Unavailable optional menu controls (" .. #optional .. "):")
        for _, message in ipairs(optional) do client.log("[sigma] Optional: " .. message) end
        client.log("[sigma] Missing optional controls are left alone; Fake yaw limit writes and its crouching CT override require that control.")
    end
    if #failures > 0 then return nil end
    return function(tab, container, name)
        local handles = cache[path_key(tab, container, name)]
        if handles == nil then error("[sigma] Native reference missing from dependency audit: " .. tab .. "/" .. container .. "/" .. name, 2) end
        return unpack(handles, 1, handles.n)
    end
end
local cached_native_reference = preflight_native_menu()
if cached_native_reference == nil then return end

'''
first,rest=source.split('\n',1);source=first+'\n'+prefix+rest
p.write_text(source)
(ROOT/'menu_dependency_audit.json').write_text(json.dumps({'used_references':[{'key':s[0],'tab':s[1],'container':s[2],'name':s[3],'minimum_handles':s[4],'required':s[5]}for s in specs],'removed_unused_references':unused,'optional_missing_behavior':'Skip visibility-only controls and existing guarded Fake yaw limit writes.','required_missing_behavior':'Log every missing dependency, then return before original prefix/RNG/UI mutations/callback registration.'},indent=2)+'\n')
print('Audited',len(specs),'used dependencies; removed',len(unused),'unused references')
