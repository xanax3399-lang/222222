"""Lift every used PSU opcode to explicit Lua operations and control flow."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parent
graph=json.loads((ROOT/'application.graph.json').read_text());objects=graph['objects']
def table(v):return dict(objects[v if isinstance(v,int)else v['ref']]['items'])
root=table(table(graph['root'])['proto'])
protos=[];ids={}
def visit(ref,parent=None,child_index=None):
 p=table(ref);n=len(protos);ids[ref['ref']]=n
 protos.append({'id':n,'parent':parent,'child_index':child_index,'ref':ref,'data':p})
 for index,child in sorted(table(p['m0Y6bQ0S']).items()):visit(child,n,index)
visit(table(graph['root'])['proto'])
def quote(v):
 if v is None:return 'nil'
 if v is True:return 'true'
 if v is False:return 'false'
 if isinstance(v,(int,float)):return repr(v)
 if isinstance(v,dict)and'bytes'in v:v=bytes.fromhex(v['bytes']).decode('latin1');binary=True
 else:binary=False
 assert isinstance(v,str),v
 return '"'+''.join('\\%03d'%ord(c)if ord(c)<32 or ord(c)==127 or binary and ord(c)>=128 else '\\'+c if c in '\\"'else c for c in v)+'"'
def R(n):assert isinstance(n,int),n;return 'r[%d]'%n

HELPERS='''local env = getfenv()
local unpack_values = unpack
local function pack_values(...) return {n=select('#',...), ...} end
local function clear_values(r, first, last)
    for index=first,last do r[index]=nil end
end
local function assign_results(r, first, last, values)
    for index=first,last do r[index]=values[index-first+1] end
end
local function make_table(size)
    if table.create then return table.create(size) end
    return {}
end
local function capture_upvalues(registers, inherited, specification)
    local slots={}
    for index,entry in ipairs(specification) do
        slots[index-1]={entry[1]==0 and registers or inherited,entry[2]}
    end
    return setmetatable({}, {
        __index=function(_,index)local slot=slots[index];return slot[1][slot[2]]end,
        __newindex=function(_,index,value)local slot=slots[index];slot[1][slot[2]]=value end,
    })
end
local functions={}
'''
out=['-- Reconstructed from new_sigma_pred.lua; all 41 application bodies.\n-- Names are inferred. PSU VM, byte stream and opcode dispatch are removed.\n-- Labels preserve recovered branches; see function_index.json and README_RU.txt.\n']
original=(ROOT/'new_sigma_pred.original.lua').read_text()
out.append(original[:original.index('for l,e in pairs({(function')].rstrip()+'\n')
out.append(HELPERS);function_index=[];ir=[]
for item in protos:
 p=item['data'];number=item['id'];limit=p[-548824];params=p[798523]
 code=table(p[112464]);rev={ref['ref']:pc for pc,ref in code.items()};nodes=[];all_strings=set()
 for pc,ref in sorted(code.items()):
  ins=table(ref);op=ins['hTQq'];a=ins[173253];b=ins.get('Sf9G');c=ins.get('mkkUa');nxt=ins.get('nMooY');nxt=rev[nxt['ref']]if nxt else None
  branch=None;condition=None;onbranch=[];stmts=[];terminal=False
  def arglist(last):return 'unpack_values(r,%d,%s)'%(a+1,last)
  def fncall(last):return R(a)+'('+arglist(last)+')'
  def clear(first,last=limit):return 'clear_values(r,%s,%s)'%(first,last)
  if op==19:pass
  elif op==117:branch=rev[b['ref']]
  elif op in (0,16,23,24,35,36,60,66,91,104,109,116,118):
   lhs=quote(a)if op in (23,91,104)else R(a)
   rhs=R(c)if op in (16,23,24,35,36,91,104,109)else quote(c)
   operator={0:'>',16:'>',23:'>=',24:'<',35:'>=',36:'==',60:'~=',66:'>=',91:'<',104:'>',109:'~=',116:'==',118:'<'}[op]
   branch=rev[b['ref']];condition=lhs+' '+operator+' '+rhs
  elif op in (34,38):branch=rev[b['ref']];condition=('not 'if op==34 else '')+R(a)
  elif op==22:branch=rev[b['ref']];condition=R(c);onbranch=[R(a)+' = '+R(c)]
  elif op in (2,37):stmts=[R(a)+' = '+('true'if b!=0 else 'false')]
  elif op==5:stmts=[R(a)+' = '+R(b)+'['+quote(c)+']']
  elif op==13:stmts=[R(a)+' = '+R(b)+'['+R(c)+']']
  elif op==48:stmts=[R(a)+' = env['+quote(b)+']']
  elif op==76:stmts=[R(a)+' = up['+quote(b)+']']
  elif op==107:stmts=['up['+quote(b)+'] = '+R(a)]
  elif op==78:stmts=[R(a)+' = '+R(b)]
  elif op==42:stmts=[R(a)+' = '+quote(b)]
  elif op in (10,21,46,51,58,65,74,84,85,96,102,113,115):
   if op==21:expr='-('+R(b)+')'
   elif op==113:expr='not '+R(b)
   else:
    lhs=quote(b)if op in (10,74)else R(b)
    rhs=R(c)if op in (10,74,85,96,102,115)else quote(c)
    expr=lhs+' '+{10:'-',46:'^',51:'/',58:'+',65:'-',74:'+',84:'*',85:'*',96:'/',102:'+',115:'-'}[op]+' '+rhs
   stmts=[R(a)+' = '+expr]
  elif op==69:stmts=[R(a)+' = #'+R(b)]
  elif op in (20,67,90):stmts=[R(a)+' = '+('make_table('+quote(256 if op==20 else b)+')'if op!=90 else '{}')]
  elif op in (31,40,54,68):
   key=quote(b)if op in (31,40)else R(b)
   val=quote(c)if op in (31,68)else R(c)
   stmts=[R(a)+'['+key+'] = '+val]
  elif op==71:stmts=[R(a)+' = '+' .. '.join(R(i)for i in range(b,c+1))]
  elif op==89:stmts=[clear(a,b)]
  elif op in (9,87):
   childref=table(p['m0Y6bQ0S'])[b];child=ids[childref['ref']]
   up='nil'
   if op==87:
    spec=table(ins[-78909]);pairs=[table(spec[i])for i in range(1,c+1)]
    up='capture_upvalues(r,up,{'+','.join('{%d,%d}'%(v[0],v[1])for v in pairs)+'})'
   stmts=[R(a)+' = functions[%d](env,%s)'%(child,up)]
  elif op in (1,4,6,25,57,64,77,81):
   terminal=True
   if op==57:stmts=['return']
   elif op in (4,64):stmts=['return '+R(a)]
   elif op==1:stmts=['return '+R(a)+', '+R(a+1)]
   elif op in (6,25):stmts=['return unpack_values(r,%d,%s)'%(a,'top'if op==6 else a+b)]
   else:stmts=['return '+fncall('top'if op==81 else b)]
  elif op in (8,18,26,32,44,45,49,61,63,70,73,82,83,86,93,111):
   last='top'if op in (61,70,86,111)else b
   call=R(a)+'()'if op in (26,32,73,83)else R(a)+'('+R(a+1)+')'if op in (44,45,49,63)else fncall(last)
   if op in (26,45,61,82):
    stmts=[call]
    if op!=26:stmts.append(clear(a if op==45 else a+1,'top'if op==61 else limit))
   elif op in (32,49,86,93):
    stmts=[R(a)+' = '+call]
    if op!=32:stmts.append(clear(a+1,'top'if op==86 else limit))
   elif op in (18,63,70,73):stmts=['assign_results(r,%d,%d,{%s})'%(a,c,call),clear(c+1)]
   else:
    stmts=['do local values=pack_values('+call+'); top=%d+values.n-1; assign_results(r,%d,top,values) end'%(a,a)]
    if op in (83,111):stmts.append(clear('top+1'))
  elif op in (52,112):
   if op==52:stmts=['for index=%d,%d do %s[%d+index-%d] = r[index] end'%(a+1,b,R(a),50*(c-1),a)]
   else:stmts=['for index=%d,top do %s[%d+index-%d] = r[index] end'%(a+1,R(a),50*(c-1),a)]
  elif op==120:
   stmts=['top=%d+vararg_count-1'%a,'for index=0,vararg_count do r[%d+index]=varargs[index] end'%a,clear('top+1')]
  elif op in (43,47):
   branch=rev[b['ref']]
   if op==43:
    stmts=[R(a)+' = 0 + '+R(a),R(a+1)+' = 0 + '+R(a+1),R(a+2)+' = 0 + '+R(a+2)]
    condition='('+R(a+2)+' > 0 and '+R(a)+' > '+R(a+1)+') or ('+R(a+2)+' <= 0 and '+R(a)+' < '+R(a+1)+')'
    # Assignment occurs on the fallthrough edge only.
    onbranch=[]
   else:
    stmts=[R(a)+' = '+R(a)+' + '+R(a+2)]
    condition='('+R(a+2)+' > 0 and '+R(a)+' <= '+R(a+1)+') or ('+R(a+2)+' <= 0 and '+R(a)+' >= '+R(a+1)+')'
    onbranch=[R(a+3)+' = '+R(a)]
  else:raise AssertionError(('Unimplemented used opcode',op))
  for v in ins.values():
   if isinstance(v,str):all_strings.add(v)
  nodes.append({'pc':pc,'op':op,'statements':stmts,'next':nxt,'branch':branch,'condition':condition,'on_branch':onbranch,'terminal':terminal,
                'on_fallthrough':[R(a+3)+' = '+R(a)]if op==43 else []})
 # Every static branch is resolved to a code node; no opcode interpreter remains.
 targets={n['branch']for n in nodes if n['branch']is not None}
 out+=['\n-- Function %d; %d parameters; original register limit %d.'%(number,params,limit),
        '-- Referenced strings: '+', '.join(sorted(quote(s)for s in all_strings if len(s)<70))[:260],
        'functions[%d] = function(env, up)'%number,'    return function(...)','        local r, varargs = {}, {}',
        '        local arguments=pack_values(...)','        local vararg_count=arguments.n-%d'%params,
        '        for index=0,arguments.n-1 do',
        '            if index<%d then r[index]=arguments[index+1] else varargs[index-%d]=arguments[index+1] end'%(params,params),
        '        end','        local top=-1']
 for n in nodes:
  pc=n['pc']
  if pc in targets:out.append('        ::L%d::'%pc)
  # Return must be lexically last in its block; isolate it from later labels.
  if n['terminal']:out.append('        do '+n['statements'][0]+' end')
  else:
   out+=['        '+s for s in n['statements']]
   if n['branch']is not None:
    if n['condition']:
     out.append('        if '+n['condition']+' then')
     out+=['            '+s for s in n['on_branch']]
     out.append('            goto L%d'%n['branch']);out.append('        end')
    else:out.append('        goto L%d'%n['branch'])
   out+=['        '+s for s in n['on_fallthrough']]
   if n['branch']is None or n['condition']:
    if n['next']is not None and n['next']!=pc+1:
     out.append('        goto L%d'%n['next']);targets.add(n['next'])
 out+=['    end','end']
 function_index.append({'function':number,'parent':item['parent'],'child_index':item['child_index'],'parameters':params,'register_limit':limit,'instructions':len(nodes),'strings':sorted(all_strings)})
 ir.append({'function':number,'nodes':nodes})
out.append('return functions[0](env,nil)(...)')
(ROOT/'new_sigma_pred.source.lua').write_text('\n'.join(out)+'\n')
(ROOT/'function_index.json').write_text(json.dumps(function_index,ensure_ascii=False,indent=2)+'\n')
(ROOT/'application.ir.json').write_text(json.dumps(ir,ensure_ascii=False,indent=2)+'\n')
print('Lifted',len(protos),'functions',sum(p['instructions']for p in function_index),'instructions')
