"""Execute the opaque PSU jump handler without host APIs."""
from pathlib import Path
import json,re
from lupa.luajit21 import LuaRuntime
ROOT=Path(__file__).resolve().parent
ops=json.loads((ROOT/'opcodes.json').read_text());body=re.sub(r';(?:\s*;)+',';',ops['117']).rstrip(' ;')
lua=LuaRuntime(encoding=None)
fn=lua.eval(('function(e)local a="Sf9G";local h={};'+body+';return h end').encode())
graph=json.loads((ROOT/'application.graph.json').read_text());count=0
for obj in graph['objects']:
 ins=dict(obj['items'])
 if ins.get('hTQq')==117:
  target=lua.table();e=lua.table_from({b'Sf9G':target})
  assert lua.eval(b'rawequal')(fn(e),target);count+=1
(ROOT/'jump_validation.json').write_text(json.dumps({'opaque_jump_instances':count,'original_handler_executed':True,'resolved_to_Sf9G_target':True},indent=2)+'\n')
print('Verified opaque jump instances:',count)
