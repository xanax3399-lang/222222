-- Reconstructed complete Lua; names are inferred. See README_FULL_RU.txt.
local environment = getfenv()
local unpack_results = unpack
local function pack_results(...)
    return {
        n = select("#", ...),
        ...,
    }
end
local function new_table(size)
    if table.create then
        return table.create(size)
    end
    return {
    }
end
local helpers = {
}
helpers[1] = function(environment, test_up)
    return function(...)
        return ...
    end
end
helpers[3] = function(environment, test_up)
    return function(values, wanted)
        local value_2, value_3, value_4, value_5, value_6
        if values ~= nil then
            value_2 = test_up[0]
            value_3 = values
            value_2 = value_2(value_3)
            if not (value_2 ~= "number") then
                value_2 = test_up[1]
                value_3 = values
                value_2 = value_2(value_3)
                values = value_2
            end
            value_3 = #values
            do
                local loop_has_value_15 = true
                value_2 = 0 + (0)
                value_3 = 0 + value_3
                value_4 = 0 + (1)
                if (value_4 > 0 and value_2 > value_3) or (value_4 <= 0 and value_2 < value_3) then
                    value_2 = value_2 + value_4
                    loop_has_value_15 = (value_4 > 0 and value_2 <= value_3) or (value_4 <= 0 and value_2 >= value_3)
                    if loop_has_value_15 then
                        value_5 = value_2
                    end
                else
                    value_5 = value_2
                end
                while loop_has_value_15 do
                    value_6 = values[value_5]
                    if not (value_6 ~= wanted) then
                        return (true)
                    end
                    value_2 = value_2 + value_4
                    loop_has_value_15 = (value_4 > 0 and value_2 <= value_3) or (value_4 <= 0 and value_2 >= value_3)
                    if loop_has_value_15 then
                        value_5 = value_2
                    end
                end
            end
            return (false)
        else
            return (false)
        end
    end
end
helpers[5] = function(environment, test_up)
    return function(yaw)
        while not (180 >= yaw) do
            yaw = yaw - 360
        end
        while not (yaw >= -180) do
            yaw = yaw + 360
        end
        return yaw
    end
end
helpers[6] = function(environment, test_up)
    return function(from_x, from_y, to_x, to_y)
        local value_4, value_5, value_6, value_7, value_8, value_9
        value_4 = from_y - to_y
        value_5 = from_x - to_x
        value_6 = test_up[0]
        value_7 = value_4 / value_5
        value_6 = value_6(value_7)
        value_7 = test_up[1]
        value_8 = value_6 * 180
        value_9 = (environment.math).pi
        value_8 = value_8 / value_9
        value_7 = value_7(value_8)
        value_6 = value_7
        if not (0 > value_5) then
            value_7 = test_up[1]
            value_8 = value_6 + 180
            value_7 = value_7(value_8)
            value_6 = value_7
        end
        return value_6
    end
end
helpers[7] = function(environment, test_up)
    return function(position, target_position, flatten_height)
        local value_3, value_4, value_5, value_6
        if not (flatten_height ~= nil) then
            flatten_height = false
        end
        if not (not flatten_height) then
            value_3 = new_table(3)
            value_4 = target_position[1]
            value_5 = target_position[2]
            value_6 = position[3]
            value_3[1] = value_4
            value_3[2] = value_5
            value_3[3] = value_6
            target_position = value_3
        end
        value_3 = position[1]
        value_4 = target_position[1]
        value_3 = value_3 - value_4
        value_4 = position[2]
        value_5 = target_position[2]
        value_4 = value_4 - value_5
        value_3 = value_3 + value_4
        value_4 = position[3]
        value_5 = target_position[3]
        value_4 = value_4 - value_5
        value_3 = value_3 + value_4
        if not (value_3 >= 0) then
            value_3 = value_3 * 0.75
        end
        return value_3
    end
end
helpers[9] = function(environment, test_up)
    return function(line_start, line_end, point)
        local value_3, value_4, value_5, value_6, value_7, value_8, value_9, value_10, value_11, value_12
        value_3 = test_up[0]
        value_4 = line_start
        value_3, value_4, value_5 = value_3(value_4)
        value_6 = test_up[0]
        value_7 = line_end
        value_6, value_7, value_8 = value_6(value_7)
        value_9 = ((point.y) - value_4) * value_6
        value_10 = ((point.x) - value_3) * value_7
        value_9 = value_9 - value_10
        value_10 = (point.x) * value_4
        value_9 = value_9 + value_10
        value_10 = (point.y) * value_3
        value_9 = value_9 - value_10
        value_10 = test_up[1]
        value_11 = ((point.y) - value_4) ^ 2
        value_12 = ((point.x) - value_3) ^ 2
        value_11 = value_11 + value_12
        value_10 = value_10(value_11)
        value_9 = value_9 / value_10
        return value_9
    end
end
helpers[11] = function(environment, test_up)
    return function(player)
        local value_1, value_2
        value_1 = (test_up[0]).desync
        if value_1 ~= 0 then
            value_1 = test_up[1]
            value_2 = player
            value_1 = ((value_1(value_2, ("m_flPoseParameter"), (11))) * 120) - 60
            if value_1 >= 0 then
                value_2 = -90
            else
                value_2 = 90
                if not (90) then
                    value_2 = -90
                end
            end
            return value_2
        else
            return (0)
        end
    end
end
helpers[13] = function(environment, test_up)
    return function(pitch, yaw)
        local value_2, value_3, value_4, value_5, value_6, value_7, value_8
        value_2 = test_up[0]
        value_3 = test_up[1]
        value_4 = yaw
        local returned_4 = pack_results(value_3(value_4))
        value_2 = value_2(unpack_results(returned_4, 1, returned_4.n))
        value_3 = test_up[2]
        value_4 = test_up[1]
        value_5 = yaw
        local returned_9 = pack_results(value_4(value_5))
        value_3 = value_3(unpack_results(returned_9, 1, returned_9.n))
        value_4 = test_up[0]
        value_5 = test_up[1]
        value_6 = pitch
        local returned_14 = pack_results(value_5(value_6))
        value_4 = value_4(unpack_results(returned_14, 1, returned_14.n))
        value_5 = test_up[2]
        value_6 = test_up[1]
        value_7 = pitch
        local returned_19 = pack_results(value_6(value_7))
        value_5 = value_5(unpack_results(returned_19, 1, returned_19.n))
        value_6 = value_5 * value_3
        value_7 = value_5 * value_2
        value_8 = -(value_4)
        return value_6, value_7, value_8
    end
end
helpers[15] = function(environment, test_up)
    return function(x, y)
        local value_2, value_3, value_4, value_5
        if x ~= 0 then
            value_2 = test_up[0]
            value_3 = test_up[1]
            value_4 = y
            value_5 = x
            local returned_9 = pack_results(value_3(value_4, value_5))
            return value_2(unpack_results(returned_9, 1, returned_9.n))
        else
            if y ~= 0 then
                value_2 = test_up[0]
                value_3 = test_up[1]
                value_4 = y
                value_5 = x
                local returned_9 = pack_results(value_3(value_4, value_5))
                return value_2(unpack_results(returned_9, 1, returned_9.n))
            else
                return (0)
            end
        end
    end
end
helpers[18] = function(environment, test_up)
    return function(player)
        local value_1, value_2
        if player ~= 0 then
            value_1 = test_up[0]
            value_2 = player
            value_1 = value_1(value_2)
            if value_1 then
                value_1 = test_up[1]
                value_2 = player
                value_1 = value_1(value_2)
                if not value_1 then
                    return (true)
                else
                    return (false)
                end
            else
                return (false)
            end
        else
            return (false)
        end
    end
end
helpers[23] = function(environment, test_up)
    return function(center_x, center_y, angle, radius)
        local value_4, value_5, value_6, value_7
        value_4 = test_up[0]
        value_5 = test_up[1]
        value_6 = angle
        local returned_4 = pack_results(value_5(value_6))
        value_4 = ((value_4(unpack_results(returned_4, 1, returned_4.n))) * radius) + center_x
        value_5 = test_up[2]
        value_6 = test_up[1]
        value_7 = angle
        local returned_11 = pack_results(value_6(value_7))
        value_5 = ((value_5(unpack_results(returned_11, 1, returned_11.n))) * radius) + center_y
        return value_4, value_5
    end
end
helpers[35] = function(environment, test_up)
    return function(x, y, width, height)
        local value_4, value_5, value_6, value_7
        value_4 = (environment.ui).mouse_position
        value_4, value_5 = value_4()
        value_6 = (environment.ui).get
        value_7 = test_up[0]
        value_6 = value_6(value_7)
        if not value_6 then
            return (false)
        else
            if x >= value_4 then
                value_6 = false
            else
                value_6 = x + width
                if value_4 < value_6 then
                    value_6 = true
                else
                    value_6 = false
                end
            end
            if y >= value_5 then
                value_7 = false
            else
                value_7 = y + height
                if value_5 < value_7 then
                    value_7 = true
                else
                    value_7 = false
                end
            end
            if not value_6 then
                return (false)
            else
                if not value_7 then
                    return (false)
                else
                    return (true)
                end
            end
        end
    end
end
helpers[36] = function(environment, test_up)
    return function(command)
        local value_1
        value_1 = command.chokedcommands
        test_up[0] = value_1
        return 
    end
end
return helpers
