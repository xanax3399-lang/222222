from pathlib import Path
import hashlib,json,os
os.environ['SIGMA_SOURCE']='new_sigma_pred.full_source.lua'
from verify_sigma import run
ROOT=Path(__file__).resolve().parent
SETUP=b'''
math.randomseed(927511)
padding_draws={};padding_text=nil
local random,concat=math.random,table.concat
math.random=function(a,b)
 local value=random(a,b)
 padding_draws[#padding_draws+1]={a,b,value}
 return value
end
table.concat=function(values,separator,...)
 local text=concat(values,separator,...)
 if #values==2000 then padding_text=text end
 return text
end
'''
results=[]
for recovered in [False,True]:
 lua,_=run(recovered,SETUP)
 draws=lua.globals().padding_draws
 count=len(draws);assert count==2000
 records=[tuple(draws[i][k]for k in [1,2,3])for i in range(1,count+1)]
 assert all(a==1 and b==201 for a,b,_ in records)
 text=lua.globals().padding_text;assert isinstance(text,bytes)
 following=lua.execute(b'return math.random(1,1000000)')
 results.append((records,text,following))
assert results[0]==results[1]
report={'original_vm_and_cleaned_source_matched':True,'random_draws':2000,'vocabulary_size':201,
 'padding_text_sha256':hashlib.sha256(results[0][1]).hexdigest(),'next_random_value':results[0][2]}
(ROOT/'padding_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Matched padding text, all 2000 random draws, and the next RNG result')
