"""Rebuild lexical Lua functions from the verified structured program.

Static temporary slots become ordinary locals. Captured slots become native Lua
upvalues. Variable return lists use explicit packed tuples, never a VM register
array. Branches/loops are emitted by the checked control-flow structurer.
"""
from pathlib import Path
import json,re,copy
from structure_sigma import Structurer
ROOT=Path(__file__).resolve().parent
ir=json.loads((ROOT/'optimized_lexical.ir.json').read_text())
index=json.loads((ROOT/'function_index.json').read_text())
names=json.loads((ROOT/'function_names.json').read_text())
root_names=dict(enumerate(['return_varargs','padding_count','padding_words','padding_lines',
 'bit_band','camera_angles','eye_position','key_state','scale_damage','screen_size','set_event_callback',
 'trace_bullet','trace_line','userid_to_entindex','get_all_entities','get_classname','get_local_player',
 'get_player_resource','get_players','get_prop','hitbox_position','is_alive','is_dormant','is_enemy',
 'curtime','tickcount','tickinterval','math_abs','math_atan','math_atan2','math_cos','math_deg','math_rad',
 'math_sin','math_sqrt','draw_gradient','draw_line','draw_text','draw_triangle','table_remove',
 'ui_get','ui_new_color_picker','ui_new_hotkey','ui_new_label','ui_new_multiselect','ui_reference',
 'ui_set','ui_set_callback','ui_set_visible','get_value_type','native_controls','set_native_ui_visible',
 'script_controls','anti_aim_state','player_records','contains_value','head_coordinates','normalize_yaw',
 'yaw_between_points','signed_coordinate_delta','target_info','signed_line_distance','target_record_info',
 'pose_desync_side','update_shot_history','angles_to_direction','classify_movement','vector_yaw',
 'estimate_damage_at_offsets','select_nearest_player','is_valid_player','update_target_anti_aim',
 'reset_player_state','handle_use_key','update_manual_and_freestanding','point_on_circle',
 'draw_indicator_triangle','apply_body_yaw','on_bullet_impact','on_player_hurt','on_player_spawn',
 'draw_keybind_indicators','update_ui_visibility','get_steam_identity','whitelisted_steam_id',
 'whitelist_initialized','next_whitelist_poll','update_whitelist','register_events_if_whitelisted',
 'custom_indicator_enabled','background_label_1','background_color_1','background_label_2',
 'background_color_2','accent_label_1','accent_color_1','accent_label_2','accent_color_2',
 'indicator_x','indicator_y','indicator_drag_key','onshot_enabled','onshot_key','force_safe_point',
 'double_tap_enabled','double_tap_key','force_body_aim','duck_peek_assist','indicator_dimensions',
 'choked_commands','is_mouse_in_rectangle','drag_origin_x','drag_origin_y','indicator_alpha',
 'indicator_scale','indicator_dragging','unused_callback','crouching_ct_fake_yaw']))
arg_names={2:['visible'],3:['values','wanted'],4:['player'],5:['yaw'],
 6:['from_x','from_y','to_x','to_y'],7:['position','target_position','flatten_height'],
 8:['player','other_player'],9:['line_start','line_end','point'],11:['player'],
 12:['event'],13:['pitch','yaw'],14:['player','command'],15:['x','y'],
 17:['origin','other'],18:['player'],19:['command'],20:['event'],21:['command','other'],
 22:['command'],23:['center_x','center_y','angle','radius'],25:['command'],26:['event'],
 27:['event'],28:['event'],35:['x','y','width','height'],36:['command'],40:['command']}
lexical_token=re.compile(r'"(?:\\.|[^"\\])*"|\br\[(\d+)\]|\bup\[(\d+)\]|\benv\b')
def subst(text,variables,bindings):
 def replace(m):
  if m[0].startswith('"'):return m[0]
  if m[1]is not None:return variables[int(m[1])]
  if m[2]is not None:return bindings[int(m[2])]
  return 'environment'
 return lexical_token.sub(replace,text)
def successors(n):
 if n['terminal']:return []
 if n['branch']is not None:return [n['branch']]+([n['next']]if n['condition']else [])
 return [n['next']]if n['next']is not None else []
def top_definitions(nodes):
 pred={n['pc']:[]for n in nodes};out={pc:set()for pc in pred}
 for n in nodes:
  for dest in successors(n):
   if dest in pred:pred[dest].append(n['pc'])
 for _ in range(1000):
  changed=False
  for n in nodes:
   parents=[out[p]for p in pred[n['pc']]];incoming=set().union(*parents)if parents else {-1}
   value={n['pc']}if n['op']in (8,44,83,111,120)else incoming
   if value!=out[n['pc']]:out[n['pc']]=value;changed=True
  if not changed:break
 else:raise AssertionError('Return tuple analysis did not converge')
 return {pc:set().union(*(out[p]for p in parents))if parents else {-1}for pc,parents in pred.items()}

HELPERS='''local environment = getfenv()
local unpack_results = unpack
local function pack_results(...) return {n = select("#", ...), ...} end
local function new_table(size)
    if table.create then return table.create(size) end
    return {}
end
'''
report=[]
def compile_function(fid,bindings,testing=False):
 fun=copy.deepcopy(ir[fid]);nodes=fun['nodes'];by={n['pc']:n for n in nodes};limit=index[fid]['register_limit'];params=index[fid]['parameters']
 if fid==1:
  report.append({'function':1,'name':names['1'],'parameters':['...'],'captured_bindings':bindings});return ['...'],['return ...']
 arguments=arg_names.get(fid,['argument_%d'%(i+1)for i in range(params)])
 assert len(arguments)==params
 reserved=set(bindings.values())|{'environment','pack_results','unpack_results','new_table'}
 variables={}
 for reg in range(limit+1):
  candidate=arguments[reg]if reg<params else root_names.get(reg,'value_%d'%reg)if fid==0 else 'value_%d'%reg
  while candidate in reserved:candidate+='_local'
  variables[reg]=candidate
 declarations=[variables[i]for i in range(params,limit+1)]
 incoming=top_definitions(nodes);tuples={}
 for n in nodes:
  if n['op']in (8,44,83,111):
   text=next(s for s in n['statements']if s.startswith('do local values=pack_values('))
   m=re.fullmatch(r'do local values=pack_values\((.*)\); top=(\d+)\+values.n-1; assign_results\(r,\d+,top,values\) end',text)
   assert m,text
   tuples[n['pc']]={'name':'returned_%d'%n['pc'],'base':int(m[2]),'call':m[1]}
 # Compute demand for lexical locals after tuple consumers have been lowered.
 # A dynamic result list is read from its packed tuple, not from scalar locals.
 def static_reads(text,pc):
  text=re.sub(r'"(?:\\.|[^"\\])*"','""',text)
  reads={int(i)for i in re.findall(r'r\[(\d+)\]',text)}
  assignment=re.fullmatch(r'((?:r\[\d+\](?:, )?)+) = (.*)',text)
  defs=set()
  if assignment:
   defs={int(i)for i in re.findall(r'r\[(\d+)\]',assignment[1])};reads={int(i)for i in re.findall(r'r\[(\d+)\]',assignment[2])}
  for first,last in re.findall(r'unpack_values\(r,(\d+),(\d+|top)\)',text):
   first=int(first)
   if last=='top':
    origin=next(iter(incoming[pc]));last=tuples[origin]['base']-1
   else:last=int(last)
   reads|=set(range(first,last+1))
  for first,last in re.findall(r'clear_values\(r,(\d+),(\d+)\)',text):defs|=set(range(int(first),int(last)+1))
  for first,last in re.findall(r'assign_results\(r,(\d+),(\d+),',text):defs|=set(range(int(first),int(last)+1))
  reads|={int(i)for i in re.findall(r'\{0,(\d+)\}',text)}
  fill=re.fullmatch(r'for index=(\d+),(\d+|top) do r\[(\d+)\]\[.*',text)
  if fill:
   first,last,_=fill.groups();first=int(first)
   if last=='top':last=tuples[next(iter(incoming[pc]))]['base']-1
   else:last=int(last)
   reads|=set(range(first,last+1))
  return reads,defs
 demand_in={n['pc']:set()for n in nodes};demand_out={n['pc']:set()for n in nodes}
 for _ in range(1000):
  changed=False
  for n in reversed(nodes):
   pc=n['pc'];after=set(fun['active_captures'][str(pc)])
   for dest in successors(n):after|=demand_in.get(dest,set())
   need=after.copy()
   for text in ([n['condition']]if n['condition']else [])+n['on_branch']+n['on_fallthrough']:
    need|=static_reads(text,pc)[0]
   for text in reversed(n['statements']):
    if text.startswith('do local values=pack_values('):
     reads,_=static_reads(tuples[pc]['call'],pc)
     defs=set(range(tuples[pc]['base'],limit+1))if n['op']in (83,111)else set()
    else:reads,defs=static_reads(text,pc)
    need=(need-defs)|reads
   if after!=demand_out[pc]or need!=demand_in[pc]:demand_out[pc]=after;demand_in[pc]=need;changed=True
  if not changed:break
 else:raise AssertionError('Lexical result demand did not converge')
 def tuple_at(pc):
  definitions=incoming[pc];assert len(definitions)==1,(fid,pc,definitions)
  definition=next(iter(definitions));assert definition in tuples,(fid,pc,definition)
  return tuples[definition]
 def unpack_dynamic(start,tup):
  start=int(start);base=tup['base'];result=[]
  if start<base:result +=[variables[i]for i in range(start,base)]
  result.append('unpack_results(%s,%d,%s.n)'%(tup['name'],max(1,start-base+1),tup['name']))
  return ', '.join(result)
 def transform_expression(text,pc):
  if 'unpack_values(r,'in text:
   text=re.sub(r'unpack_values\(r,(\d+),top\)',lambda m:unpack_dynamic(m[1],tuple_at(pc)),text)
   text=re.sub(r'unpack_values\(r,(\d+),(\d+)\)',lambda m:', '.join(variables[i]for i in range(int(m[1]),int(m[2])+1)),text)
  text=text.replace('make_table(','new_table(')
  return subst(text,variables,bindings)
 for node in nodes:
  pc=node['pc'];output=[];live=demand_out[pc]
  for statement in node['statements']:
   closure=re.fullmatch(r'r\[(\d+)\] = functions\[(\d+)\]\(env,(.*)\)',statement)
   if closure:
    dest,child=int(closure[1]),int(closure[2]);spec=closure[3];captures={}
    if spec!='nil':
     for i,(flag,slot)in enumerate(re.findall(r'\{([01]),(\d+)\}',spec)):
      captures[i]=variables[int(slot)]if flag=='0'else bindings[int(slot)]
    child_args,child_body=compile_function(child,captures,testing)
    output +=[variables[dest]+' = function('+', '.join(child_args)+')']+['    '+line for line in child_body]+['end']
    continue
   if statement.startswith('do local values=pack_values('):
    tup=tuples[pc];output.append('local %s = pack_results(%s)'%(tup['name'],transform_expression(tup['call'],pc)))
    for slot in sorted(i for i in live if i>=tup['base']):
     offset=slot-tup['base']+1
     assignment=variables[slot]+' = %s[%d]'%(tup['name'],offset)
     output.append(assignment if node['op']in (83,111)else 'if %s.n >= %d then %s end'%(tup['name'],offset,assignment))
    continue
   clear=re.fullmatch(r'clear_values\(r,([^,]+),([^,)]+)\)',statement)
   if clear:
    lo,hi=clear[1],clear[2]
    if lo.isdigit()and hi.isdigit():
     slots=[variables[i]for i in sorted(live&set(range(int(lo),int(hi)+1)))]
     if slots:output.append(', '.join(slots)+' = nil')
    else:
     tup=tuples[pc]if pc in tuples else tuple_at(pc);base=tup['base'];bound='%d+%s.n-1'%(base,tup['name'])
     for slot in sorted(live):
      if lo.isdigit()and slot<int(lo)or hi.isdigit()and slot>int(hi):continue
      condition=('%d > %s'if lo=='top+1'else '%d <= %s')%(slot,bound)
      output.append('if '+condition+' then '+variables[slot]+' = nil end')
    continue
   copy_fixed=re.fullmatch(r'assign_results\(r,(\d+),(\d+),\{(.*)\}\)',statement)
   if copy_fixed:
    first,last=int(copy_fixed[1]),int(copy_fixed[2]);targets=[variables[i]for i in range(first,last+1)]
    output.append((', '.join(targets)+' = 'if targets else '')+transform_expression(copy_fixed[3],pc));continue
   fill=re.fullmatch(r'for index=(\d+),(\d+|top) do r\[(\d+)\]\[(\d+)\+index-(\d+)\] = r\[index\] end',statement)
   if fill:
    first,last,table_slot,offset,minus=fill.groups();first,table_slot,offset,minus=map(int,[first,table_slot,offset,minus]);array=variables[table_slot]
    if last=='top':
     tup=tuple_at(pc);base=tup['base']
     for slot in range(first,base):output.append('%s[%d] = %s'%(array,offset+slot-minus,variables[slot]))
     begin=max(1,first-base+1)
     output.append('for index=%d,%s.n do %s[%d+index] = %s[index] end'%(begin,tup['name'],array,offset+base-1-minus,tup['name']))
    else:
     output +=['%s[%d] = %s'%(array,offset+slot-minus,variables[slot])for slot in range(first,int(last)+1)]
    continue
   if node['op']==120:
    assert fid==1;continue
   output.append(transform_expression(statement,pc))
  node['statements']=output
  if node['condition']:node['condition']=transform_expression(node['condition'],pc)
  node['on_branch']=[transform_expression(s,pc)for s in node['on_branch']]
  node['on_fallthrough']=[transform_expression(s,pc)for s in node['on_fallthrough']]
  if fid==1 and node['terminal']and node['op']==6:node['statements']=['return ...']
 if fid==1:body=['return ...'];arguments=['...'];declarations=[]
 else:body=Structurer(nodes).emit(0)
 # Ordinary local variables replace the interpreter's register table.
 if declarations:
  body=['local '+', '.join(declarations[i:i+12])for i in range(0,len(declarations),12)]+body
 report.append({'function':fid,'name':names[str(fid)],'parameters':[variables[i]for i in range(params)],'captured_bindings':bindings})
 return [variables[i]for i in range(params)]+(['...']if fid==1 or fid==0 else []),body

prefix=(ROOT/'new_sigma_pred.original.lua').read_text().split('for l,e in pairs({(function',1)[0].rstrip()
arguments,body=compile_function(0,{})
text='-- Reconstructed ordinary Lua source; inferred names, not original author names.\n'+prefix+'\n\n'+HELPERS+'\nlocal function main('+', '.join(arguments)+')\n'+'\n'.join('    '+s for s in body)+'\nend\nreturn main(...)\n'
assert not re.search(r'\br\[|\bup\[|capture_upvalues|assign_results|clear_values|\bgoto\b|functions\[',text)
(ROOT/'new_sigma_pred.full_source.lua').write_text(text)
(ROOT/'lexical_recovery.json').write_text(json.dumps(sorted(report,key=lambda v:v['function']),indent=2)+'\n')
print('Rebuilt native lexical functions:',len(report))
# Isolated helper factories are test evidence only; the shipped source has
# native lexical closures and does not contain this test injection layer.
test_helpers=[1,3,5,6,7,9,11,13,15,18,23,35,36]
test_out=[HELPERS,'local helpers={}']
for fid in test_helpers:
    used=set()
    for node in ir[fid]['nodes']:
        for text in node['statements']+[node['condition']or'']+node['on_branch']+node['on_fallthrough']:
            used|={int(k)for k in re.findall(r'up\[(\d+)\]',text)}
    arguments,body=compile_function(fid,{slot:'test_up[%d]'%slot for slot in used},True)
    test_out+=['helpers[%d]=function(environment,test_up)'%fid,'    return function('+', '.join(arguments)+')']+['        '+s for s in body]+['    end','end']
test_out.append('return helpers')
(ROOT/'native_test_factories.lua').write_text('\n'.join(test_out)+'\n')
