"""Conservative CFG-aware literal propagation and dead-register cleanup.

Only immutable literals are propagated. Host calls and captured registers are
treated as barriers. Property accesses are retained, including unused ones.
"""
from pathlib import Path
import json,re,copy
ROOT=Path(__file__).resolve().parent
ir=json.loads((ROOT/'application.ir.json').read_text())
source=(ROOT/'new_sigma_pred.source.lua').read_text()
def expand(text):
 text=re.sub(r'unpack_values\(r,(\d+),(\d+)\)',lambda m:', '.join('r[%d]'%i for i in range(int(m[1]),int(m[2])+1)),text)
 m=re.fullmatch(r'assign_results\(r,(\d+),(\d+),\{(.*)\}\)',text)
 if m:
  targets=', '.join('r[%d]'%i for i in range(int(m[1]),int(m[2])+1))
  return targets+' = '+m[3]if targets else m[3]
 return text
for fun in ir:
 for node in fun['nodes']:node['statements']=[expand(s)for s in node['statements']]

token=re.compile(r'"(?:\\.|[^"\\])*"|\br\[(\d+)\]')
assign=re.compile(r'^r\[(\d+)\] = (.*)$')
literal=re.compile(r'^(?:nil|true|false|-?\d+(?:\.\d*)?(?:e[+-]?\d+)?|"(?:\\.|[^"\\])*")$',re.I)
def refs(text):return {int(m[1])for m in token.finditer(text)if m[1]is not None}
def rw(text,limit):
 reads=refs(text);writes=set();m=assign.fullmatch(text)
 if m:writes.add(int(m[1]));reads=refs(m[2])
 else:
  multi=re.fullmatch(r'((?:r\[\d+\](?:, )?)+) = (.*)',text)
  if multi:writes|=refs(multi[1]);reads=refs(multi[2])
 for name,a,b in re.findall(r'(clear_values|assign_results|unpack_values)\(r,([^,]+),([^,)]+)',text):
  if a.isdigit()and b.isdigit():indexes=set(range(int(a),int(b)+1))
  else:indexes=set(range(limit+1))
  if name=='unpack_values':reads|=indexes
  elif a.isdigit()and b.isdigit():writes|=indexes
 if re.search(r'\br\[(?!\d+\])',text):reads|=set(range(limit+1))
 if 'capture_upvalues' in text:
  reads|={int(x)for x in re.findall(r'\{0,(\d+)\}',text)}
 return reads,writes
def substitute(text,known):
 match=assign.fullmatch(text);protected=(0,len('r['+match[1]+']'))if match else None
 def repl(m):
  if m[1]is None or protected and m.start()==0 or ' = 'in text and m.start()<text.index(' = '):return m.group()
  return '('+known[int(m[1])]+')'if int(m[1])in known else m.group()
 return token.sub(repl,text)
def successors(n):
 if n['terminal']:return []
 if n['branch']is not None:return [n['branch']]+([n['next']]if n['condition']else [])
 return [n['next']]if n['next']is not None else []
def reach(nodes):
 by={n['pc']:n for n in nodes};todo=[0];seen=set()
 while todo:
  pc=todo.pop()
  if pc in seen or pc not in by:continue
  seen.add(pc);todo+=successors(by[pc])
 return [n for n in nodes if n['pc']in seen]
index=json.loads((ROOT/'function_index.json').read_text())
out=[source[:source.index('\n-- Function 0;')]];counts={};optimized_ir=[]
for fun in ir:
 f=fun['function'];limit=index[f]['register_limit'];nodes=reach(copy.deepcopy(fun['nodes']));by={n['pc']:n for n in nodes}
 pinned=set()
 for n in nodes:
  for line in n['statements']:pinned|={int(x)for x in re.findall(r'\{0,(\d+)\}',line)}
 pred={n['pc']:[]for n in nodes}
 for n in nodes:
  for target in successors(n):
   if target in pred:pred[target].append(n['pc'])
 known_in={};known_out={}
 for _ in range(100):
  changed=False
  for n in nodes:
   pc=n['pc'];parents=[known_out[p]for p in pred[pc]if p in known_out]
   # Entry has an implicit unknown predecessor; unvisited predecessors must
   # also contribute unknown values instead of optimistic loop constants.
   incoming={}if pc==0 or len(parents)!=len(pred[pc])or not parents else {k:v for k,v in parents[0].items()if all(p.get(k)==v for p in parents[1:])}
   state=incoming.copy()
   for line in n['statements']+n['on_branch']+n['on_fallthrough']:
    rhs=substitute(line,state);_,writes=rw(line,limit)
    for reg in writes:state.pop(reg,None)
    if re.search(r'\br\[(?!\d+\])',line)or any(not(a.isdigit()and b.isdigit())for _,a,b in re.findall(r'(clear_values|assign_results)\(r,([^,]+),([^,)]+)',line)):state.clear()
    m=assign.fullmatch(rhs)
    if m:
     value=m[2]
     while value.startswith('(')and value.endswith(')'):value=value[1:-1]
     if literal.fullmatch(value):state[int(m[1])]=value
    if '('in line:
     for reg in pinned:state.pop(reg,None)
   if known_in.get(pc)!=incoming or known_out.get(pc)!=state:changed=True;known_in[pc]=incoming;known_out[pc]=state
  if not changed:break
 else:raise AssertionError('Literal analysis did not converge')
 for n in nodes:
  state=known_in[n['pc']].copy();rewritten=[]
  for line in n['statements']:
   rhs=substitute(line,state);rewritten.append(rhs);_,writes=rw(line,limit)
   for reg in writes:state.pop(reg,None)
   if re.search(r'\br\[(?!\d+\])',line)or any(not(a.isdigit()and b.isdigit())for _,a,b in re.findall(r'(clear_values|assign_results)\(r,([^,]+),([^,)]+)',line)):state.clear()
   m=assign.fullmatch(rhs)
   if m:
    value=m[2]
    while value.startswith('(')and value.endswith(')'):value=value[1:-1]
    if literal.fullmatch(value):state[int(m[1])]=value
   if '('in line:
    for reg in pinned:state.pop(reg,None)
  n['statements']=rewritten
  if n['condition']:n['condition']=substitute(n['condition'],state)
  n['on_branch']=[substitute(s,state)for s in n['on_branch']]
  n['on_fallthrough']=[substitute(s,state)for s in n['on_fallthrough']]
 live_in={n['pc']:set()for n in nodes};live_out=copy.deepcopy(live_in)
 for _ in range(1000):
  changed=False
  for n in reversed(nodes):
   pc=n['pc'];after=set(pinned)
   for target in successors(n):after|=live_in.get(target,set())
   state=after.copy()
   for line in reversed(n['statements']+([n['condition']]if n['condition']else [])+n['on_branch']+n['on_fallthrough']):
    reads,writes=rw(line,limit);state=(state-writes)|reads|pinned
   if after!=live_out[pc]or state!=live_in[pc]:live_out[pc]=after;live_in[pc]=state;changed=True
  if not changed:break
 else:raise AssertionError('Liveness analysis did not converge')
 removed=0
 for n in nodes:
  state=live_out[n['pc']].copy()
  for line in ([n['condition']]if n['condition']else [])+n['on_branch']+n['on_fallthrough']:state|=rw(line,limit)[0]
  kept=[]
  for line in reversed(n['statements']):
   reads,writes=rw(line,limit);m=assign.fullmatch(line)
   pure=m and (literal.fullmatch(m[2].strip('()'))or re.fullmatch(r'r\[\d+\]',m[2]))
   if (pure or line.startswith('clear_values('))and not writes&state:removed+=1;continue
   kept.append(line);state=(state-writes)|reads|pinned
  n['statements']=list(reversed(kept))
 optimized_ir.append({'function':f,'nodes':nodes})
 targets={n['branch']for n in nodes if n['branch']is not None}
 targets|={n['next']for n in nodes if n['next']is not None and n['next']!=n['pc']+1 and not n['terminal']}
 # Reuse the exact parameter/vararg prologue from the faithful version.
 start=source.index('functions[%d] = function(env, up)'%f)
 prologue=source[start:source.index('        local top=-1',start)+len('        local top=-1')]
 out+=['\n-- Function %d; %d parameters; literal propagation follows the recovered CFG.'%(f,index[f]['parameters']),prologue]
 for n in nodes:
  if n['pc']in targets:out.append('        ::L%d::'%n['pc'])
  if n['terminal']:out.append('        do '+n['statements'][0]+' end');continue
  out+=['        '+s for s in n['statements']]
  if n['branch']is not None:
   if n['condition']:
    out.append('        if '+n['condition']+' then');out+=['            '+s for s in n['on_branch']];out+=['            goto L%d'%n['branch'],'        end']
   else:out.append('        goto L%d'%n['branch'])
  out+=['        '+s for s in n['on_fallthrough']]
  if (n['branch']is None or n['condition'])and n['next']is not None and n['next']!=n['pc']+1:out.append('        goto L%d'%n['next'])
 out+=['    end','end'];counts[f]={'removed_dead_assignments':removed,'reachable_instructions':len(nodes)}
out.append('return functions[0](env,nil)(...)')
(ROOT/'new_sigma_pred.readable.lua').write_text('\n'.join(out)+'\n')
(ROOT/'optimizer_report.json').write_text(json.dumps(counts,indent=2)+'\n')
(ROOT/'optimized.ir.json').write_text(json.dumps(optimized_ir,ensure_ascii=False,indent=2)+'\n')
print('Removed',sum(c['removed_dead_assignments']for c in counts.values()),'dead assignments/clears')
