"""Separate the original padding routine from meaningful application locals."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
p=ROOT/'new_sigma_pred.full_source.lua';source=p.read_text()
start=source.index('    padding_count = 2000\n')
finish=source.index('    bit_band = environment.bit\n',start)
fragment=source[start:finish]
prefix,rest=fragment.split('    padding_lines = new_table(256)\n',1)
values={};words={}
for line in prefix.splitlines():
    if line.strip()in ('padding_count = 2000','padding_words = new_table(45)'):continue
    literal=re.fullmatch(r'    (\w+) = ("(?:\\.|[^"\\])*")',line)
    if literal:values[literal[1]]=literal[2];continue
    assign=re.fullmatch(r'    padding_words\[(\d+)\] = (\w+)',line)
    assert assign,line
    words[int(assign[1])]=values[assign[2]]
assert sorted(words)==list(range(1,202))
block=['    -- Original padding: builds unused text and advances the random generator.',
       '    -- Kept separate from the real GameSense API bindings below.',
       '    do','        local padding_words = new_table(45)']
block+=['        padding_words[%d] = %s'%(i,words[i])for i in range(1,202)]
block+=['        local padding_lines = new_table(256)',
        '        for padding_index = 1, 2000 do',
        '            local append_line = environment.table.insert',
        '            local to_string = environment.tostring',
        '            local random_index = environment.math.random(1, #padding_words)',
        '            local word = to_string(padding_words[random_index])',
        '            append_line(padding_lines, "aMdoSpbPT = \'" .. word .. "\'")',
        '        end',
        '        environment.table.concat(padding_lines, "\\010")',
        '    end']
source=source[:start]+'\n'.join(block)+'\n'+source[finish:]
source=source.replace('return_varargs, padding_count, padding_words, padding_lines, bit_band,','return_varargs, bit_band,',1)
p.write_text(source)
(ROOT/'padding_cleanup.json').write_text(json.dumps({'words':201,'padding_iterations':2000,'preserved_random_calls':True,'api_aliases_no_longer_reused_for_padding':True},indent=2)+'\n')
print('Separated padding vocabulary and preserved 2000 random draws')
