from pathlib import Path
import json,re,os
from unpack_sigma import unpack
from lupa.luajit21 import lua_type
ROOT=Path(__file__).resolve().parent
fixture=(ROOT/'gamesense_fixture.lua').read_bytes()
original=(ROOT/'new_sigma_pred.original.lua').read_bytes()
prefix=original[:original.index(b'for l,e in pairs({(function')]
source=(ROOT/os.environ.get('SIGMA_SOURCE',('new_sigma_pred.readable.lua'if os.environ.get('SIGMA_READABLE')else 'new_sigma_pred.source.lua'))).read_bytes()

def run(recovered=False):
 lua,result=unpack()
 lua.execute(fixture)
 lua.execute(b'''
 trace={}
 local function encode(value)
  if type(value)=='function'then return '<function>'end
  if type(value)=='table'then local copy={};for k,v in pairs(value)do copy[k]=encode(v)end;return copy end
  return value
 end
 for _,module in ipairs({'ui','client','renderer','database','plist'})do
  for name,fn in pairs(_G[module])do
   if type(fn)=='function'then
    _G[module][name]=function(...)
     trace[#trace+1]={module=module,name=name,args=encode({...})}
     return fn(...)
    end
   end
  end
 end
 client.trace_bullet=function()return 0,0 end
 client.scale_damage=function(player,hitgroup,damage)return damage end
 fixture_world=false
entity.get_local_player=function()return fixture_world and 1 or nil end
entity.is_alive=function()return fixture_world end
entity.get_players=function()return {2}end
entity.get_all=function()return {}end
entity.get_player_resource=function()return 65 end
entity.hitbox_position=function(id)return id*20,0,64 end
entity.get_prop=function(id,name,index)
 if name=='m_vecOrigin'then return id*20,0,0 end
 if name=='m_vecVelocity'then return 0,0,0 end
 if name=='m_flPoseParameter'then return 0.5 end
 if name=='m_iTeamNum'then return id==1 and 3 or 2 end
 if name=='m_fFlags'then return 1 end
 if name=='m_iPing'then return 40 end
 return 0
end
client.userid_to_entindex=function(id)return id end
client.trace_line=function()return 1,0 end
client.trace_bullet=function()return 0,0 end
 client.scale_damage=function(player,hitgroup,damage)return damage end
client.eye_position=function()return 20,0,64 end
client.camera_angles=function()return 0,0 end
 entity.hitbox_position=function(id)return id*20,0,64 end
 entity.get_player_resource=function()return 65 end
 client.camera_angles=function()return 0,0 end
 entity.hitbox_position=function(id)return id*20,0,64 end
 entity.get_player_resource=function()return 65 end
 globals.curtime=function()return 120 end
 panorama.loadstring=function()return function()return '76561198000000000'end end
 ''')
 if recovered:lua.execute(source)
 else:
  lua.execute(prefix)
  result[b'vm'](result[b'proto'],lua.table(),result[b'env'])()
 return lua,result

EXERCISE=b'''
local outcomes={}
local function call(label,fn,arg)
 local ok,why=pcall(fn,arg)
 outcomes[#outcomes+1]={label=label,ok=ok,error=not ok and tostring(why)or nil}
end
local controls=sigma_controls()
for _,c in pairs(controls)do
 if c.name=='Fake yaw limit'then c.kind='slider';c.value=60 end
 if c.name=='Limit'then c.kind='slider';c.value=14 end
 if c.name=='sv_maxusrcmdprocessticks'then c.kind='slider';c.value=16 end
end
fixture_world=true
for variant=1,3 do
 for id,c in pairs(controls)do
  if c.callback then
   c.value=variant==1 and {}or variant==2 and {'On E','Manual AA','Freestanding'}or c.options
   call('ui:'..variant..':'..c.name,c.callback,id)
  end
  if c.kind=='checkbox'then c.value=variant==3 end
 end
 for index,e in ipairs(events)do
  local data={userid=1,attacker=2,weapon='ssg08',hitgroup=1,target=2,x=40,y=0,z=64,
   chokedcommands=variant-1,in_jump=0,in_use=0,command_number=64+variant}
  if e[1]=='paint'or e[1]=='paint_ui'or e[1]=='shutdown'then data=nil end
  call('event:'..variant..':'..index..':'..e[1],e[2],data)
 end
end
return outcomes
'''

def plain(v):
 if lua_type(v)=='table':return {k.decode()if isinstance(k,bytes)else k:plain(x)for k,x in v.items()}
 if isinstance(v,bytes):return v.decode('utf-8',errors='backslashreplace')
 return v

if __name__=='__main__':
 outcomes={}
 for recovered in (False,True):
  label='recovered'if recovered else 'original'
  try:
   lua,result=run(recovered)
   stats=lua.eval(b'fixture_stats')();trace=plain(lua.globals().trace)
   exercised=plain(lua.execute(EXERCISE));trace=plain(lua.globals().trace)
   for row in exercised.values():
    if row.get('error'):
     # Source locations and temporary variable names differ after lifting.
     row['error']=re.sub(r'^.*?:\d+: ','',row['error'])
     row['error']=re.sub(r"\([^)]*'(?:r|l|e|n|o)'[^)]*\)",'',row['error'])
   outcomes[label]={'stats':stats,'trace':trace,'exercises':exercised}
   print(label,stats,'host calls',len(trace))
  except Exception as error:
   print(label,'ERROR',error);raise
 if outcomes['original']!=outcomes['recovered']:
  (ROOT/'exercise_failure.json').write_text(json.dumps(outcomes,ensure_ascii=False,indent=2))
  raise AssertionError('Host traces differ; see exercise_failure.json')
 failures=[r for r in outcomes['original']['exercises'].values()if not r['ok']]
 (ROOT/('structured_callback_validation.json'if os.environ.get('SIGMA_SOURCE')else 'readable_validation.json'if os.environ.get('SIGMA_READABLE')else 'startup_validation.json')).write_text(json.dumps({'matched':True,'stats':outcomes['original']['stats'],'host_calls':len(outcomes['original']['trace']),'callback_cases':len(outcomes['original']['exercises']),'fixture_limited_callback_failures':failures,'gameplay_tested':False},indent=2)+'\n')
 print('STARTUP TRACES MATCH')
