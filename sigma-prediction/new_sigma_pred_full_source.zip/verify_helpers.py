from pathlib import Path
import math,json,random
from unpack_sigma import unpack
from lupa.luajit21 import lua_type
ROOT=Path(__file__).resolve().parent

def prototypes(proto):
 result=[proto]
 for _,child in sorted(proto[b'm0Y6bQ0S'].items()):result+=prototypes(child)
 return result
def table(lua,value):
 if isinstance(value,dict):return lua.table_from({k.encode()if isinstance(k,str)else k:table(lua,v)for k,v in value.items()})
 if isinstance(value,(tuple,list)):return lua.table_from({i+1:table(lua,v)for i,v in enumerate(value)})
 if isinstance(value,str):return value.encode()
 return value
def plain(value):
 if lua_type(value)=='table':return {k.decode()if isinstance(k,bytes)else k:plain(v)for k,v in value.items()}
 if isinstance(value,float)and math.isnan(value):return '<nan>'
 if isinstance(value,bytes):return value.decode('utf-8',errors='backslashreplace')
 return value
def scenarios():
 cases=[]
 def add(function,args,up='{}',setup=''):
  cases.append({'function':function,'args':{**{i+1:v for i,v in enumerate(args)},'n':len(args)},'up':up,'setup':setup})
 for args in [[],[None],[1,None,False,'x'],[1,2,3,4,5,6]]:add(1,args)
 for sequence in [None,[],[1,2,3],['a','b'],{0:'zero',1:'one'},123]:
  for target in [None,False,1,3,'a','missing']:add(3,[sequence,target],'{[0]=type,[1]=tostring}')
 for angle in [-1080,-540,-360,-181,-180,-179,0,179,180,181,360,540,1080]+[random.Random(i).uniform(-100000,100000)for i in range(100)]:add(5,[angle])
 for i in range(50):
  r=random.Random(i);values=[r.uniform(-100,100)for _ in range(4)]
  add(6,values,'{[0]=math.atan,[1]=function(y)while y>180 do y=y-360 end;while y< -180 do y=y+360 end;return y end}')
 for a,b in [([0,0,0],[1,2,3]),([9,8,7],[1,2,3]),([-9,8,-7],[5,-2,3]),([0,0,0],[0,0,0])]:
  for flatten in [None,False,True]:add(7,[a,b,flatten])
 for i in range(40):
  r=random.Random(i);a=[r.uniform(-100,100)for _ in range(3)];b=[r.uniform(-100,100)for _ in range(3)]
  add(9,[a,b,{'x':r.random()*30,'y':r.random()*30}],'{[0]=function(v)return unpack(v)end,[1]=math.sqrt}')
 for sign in [0,-1,1]:
  for pose in [0,0.25,0.5,0.75,1]:add(11,[7],'{[0]={desync=%d},[1]=function()return %s end}'%(sign,pose))
 for a in [-89,0,45,89]:
  for b in [-180,-90,0,90,180]:add(13,[a,b],'{[0]=math.sin,[1]=math.rad,[2]=math.cos}')
 for a,b in [(0,0),(1,0),(0,1),(-1,0),(0,-1),(3,4),(-3,-4)]:add(15,[a,b],'{[0]=math.deg,[1]=math.atan2}')
 for alive in ['true','false']:
  for dormant in ['true','false']:
   for target in [0,1,64]:add(18,[target],'{[0]=function()return %s end,[1]=function()return %s end}'%(alive,dormant))
 for angle in [-180,-90,0,45,90,180,360]:
  for radius in [0,1,20]:add(23,[10,15,angle,radius],'{[0]=math.cos,[1]=math.rad,[2]=math.sin}')
 for enabled in ['true','false']:
  for x,y in [(0,0),(5,5),(10,10),(-1,-1),(11,5)]:add(35,[0,0,10,10],'{[0]=1}', 'ui={mouse_position=function()return %s,%s end,get=function()return %s end}'%(x,y,enabled))
 for choke in [0,1,4,16]:add(36,[{'chokedcommands':choke}],'{[0]=999}')
 return cases

def execute(mode,cases):
 lua,result=unpack();ps=prototypes(result[b'proto']);env=result[b'env']
 if mode!='original':
  source=(ROOT/('native_test_factories.lua'if mode=='native'else 'new_sigma_pred.source.lua'if mode=='faithful'else 'new_sigma_pred.structured.lua'if mode=='structured'else 'new_sigma_pred.readable.lua')).read_text()
  if mode!='native':source=source[source.index('local env = getfenv()'):].replace('return functions[0](env,nil)(...)','return functions')
  factories=lua.execute(source.encode())
 invoke=lua.eval(b'function(fn,args,up)local function pack(...)return {n=select("#",...),...}end;return {result=pack(fn(unpack(args,1,args.n))),up=up}end')
 results=[]
 for case in cases:
  if case['setup']:lua.execute(case['setup'].encode())
  up=lua.eval(case['up'].encode());args=table(lua,case['args']);fid=case['function']
  fn=result[b'vm'](ps[fid],up,env)if mode=='original'else factories[fid](env,up)
  # Return only scalar/table state, not the callable helpers in the upvalue fixture.
  response=invoke(fn,args,up);response[b'up']=lua.table_from({k:v for k,v in up.items()if lua_type(v)!='function'})
  results.append(plain(response))
 return results

if __name__=='__main__':
 cases=scenarios();baseline=execute('original',cases)
 for mode in ['faithful','readable','structured','native']:
  values=execute(mode,cases)
  for index,(a,b)in enumerate(zip(baseline,values)):
   assert a==b,(mode,index,cases[index],a,b)
  print(mode,len(values),'helper comparisons passed')
 (ROOT/'helper_validation.json').write_text(json.dumps({'cases_per_variant':len(cases),'functions_tested':sorted(set(c['function']for c in cases)),'variants':['faithful','readable','structured','native'],'matched_original_vm':True},indent=2)+'\n')
