                                    struct {
                                        char pad_0000[8];
                                        int32_t	client;
                                        int32_t	audible_mask;
                                        uint32_t xuid_low;
                                        uint32_t xuid_high;
                                        void* voice_data;
                                        bool proximity;
                                        bool caster;
                                        char pad_001E[2];
                                        int32_t	format;
                                        int32_t	sequence_bytes;
                                        uint32_t section_number;
                                        uint32_t uncompressed_sample_offset;
                                        char pad_0030[4];
                                        uint32_t has_bits;
                                    } *
                                