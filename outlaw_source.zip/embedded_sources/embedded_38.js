                                let context_panel = $.GetContextPanel();
        
                                let _set_icon = function(entity_index, icon) {
                                    let xuid = GameStateAPI.GetPlayerXuidStringFromEntIndex(entity_index);
                                    let ctx = context_panel.FindChildTraverse('ScoreboardContainer').FindChildTraverse('Scoreboard') || context_panel.FindChildTraverse('id-eom-scoreboard-container').FindChildTraverse('Scoreboard')
                                    if (ctx == null)
                                        return;
        
                                    ctx.FindChildrenWithClassTraverse('sb-row').forEach(function(e) {
                                        if (e.m_xuid != xuid)
                                            return false;
        
                                        e.Children().forEach(function(child) {
                                            let attribute = child.GetAttributeString('data-stat', '');
                                            if (attribute != 'rank')
                                                return false;
        
                                            var image = child.FindChildTraverse('image');
                                            if (!image || !image.IsValid())
                                                return false;
        
                                            image.SetImage(icon === null ? '' : icon)
                                            return true;
                                        })
                                    })
        
                                    return xuid;
                                }
        
                                return {
                                    set_icon: _set_icon
                                }
                            