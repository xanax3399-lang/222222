        typedef uint32_t request_handle_t;
        typedef uint64_t steam_api_call_t;
        typedef struct {
            void* __pad[12];
            void* steam_http;
        } steam_ctx_t;
        typedef uint32_t(__thiscall* create_http_request_t)(void*, uint32_t, const char*);
        typedef bool(__thiscall* send_http_request_t)(void* _this, request_handle_t handle, steam_api_call_t call_handle);
        typedef bool(__thiscall* get_http_response_header_size_t)(void* _this, request_handle_t hRequest, const char *pchHeaderName, uint32_t *unResponseHeaderSize );
        typedef bool(__thiscall* get_http_response_header_value_t)(void* _this, request_handle_t hRequest, const char *pchHeaderName, char *pHeaderValueBuffer, uint32_t unBufferSize);
        typedef bool(__thiscall* get_http_response_body_size_t)(void* _this, request_handle_t hRequest, uint32_t *unBodySize );
        typedef bool(__thiscall* get_http_response_body_data_t)(void* _this, request_handle_t hRequest, char *pBodyDataBuf, uint32_t unBufferSize );
        typedef bool(__thiscall* set_http_request_param_t)(void* _this, request_handle_t hRequest, const char* pchParamName, const char* pchParamValue);
        typedef bool(__thiscall* release_http_request_t)(void* _this, request_handle_t hRequest);
        typedef bool(__thiscall* set_http_request_user_agent_info_t)(void* _this, request_handle_t hRequest, const char *pchUserAgentInfo);
    