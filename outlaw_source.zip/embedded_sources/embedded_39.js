                                let context_panel = $.GetContextPanel();
        
                                let _SetVisible = function(visible) {
                                    let hud_money_panel = context_panel.FindChildTraverse('HudMoney');
        
                                    hud_money_panel.visible = visible;
                                }
        
                                return {
                                    set_visible: _SetVisible
                                }
                            