                                struct {
                                    char pad0[0x18];
                                    uint32_t sequence;
                                    float prev_cycle;
                                    float weight;
                                    float weight_delta_rate;
                                    float playback_rate;
                                    float cycle;
                                    void *entity;
                                    char pad1[0x4];
                                } **
                            