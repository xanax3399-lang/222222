                                let context_panel = $.GetContextPanel();
        
                                let _SetVisible = function(visible) {
                                    // health
                                    let health_panel = context_panel.FindChildTraverse('HudHealthArmor');
        
                                    let health_background_bar = health_panel.FindChildTraverse('HudHealthBG');
        
                                    let health_progress_bar = health_panel.FindChildTraverse('HealthBar');
        
                                    health_background_bar.visible = visible;
                                    health_progress_bar.visible = visible;
        
                                    // armor
                                    let armor_panel = context_panel.FindChildTraverse('HudHealthArmor');
        
                                    let armor_background_bar = health_panel.FindChildTraverse('HudHealthBG');
        
                                    let armor_progress_bar = armor_panel.FindChildTraverse('ArmorBar');
        
                                    armor_background_bar.visible = visible;
                                    armor_progress_bar.visible = visible;
                                }
        
                                return {
                                    set_visible: _SetVisible
                                }
                            