                                let context_panel = $.GetContextPanel();
        
                                let panel;
        
                                let _CreatePanel = function() {
                                    if (panel != null)
                                        return;
        
                                    panel = $.CreatePanel('Label', context_panel, 'watermark');
        
                                    panel.style = {}
                                    panel.style['font-family'] = "Stratum2, 'Arial Unicode MS'";
                                    panel.style['font-weight'] = 'bold';
                                    panel.style['font-size'] = '19px';
                                    panel.style['-s2-mix-blend-mode'] = 'normal';
                                    panel.style['opacity'] = 0.9;
                                    panel.style['text-shadow'] = '0px 0px 3px 0.0 #000000DD';
        
                                    panel.style['text-align'] = 'center';
        
                                    panel.style['width'] = '100px';
                                    panel.style['height'] = '2%';
                                    panel.style['background-color'] = 'gradient( linear, 0% 0%, 100% 0%, from( #00000000 ), color-stop( 0.5, #00000080 ), to( #00000000 ) )';
                                }
        
                                let _ChangeText = function(text) {
                                    if (panel == null)
                                        return;
        
                                    panel.text = text;
                                }
        
                                let _ChangeColor = function(color) {
                                    if (panel == null)
                                        return;
        
                                    panel.style.color = color;
                                }
        
                                let _ChangePosition = function(horizontal, vertical) {
                                    if (panel == null)
                                        return;
        
                                    panel.style['horizontal-align'] = horizontal;
                                    panel.style['vertical-align'] = vertical;
        
                                    if (horizontal == 'right') {
                                        panel.style['margin'] = '10px 14px 0px 0px';
                                    } else {
                                        panel.style['margin'] = '0px 0px 0px 0px';
                                    }
                                }
        
                                let _Delete = function() {
                                    if (panel == null)
                                        return;
        
                                    panel.RemoveAndDeleteChildren();
        
                                    panel.DeleteAsync(0);
        
                                    panel = null;
                                }
        
                                return {
                                    create_panel: _CreatePanel,
                                    change_text: _ChangeText,
                                    change_position: _ChangePosition,
                                    change_color: _ChangeColor,
                                    delete: _Delete
                                }
                            