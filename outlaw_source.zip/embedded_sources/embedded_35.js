                        let context_panel = $.GetContextPanel();
        
                        let _GetText = function(text) {
                            let hud_radar = context_panel.FindChildTraverse('HudRadar');
        
                            let dashboard_label = hud_radar.FindChildTraverse('DashboardLabel')
        
                            return dashboard_label.text;
                        }
        
                        let _ChangeText = function(text) {
                            let hud_radar = context_panel.FindChildTraverse('HudRadar');
        
                            let dashboard_label = hud_radar.FindChildTraverse('DashboardLabel')
        
                            dashboard_label.text = text;
                        }
        
                        let _ChangeColor = function(color) {
                            let hud_radar = context_panel.FindChildTraverse('HudRadar');
        
                            let dashboard_label = hud_radar.FindChildTraverse('DashboardLabel')
        
                            dashboard_label.style['wash-color'] = color;
                        }
        
                        return {
                            get_text: _GetText,
                            change_text: _ChangeText,
                            change_color: _ChangeColor
                        }
                    