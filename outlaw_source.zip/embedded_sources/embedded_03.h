        typedef union {
            uint64_t steamid64;
            struct {
                uint32_t accountid : 32;
                unsigned int instance : 20;
                unsigned int type : 4;
                unsigned int universe : 8;
            };
            struct {
                uint32_t low;
                uint32_t high;
            };
        } __attribute__((packed)) SteamID;
    