from pathlib import Path
import collections,hashlib,json,re
import validate

ROOT=Path(__file__).resolve().parent
original=validate.INPUT.read_text()
source=(ROOT/'andromeda_source.lua').read_text()
flat=(ROOT/'andromeda_flat_source.lua').read_text()
lua,module=validate.runtime(original)
strings={}
index=[]
stats=json.loads((ROOT/'recovery_stats.json').read_text())
special={1:'adapted application entry already present in input',2:'environment failure diagnostic already present in input',
         29:'SHA-256 / HMAC module',47:'replaced crash routine in supplied input',96:'application initializer',
         108:'empty function in supplied input',109:'replaced crash routine in supplied input',
         115:'empty function in supplied input',116:'replaced crash routine in supplied input',
         403:'repeating-key byte XOR implementation already substituted in input',
         416:'empty function in supplied input',418:'replaced crash routine in supplied input'}
for fid in range(1,565):
    proto=module[b'D'][f'f{fid}'.encode()]
    marker=re.search(r'^F\.f'+str(fid)+r'\s*=',source,re.M)
    flat_marker=re.search(r'^F\.f'+str(fid)+r'\s*=',flat,re.M)
    assert marker and flat_marker
    captures=[]
    for i,item in sorted(proto[4].items()): captures.append({'position':i-1,'capture_kind':item[2],'source_slot':item[1]})
    index.append({'id':fid,'source_line':source.count('\n',0,marker.start())+1,
                  'flat_source_line':flat.count('\n',0,flat_marker.start())+1,
                  'description':special.get(fid,'expanded application function; author name unavailable'),
                  'frame_size_in_input':proto[7], 'captures':captures,
                  'scalar_slots_recovered':stats[str(fid)].get('scalar_slots',0)})
    for array_slot in [1,2,3,6,8,10,11]:
        array=proto[array_slot]
        if array is None:continue
        for key,value in array.items():
            if isinstance(value,bytes):strings.setdefault(value,[]).append([fid,array_slot,key])
catalog=[]
for value,uses in sorted(strings.items(),key=lambda x:x[0]):
    record={'byte_length':len(value),'locations':uses}
    try: record['text_utf8']=value.decode('utf-8')
    except UnicodeDecodeError:record['bytes_hex']=value.hex()
    catalog.append(record)
(ROOT/'function_index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
(ROOT/'constant_strings.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
modules=sorted(set(re.findall(r'gamesense/[A-Za-z_0-9/-]+',original)))
report={'input_sha256':hashlib.sha256(validate.INPUT.read_bytes()).hexdigest(),
        'source_sha256':hashlib.sha256((ROOT/'andromeda_source.lua').read_bytes()).hexdigest(),
        'flat_source_sha256':hashlib.sha256((ROOT/'andromeda_flat_source.lua').read_bytes()).hexdigest(),
        'factories':len(index),'inherited_replaced_or_empty_factories':[1,2,47,108,109,115,116,403,416,418],
        'inherited_destroyed_instruction_checks':original.count('ANDROMEDA_DESTROYED_INSTRUCTION:'),
        'unique_metadata_byte_strings':len(strings),
        'functions_with_scalar_slots':sum(bool(row['scalar_slots_recovered']) for row in index),
        'game_client_tested':False,'original_author_project_available':False,
        'visible_module_references':modules,
        'source_bytes':len(source.encode()),'source_lines':len(source.splitlines()),
        'flat_source_bytes':len(flat.encode()),'flat_source_lines':len(flat.splitlines()),
        'input_bytes':len(validate.INPUT.read_bytes()),'input_lines':len(original.splitlines()),
        'remaining_representation':'mutable frames/capture cells and explicit goto labels retained where needed'}
(ROOT/'manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
