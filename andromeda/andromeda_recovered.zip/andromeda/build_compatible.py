"""Keep the original application chunk boundaries for LuaJIT's jump limit."""
from pathlib import Path
import contextlib,io,re,json
from luaparser import ast
from luaparser import astnodes as n
import recover

ROOT=Path(__file__).resolve().parent
source=recover.INPUT.read_text()
start=source.index('F.f96=function(function_metadata,upvalues)')
end=source.index('-- Function f97;')
text=source[start:end]
with contextlib.redirect_stdout(io.StringIO()): tree=ast.parse(text)
for node in recover.walk(tree):
    if isinstance(node,n.String):
        raw=text[node.first_token.start:node.last_token.stop+1].strip()
        while raw.startswith('(') and raw.endswith(')'):raw=raw[1:-1].strip()
        node.raw_literal=raw
inner=tree.body.body[0].values[0].body.body[-1].values[0]
count=0
for statement in inner.body.body:
    if (isinstance(statement,n.Assign) and isinstance(statement.targets[0],n.Index)
        and isinstance(statement.targets[0].value,n.Name) and statement.targets[0].value.id=='chunks'):
        fn=statement.values[0]
        fake='F.f96=function(function_metadata,upvalues)\nreturn function(...)\n'+recover.render(fn.body)+'\nend\nend'
        _,normalized,_=recover.process((96,fake,'chunk'))
        with contextlib.redirect_stdout(io.StringIO()): parsed=ast.parse(normalized)
        # The normalized source must supply raw literals relative to its own tokens.
        for node in recover.walk(parsed):
            if isinstance(node,n.String):
                raw=normalized[node.first_token.start:node.last_token.stop+1].strip()
                while raw.startswith('(') and raw.endswith(')'):raw=raw[1:-1].strip()
                node.raw_literal=raw
        fn.body=parsed.body.body[0].values[0].body.body[-1].values[0].body
        count+=1
        if count%5==0: print('Normalized application chunk',count,flush=True)
assert count==35
for i,statement in enumerate(inner.body.body):
    if isinstance(statement,n.LocalFunction) and statement.name.id=='tick':
        fid_string=next(x for x in recover.walk(statement) if isinstance(x,n.String) and x.raw_literal=='"f96"')
        inner.body.body[i]=n.LocalAssign([n.Name('tick')],[n.Call(n.Name('new_tick'),[fid_string])])
inner.body=recover.prune_declarations(inner.body)
compatible=recover.render(tree)
primary=(ROOT/'andromeda_source.lua').read_text()
(ROOT/'andromeda_flat_source.lua').write_text(primary)
(ROOT/'functions/f096_flat.lua').write_text((ROOT/'functions/f096.lua').read_text())
(ROOT/'functions/f096.lua').write_text('-- Recovered application function; original LuaJIT chunk boundaries retained.\n'+compatible+'\n')
start=primary.index('-- Recovered function f96\n')
end=primary.index('-- Recovered function f97\n',start)
primary=primary[:start]+'-- Recovered function f96\n'+compatible+'\n'+primary[end:]
(ROOT/'andromeda_source.lua').write_text(primary)
print('GameSense-compatible source written; flat source retained for analysis.',flush=True)
