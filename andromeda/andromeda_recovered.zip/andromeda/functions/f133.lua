-- Recovered function f133; author names are unavailable.
F.f133 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f133")
        tick(1)
        goto p102
        ::p10::
        tick(10)
        registers[1] = upvalues[1]
        registers[2] = "paint_ui:watermark";
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p99
        end
        goto p169
        ::p39::
        tick(39)
        registers[4] = upvalues[4]
        registers[5] = registers[1]["watermark_accent_color"]
        registers[6] = new_frame(4)
        goto p138
        ::p43::
        tick(43)
        registers[6] = upvalues[5]
        registers[7] = registers[1]["watermark_display"]
        registers[8] = registers[3]
        goto p162
        ::p47::
        tick(47)
        registers[3] = "Top Right"
        goto p97
        ::p55::
        tick(55)
        registers[5] = (110)
        goto p43
        ::p58::
        tick(58)
        registers[5] = registers[1]["watermark_cs2_gradient"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        goto p111
        ::p64::
        tick(64)
        q = registers[(6)]
        q[1] = registers[7]
        q[2] = registers[8]
        q[3] = registers[9]
        q[4] = registers[10]
        registers[4] = registers[4](registers[5], registers[6])
        registers[5] = registers[1]["watermark_cs2_gradient"]
        registers[5] = (registers[5] ~= registers[0])
        if not registers[5] then
            goto p111
        end
        goto p58
        ::p76::
        tick(76)
        if registers[1] == registers[0] then
            goto p168
        end
        goto p135
        ::p91::
        tick(91)
        do
            return 
        end
        ::p97::
        tick(97)
        if registers[2] ~= "Supremacy" then
            goto p39
        end
        goto p150
        ::p99::
        registers[1] = upvalues[2]["visuals"]
        if not registers[1] then
            goto p76
        end
        goto p143
        ::p102::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p10
        end
        goto p91
        ::p107::
        tick(107)
        registers[3] = registers[1]["watermark_position"]
        registers[3] = (registers[3] ~= registers[0])
        if not registers[3] then
            goto p129
        end
        goto p131
        ::p111::
        if registers[5] then
            goto p43
        end
        goto p55
        ::p114::
        tick(114)
        registers[3] = registers[1]["watermark"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p179
        end
        goto p168
        ::p121::
        tick(121)
        registers[2] = registers[1]["watermark_style"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        goto p147
        ::p129::
        tick(129)
        if registers[3] then
            goto p97
        end
        goto p47
        ::p131::
        registers[3] = registers[1]["watermark_position"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        goto p129
        ::p135::
        registers[2] = registers[1]["watermark"]
        if registers[2] == registers[0] then
            goto p168
        end
        goto p114
        ::p138::
        registers[7] = (186)
        registers[8] = (255)
        registers[9] = (15)
        registers[10] = (255)
        goto p64
        ::p143::
        registers[1] = upvalues[2]["visuals"]
        registers[1] = registers[1]["stubs"]
        goto p76
        ::p147::
        tick(147)
        if registers[2] then
            goto p107
        end
        goto p166
        ::p150::
        registers[4] = upvalues[3]
        registers[5] = registers[3]
        registers[(4)](registers[5])
        do
            return 
        end
        ::p162::
        registers[9] = registers[4]
        registers[10] = registers[5]
        registers[(6)](unpack_range(10, registers, 7))
        do
            return 
        end
        ::p166::
        registers[2] = "CS2"
        goto p107
        ::p168::
        do
            return 
        end
        ::p169::
        do
            return 
        end
        ::p179::
        registers[2] = registers[1]["watermark_style"]
        registers[2] = (registers[2] ~= registers[0])
        if not registers[2] then
            goto p147
        end
        goto p121
    end
end
