-- Recovered function f52; author names are unavailable.
F.f52 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f52")
        tick(1)
        goto p113
        ::p3::
        tick(3)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        goto p172
        ::p6::
        tick(6)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p229
        end
        goto p120
        ::p16::
        tick(16)
        registers[10] = (0)
        registers[11] = (255)
        registers[12] = (1)
        goto p48
        ::p42::
        tick(42)
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        goto p65
        ::p48::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p86
        ::p49::
        tick(49)
        registers[17] = upvalues[0]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(15)]
        for f = 1, top - (15) do
            q[(0) + f] = registers[(15) + f]
        end
        registers[5][registers[14]] = registers[15]
        goto p86
        ::p54::
        tick(54)
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        goto p127
        ::p63::
        tick(63)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p6
        goto p163
        ::p65::
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        registers[10] = upvalues[1]
        goto p54
        ::p79::
        tick(79)
        registers[26] = 415 + registers[26]
        registers[26] = registers[26] + -577
        registers[19][179] = registers[26]
        registers[25][220] = 171
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        registers[28] = nil
        registers[29] = nil
        goto p172
        ::p86::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p93
        end
        goto p227
        ::p91::
        tick(91)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p16
        end
        goto p157
        ::p93::
        registers[14] = upvalues[2];
        registers[14] = registers[14]()
        if not registers[14] then
            goto p209
        end
        goto p159
        ::p97::
        tick(97)
        registers[26] = constant_cache[10]
        a = registers
        z = 27;
        a[z] = "\1745\186"
        registers[28] = (2)
        registers[29] = nil;
        registers[26] = registers[26](unpack_range(29, registers, 27))
        goto p193
        ::p113::
        registers[1] = (1)
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        goto p136
        ::p117::
        tick(117);
        registers[7] = registers[7]()
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p91
        ::p120::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[6] = (1)
        registers[7] = upvalues[0]
        goto p117
        ::p127::
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        a = registers
        z = 5
        a = a[z]
        z = registers
        q = (10)
        z = z[q]
        q = registers
        m = 11
        q = q[m]
        a[z] = q
        goto p6
        ::p136::
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p217
        goto p91
        ::p148::
        tick(148)
        registers[26] = (380)
        goto p79
        ::p150::
        tick(150)
        registers[15] = upvalues[1]
        a = registers
        z = 16
        q = upvalues
        q = q[2]
        a[z] = q;
        registers[16] = registers[16]()
        goto p251
        ::p157::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p246
        ::p159::
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p209
        ::p163::
        registers[19] = code_metadata
        registers[25] = operand_k
        registers[26] = 454
        registers[27] = constant_cache[5]
        registers[28] = constant_cache[6];
        registers[(27)] = registers[(27)](registers[28])
        registers[26] = registers[26] < registers[27]
        if not registers[26] then
            goto p193
        end
        goto p97
        ::p172::
        tick(172)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[3]
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[16] = upvalues[0]
        m, x = pack_returns(registers[16]())
        m = m + 16 - 1
        top = m
        z = 0
        for f = 16, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[15] = new_frame(1)
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        goto p49
        ::p193::
        tick(193)
        if registers[26] then
            goto p79
        end
        goto p148
        ::p205::
        tick(205)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[1]
        registers[2] = upvalues[2]
        goto p234
        ::p209::
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[15] = registers[5][registers[15]]
        if registers[15] then
            goto p239
        end
        goto p150
        ::p217::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p246
        end
        goto p205
        ::p227::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p91
        ::p229::
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        goto p42
        ::p234::;
        registers[2] = registers[2]()
        registers[3] = upvalues[0]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p239::
        tick(239)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        if not registers[15] then
            goto p172
        end
        goto p3
        ::p246::
        registers[5] = {
        }
        registers[6] = (0)
        registers[7] = (255)
        registers[8] = (1)
        goto p63
        ::p251::
        registers[17] = upvalues[2]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        goto p239
    end
end
