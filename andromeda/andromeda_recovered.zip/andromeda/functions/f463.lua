-- Recovered function f463; author names are unavailable.
F.f463 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local tick = new_tick("f463")
        tick(1)
        goto p55
        ::p5::
        tick(5)
        do
            return 
        end
        ::p46::
        tick(46)
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["other"]
        if slot_2 == slot_0 then
            goto p5
        end
        slot_3 = upvalues[0]["antiaim"]
        slot_3 = slot_3["other"]
        slot_3 = slot_3["leg_movement"]
        if slot_3 == slot_0 then
            goto p5
        end
        goto p59
        ::p55::
        slot_1 = upvalues[0]["antiaim"]
        if slot_1 == slot_0 then
            goto p5
        end
        goto p46
        ::p59::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["other"]
        slot_1 = slot_1["leg_movement"]
        do
            return slot_1
        end
    end
end
