-- Recovered function f210; author names are unavailable.
F.f210 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f210")
        tick(1)
        goto p37
        ::p9::
        tick(9)
        slot_2 = (false)
        do
            return slot_2
        end
        ::p20::
        tick(20)
        slot_2 = upvalues[0][47]
        slot_3 = slot_1
        slot_4 = "m_nTickBase"
        slot_2 = slot_2(slot_3, slot_4)
        slot_3 = environment["type"]
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        branch_taken = false
        if slot_3 ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p52
        end
        goto p64
        ::p37::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 ~= slot_0 then
            goto p20
        end
        goto p9
        ::p52::
        tick(52)
        slot_3 = upvalues[0][23];
        slot_3 = slot_3()
        slot_3 = slot_3 > slot_2
        do
            return slot_3
        end
        ::p64::
        slot_3 = (false)
        do
            return slot_3
        end
    end
end
