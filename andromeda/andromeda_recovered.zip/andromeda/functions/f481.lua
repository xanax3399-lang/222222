-- Recovered function f481; author names are unavailable.
F.f481 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f481")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0]["pack"]
        slot_4 = slot_2
        goto p62
        ::p28::
        tick(28)
        slot_5 = nil
        do
            return slot_5
        end
        ::p42::
        tick(42)
        if slot_4 ~= "string" then
            goto p79
        end
        goto p95
        ::p53::
        tick(53)
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p55::
        tick(55)
        slot_5 = environment["type"]
        slot_6 = slot_4;
        slot_5 = slot_5(slot_6)
        if slot_5 ~= "string" then
            goto p28
        end
        goto p103
        ::p62::;
        slot_3 = slot_3(slot_4)
        slot_4 = environment["type"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        goto p42
        ::p79::
        tick(79)
        slot_4 = nil
        do
            return slot_4
        end
        ::p88::
        tick(88)
        slot_4 = upvalues[1]["encode"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        goto p55
        ::p95::
        if slot_3 ~= "" then
            goto p88
        end
        goto p79
        ::p103::
        if slot_4 ~= "" then
            goto p53
        end
        goto p28
    end
end
