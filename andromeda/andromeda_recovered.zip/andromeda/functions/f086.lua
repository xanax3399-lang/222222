-- Recovered function f86; author names are unavailable.
F.f86 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f86")
        tick(1)
        goto p31
        ::p2::
        tick(2)
        registers[5] = "%s"
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["format"]
        registers[7] = upvalues[0]["lua"]
        registers[7] = registers[7][registers[4]]
        registers[8] = {
        };
        registers[5] = registers[5](unpack_range(8, registers, 6))
        goto p99
        ::p9::
        tick(9)
        registers[6]["ban_info"] = registers[7]
        registers[(5)](registers[6])
        goto p18
        ::p15::
        tick(15)
        registers[6]["ban_info"] = registers[7]
        registers[(5)](registers[6])
        ::p18::
        tick(18)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p83
        end
        goto p49
        ::p21::
        tick(21)
        registers[5] = registers[5](registers[6], registers[7])
        if registers[5] ~= "function: NULL" then
            goto p2
        end
        goto p60
        ::p31::
        registers[1] = (1)
        registers[2] = upvalues[0]["lua"]
        registers[2] = (#registers[2])
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p18
        registers[20] = code_metadata
        registers[26] = operand_k
        registers[20][99] = 188
        registers[26][82] = 82
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        goto p83
        ::p49::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p60::
        registers[5] = upvalues[1]
        registers[6] = {
        }
        registers[7] = upvalues[2]["CHECK_17_FAILED"]
        registers[6]["ban_num"] = registers[7]
        registers[7] = upvalues[0]["lua_str"]
        registers[7] = registers[7][registers[4]]
        registers[7] = registers[7].." [TS][0x01]"
        goto p15
        ::p83::
        registers[5] = environment["tostring"]
        registers[6] = upvalues[0]["lua"]
        registers[6] = registers[6][registers[4]]
        registers[7] = {
        }
        goto p21
        ::p94::
        tick(94)
        registers[5] = upvalues[1]
        registers[6] = {
        }
        registers[7] = upvalues[2]["CHECK_17_FAILED"]
        goto p101
        ::p99::
        if registers[5] ~= "function: NULL" then
            goto p18
        end
        goto p94
        ::p101::
        registers[6]["ban_num"] = registers[7]
        registers[7] = upvalues[0]["lua_str"]
        registers[7] = registers[7][registers[4]]
        registers[7] = registers[7].." [SF][0x01]"
        goto p9
    end
end
