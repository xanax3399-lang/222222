-- Recovered function f394; author names are unavailable.
F.f394 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f394")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = upvalues[0]["visuals"]
        registers[5] = registers[5]["stubs"]
        registers[5] = registers[5]["feature_indicators_offset"]
        registers[5] = (registers[5] ~= registers[0])
        if not registers[5] then
            goto p234
        end
        goto p72
        ::p15::
        tick(15)
        registers[11] = (registers[11] - 5)
        registers[12] = registers[3] + registers[5]
        registers[12] = registers[12] + 5
        registers[13] = registers[3] + registers[5]
        registers[13] = registers[13] + 15
        goto p214
        ::p22::
        tick(22)
        registers[15] = registers[10]
        registers[16] = registers[12]
        registers[17] = registers[9][1]
        registers[18] = registers[9][2]
        registers[19] = registers[9][3]
        goto p92
        ::p29::
        tick(29)
        m, x = pack_returns(registers[27](unpack_range(29, registers, 28)))
        m = m + 27 - 1
        top = m
        z = 0
        for f = 27, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[18](unpack_range(top, registers, 19))
        goto p85
        ::p32::
        tick(32)
        registers[14] = (false)
        registers[15] = (false)
        registers[16] = (1)
        registers[17] = (#registers[1])
        goto p192
        ::p43::
        tick(43)
        registers[10] = (0)
        registers[11] = (255)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        goto p179
        ::p54::
        tick(54)
        if registers[20] ~= "hide" then
            goto p145
        end
        goto p253
        ::p57::
        tick(57)
        registers[8] = upvalues[2]
        m, x = pack_returns(registers[8]())
        z = 0
        for f = 8, 9 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[2] + 10
        registers[11] = registers[3] + registers[5]
        goto p15
        ::p70::
        tick(70)
        if not registers[14] then
            goto p85
        end
        goto p260
        ::p72::
        registers[5] = upvalues[0]["visuals"]
        registers[5] = registers[5]["stubs"]
        registers[5] = registers[5]["feature_indicators_offset"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"]
        goto p257
        ::p77::
        tick(77)
        registers[20] = registers[1][registers[19]]
        registers[20] = registers[20]["legacy"]
        if registers[20] ~= "dt" then
            goto p54
        end
        goto p218
        ::p81::
        tick(81)
        registers[23] = registers[6]
        registers[(14)](unpack_range(23, registers, 15))
        registers[14] = upvalues[3][131]
        goto p22
        ::p85::
        do
            return 
        end
        ::p86::
        tick(86)
        registers[27] = upvalues[4]
        z = registers[16]
        registers[29] = z;
        registers[(28)] = z["upper"];
        registers[(28)] = registers[(28)](registers[29])
        registers[29] = (1)
        goto p29
        ::p92::
        registers[20] = registers[9][4]
        registers[21] = ""
        registers[22] = (0)
        registers[23] = registers[8]
        registers[(14)](unpack_range(23, registers, 15))
        goto p32
        ::p108::
        tick(108)
        registers[16] = upvalues[4]
        registers[17] = "AA"
        registers[18] = (1)
        registers[16] = registers[16](registers[17], registers[18])
        registers[17] = upvalues[3][131]
        registers[18] = registers[10]
        registers[19] = registers[13]
        registers[20] = (209)
        goto p196
        ::p126::
        tick(126)
        registers[6] = "ANDROMEDA"
        goto p134
        ::p130::
        tick(130)
        registers[6] = upvalues[1]["is_slow_motion"];
        registers[6] = registers[6]()
        if not registers[6] then
            goto p255
        end
        goto p160
        ::p134::
        tick(134)
        registers[7] = upvalues[1]["is_slow_motion"];
        registers[7] = registers[7]()
        if not registers[7] then
            goto p179
        end
        goto p162
        ::p138::
        tick(138)
        registers[18] = upvalues[3][131]
        registers[19] = registers[10]
        registers[20] = registers[13]
        registers[21] = registers[17][1]
        registers[22] = registers[17][2]
        registers[23] = registers[17][3]
        goto p175
        ::p145::
        tick(145)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[19] = v
            branch_taken = true
        end
        if branch_taken then
            goto p77
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not registers[15] then
            goto p70
        end
        goto p108
        ::p160::
        registers[6] = "DANGEROUS"
        goto p255
        ::p162::
        registers[7] = new_frame(4)
        registers[8] = (255)
        registers[9] = (25)
        goto p43
        ::p167::
        tick(167)
        registers[5] = (25)
        goto p130
        ::p175::
        registers[24] = registers[17][4]
        registers[25] = ""
        registers[26] = (0)
        goto p86
        ::p179::
        if registers[7] then
            goto p57
        end
        registers[7] = new_frame(4)
        registers[8] = (218)
        registers[9] = (118)
        registers[10] = (0)
        registers[11] = (255)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        goto p57
        ::p188::
        tick(188)
        registers[20] = registers[7][4]
        registers[21] = ""
        registers[22] = (0)
        goto p81
        ::p192::
        registers[18] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[18] + 0
        n = (registers[17] + 0)
        v = (registers[16] - U)
        goto p145
        goto p204
        ::p196::
        registers[21] = (139)
        registers[22] = (230)
        registers[23] = (255)
        registers[24] = ""
        registers[25] = (0)
        registers[26] = registers[16]
        registers[(17)](unpack_range(26, registers, 18))
        goto p70
        ::p204::
        tick(204)
        registers[17] = registers[7][1]
        registers[18] = registers[7][2]
        registers[19] = registers[7][3]
        goto p188
        ::p214::
        registers[14] = upvalues[3][131]
        registers[15] = registers[10]
        registers[16] = registers[11]
        goto p204
        ::p218::
        registers[14] = (true)
        goto p145
        ::p234::
        tick(234)
        if registers[5] then
            goto p130
        end
        goto p167
        ::p253::
        registers[15] = (true)
        goto p145
        ::p255::
        if registers[6] then
            goto p134
        end
        goto p126
        ::p257::;
        registers[(5)] = registers[(5)](registers[6])
        goto p234
        ::p260::
        registers[16] = upvalues[5]
        registers[17] = registers[4]
        m, x = pack_returns(registers[16](unpack_range(17, registers, 17)))
        z = 0
        for f = 16, 17 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p138
    end
end
