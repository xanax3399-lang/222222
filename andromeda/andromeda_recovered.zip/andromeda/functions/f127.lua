-- Recovered function f127; author names are unavailable.
F.f127 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f127")
        tick(1)
        goto p76
        ::p23::
        tick(23)
        slot_2["Forward"] = 180
        a = upvalues[0];
        slot_3 = a[2][a[1]]["manual"]
        slot_3 = slot_2[slot_3]
        goto p79
        ::p54::
        tick(54)
        a = upvalues[0];
        slot_2 = a[2][a[1]]["manual"]
        if slot_2 ~= slot_0 then
            goto p84
        end
        goto p69
        ::p67::
        tick(67)
        slot_3 = (0)
        goto p83
        ::p69::
        tick(69)
        slot_2 = (0)
        do
            return slot_2
        end
        ::p76::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 then
            goto p69
        end
        goto p54
        ::p79::
        if slot_3 then
            goto p83
        end
        goto p67
        ::p83::
        do
            return slot_3
        end
        ::p84::
        slot_2 = {
        }
        slot_2["Left"] = -90
        slot_2["Right"] = 90
        goto p23
    end
end
