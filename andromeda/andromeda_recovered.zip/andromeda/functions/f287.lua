-- Recovered function f287; author names are unavailable.
F.f287 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f287")
        tick(1)
        goto p61
        ::p2::
        tick(2)
        registers[1] = upvalues[0]["restore_original"]
        registers[(1)]()
        do
            return 
        end
        ::p22::
        tick(22)
        upvalues[0]["active"] = false
        registers[1] = upvalues[1]["set_callback"]
        registers[2] = "setup_command"
        registers[3] = upvalues[0]["setup_command"]
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[1]["set_callback"]
        registers[2] = "paint"
        registers[3] = upvalues[0]["paint"]
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[0]["restore_original"]
        goto p64
        ::p61::
        registers[1] = upvalues[0]["active"]
        if registers[1] then
            goto p22
        end
        goto p2
        ::p64::
        registers[(1)]()
        do
            return 
        end
    end
end
