-- Recovered function f274; author names are unavailable.
F.f274 = function(function_metadata, upvalues)
    local operand_g, code_metadata, operand_k = function_metadata[6], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f274")
        tick(1)
        goto p71
        ::p2::
        tick(2)
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p79
        ::p4::
        tick(4)
        registers[2] = registers[2]["bomb_planting"]
        registers[2] = (registers[2] == true)
        registers[(1)](registers[2])
        registers[1] = upvalues[0]["capture_frame"]
        upvalues[0]["published_frame"] = registers[1]
        goto p62
        ::p20::
        tick(20)
        registers[5] = upvalues[0]["capture_items"]
        registers[5] = registers[5][registers[4]]
        registers[6] = upvalues[0]["render_items"]
        registers[6] = registers[6][registers[4]]
        if registers[6] ~= registers[0] then
            goto p127
        end
        goto p57
        ::p26::
        tick(26)
        registers[3] = upvalues[0]["sort_items"];
        registers[1](registers[2], registers[3])
        registers[1] = upvalues[0]["clear_table"]
        goto p160
        ::p30::
        tick(30)
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p122
        registers[11] = code_metadata
        registers[15] = operand_g
        registers[17] = operand_k
        registers[15][26] = 0
        registers[11][26] = 111
        registers[17][153] = 193
        registers[10] = nil
        registers[11] = nil
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        goto p194
        ::p40::
        tick(40)
        registers[7] = registers[5]["g"]
        registers[6]["g"] = registers[7]
        registers[7] = registers[5]["b"]
        registers[6]["b"] = registers[7]
        registers[7] = registers[5]["a"]
        registers[6]["a"] = registers[7]
        registers[7] = registers[5]["kind"]
        registers[6]["kind"] = registers[7]
        registers[7] = registers[5]["order"]
        registers[6]["order"] = registers[7]
        registers[7] = registers[5]["sequence"]
        registers[6]["sequence"] = registers[7]
        goto p75
        ::p53::
        tick(53)
        registers[3] = upvalues[0]["published_count"]
        registers[4] = upvalues[0]["capture_count"]
        if registers[3] ~= registers[4] then
            goto p167
        end
        goto p185
        ::p57::
        registers[7] = {
        }
        registers[6] = registers[7]
        registers[7] = upvalues[0]["render_items"]
        registers[7][registers[4]] = registers[6]
        goto p127
        ::p62::
        registers[1] = upvalues[0]["capture_count"]
        upvalues[0]["published_count"] = registers[1]
        do
            return 
        end
        ::p66::
        tick(66)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[0]["update_planting_state"]
        registers[2] = upvalues[0]["current_keys"]
        goto p4
        ::p71::
        registers[1] = upvalues[0]["published_frame"]
        registers[2] = upvalues[0]["capture_frame"]
        if registers[1] ~= registers[2] then
            goto p167
        end
        goto p53
        ::p75::
        registers[7] = registers[5]["key"]
        registers[6]["key"] = registers[7]
        registers[7] = registers[6]["key"]
        goto p154
        ::p79::
        tick(79)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p102
        end
        goto p194
        ::p82::
        tick(82)
        registers[7] = upvalues[0]["current_keys"]
        registers[8] = registers[6]["key"]
        registers[7][registers[8]] = true
        registers[7] = upvalues[0]["visible_keys"]
        goto p98
        ::p87::
        tick(87)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[0]["capture_count"]
        registers[1] = registers[1] + 1
        registers[2] = upvalues[0]["max_items"]
        goto p2
        ::p98::
        registers[8] = registers[6]["key"]
        registers[7] = registers[7][registers[8]]
        if registers[7] then
            goto p122
        end
        goto p156
        ::p102::
        registers[5] = upvalues[0]["render_items"]
        registers[5][registers[4]] = registers[0]
        goto p79
        ::p118::
        tick(118)
        upvalues[0]["render_count"] = registers[1]
        registers[1] = (1)
        registers[2] = upvalues[0]["capture_count"]
        goto p30
        ::p122::
        tick(122)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p20
        end
        goto p87
        ::p127::
        registers[7] = registers[5]["text"]
        registers[6]["text"] = registers[7]
        registers[7] = registers[5]["r"]
        registers[6]["r"] = registers[7]
        goto p40
        ::p154::
        if registers[7] == registers[0] then
            goto p122
        end
        goto p82
        ::p156::
        registers[7] = upvalues[0]["reset_animation"]
        registers[8] = registers[6]["key"]
        registers[(7)](registers[8])
        goto p122
        ::p160::
        registers[2] = upvalues[0]["visible_keys"]
        registers[(1)](registers[2])
        registers[1] = environment["pairs"]
        registers[2] = upvalues[0]["current_keys"]
        m, x = pack_returns(registers[1](unpack_range(2, registers, 2)))
        z = 0
        for f = 1, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(1)]
        n = registers[2]
        U = registers[3]
        goto p186
        goto p40
        ::p167::
        registers[1] = upvalues[0]["clear_table"]
        registers[2] = upvalues[0]["current_keys"]
        registers[(1)](registers[2])
        registers[1] = upvalues[0]["capture_count"]
        goto p118
        ::p185::
        do
            return 
        end
        ::p186::
        tick(186)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[2] = z;
            registers[3] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p188
        end
        goto p66
        ::p188::
        registers[3] = upvalues[0]["visible_keys"]
        registers[3][registers[2]] = true
        goto p186
        ::p194::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = environment["table"]
        registers[1] = registers[1]["sort"]
        registers[2] = upvalues[0]["render_items"]
        goto p26
    end
end
