-- Recovered function f238; author names are unavailable.
F.f238 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f238")
        tick(1)
        goto p56
        ::p2::
        tick(2)
        slot_2 = slot_2["hotkey"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        if not slot_2 then
            goto p70
        end
        goto p86
        ::p35::
        tick(35)
        slot_2 = upvalues[0]["is_fake_duck"];
        slot_2 = slot_2()
        slot_2 = not slot_2
        goto p80
        ::p39::
        tick(39)
        slot_2 = slot_2[1]
        slot_2 = slot_2["hotkey"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"]
        goto p67
        ::p43::
        tick(43)
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["other"]
        slot_2 = slot_2["on_shot_antiaim"]
        slot_2 = slot_2[1]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        goto p63
        ::p50::
        tick(50)
        slot_2 = upvalues[0]["is_fake_duck"];
        slot_2 = slot_2()
        slot_2 = not slot_2
        goto p66
        ::p54::
        tick(54)
        if not slot_2 then
            goto p80
        end
        goto p35
        ::p56::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 ~= "no dt" then
            goto p72
        end
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["other"]
        slot_2 = slot_2["on_shot_antiaim"]
        goto p39
        ::p63::
        tick(63)
        if not slot_2 then
            goto p66
        end
        goto p50
        ::p66::
        do
            return slot_2
        end
        ::p67::;
        slot_2 = slot_2(slot_3)
        if not slot_2 then
            goto p63
        end
        goto p43
        ::p70::
        tick(70)
        if not slot_2 then
            goto p54
        end
        goto p82
        ::p72::
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["other"]
        slot_2 = slot_2["on_shot_antiaim"]
        slot_2 = slot_2[1]
        goto p2
        ::p80::
        tick(80)
        do
            return slot_2
        end
        ::p82::
        slot_2 = upvalues[0]["is_double_tap"];
        slot_2 = slot_2()
        slot_2 = not slot_2
        goto p54
        ::p86::
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["other"]
        slot_2 = slot_2["on_shot_antiaim"]
        slot_2 = slot_2[1]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        goto p70
    end
end
