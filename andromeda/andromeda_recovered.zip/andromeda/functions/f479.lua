-- Recovered function f479; author names are unavailable.
F.f479 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f479")
        tick(1)
        goto p22
        ::p4::
        tick(4)
        if slot_2 ~= "Testing[2]" then
            goto p11
        end
        goto p52
        ::p6::
        tick(6)
        slot_2 = (slot_1 ~= slot_0)
        if not slot_2 then
            goto p16
        end
        goto p26
        ::p11::
        slot_3 = slot_2
        do
            return slot_3
        end
        ::p13::
        tick(13)
        if slot_2 ~= "Testing" then
            goto p4
        end
        goto p74
        ::p16::
        tick(16)
        if slot_2 then
            goto p13
        end
        slot_2 = "Custom"
        goto p13
        ::p22::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p50
        end
        goto p29
        ::p26::
        z = slot_1
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        goto p16
        ::p29::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["enemy_resolver_mode"]
        ::p50::
        if slot_1 then
            goto p6
        end
        goto p76
        ::p52::
        slot_3 = "Auto"
        do
            return slot_3
        end
        ::p74::
        slot_3 = "Custom"
        do
            return slot_3
        end
        ::p76::
        slot_1 = nil
        goto p6
    end
end
