-- Recovered function f282; author names are unavailable.
F.f282 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f282")
        tick(1)
        goto p81
        ::p11::
        tick(11)
        registers[6] = upvalues[0]
        registers[7] = registers[3]
        registers[5] = registers[5](registers[6], registers[7])
        a = registers
        z = (6)
        q = environment
        q = q["bit"]
        a[z] = q
        goto p102
        ::p32::
        tick(32)
        registers[7] = (true)
        do
            return registers[7]
        end
        ::p49::
        tick(49)
        registers[7] = (false)
        do
            return registers[7]
        end
        ::p53::
        tick(53)
        a = registers
        z = 7;
        a[z] = false
        do
            return registers[7]
        end
        ::p57::
        tick(57)
        registers[7] = environment["entity"]
        registers[7] = registers[7]["get_local_player"];
        registers[7] = registers[7]()
        registers[8] = registers[2]["entity"]
        if registers[7] == registers[8] then
            goto p32
        end
        goto p53
        ::p64::
        tick(64)
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = registers[2]["hint"]
        if registers[6] == registers[7] then
            goto p57
        end
        goto p49
        ::p81::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[1]["command_number"]
        registers[4] = (registers[3] * 4)
        registers[5] = environment["bit"]
        registers[5] = registers[5]["bxor"]
        goto p11
        ::p102::
        registers[6] = registers[6]["bxor"]
        registers[7] = registers[4]
        a = registers
        z = 8
        q = registers
        q = q[5]
        a[z] = q
        goto p64
    end
end
