-- Recovered function f196; author names are unavailable.
F.f196 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f196")
        tick(1)
        goto p123
        ::p2::
        tick(2)
        branch_taken = false
        if not (not (registers[8] < 1000)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p23
        end
        goto p109
        ::p21::
        tick(21)
        if not registers[7] then
            goto p23
        end
        goto p2
        ::p23::
        tick(23)
        registers[9] = upvalues[2][138]
        registers[10] = (255)
        registers[11] = (0)
        registers[12] = (0)
        registers[13] = (255)
        registers[14] = "BT"
        registers[(9)](unpack_range(14, registers, 10))
        goto p61
        ::p40::
        tick(40)
        registers[9] = upvalues[2][138]
        registers[10] = (45)
        registers[11] = (255)
        registers[12] = (60)
        registers[13] = (255)
        goto p150
        ::p61::
        tick(61)
        do
            return 
        end
        ::p68::
        tick(68)
        registers[3] = upvalues[2][32];
        registers[3] = registers[3]()
        if registers[3] == registers[0] then
            goto p157
        end
        goto p105
        ::p72::
        tick(72)
        registers[5] = upvalues[3]
        registers[6] = upvalues[2][91]
        m, x = pack_returns(registers[6]())
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[6] = upvalues[3]
        registers[7] = upvalues[2][46]
        registers[8] = registers[4]
        m, x = pack_returns(registers[7](unpack_range(8, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[3]
        registers[8] = upvalues[2][47]
        registers[9] = registers[4]
        registers[10] = "m_vecViewOffset"
        m, x = pack_returns(registers[8](unpack_range(10, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[6] = registers[6] + registers[7]
        z = registers[1]
        registers[8] = z;
        registers[(7)] = z["is_invalid_tick_cleaner_visible"]
        goto p118
        ::p96::
        tick(96)
        do
            return 
        end
        ::p99::
        tick(99)
        if registers[4] then
            goto p153
        end
        goto p157
        ::p101::
        tick(101)
        z = registers[5]
        registers[9] = z;
        registers[(8)] = z["dist"]
        registers[10] = registers[6]
        registers[8] = registers[8](registers[9], registers[10])
        goto p21
        ::p105::
        registers[4] = upvalues[2][50]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p99
        ::p109::
        registers[9] = registers[1]["backtrack_cleaner_timer"]
        branch_taken = false
        if not (not (registers[9] < 66)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p23
        end
        goto p40
        ::p118::
        registers[9] = registers[3]
        registers[10] = registers[4];
        registers[7] = registers[7](unpack_range(10, registers, 8))
        goto p101
        ::p123::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        a = upvalues[1];
        registers[3] = a[2][a[1]]["current"];
        registers[(2)] = registers[(2)](registers[3])
        z = registers[1]
        registers[4] = z;
        registers[(3)] = z["is_invalid_tick_cleaner_enabled"]
        registers[5] = registers[2]
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] then
            goto p68
        end
        goto p159
        ::p150::
        registers[14] = "BT"
        registers[(9)](unpack_range(14, registers, 10))
        goto p61
        ::p153::
        registers[4] = upvalues[2][52];
        registers[4] = registers[4]()
        if registers[4] ~= registers[0] then
            goto p72
        end
        goto p96
        ::p157::
        do
            return 
        end
        ::p159::
        do
            return 
        end
    end
end
