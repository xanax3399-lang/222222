-- Recovered function f492; author names are unavailable.
F.f492 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f492")
        tick(1)
        goto p11
        ::p3::
        tick(3)
        slot_3 = upvalues[1]["set"]
        slot_4 = slot_2
        slot_3(slot_4)
        slot_3 = upvalues[0][86]
        slot_4 = "play ui\\beepclear"
        slot_3(slot_4)
        do
            return 
        end
        ::p10::
        tick(10)
        do
            return 
        end
        ::p11::
        a = {
            ...,
        }
        slot_1 = a[1]
        z = slot_1
        slot_3 = z;
        slot_2 = z["build_encoded_payload"];
        slot_2 = slot_2(slot_3)
        if slot_2 ~= slot_0 then
            goto p3
        end
        slot_3 = upvalues[0][86]
        slot_4 = "play resource/warning.wav"
        slot_3(slot_4)
        goto p10
    end
end
