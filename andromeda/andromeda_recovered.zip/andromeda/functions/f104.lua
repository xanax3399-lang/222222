-- Recovered function f104; author names are unavailable.
F.f104 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f104")
        tick(1)
        goto p36
        ::p2::
        tick(2)
        registers[2] = upvalues[1];
        registers[2] = registers[2]()
        if registers[2] ~= registers[0] then
            goto p75
        end
        goto p25
        ::p10::
        tick(10)
        registers[3] = registers[1]["enabled"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p2
        end
        goto p74
        ::p23::
        tick(23)
        if not registers[3] then
            goto p32
        end
        goto p26
        ::p25::
        do
            return 
        end
        ::p26::
        registers[4] = upvalues[3]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        goto p80
        ::p32::
        tick(32)
        do
            return 
        end
        ::p36::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p74
        end
        registers[2] = registers[1]["enabled"]
        if registers[2] == registers[0] then
            goto p74
        end
        goto p10
        ::p60::
        tick(60)
        registers[5] = upvalues[4]["capture_smooth_state"]
        registers[6] = registers[1]
        registers[7] = registers[2]
        registers[8] = registers[4]
        registers[(5)](unpack_range(8, registers, 6))
        goto p32
        ::p74::
        do
            return 
        end
        ::p75::
        registers[3] = upvalues[2]
        registers[4] = registers[1]
        registers[5] = "Smooth"
        registers[3] = registers[3](registers[4], registers[5])
        goto p23
        ::p80::
        if registers[4] == registers[0] then
            goto p32
        end
        goto p60
    end
end
