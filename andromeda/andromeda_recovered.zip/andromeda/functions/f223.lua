-- Recovered function f223; author names are unavailable.
F.f223 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f223")
        tick(1)
        goto p41
        ::p5::
        tick(5)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_delay"]
        registers[5] = registers[1]
        goto p97
        ::p21::
        tick(21)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["set_aa"]
        registers[(3)](registers[4])
        do
            return 
        end
        ::p41::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["unset_aa"]
        goto p88
        ::p53::
        tick(53)
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] then
            goto p21
        end
        goto p21
        ::p62::
        tick(62)
        registers[5] = registers[1];
        registers[3](registers[4], registers[5])
        registers[3] = upvalues[0]
        goto p101
        ::p74::
        tick(74)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_pitch"]
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_defensive_yaw_double_delay"]
        goto p161
        ::p88::
        registers[(2)](registers[3])
        registers[2] = upvalues[1]
        a = upvalues[2];
        registers[3] = a[2][a[1]]["current"]
        goto p130
        ::p92::
        tick(92)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_body_yaw"]
        registers[5] = registers[1]
        registers[6] = registers[2]
        goto p138
        ::p97::
        registers[6] = registers[2]
        registers[(3)](unpack_range(6, registers, 4))
        goto p92
        ::p101::
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_disable_fakelag"]
        registers[(3)](registers[4])
        registers[3] = upvalues[0]
        goto p142
        ::p105::
        tick(105)
        upvalues[0]["updated"] = true
        goto p134
        ::p125::
        tick(125)
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_safehead"]
        a = upvalues[2];
        registers[5] = a[2][a[1]]["current"]
        registers[3] = registers[3](registers[4], registers[5])
        if not registers[3] then
            goto p74
        end
        goto p134
        ::p130::;
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_hotkeys"]
        goto p62
        ::p134::
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_defensive"]
        registers[5] = registers[1]
        goto p53
        ::p138::
        registers[(3)](unpack_range(6, registers, 4))
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_yaw"]
        goto p149
        ::p142::
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["break_lc"]
        registers[5] = registers[1]
        registers[6] = registers[2]
        registers[(3)](unpack_range(6, registers, 4))
        upvalues[0]["updated"] = false
        registers[3] = upvalues[0]
        goto p125
        ::p149::
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_yaw_jitter"]
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["update_hidden"]
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        goto p105
        ::p161::
        registers[5] = registers[1]
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] then
            goto p92
        end
        goto p5
    end
end
