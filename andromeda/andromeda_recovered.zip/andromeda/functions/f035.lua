-- Recovered function f35; author names are unavailable.
F.f35 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f35")
        tick(1)
        goto p7
        ::p2::
        tick(2)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_7 = v
            branch_taken = true
        end
        if branch_taken then
            goto p20
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_4 = slot_3
        do
            return slot_4
        end
        ::p7::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (0)
        slot_4 = slot_2
        goto p32
        ::p20::
        slot_8 = (slot_3 * 256)
        slot_9 = upvalues[0]
        slot_10 = slot_1
        slot_11 = slot_7
        slot_9 = slot_9(slot_10, slot_11)
        slot_3 = slot_8 + slot_9
        goto p2
        ::p32::
        slot_5 = slot_2 + 3
        slot_6 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_6 + 0
        n = (slot_5 + 0)
        v = (slot_4 - U)
        goto p2
        goto p2
    end
end
