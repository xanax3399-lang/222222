-- Recovered function f370; author names are unavailable.
F.f370 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f370")
        tick(1)
        goto p23
        ::p2::
        tick(2)
        do
            return 
        end
        ::p4::
        tick(4)
        slot_5 = slot_1["forwardmove"]
        if not (0 < slot_5) then
            goto p133
        end
        goto p167
        ::p9::
        tick(9)
        slot_5 = slot_1["sidemove"]
        branch_taken = false
        if not (not (slot_5 < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p132
        end
        goto p80
        ::p12::
        tick(12)
        slot_5 = slot_1["sidemove"]
        if not (0 < slot_5) then
            goto p132
        end
        goto p125
        ::p15::
        tick(15)
        slot_5 = slot_1["sidemove"]
        if not (0 < slot_5) then
            goto p9
        end
        goto p74
        ::p18::
        tick(18)
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 90
        slot_1["yaw"] = slot_5
        goto p129
        ::p23::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][32];
        slot_2 = slot_2()
        goto p157
        ::p36::
        tick(36)
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 150
        slot_1["yaw"] = slot_5
        goto p12
        ::p40::
        tick(40)
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 90
        slot_1["yaw"] = slot_5
        goto p15
        ::p53::
        tick(53)
        do
            return 
        end
        ::p55::
        tick(55)
        slot_6 = slot_1["yaw"]
        slot_6 = 0.5 + slot_6;
        slot_5 = slot_5(slot_6)
        slot_1["yaw"] = slot_5
        goto p4
        ::p74::
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 150
        slot_1["yaw"] = slot_5
        goto p9
        ::p80::
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 30
        slot_1["yaw"] = slot_5
        goto p132
        ::p93::
        tick(93)
        slot_5 = slot_1["sidemove"]
        if slot_5 ~= 0 then
            goto p129
        end
        goto p18
        ::p96::
        tick(96)
        slot_1["in_forward"] = 1
        slot_5 = slot_1["sidemove"]
        if slot_5 ~= 0 then
            goto p15
        end
        goto p40
        ::p100::
        tick(100)
        slot_1["pitch"] = 89
        slot_1["in_moveleft"] = 1
        slot_1["in_moveright"] = 0
        slot_1["in_back"] = 0
        goto p96
        ::p106::
        tick(106)
        slot_3 = upvalues[0][47]
        slot_4 = slot_2
        slot_5 = "m_MoveType"
        slot_3 = slot_3(slot_4, slot_5)
        branch_taken = false
        if slot_3 ~= 9 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p113
        end
        goto p2
        ::p113::
        slot_4 = upvalues[0][93];
        slot_4 = slot_4()
        slot_5 = upvalues[0][154]
        goto p55
        ::p125::
        slot_5 = slot_1["yaw"]
        slot_5 = slot_5 + 30
        slot_1["yaw"] = slot_5
        goto p132
        ::p129::
        slot_5 = slot_1["sidemove"]
        branch_taken = false
        if not (not (slot_5 < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p12
        end
        goto p36
        ::p132::
        tick(132)
        do
            return 
        end
        ::p133::
        tick(133)
        slot_5 = slot_1["forwardmove"]
        branch_taken = false
        if not (not (slot_5 < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p132
        end
        goto p182
        ::p136::
        tick(136)
        slot_1["pitch"] = 89
        slot_1["in_moveleft"] = 0
        slot_1["in_moveright"] = 1
        slot_1["in_back"] = 1
        slot_1["in_forward"] = 0
        goto p93
        ::p157::
        if slot_2 ~= slot_0 then
            goto p106
        end
        goto p53
        ::p167::
        branch_taken = false
        if not (not (slot_4 < 45)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p133
        end
        goto p136
        ::p182::
        branch_taken = false
        if not (not (slot_4 < 45)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p132
        end
        goto p100
    end
end
