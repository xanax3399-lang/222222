-- Recovered function f266; author names are unavailable.
F.f266 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f266")
        tick(1)
        goto p20
        ::p2::
        tick(2)
        if slot_2 then
            goto p7
        end
        goto p45
        ::p4::
        tick(4)
        slot_2 = slot_1["chokedcommands"]
        upvalues[0]["choked_commands"] = slot_2
        goto p19
        ::p7::
        slot_2 = slot_1["chokedcommands"]
        if not (16 < slot_2) then
            goto p27
        end
        goto p4
        ::p19::
        tick(19)
        do
            return 
        end
        ::p20::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["is_enabled"];
        slot_2 = slot_2()
        goto p2
        ::p27::
        upvalues[0]["choked_commands"] = 0
        goto p19
        ::p45::
        upvalues[0]["choked_commands"] = 0
        do
            return 
        end
    end
end
