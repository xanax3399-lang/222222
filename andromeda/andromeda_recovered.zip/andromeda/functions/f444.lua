-- Recovered function f444; author names are unavailable.
F.f444 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f444")
        tick(1)
        goto p345
        ::p17::
        tick(17)
        registers[10] = (255)
        registers[11] = (220)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        goto p306
        ::p31::
        tick(31)
        registers[8] = upvalues[2]["antiaim"]
        registers[8] = registers[8]["features"]
        registers[8] = registers[8]["hotkeys"]
        registers[8] = registers[8]["freestanding"]
        goto p320
        ::p52::
        tick(52)
        registers[4] = upvalues[4]["is_force_safe_point"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p264
        end
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "SAFE"
        registers[7] = new_frame(4)
        goto p97
        ::p61::
        tick(61)
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "FS"
        registers[7] = new_frame(4)
        goto p199
        ::p66::
        tick(66)
        registers[5] = upvalues[2]["antiaim"]
        registers[5] = registers[5]["features"]
        if registers[5] == registers[0] then
            goto p389
        end
        goto p315
        ::p70::
        tick(70)
        if registers[1] then
            goto p124
        end
        goto p329
        ::p72::
        tick(72)
        registers[9] = "safe"
        registers[(4)](unpack_range(9, registers, 5))
        goto p264
        ::p83::
        tick(83)
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "OSAA"
        registers[7] = new_frame(4)
        goto p141
        ::p89::
        tick(89)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p91::
        tick(91)
        registers[1] = upvalues[2]["visuals"]
        if registers[1] == registers[0] then
            goto p152
        end
        goto p349
        ::p95::
        tick(95)
        if registers[3] then
            goto p119
        end
        goto p221
        ::p97::
        registers[8] = (255)
        registers[9] = (255)
        registers[10] = (255)
        registers[11] = (220)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        registers[8] = (50)
        goto p72
        ::p105::
        tick(105)
        registers[9] = (30)
        registers[10] = "dt"
        registers[(5)](unpack_range(10, registers, 6))
        goto p374
        ::p109::
        tick(109)
        if not registers[4] then
            goto p226
        end
        goto p331
        ::p111::
        tick(111)
        if not registers[1] then
            goto p70
        end
        goto p257
        ::p119::
        registers[3] = {
        }
        registers[4] = upvalues[4]["is_ping_spike"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p147
        end
        goto p295
        ::p124::
        registers[2] = upvalues[3][32];
        registers[2] = registers[2]()
        if registers[2] == registers[0] then
            goto p221
        end
        goto p222
        ::p133::
        tick(133)
        registers[7] = upvalues[2]["antiaim"]
        registers[7] = registers[7]["features"]
        registers[7] = registers[7]["hotkeys"]
        registers[7] = registers[7]["freestanding"]
        if registers[7] == registers[0] then
            goto p389
        end
        goto p31
        ::p141::
        registers[8] = (255)
        registers[9] = (255)
        registers[10] = (255)
        registers[11] = (220)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        goto p360
        ::p147::
        tick(147)
        registers[4] = upvalues[4]["is_on_shot_antiaim"]
        registers[5] = "no dt";
        registers[(4)] = registers[(4)](registers[5])
        if not registers[4] then
            goto p231
        end
        goto p83
        ::p152::
        tick(152)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p153::
        tick(153)
        registers[10] = registers[6]
        registers[11] = registers[7]
        registers[12] = registers[2]
        goto p304
        ::p164::
        tick(164)
        registers[1] = upvalues[2]["visuals"]
        registers[1] = registers[1]["stubs"]
        registers[1] = registers[1]["feature_indicators"]
        registers[1] = (registers[1] ~= registers[0])
        goto p111
        ::p169::
        tick(169)
        registers[3] = upvalues[2]["visuals"]
        registers[3] = registers[3]["stubs"]
        registers[3] = registers[3]["feature_indicators"]
        if registers[3] ~= registers[0] then
            goto p164
        end
        goto p152
        ::p192::
        tick(192)
        registers[8] = (255)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        q[3] = registers[7]
        q[4] = registers[8]
        goto p290
        ::p196::
        tick(196)
        registers[9] = "fs"
        registers[(4)](unpack_range(9, registers, 5))
        goto p389
        ::p199::
        registers[8] = (255)
        registers[9] = (255)
        registers[10] = (255)
        registers[11] = (220)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        registers[8] = (70)
        goto p196
        ::p206::
        tick(206)
        registers[4] = upvalues[7]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        goto p109
        ::p216::
        tick(216)
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        q[3] = registers[10]
        q[4] = registers[11]
        registers[8] = (60)
        registers[9] = "baim"
        registers[(4)](unpack_range(9, registers, 5))
        goto p254
        ::p221::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p222::
        registers[3] = upvalues[3][50]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        goto p95
        ::p226::
        tick(226)
        if registers[4] then
            goto p290
        end
        goto p310
        ::p228::
        tick(228)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p231::
        tick(231)
        registers[4] = upvalues[4]["is_double_tap"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p374
        end
        goto p206
        ::p236::
        tick(236)
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "DUCK"
        goto p369
        ::p241::
        tick(241)
        registers[8] = (255)
        registers[9] = (255)
        registers[10] = (255)
        registers[11] = (220)
        goto p216
        ::p246::
        tick(246)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        q[3] = registers[7]
        q[4] = registers[8]
        goto p226
        ::p254::
        tick(254)
        registers[4] = upvalues[2]["antiaim"]
        if registers[4] == registers[0] then
            goto p389
        end
        goto p66
        ::p257::
        registers[1] = upvalues[2]["visuals"]
        registers[1] = registers[1]["stubs"]
        registers[1] = registers[1]["feature_indicators"]
        goto p325
        ::p264::
        registers[4] = upvalues[4]["is_force_baim"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p254
        end
        goto p279
        ::p268::
        tick(268)
        registers[7] = upvalues[6];
        registers[7] = registers[7]()
        registers[8] = (10)
        goto p300
        ::p279::
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "BODY"
        registers[7] = new_frame(4)
        goto p241
        ::p284::
        tick(284)
        registers[8] = registers[8] + 0.5;
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = upvalues[8]
        registers[9] = registers[3]
        goto p153
        ::p290::
        registers[5] = upvalues[5]
        registers[6] = registers[3]
        registers[7] = "DT"
        registers[8] = registers[4]
        goto p105
        ::p295::
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[6] = "PING"
        goto p268
        ::p300::
        registers[9] = "ping"
        registers[(4)](unpack_range(9, registers, 5))
        goto p147
        ::p304::
        registers[(8)](unpack_range(12, registers, 9))
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p306::
        registers[8] = (40)
        registers[9] = "duck"
        registers[(4)](unpack_range(9, registers, 5))
        goto p52
        ::p310::
        registers[4] = new_frame(4)
        registers[5] = (255)
        registers[6] = (0)
        registers[7] = (50)
        goto p192
        ::p315::
        registers[6] = upvalues[2]["antiaim"]
        registers[6] = registers[6]["features"]
        registers[6] = registers[6]["hotkeys"]
        if registers[6] == registers[0] then
            goto p389
        end
        goto p133
        ::p320::
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        if not registers[8] then
            goto p389
        end
        goto p61
        ::p325::
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[1] = (registers[1] == true)
        goto p70
        ::p329::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p331::
        registers[4] = new_frame(4)
        registers[5] = (255)
        registers[6] = (255)
        registers[7] = (255)
        registers[8] = (200)
        goto p246
        ::p345::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p384
        end
        goto p89
        ::p349::
        registers[2] = upvalues[2]["visuals"]
        registers[2] = registers[2]["stubs"]
        if registers[2] == registers[0] then
            goto p152
        end
        goto p169
        ::p360::
        registers[8] = (20)
        registers[9] = "hide"
        registers[(4)](unpack_range(9, registers, 5))
        goto p231
        ::p369::
        registers[7] = new_frame(4)
        registers[8] = (255)
        registers[9] = (255)
        goto p17
        ::p374::
        registers[4] = upvalues[4]["is_fake_duck"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p52
        end
        goto p236
        ::p384::
        registers[1] = upvalues[1]
        registers[2] = "paint:feature_indicators";
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p91
        end
        goto p228
        ::p389::
        registers[4] = environment["table"]
        registers[4] = registers[4]["sort"]
        registers[5] = registers[3]
        a = D.f445
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[4](registers[5], registers[6])
        registers[4] = upvalues[3][57]
        m, x = pack_returns(registers[4]())
        z = 0
        for f = 4, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = upvalues[3][154]
        registers[7] = (registers[4] * 0.5)
        registers[7] = registers[7] + 0.5;
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = upvalues[3][154]
        registers[8] = (registers[5] * 0.5)
        goto p284
    end
end
