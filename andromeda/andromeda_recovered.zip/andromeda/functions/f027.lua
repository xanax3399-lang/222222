-- Recovered function f27; author names are unavailable.
F.f27 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f27")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1
        slot_4 = upvalues[1];
        slot_2(slot_3, slot_4)
        do
            return 
        end
    end
end
