-- Recovered function f426; author names are unavailable.
F.f426 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f426")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if not (registers[2] < registers[1]) then
            goto p16
        end
        goto p37
        ::p16::
        tick(16)
        registers[3] = upvalues[0][87]
        registers[4] = registers[1]
        registers[5] = registers[2]
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p37::
        registers[3] = registers[2]
        a = registers
        z = 2
        q = registers
        q = q[1]
        a[z] = q
        a = registers
        z = 1
        q = registers
        q = q[3]
        a[z] = q
        goto p16
    end
end
