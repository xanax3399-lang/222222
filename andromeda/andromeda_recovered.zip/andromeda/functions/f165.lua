-- Recovered function f165; author names are unavailable.
F.f165 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f165")
        tick(1)
        goto p40
        ::p2::
        tick(2)
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[(2)](registers[3])
        a = registers
        z = (2)
        q = registers
        q = q[1]
        q = q["hotkey"]
        a[z] = q
        goto p48
        ::p9::
        tick(9);
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= "table" then
            goto p51
        end
        tick(29)
        registers[3] = registers[1]["override"]
        if registers[3] ~= registers[0] then
            goto p2
        end
        goto p51
        ::p40::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["type"]
        registers[3] = registers[1]
        goto p9
        ::p48::
        if registers[2] == registers[0] then
            goto p66
        end
        goto p73
        ::p51::
        do
            return 
        end
        ::p66::
        tick(66)
        do
            return 
        end
        ::p73::
        registers[2] = registers[1]["hotkey"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[(2)](registers[3])
        goto p66
    end
end
