-- Recovered function f224; author names are unavailable.
F.f224 = function(function_metadata, upvalues)
    local operand_g, operand_k = function_metadata[6], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f224")
        tick(1)
        goto p104
        ::p8::
        tick(8);
        registers[3] = registers[3]()
        registers[4] = upvalues[2][154]
        registers[5] = 5 * registers[3]
        goto p172
        ::p25::
        tick(25)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[14] = v
            branch_taken = true
        end
        if branch_taken then
            goto p110
        end
        goto p138
        ::p27::
        tick(27)
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[8] = upvalues[2][151]
        registers[9] = (2)
        registers[10] = upvalues[2][154]
        registers[11] = 3 * registers[3]
        registers[11] = registers[11] + 0.5
        m, x = pack_returns(registers[10](unpack_range(11, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = upvalues[1]["get_gradient_alpha"];
        registers[9] = registers[9]()
        registers[10] = (0)
        registers[11] = registers[1]
        registers[12] = (1)
        registers[13] = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[13] + 0
        n = (registers[12] + 0)
        v = (registers[11] - U)
        goto p25
        ::p52::
        tick(52)
        registers[33] = registers[15]["segments"]
        registers[33] = registers[33][registers[32]]
        registers[34] = upvalues[1]["get_segment_color"]
        registers[35] = registers[33][2]
        registers[36] = registers[19]
        m, x = pack_returns(registers[34](unpack_range(36, registers, 35)))
        z = 0
        for f = 34, 37 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[38] = upvalues[2][131]
        registers[39] = registers[26]
        goto p100
        ::p61::
        tick(61)
        registers[21] = registers[17]
        registers[22] = registers[18]
        registers[20] = registers[20](registers[21], registers[22])
        registers[20] = 255 * registers[20]
        registers[20] = registers[20] + 0.5
        goto p225
        ::p68::
        tick(68)
        registers[29] = (1)
        registers[30] = registers[15]["segments"]
        registers[30] = (#registers[30])
        registers[31] = (1)
        goto p253
        ::p79::
        tick(79)
        registers[2] = upvalues[2][30];
        registers[2] = registers[2]()
        registers[3] = upvalues[1]["get_dpi_scale"]
        goto p8
        ::p83::
        tick(83)
        registers[43] = registers[36]
        registers[44] = registers[37]
        registers[45] = "d"
        registers[46] = (0)
        goto p270
        ::p96::
        tick(96)
        registers[16] = (registers[2] - registers[16])
        registers[17] = upvalues[1]["hold_time"]
        if not (registers[17] < registers[16]) then
            goto p282
        end
        goto p124
        ::p100::
        registers[40] = registers[27]
        registers[41] = registers[34]
        registers[42] = registers[35]
        goto p83
        ::p104::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p140
        end
        goto p196
        ::p110::
        registers[15] = upvalues[1]["items"]
        registers[15] = registers[15][registers[14]]
        registers[16] = registers[15]["time"]
        goto p96
        ::p124::
        registers[17] = environment["table"]
        registers[17] = registers[17]["remove"]
        registers[18] = upvalues[1]["items"]
        registers[19] = registers[14];
        registers[17](registers[18], registers[19])
        goto p25
        ::p132::
        tick(132)
        registers[29] = registers[29] / 255
        registers[29] = registers[29] + 0.5;
        registers[(28)] = registers[(28)](registers[29])
        registers[29] = upvalues[1]["draw_background"]
        registers[30] = registers[24]
        goto p234
        ::p138::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p140::
        registers[1] = upvalues[1]["active"]
        if registers[1] then
            goto p159
        end
        goto p224
        ::p143::
        tick(143)
        registers[38] = registers[38](registers[39], registers[40])
        registers[39] = registers[38]
        if registers[39] then
            goto p194
        end
        registers[39] = (0)
        goto p194
        ::p159::
        registers[1] = upvalues[1]["items"]
        registers[1] = (#registers[1])
        if registers[1] ~= 0 then
            goto p79
        end
        goto p184
        ::p163::
        tick(163);
        registers[(24)] = registers[(24)](registers[25])
        registers[24] = (registers[4] - registers[24])
        registers[25] = registers[23] + registers[6]
        registers[25] = registers[10] * registers[25]
        registers[25] = registers[5] + registers[25]
        registers[26] = registers[24] + registers[7]
        registers[27] = upvalues[2][154]
        goto p261
        ::p172::
        registers[5] = registers[5] + 0.5;
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = upvalues[2][154]
        registers[6] = 5 * registers[3]
        registers[6] = registers[6] + 0.5;
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[2][151]
        registers[7] = (2)
        registers[8] = upvalues[2][154]
        registers[9] = 4 * registers[3]
        registers[9] = registers[9] + 0.5
        goto p297
        ::p184::
        do
            return 
        end
        ::p185::
        tick(185)
        registers[22] = (registers[7] * 2)
        registers[22] = registers[20] + registers[22]
        registers[23] = (registers[8] * 2)
        registers[23] = registers[21] + registers[23]
        registers[24] = upvalues[2][154]
        registers[25] = 1 - registers[18]
        registers[25] = (registers[25] * 12)
        registers[25] = registers[25] + 0.5
        goto p163
        ::p194::
        registers[26] = registers[26] + registers[39]
        goto p200
        ::p196::
        do
            return 
        end
        ::p200::
        tick(200)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[32] = v
            branch_taken = true
        end
        if branch_taken then
            goto p52
        end
        goto p231
        ::p224::
        do
            return 
        end
        ::p225::;
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = upvalues[1]["measure_item"]
        registers[21] = registers[15]
        registers[22] = "d"
        m, x = pack_returns(registers[20](unpack_range(22, registers, 21)))
        z = 0
        for f = 20, 21 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p185
        ::p231::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[10] = registers[10] + 1
        goto p25
        ::p234::
        registers[31] = registers[25]
        registers[32] = registers[22]
        registers[33] = registers[23]
        registers[34] = registers[28]
        registers[(29)](unpack_range(34, registers, 30))
        goto p68
        ::p253::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[31] + 0
        n = (registers[30] + 0)
        v = (registers[29] - U)
        goto p200
        registers[63] = operand_g
        registers[65] = operand_k
        registers[63][52] = 33
        registers[65][67] = 199
        registers[58] = nil
        registers[59] = nil
        registers[60] = nil
        registers[61] = nil
        registers[62] = nil
        registers[63] = nil
        registers[64] = nil
        registers[65] = nil
        goto p200
        ::p261::
        registers[28] = (registers[23] - registers[21])
        registers[28] = (registers[28] * 0.5)
        registers[28] = registers[28] + 0.5;
        registers[(27)] = registers[(27)](registers[28])
        registers[27] = registers[25] + registers[27]
        registers[28] = upvalues[2][154]
        registers[29] = registers[9] * registers[19]
        goto p132
        ::p270::
        registers[47] = registers[33][1]
        registers[(38)](unpack_range(47, registers, 39))
        registers[38] = upvalues[2][136]
        registers[39] = "d"
        registers[40] = registers[33][1]
        goto p143
        ::p282::
        registers[17] = upvalues[3]["clamp"]
        registers[18] = upvalues[1]["hold_time"]
        registers[18] = (registers[18] - registers[16])
        registers[18] = registers[18] / 0.45
        registers[19] = (0)
        registers[20] = (1);
        registers[17] = registers[17](unpack_range(20, registers, 18))
        registers[18] = upvalues[3]["clamp"]
        registers[19] = registers[16] / 0.18
        registers[20] = (0)
        registers[21] = (1);
        registers[18] = registers[18](unpack_range(21, registers, 19))
        registers[19] = upvalues[2][154]
        registers[20] = upvalues[2][162]
        goto p61
        ::p297::
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[2][151]
        registers[8] = (4)
        registers[9] = upvalues[2][154]
        registers[10] = 6 * registers[3]
        registers[10] = registers[10] + 0.5
        goto p27
    end
end
