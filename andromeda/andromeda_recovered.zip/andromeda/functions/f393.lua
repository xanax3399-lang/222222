-- Recovered function f393; author names are unavailable.
F.f393 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f393")
        tick(1)
        goto p95
        ::p3::
        tick(3)
        registers[3] = "dt+"
        registers[4] = new_frame(4)
        registers[5] = (0)
        registers[6] = (255)
        goto p40
        ::p8::
        tick(8)
        a = upvalues[1];
        registers[2] = a[2][a[1]]["exploits"]
        registers[2] = registers[2]["defensive"]
        registers[2] = (registers[2] ~= registers[0])
        goto p118
        ::p21::
        tick(21)
        do
            return unpack_range(3, registers, (2))
        end
        ::p22::
        tick(22)
        if not (0 < registers[2]) then
            goto p140
        end
        goto p3
        ::p32::
        tick(32)
        a = upvalues[1];
        registers[2] = a[2][a[1]]
        registers[2] = (registers[2] ~= registers[0])
        if not registers[2] then
            goto p116
        end
        goto p82
        ::p36::
        tick(36)
        a = upvalues[1];
        registers[2] = a[2][a[1]]["exploits"]
        registers[2] = registers[2]["defensive"]
        registers[2] = registers[2]["left"]
        goto p85
        ::p40::
        registers[7] = (0)
        registers[8] = (255)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        q[3] = registers[7]
        q[4] = registers[8]
        do
            return unpack_range(4, registers, (3))
        end
        ::p57::
        tick(57)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        q[3] = registers[7]
        q[4] = registers[8]
        do
            return unpack_range(4, registers, (3))
        end
        ::p61::
        tick(61)
        registers[6] = (255)
        registers[7] = (0)
        registers[8] = (255)
        goto p57
        ::p67::
        tick(67)
        registers[2] = (0)
        goto p22
        ::p82::
        a = upvalues[1];
        registers[2] = a[2][a[1]]["exploits"]
        registers[2] = (registers[2] ~= registers[0])
        goto p116
        ::p85::
        tick(85)
        if registers[2] then
            goto p22
        end
        goto p67
        ::p87::
        tick(87)
        registers[2] = "dt"
        registers[3] = new_frame(4)
        registers[4] = (255)
        registers[5] = (64)
        registers[6] = (64)
        registers[7] = (255)
        q = registers[(3)]
        q[1] = registers[4]
        q[2] = registers[5]
        q[3] = registers[6]
        q[4] = registers[7]
        goto p21
        ::p95::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] then
            goto p32
        end
        goto p87
        ::p116::
        if not registers[2] then
            goto p118
        end
        goto p8
        ::p118::
        if not registers[2] then
            goto p85
        end
        goto p36
        ::p140::
        registers[3] = "dt"
        registers[4] = new_frame(4)
        registers[5] = (0)
        goto p61
    end
end
