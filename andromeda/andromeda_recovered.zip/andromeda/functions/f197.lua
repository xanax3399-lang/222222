-- Recovered function f197; author names are unavailable.
F.f197 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local q = nil
        local z, a = nil, nil
        local tick = new_tick("f197")
        tick(1)
        goto p72
        ::p10::
        tick(10)
        slot_5 = (true);
        slot_3(slot_4, slot_5)
        slot_3 = upvalues[0]["antiaim"]
        goto p171
        ::p35::
        tick(35)
        slot_3 = upvalues[0]["antiaim"]
        slot_3 = slot_3["angles"]
        slot_3 = slot_3["edge_yaw"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        goto p185
        ::p52::
        tick(52)
        slot_1["freestanding_side"] = slot_0
        goto p177
        ::p56::
        tick(56)
        slot_3 = slot_3["angles"]
        slot_3 = slot_3["freestanding"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        goto p66
        ::p61::
        tick(61)
        a = upvalues[2];
        slot_3 = a[2][a[1]]["manual"]
        if slot_3 == slot_0 then
            goto p154
        end
        goto p126
        ::p66::
        slot_5 = (false);
        slot_3(slot_4, slot_5)
        slot_3 = upvalues[0]["antiaim"]
        slot_3 = slot_3["angles"]
        goto p139
        ::p72::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_1["edge_yaw"] = false
        slot_1["freestanding"] = false
        slot_3 = upvalues[0]["antiaim"]
        goto p56
        ::p104::
        tick(104)
        slot_6 = "Always on"
        q = slot_5
        q[1] = slot_6;
        slot_3(slot_4, slot_5)
        goto p112
        ::p108::
        tick(108)
        slot_5 = (false);
        slot_3(slot_4, slot_5)
        slot_3 = upvalues[1]
        goto p130
        ::p112::
        slot_1["freestanding"] = true
        slot_3 = slot_2["chokedcommands"]
        if slot_3 ~= 0 then
            goto p177
        end
        slot_3 = upvalues[4];
        slot_3 = slot_3()
        slot_1["freestanding_side"] = slot_3
        goto p177
        ::p120::
        tick(120)
        slot_3 = upvalues[0]["antiaim"]
        slot_3 = slot_3["angles"]
        slot_3 = slot_3["edge_yaw"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        goto p108
        ::p126::
        tick(126)
        slot_1["freestanding_side"] = slot_0
        do
            return 
        end
        ::p130::;
        slot_3 = slot_3()
        if slot_3 then
            goto p126
        end
        goto p61
        ::p134::
        tick(134)
        slot_3 = upvalues[0]["antiaim"]
        slot_3 = slot_3["angles"]
        slot_3 = slot_3["freestanding"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        goto p10
        ::p139::
        slot_3 = slot_3["freestanding"]
        slot_3 = slot_3["hotkey"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        slot_5 = new_frame(1)
        slot_6 = "On hotkey"
        q = slot_5
        q[1] = slot_6;
        slot_3(slot_4, slot_5)
        goto p120
        ::p154::
        slot_3 = upvalues[3]["antiaim"]
        slot_3 = slot_3["features"]
        slot_3 = slot_3["hotkeys"]
        slot_3 = slot_3["freestanding"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        if not slot_3 then
            goto p52
        end
        goto p134
        ::p171::
        slot_3 = slot_3["angles"]
        slot_3 = slot_3["freestanding"]
        slot_3 = slot_3["hotkey"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["override"]
        slot_5 = new_frame(1)
        goto p104
        ::p177::
        slot_3 = upvalues[3]["antiaim"]
        slot_3 = slot_3["features"]
        slot_3 = slot_3["hotkeys"]
        slot_3 = slot_3["edgeyaw"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        if not slot_3 then
            goto p198
        end
        goto p35
        ::p185::
        slot_5 = (true);
        slot_3(slot_4, slot_5)
        slot_1["edge_yaw"] = true
        ::p198::
        do
            return 
        end
    end
end
