-- Recovered function f139; author names are unavailable.
F.f139 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f139")
        tick(1)
        goto p44
        ::p26::
        tick(26)
        registers[4] = environment["string"]
        registers[4] = registers[4]["byte"]
        registers[5] = registers[3]
        registers[6] = (1)
        registers[4] = registers[4](registers[5], registers[6])
        registers[5] = (registers[4] ~= registers[0])
        if not registers[5] then
            goto p68
        end
        goto p70
        ::p40::
        tick(40)
        registers[4] = environment["type"]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p48
        ::p44::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0]
        registers[4] = registers[2]
        goto p117
        ::p48::
        if registers[4] ~= "string" then
            goto p150
        end
        goto p145
        ::p50::
        tick(50)
        branch_taken = false
        if registers[7] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p161
        end
        registers[7] = nil
        do
            return registers[7]
        end
        ::p61::
        tick(61)
        registers[3] = nil
        do
            return registers[3]
        end
        ::p63::
        tick(63)
        if registers[5] then
            goto p68
        end
        goto p148
        ::p68::
        tick(68)
        if not registers[5] then
            goto p128
        end
        goto p108
        ::p70::
        registers[5] = (registers[4] >= 128)
        if not registers[5] then
            goto p143
        end
        goto p159
        ::p108::
        z = registers[3]
        registers[7] = z;
        registers[(6)] = z["find"]
        registers[8] = "antiaim"
        registers[9] = (1)
        registers[10] = (true);
        registers[6] = registers[6](unpack_range(10, registers, 7))
        if registers[6] == registers[0] then
            goto p128
        end
        goto p137
        ::p117::;
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p165
        end
        goto p61
        ::p128::
        tick(128)
        registers[6] = nil
        do
            return registers[6]
        end
        ::p131::
        tick(131)
        if registers[7] ~= registers[0] then
            goto p171
        end
        goto p128
        ::p133::
        tick(133)
        registers[7] = environment["type"]
        registers[8] = registers[6];
        registers[(7)] = registers[(7)](registers[8])
        goto p50
        ::p137::
        z = registers[3]
        registers[8] = z;
        registers[(7)] = z["find"]
        registers[9] = "visuals"
        registers[10] = (1)
        registers[11] = (true);
        registers[7] = registers[7](unpack_range(11, registers, 8))
        goto p131
        ::p143::
        tick(143)
        if registers[5] then
            goto p63
        end
        goto p163
        ::p145::
        if registers[3] ~= "" then
            goto p26
        end
        goto p150
        ::p148::
        registers[5] = (registers[4] == 223)
        goto p68
        ::p150::
        registers[4] = nil
        do
            return registers[4]
        end
        ::p159::
        registers[5] = registers[4] <= 143
        goto p143
        ::p161::
        registers[7] = registers[6]
        do
            return registers[7]
        end
        ::p163::
        registers[5] = (registers[4] == 222)
        goto p63
        ::p165::
        registers[3] = upvalues[1]["decode"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        goto p40
        ::p171::
        registers[6] = upvalues[2]["unpack"]
        registers[7] = registers[3];
        registers[(6)] = registers[(6)](registers[7])
        goto p133
    end
end
