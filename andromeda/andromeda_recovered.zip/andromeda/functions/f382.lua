-- Recovered function f382; author names are unavailable.
F.f382 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f382")
        tick(1)
        goto p27
        ::p9::
        tick(9)
        registers[7] = "ease_out"
        do
            return registers[(2)](unpack_range(7, registers, 3))
        end
        ::p19::
        tick(19);
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = "native_indicator_slide:"..registers[3]
        registers[4] = (0)
        registers[5] = (11)
        registers[6] = (0.01)
        goto p9
        ::p25::
        tick(25)
        registers[4] = ""
        goto p19
        ::p27::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        registers[3] = environment["tostring"]
        registers[4] = registers[1]
        if registers[4] then
            goto p19
        end
        goto p25
    end
end
