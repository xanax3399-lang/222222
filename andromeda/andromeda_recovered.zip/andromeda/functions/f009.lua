-- Recovered function f9; author names are unavailable.
F.f9 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f9")
        tick(1)
        goto p63
        ::p11::
        tick(11)
        slot_5 = slot_1 * slot_3
        slot_5 = slot_4 + slot_5
        slot_6 = slot_2 * slot_3
        goto p20
        ::p16::
        tick(16)
        if not (0 < slot_2) then
            goto p11
        end
        goto p73
        ::p20::
        slot_5 = slot_5 + slot_6
        do
            return slot_5
        end
        ::p22::
        tick(22)
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 16
        slot_3 = (slot_3 * 16)
        ::p29::
        tick(29)
        if not (0 < slot_1) then
            goto p11
        end
        goto p16
        ::p63::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p29
        ::p73::
        slot_5 = slot_1 % 16
        slot_6 = slot_2 % 16
        slot_7 = upvalues[0][slot_5]
        slot_7 = slot_7[slot_6]
        slot_7 = slot_7 * slot_3
        slot_4 = slot_4 + slot_7
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 16
        goto p22
    end
end
