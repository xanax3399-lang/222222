-- Recovered function f234; author names are unavailable.
F.f234 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f234")
        tick(1)
        goto p27
        ::p4::
        tick(4);
        slot_1 = slot_1(slot_2)
        goto p36
        ::p27::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["other"]
        slot_1 = slot_1["slow_motion"]
        slot_1 = slot_1[1]
        goto p57
        ::p36::
        tick(36)
        do
            return slot_1
        end
        ::p37::
        tick(37)
        slot_1 = slot_1[1]
        slot_1 = slot_1["hotkey"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"]
        goto p4
        ::p57::
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        if not slot_1 then
            goto p36
        end
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["other"]
        slot_1 = slot_1["slow_motion"]
        goto p37
    end
end
