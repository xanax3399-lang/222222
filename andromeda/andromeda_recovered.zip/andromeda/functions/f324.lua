-- Recovered function f324; author names are unavailable.
F.f324 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f324")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if not registers[1] then
            goto p80
        end
        goto p92
        ::p11::
        tick(11)
        a = registers
        z = 5;
        a[z] = true
        ::p14::
        tick(14)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[6] = registers[5]
        do
            return registers[6]
        end
        ::p17::
        tick(17)
        registers[5] = (false)
        registers[6] = environment["pairs"]
        registers[7] = registers[3]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        z = 0
        for f = 6, 8 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(6)]
        n = registers[7]
        U = registers[8]
        goto p62
        registers[20] = (275)
        goto p123
        ::p62::
        tick(62)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[7] = z;
            registers[8] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p76
        end
        goto p14
        ::p73::
        tick(73)
        a = registers
        z = 5;
        a[z] = false
        do
            return registers[5]
        end
        ::p76::
        registers[9] = environment["bit"]
        registers[9] = registers[9]["band"]
        registers[10] = registers[4]["flags"]
        goto p129
        ::p80::
        tick(80)
        registers[3] = (false)
        do
            return registers[3]
        end
        ::p90::
        tick(90)
        if registers[8] ~= registers[2] then
            goto p62
        end
        goto p11
        ::p92::
        registers[3] = upvalues[0][50]
        registers[4] = registers[1];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p97
        end
        goto p80
        ::p97::
        registers[3] = {
        }
        registers[3][1] = "Helmet"
        registers[3][2] = "Kevlar"
        registers[3][4] = "Helmet + Kevlar"
        registers[3][8] = "Zoom"
        registers[3][16] = "Blind"
        registers[3][32] = "Reload"
        registers[3][64] = "Bomb"
        registers[3][128] = "Vip"
        registers[3][256] = "Defuse"
        registers[3][512] = "Fakeduck"
        registers[3][1024] = "Pin pulled"
        registers[3][2048] = "Hit"
        registers[3][4096] = "Occluded"
        registers[3][8192] = "Exploiter"
        registers[4] = upvalues[0][41]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= registers[0] then
            goto p17
        end
        goto p73
        ::p123::
        registers[20] = 28824 + registers[20]
        registers[20] = registers[20] + -28733
        registers[13][81] = registers[20]
        registers[19][142] = 79
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        goto p80
        ::p129::
        registers[11] = registers[7]
        registers[9] = registers[9](registers[10], registers[11])
        if registers[9] ~= registers[7] then
            goto p62
        end
        goto p90
    end
end
