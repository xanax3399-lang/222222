-- Recovered function f460; author names are unavailable.
F.f460 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1 = nil, nil
        local tick = new_tick("f460")
        tick(1)
        goto p39
        ::p3::
        tick(3)
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["animations"]
        goto p24
        ::p15::
        tick(15)
        slot_1 = nil
        goto p45
        ::p24::
        tick(24)
        if slot_1 then
            goto p45
        end
        goto p15
        ::p39::
        slot_1 = upvalues[0]["visuals"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p24
        end
        goto p3
        ::p45::
        do
            return slot_1
        end
    end
end
