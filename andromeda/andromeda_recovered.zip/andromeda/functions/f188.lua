-- Recovered function f188; author names are unavailable.
F.f188 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f188")
        tick(1)
        goto p44
        ::p2::
        tick(2)
        registers[17] = registers[9]["slots"]
        registers[17] = registers[17][registers[16]]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["set_visible"]
        registers[19] = registers[11]
        if not registers[19] then
            goto p116
        end
        goto p70
        ::p14::
        tick(14)
        registers[12] = registers[11]
        if not registers[12] then
            goto p206
        end
        goto p175
        ::p17::
        tick(17)
        registers[1] = (registers[1] == "Anti-Aim")
        if not registers[1] then
            goto p127
        end
        goto p23
        ::p20::
        tick(20)
        if not registers[11] then
            goto p74
        end
        goto p132
        ::p23::
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        goto p127
        ::p38::
        tick(38)
        registers[16] = (10)
        registers[17] = registers[12]
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[13] = registers[13](unpack_range(top, registers, 14))
        registers[12] = registers[13]
        goto p112
        ::p44::
        registers[1] = upvalues[0]["switch"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        goto p17
        ::p50::
        tick(50)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p194
        ::p70::
        registers[19] = (registers[16] <= registers[12])
        goto p116
        ::p72::
        tick(72)
        if not registers[11] then
            goto p20
        end
        goto p102
        ::p74::
        tick(74)
        if not registers[11] then
            goto p14
        end
        goto p151
        ::p76::
        tick(76)
        registers[11] = registers[7]["state_name"]
        registers[11] = registers[2] == registers[11]
        goto p72
        ::p79::
        tick(79)
        if registers[11] then
            goto p74
        end
        goto p197
        ::p92::
        tick(92)
        registers[11] = (registers[11] == "Hidden")
        goto p20
        ::p102::
        registers[11] = registers[7]["builder_type"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        goto p92
        ::p106::
        tick(106)
        registers[11] = (registers[10] == "Random")
        goto p79
        ::p108::
        tick(108)
        registers[3] = (1)
        registers[4] = upvalues[2]
        registers[4] = (#registers[4])
        goto p135
        ::p112::
        registers[13] = (1)
        registers[14] = (10)
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p159
        ::p116::;
        registers[17](registers[18], registers[19])
        goto p159
        ::p125::
        tick(125)
        registers[12] = (0)
        goto p138
        ::p127::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["conditions"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        goto p108
        ::p132::
        registers[11] = (registers[10] == "Center")
        if registers[11] then
            goto p79
        end
        goto p106
        ::p135::
        registers[5] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p194
        goto p151
        ::p138::
        tick(138)
        registers[13] = upvalues[3][151]
        a = registers
        z = 14;
        a[z] = 0
        registers[15] = upvalues[3][162]
        goto p38
        ::p151::
        registers[11] = registers[8]["values"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[11] == "Custom")
        goto p14
        ::p159::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p2
        end
        goto p50
        ::p175::
        registers[12] = upvalues[3][154]
        registers[13] = registers[9]["count"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["get"]
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        goto p206
        ::p182::
        tick(182)
        registers[10] = registers[8]["type"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        a = registers
        z = 11
        q = registers
        q = q[1]
        a[z] = q
        if not registers[11] then
            goto p72
        end
        goto p76
        ::p190::
        tick(190)
        registers[7] = upvalues[2][registers[6]]
        registers[8] = registers[7]["modifiers"]
        registers[9] = registers[8]["custom"]
        goto p182
        ::p194::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p190
        end
        goto p208
        ::p197::
        registers[11] = (registers[10] == "Spin")
        goto p74
        ::p206::
        if registers[12] then
            goto p138
        end
        goto p125
        ::p208::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
    end
end
