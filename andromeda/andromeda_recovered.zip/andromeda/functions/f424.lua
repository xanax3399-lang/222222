-- Recovered function f424; author names are unavailable.
F.f424 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f424")
        tick(1)
        registers[1] = upvalues[0]["hmac_sha256"]
        registers[2] = upvalues[1]
        registers[3] = environment["_SCRIPT_NAME"]
        do
            return registers[(1)](unpack_range(3, registers, 2))
        end
    end
end
