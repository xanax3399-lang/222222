-- Recovered function f258; author names are unavailable.
F.f258 = function(function_metadata, upvalues)
    local operand_i, operand_k = function_metadata[2], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_23, slot_24, slot_25, slot_26, slot_27, slot_28, slot_29, slot_30 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, n, v, R, q = andromeda_environment, nil, nil, nil, nil
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f258")
        tick(1)
        goto p63
        ::p4::
        tick(4)
        slot_5 = upvalues[1][86]
        slot_6 = "play resource/warning.wav"
        slot_5(slot_6)
        goto p30
        ::p8::
        tick(8)
        slot_6 = slot_6["menu_list"]
        slot_7 = slot_3;
        slot_5(slot_6, slot_7)
        goto p113
        ::p20::
        tick(20)
        slot_5 = upvalues[1][86]
        slot_6 = "play resource/warning.wav"
        slot_5(slot_6)
        goto p67
        ::p30::
        tick(30)
        slot_5 = slot_1["configs_db"]
        slot_5 = slot_5["cfg_list"]
        slot_5 = (#slot_5)
        do
            return slot_5
        end
        ::p34::
        tick(34)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_4 = slot_1["configs_db"]
        slot_4 = slot_4["cfg_list"]
        slot_4 = (#slot_4)
        slot_5 = slot_1["max_configs"]
        goto p148
        ::p46::
        tick(46)
        slot_5 = upvalues[1][86]
        slot_6 = "play ui\\beepclear"
        slot_5(slot_6)
        goto p30
        ::p50::
        tick(50)
        slot_5 = environment["table"]
        slot_5 = slot_5["insert"]
        slot_6 = slot_1["configs_db"]
        slot_6 = slot_6["cfg_list"]
        slot_7 = new_frame(2)
        goto p80
        ::p56::
        tick(56)
        slot_8 = slot_7
        do
            return slot_8
        end
        ::p63::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0]
        slot_4 = slot_2
        goto p90
        ::p67::
        do
            return 
        end
        ::p68::
        tick(68)
        slot_4 = slot_1["configs_db"]
        slot_4 = slot_4["menu_list"]
        slot_4 = (#slot_4)
        slot_5 = (1)
        slot_6 = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_6 + 0
        n = (slot_5 + 0)
        v = (slot_4 - U)
        goto p163
        slot_30 = operand_k
        slot_29 = operand_i
        slot_29[114] = 5
        slot_30[154] = 112
        slot_23 = nil
        slot_24 = nil
        slot_25 = nil
        slot_26 = nil
        slot_27 = nil
        slot_28 = nil
        slot_29 = nil
        slot_30 = nil
        goto p113
        ::p80::
        slot_8 = slot_3
        slot_9 = slot_4
        q = slot_7
        q[1] = slot_8
        q[2] = slot_9;
        slot_5(slot_6, slot_7)
        slot_5 = environment["table"]
        slot_5 = slot_5["insert"]
        slot_6 = slot_1["configs_db"]
        goto p8
        ::p90::;
        slot_3 = slot_3(slot_4)
        if slot_3 ~= "" then
            goto p68
        end
        goto p150
        ::p113::
        tick(113)
        z = slot_1
        slot_6 = z;
        slot_5 = z["write_db"];
        slot_5 = slot_5(slot_6)
        if not slot_5 then
            goto p4
        end
        goto p46
        ::p135::
        tick(135)
        slot_8 = slot_1["configs_db"]
        slot_8 = slot_8["menu_list"]
        slot_8 = slot_8[slot_7]
        if slot_8 ~= slot_3 then
            goto p163
        end
        goto p56
        ::p148::
        branch_taken = false
        if not (not (slot_5 <= slot_4)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p165
        end
        goto p157
        ::p150::
        slot_4 = upvalues[1][86]
        slot_5 = "play resource/warning.wav"
        slot_4(slot_5)
        do
            return 
        end
        ::p157::
        slot_4 = upvalues[1][86]
        slot_5 = "play resource/warning.wav"
        slot_4(slot_5)
        do
            return 
        end
        ::p163::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_7 = v
            branch_taken = true
        end
        if branch_taken then
            goto p135
        end
        goto p34
        ::p165::
        z = slot_1
        slot_5 = z;
        slot_4 = z["build_encoded_payload"];
        slot_4 = slot_4(slot_5)
        if slot_4 ~= slot_0 then
            goto p50
        end
        goto p20
    end
end
