-- Recovered function f5; author names are unavailable.
F.f5 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f5")
        tick(1)
        goto p33
        ::p10::
        tick(10)
        registers[4] = (4)
        m, x = pack_returns(registers[1](unpack_range(4, registers, 2)))
        z = 0
        for f = 1, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = upvalues[2]
        goto p49
        ::p15::
        tick(15)
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[1]
        registers[8] = (8)
        registers[6] = registers[6](registers[7], registers[8])
        registers[5] = registers[5] + registers[6]
        do
            return registers[5]
        end
        ::p23::
        tick(23)
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 256)
        goto p15
        ::p27::
        tick(27)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 65536)
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[2]
        goto p23
        ::p33::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]
        registers[3] = (1)
        goto p10
        ::p49::
        registers[6] = registers[4]
        registers[7] = (64)
        registers[5] = registers[5](registers[6], registers[7])
        registers[5] = (registers[5] * 16777216)
        registers[6] = upvalues[2]
        registers[7] = registers[3]
        registers[8] = (32)
        goto p27
    end
end
