-- Recovered function f42; author names are unavailable.
F.f42 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f42")
        tick(1)
        tick(25)
        a = {
            ...,
        }
        registers[1] = a[1]
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["gsub"]
        a = registers
        z = 4;
        a[z] = ".."
        a = D.f43
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[5] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f]
                        F[1] = (3);
                        N[f] = nil
                    end
                end
            end
            return registers[(2)](unpack_range(5, registers, 3))
        end
    end
end
