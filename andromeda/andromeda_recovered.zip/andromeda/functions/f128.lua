-- Recovered function f128; author names are unavailable.
F.f128 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f128")
        tick(1)
        goto p42
        ::p10::
        tick(10)
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p14::
        tick(14)
        registers[5] = upvalues[1][45]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        goto p57
        ::p18::
        tick(18)
        registers[2] = upvalues[2]["closest_enemy"]
        m, x = pack_returns(registers[2]())
        z = 0
        for f = 2, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        if not registers[3] then
            goto p88
        end
        goto p50
        ::p32::
        tick(32)
        registers[7] = (true)
        do
            return registers[7]
        end
        ::p34::
        tick(34)
        registers[1] = (false)
        do
            return registers[1]
        end
        ::p36::
        tick(36)
        registers[4] = upvalues[1][37]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p14
        end
        goto p59
        ::p42::
        registers[1] = upvalues[0]["antiaim"]
        registers[1] = registers[1]["features"]
        registers[1] = registers[1]["anti_backstab"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p84
        end
        goto p34
        ::p50::
        if registers[2] then
            goto p36
        end
        goto p88
        ::p55::
        tick(55)
        registers[2] = (false)
        do
            return registers[2]
        end
        ::p57::
        branch_taken = false
        if registers[5] ~= "CKnife" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p61
        end
        goto p120
        ::p59::
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p61::
        registers[5] = environment["entity"]
        registers[5] = registers[5]["get_flag"]
        registers[6] = registers[3]
        registers[7] = "Hit"
        registers[5] = registers[5](registers[6], registers[7])
        if registers[5] then
            goto p92
        end
        goto p10
        ::p84::
        registers[1] = upvalues[1][32];
        registers[1] = registers[1]()
        if registers[1] then
            goto p18
        end
        goto p55
        ::p88::
        registers[4] = (false)
        do
            return registers[4]
        end
        ::p90::
        tick(90)
        registers[7] = (false)
        do
            return registers[7]
        end
        ::p92::
        registers[5] = upvalues[3]
        registers[6] = upvalues[1][46]
        registers[7] = registers[1]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[6] = upvalues[3]
        goto p127
        ::p120::
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p127::
        registers[7] = upvalues[1][46]
        registers[8] = registers[3]
        m, x = pack_returns(registers[7](unpack_range(8, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["dist2d"]
        registers[9] = registers[6]
        registers[7] = registers[7](registers[8], registers[9])
        if not (300 < registers[7]) then
            goto p32
        end
        goto p90
    end
end
