-- Recovered function f49; author names are unavailable.
F.f49 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f49")
        tick(1)
        goto p38
        ::p2::
        tick(2)
        if not registers[5] then
            goto p12
        end
        goto p81
        ::p12::
        tick(12)
        if registers[5] then
            goto p80
        end
        goto p72
        ::p32::
        tick(32)
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        registers[5] = registers[4] + registers[4]
        registers[5] = registers[1] % registers[5]
        registers[5] = (registers[5] >= registers[4])
        goto p2
        ::p38::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if not registers[3] then
            goto p32
        end
        goto p83
        ::p50::
        tick(50)
        registers[5] = registers[4] % 1
        registers[5] = (registers[4] - registers[5])
        do
            return registers[5]
        end
        ::p72::
        registers[5] = (0)
        goto p80
        ::p75::
        tick(75)
        registers[5] = registers[5] + 1
        registers[5] = 2 ^ registers[5]
        registers[4] = registers[4] % registers[5]
        goto p50
        ::p80::
        do
            return registers[5]
        end
        ::p81::
        registers[5] = (1)
        goto p12
        ::p83::
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        registers[4] = (registers[1] / registers[4])
        a = registers
        z = 5
        q = registers
        q = q[3]
        m = 1
        q = q - m;
        a[z] = q
        registers[6] = (registers[2] - 1)
        registers[5] = (registers[5] - registers[6])
        goto p75
    end
end
