-- Recovered function f309; author names are unavailable.
F.f309 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f309")
        tick(1)
        goto p69
        ::p16::
        tick(16)
        a = upvalues[2];
        slot_3 = a[2][a[1]]
        if slot_3 ~= slot_0 then
            goto p72
        end
        goto p98
        ::p19::
        tick(19)
        slot_3 = (true)
        do
            return slot_3
        end
        ::p31::
        tick(31)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p33::
        tick(33)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p37::
        tick(37)
        slot_3 = upvalues[1]
        slot_4 = slot_1
        slot_5 = slot_2
        slot_3 = slot_3(slot_4, slot_5)
        branch_taken = false
        if slot_3 ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p44
        end
        goto p16
        ::p44::
        tick(44)
        a = upvalues[3]
        a[2][a[1]] = slot_0
        a = upvalues[2]
        a[2][a[1]] = slot_0
        slot_3 = (false)
        do
            return slot_3
        end
        ::p48::
        tick(48)
        slot_3 = environment["entity"]
        slot_3 = slot_3["get_flag"]
        slot_4 = slot_2
        slot_5 = "Hit"
        slot_3 = slot_3(slot_4, slot_5)
        if not slot_3 then
            goto p44
        end
        goto p37
        ::p55::
        tick(55)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p58::
        tick(58)
        a = upvalues[0];
        slot_3 = a[2][a[1]]["moving"]
        if not slot_3 then
            goto p31
        end
        goto p105
        ::p69::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if not slot_1 then
            goto p31
        end
        goto p58
        ::p72::
        tick(72)
        slot_3 = upvalues[4][161]
        slot_4 = upvalues[4][23];
        slot_4 = slot_4()
        goto p114
        ::p98::
        slot_3 = upvalues[4][23];
        slot_3 = slot_3()
        a = upvalues[3]
        a[2][a[1]] = slot_3
        slot_3 = upvalues[4][23];
        slot_3 = slot_3()
        a = upvalues[2]
        a[2][a[1]] = slot_3
        goto p72
        ::p105::
        if slot_2 then
            goto p107
        end
        goto p31
        ::p107::
        slot_3 = environment["entity"]
        slot_3 = slot_3["get_flag"]
        slot_4 = slot_2
        slot_5 = "Occluded"
        slot_3 = slot_3(slot_4, slot_5)
        if not slot_3 then
            goto p48
        end
        goto p55
        ::p114::
        a = upvalues[3];
        slot_5 = a[2][a[1]]
        slot_4 = (slot_4 - slot_5);
        slot_3 = slot_3(slot_4)
        branch_taken = false
        if not (not (16 <= slot_3)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p19
        end
        goto p33
    end
end
