-- Recovered function f88; author names are unavailable.
F.f88 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f88")
        tick(1)
        goto p18
        ::p15::
        tick(15)
        do
            return slot_2
        end
        ::p18::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = slot_1 % 1
        slot_2 = (slot_1 - slot_2)
        goto p15
    end
end
