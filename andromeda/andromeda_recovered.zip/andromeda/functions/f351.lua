-- Recovered function f351; author names are unavailable.
F.f351 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f351")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][163]
        slot_3 = (slot_1 * 12.9898)
        slot_3 = slot_3 + 78.233;
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 * 43758.5453)
        slot_3 = upvalues[0][154]
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        slot_3 = (slot_2 - slot_3)
        do
            return slot_3
        end
    end
end
