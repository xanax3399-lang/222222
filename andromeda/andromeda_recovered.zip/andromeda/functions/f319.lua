-- Recovered function f319; author names are unavailable.
F.f319 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f319")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = a[6]
        registers[7] = a[7]
        registers[8] = upvalues[0]["get_animation_alpha"]
        registers[9] = registers[1]["key"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = upvalues[0]["get_animation_slide"]
        registers[10] = registers[1]["key"]
        goto p106
        ::p13::
        tick(13)
        registers[13] = registers[3]
        registers[14] = registers[4]
        registers[15] = registers[5]
        registers[16] = registers[8]
        registers[(11)](unpack_range(16, registers, 12))
        registers[11] = upvalues[0]["draw_item"]
        registers[12] = registers[1]
        registers[13] = registers[2]
        goto p31
        ::p29::
        tick(29)
        registers[(11)](unpack_range(17, registers, 12))
        do
            return 
        end
        ::p31::
        registers[14] = registers[3]
        registers[15] = registers[4]
        registers[16] = registers[5]
        registers[17] = registers[6]
        registers[18] = registers[7]
        registers[19] = registers[8]
        registers[20] = registers[9]
        registers[21] = (false)
        registers[(11)](unpack_range(21, registers, 12))
        registers[11] = upvalues[0]["draw_planting_progress_circle"]
        registers[12] = registers[10]
        registers[13] = registers[3]
        goto p120
        ::p106::;
        registers[(9)] = registers[(9)](registers[10])
        registers[10] = upvalues[1][154]
        registers[11] = upvalues[0]["px"]
        registers[12] = (26)
        registers[13] = registers[6]
        registers[11] = registers[11](registers[12], registers[13])
        registers[11] = registers[11] * registers[9]
        registers[11] = registers[11] + 0.5;
        registers[(10)] = registers[(10)](registers[11])
        registers[10] = (registers[2] - registers[10])
        registers[11] = upvalues[0]["draw_row_background"]
        registers[12] = registers[10]
        goto p13
        ::p120::
        registers[14] = registers[4]
        registers[15] = registers[5]
        registers[16] = registers[6]
        registers[17] = registers[8]
        goto p29
    end
end
