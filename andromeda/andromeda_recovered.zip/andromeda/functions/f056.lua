-- Recovered function f56; author names are unavailable.
F.f56 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f56")
        tick(1)
        a = D.f57
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[1] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = upvalues[0]
        a[2][a[1]] = registers[1]
        a = upvalues[1]
        a[2][a[1]] = (0)
        ::p6::
        tick(6)
        goto p6
        error("ANDROMEDA_INVALID_FALLTHROUGH: f56 pc=6", 0)
    end
end
