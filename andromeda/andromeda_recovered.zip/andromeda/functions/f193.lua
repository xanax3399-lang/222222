-- Recovered function f193; author names are unavailable.
F.f193 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f193")
        tick(1)
        slot_1 = upvalues[0]
        z = slot_1
        slot_2 = z;
        slot_1 = z["export_config"]
        slot_1(slot_2)
        do
            return 
        end
    end
end
