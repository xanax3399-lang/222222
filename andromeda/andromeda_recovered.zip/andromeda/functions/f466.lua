-- Recovered function f466; author names are unavailable.
F.f466 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8 = nil, nil, nil, nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f466")
        tick(1)
        goto p42
        ::p2::
        tick(2)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_2 = nil
        do
            return slot_2
        end
        ::p16::
        tick(16)
        slot_6 = upvalues[0]["render_items"]
        slot_6 = slot_6[slot_5]
        if slot_6 == slot_0 then
            goto p20
        end
        goto p22
        ::p20::
        tick(20)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_5 = v
            branch_taken = true
        end
        if branch_taken then
            goto p49
        end
        goto p2
        ::p22::
        slot_7 = slot_6["kind"]
        branch_taken = false
        if slot_7 ~= "bomb_hp" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p40
        end
        slot_8 = slot_6["kind"]
        if slot_8 ~= "fatal" then
            goto p20
        end
        ::p40::
        slot_7 = slot_5
        do
            return slot_7
        end
        ::p42::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = (1)
        slot_3 = upvalues[0]["render_count"]
        slot_4 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_4 + 0
        n = (slot_3 + 0)
        v = (slot_2 - U)
        goto p20
        goto p20
        ::p49::
        if slot_5 == slot_1 then
            goto p20
        end
        goto p16
    end
end
