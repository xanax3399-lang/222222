-- Recovered function f220; author names are unavailable.
F.f220 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_28, slot_29, slot_30, slot_31, slot_32, slot_33, slot_34, slot_35 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, n, v, R = andromeda_environment, nil, nil, nil
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f220")
        tick(1)
        goto p78
        ::p2::
        tick(2)
        slot_5 = (1)
        slot_6 = (#slot_4)
        slot_7 = (1)
        goto p41
        ::p6::
        tick(6)
        slot_4 = {
        }
        goto p2
        ::p16::
        tick(16);
        slot_11 = slot_11(slot_12)
        if slot_11 ~= "number" then
            goto p82
        end
        goto p97
        ::p20::
        tick(20)
        slot_9 = slot_4[slot_8]
        if slot_9 == slot_0 then
            goto p82
        end
        goto p130
        ::p41::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_7 + 0
        n = (slot_6 + 0)
        v = (slot_5 - U)
        goto p82
        slot_29 = code_metadata
        slot_35 = operand_k
        slot_29[75] = 184
        slot_35[49] = 77
        slot_28 = nil
        slot_29 = nil
        slot_30 = nil
        slot_31 = nil
        slot_32 = nil
        slot_33 = nil
        slot_34 = nil
        slot_35 = nil
        goto p78
        ::p63::
        tick(63)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_5 = upvalues[0]["cache"]
        slot_5[slot_1] = slot_3
        slot_5 = slot_3
        do
            return slot_5
        end
        ::p78::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0]["cache"]
        slot_3 = slot_3[slot_1]
        goto p90
        ::p82::
        tick(82)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_8 = v
            branch_taken = true
        end
        if branch_taken then
            goto p20
        end
        goto p63
        ::p86::
        tick(86)
        slot_3 = upvalues[0]["cache"]
        slot_3 = slot_3[slot_1]
        do
            return slot_3
        end
        ::p90::
        if slot_3 == slot_0 then
            goto p113
        end
        goto p86
        ::p97::
        slot_11 = (#slot_3)
        slot_11 = slot_11 + 1
        slot_12 = {
        }
        slot_12["ref"] = slot_9
        slot_12["value"] = slot_10
        slot_3[slot_11] = slot_12
        goto p82
        ::p113::
        slot_3 = {
        }
        slot_4 = slot_2["cvars"]
        if slot_4 then
            goto p2
        end
        goto p6
        ::p130::
        z = slot_9
        slot_11 = z;
        slot_10 = z["get_int"];
        slot_10 = slot_10(slot_11)
        slot_11 = environment["type"]
        slot_12 = slot_10
        goto p16
    end
end
