-- Recovered function f244; author names are unavailable.
F.f244 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f244")
        tick(1)
        goto p17
        ::p2::
        tick(2)
        slot_3 = nil
        ::p3::
        tick(3)
        slot_4 = (slot_3 ~= slot_0)
        if not slot_4 then
            goto p7
        end
        goto p22
        ::p6::
        tick(6)
        do
            return slot_4
        end
        ::p7::
        tick(7)
        if not slot_4 then
            goto p6
        end
        goto p14
        ::p9::
        tick(9)
        slot_3 = slot_2["invalid_tick_cleaner"]
        ::p12::
        tick(12)
        if slot_3 then
            goto p3
        end
        goto p2
        ::p14::
        a = upvalues[0];
        slot_4 = a[2][a[1]]["air"]
        slot_4 = (slot_4 == true)
        goto p6
        ::p17::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = slot_2
        if not slot_3 then
            goto p12
        end
        goto p9
        ::p22::
        z = slot_3
        slot_5 = z;
        slot_4 = z["get"];
        slot_4 = slot_4(slot_5)
        slot_4 = (slot_4 == "Remove Backtrack")
        goto p7
    end
end
