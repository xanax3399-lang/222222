-- Recovered function f350; author names are unavailable.
F.f350 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f350")
        tick(1)
        tick(40)
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["fakeduck"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        slot_1 = (slot_1 == true)
        do
            return slot_1
        end
    end
end
