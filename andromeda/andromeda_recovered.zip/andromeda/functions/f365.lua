-- Recovered function f365; author names are unavailable.
F.f365 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local tick = new_tick("f365")
        tick(1)
        goto p275
        ::p3::
        tick(3)
        registers[8] = registers[5]
        m, x = pack_returns(registers[8]())
        z = 0
        for f = 8, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[4]
        if not registers[11] then
            goto p110
        end
        goto p239
        ::p8::
        tick(8)
        registers[15] = registers[10]
        m, x = pack_returns(registers[13](unpack_range(15, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        registers[13] = upvalues[5]
        registers[14] = -registers[12]
        registers[15] = registers[12]
        a = upvalues[3];
        registers[16] = a[2][a[1]]["current"]
        goto p183
        ::p16::
        tick(16)
        if registers[7] ~= "Spin" then
            goto p39
        end
        goto p3
        ::p30::
        tick(30)
        registers[11] = registers[8]
        goto p62
        ::p39::
        if registers[7] ~= "Meta" then
            goto p66
        end
        goto p118
        ::p41::
        tick(41)
        registers[8] = registers[5]
        m, x = pack_returns(registers[8]())
        z = 0
        for f = 8, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[4]
        goto p174
        ::p47::
        tick(47)
        a = D.f366
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[7] = registers[2]["type"]
        z = registers[7]
        registers[8] = z;
        registers[(7)] = z["get"]
        goto p91
        ::p52::
        tick(52)
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f]
                        F[1] = (3);
                        N[f] = nil
                    end
                end
            end
            return registers[(14)](unpack_range(17, registers, 15))
        end
        ::p60::
        tick(60)
        registers[13] = registers[12]
        goto p266
        ::p62::
        tick(62)
        if registers[11] then
            goto p85
        end
        goto p95
        ::p64::
        tick(64)
        if registers[7] ~= "Skitter" then
            goto p237
        end
        goto p104
        ::p66::
        registers[8] = (0)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[8]
        end
        ::p68::
        tick(68)
        registers[4] = (0)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[4]
        end
        ::p76::
        tick(76)
        if registers[10] then
            goto p229
        end
        goto p270
        ::p78::
        tick(78)
        z = registers[3]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p134
        end
        goto p68
        ::p82::
        tick(82)
        registers[13] = -registers[12]
        goto p272
        ::p85::
        tick(85)
        registers[12] = upvalues[0][161]
        registers[13] = registers[11];
        registers[(12)] = registers[(12)](registers[13])
        registers[13] = registers[4]
        goto p227
        ::p91::;
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] ~= "Off" then
            goto p64
        end
        goto p132
        ::p95::
        registers[11] = registers[9]
        goto p85
        ::p97::
        tick(97)
        if registers[10] then
            goto p76
        end
        goto p129
        ::p104::
        registers[8] = registers[1]["inverts"]
        registers[8] = registers[8] % 3
        registers[9] = registers[2]["global"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p171
        ::p110::
        tick(110)
        if registers[11] then
            goto p121
        end
        goto p241
        ::p112::
        tick(112)
        if registers[11] then
            goto p139
        end
        goto p187
        ::p114::
        tick(114)
        if registers[3] == registers[0] then
            goto p134
        end
        goto p78
        ::p116::
        tick(116)
        registers[11] = registers[8]
        goto p112
        ::p118::
        z = registers[1]
        registers[9] = z;
        registers[(8)] = z["get_hidden_meta_modifier_add"]
        registers[10] = registers[2]
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f]
                        F[1] = (3);
                        N[f] = nil
                    end
                end
            end
            return registers[(8)](unpack_range(10, registers, 9))
        end
        ::p121::
        tick(121)
        registers[12] = upvalues[0][161]
        registers[13] = registers[6]
        registers[14] = registers[11]
        goto p212
        ::p127::
        tick(127)
        registers[10] = (0)
        goto p76
        ::p129::
        registers[10] = (registers[8] == 1)
        if not registers[10] then
            goto p76
        end
        goto p127
        ::p132::
        registers[8] = (0)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[8]
        end
        ::p134::
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["is_left_side"];
        registers[(4)] = registers[(4)](registers[5])
        a = D.f367
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[5] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p47
        ::p139::
        tick(139)
        registers[12] = upvalues[0][161]
        registers[13] = registers[6]
        registers[14] = registers[11]
        goto p8
        ::p171::
        registers[10] = (registers[8] == 0)
        if not registers[10] then
            goto p97
        end
        goto p243
        ::p174::
        if not registers[11] then
            goto p62
        end
        goto p30
        ::p183::
        registers[16] = upvalues[2][registers[16]]
        registers[17] = registers[4]
        registers[18] = 41 + registers[10]
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f]
                        F[1] = (3);
                        N[f] = nil
                    end
                end
            end
            return registers[(13)](unpack_range(18, registers, 14))
        end
        ::p187::
        registers[11] = registers[9]
        goto p139
        ::p210::
        tick(210)
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f]
                        F[1] = (3);
                        N[f] = nil
                    end
                end
            end
            return registers[(14)](unpack_range(16, registers, 15))
        end
        ::p212::
        registers[15] = registers[10]
        m, x = pack_returns(registers[13](unpack_range(15, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        registers[13] = upvalues[0][26];
        registers[13] = registers[13]()
        registers[13] = (registers[13] * 3)
        registers[13] = registers[13] % 1
        goto p222
        ::p220::
        tick(220)
        if registers[7] ~= "Random" then
            goto p16
        end
        goto p260
        ::p222::
        registers[14] = upvalues[4]["lerp"]
        registers[15] = -registers[12]
        registers[16] = registers[12]
        registers[17] = registers[13]
        goto p52
        ::p227::
        if not registers[13] then
            goto p272
        end
        goto p82
        ::p229::
        tick(229)
        registers[11] = registers[10]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[11]
        end
        ::p237::
        if registers[7] ~= "Center" then
            goto p220
        end
        goto p41
        ::p239::
        registers[11] = registers[8]
        goto p110
        ::p241::
        registers[11] = registers[9]
        goto p121
        ::p243::
        registers[10] = -registers[9]
        goto p97
        ::p260::
        registers[8] = registers[5]
        m, x = pack_returns(registers[8]())
        z = 0
        for f = 8, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[4]
        if not registers[11] then
            goto p112
        end
        goto p116
        ::p266::
        tick(266)
        registers[14] = registers[6]
        registers[15] = registers[13]
        registers[16] = registers[10]
        goto p210
        ::p270::
        registers[10] = registers[9]
        goto p229
        ::p272::
        if registers[13] then
            goto p266
        end
        goto p60
        ::p275::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[2] == registers[0] then
            goto p68
        end
        goto p114
    end
end
