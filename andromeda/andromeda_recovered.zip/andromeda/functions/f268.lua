-- Recovered function f268; author names are unavailable.
F.f268 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local tick = new_tick("f268")
        tick(1)
        goto p57
        ::p2::
        tick(2)
        do
            return slot_2
        end
        ::p24::
        tick(24)
        if not slot_2 then
            goto p2
        end
        goto p28
        ::p26::
        tick(26)
        slot_2 = (slot_1 ~= "")
        goto p41
        ::p28::
        z = slot_1
        slot_3 = z;
        slot_2 = z["match"]
        slot_4 = "^[A-Za-z0-9+/=]+$"
        slot_2 = slot_2(slot_3, slot_4)
        slot_2 = (slot_2 ~= slot_0)
        goto p2
        ::p41::
        tick(41)
        if not slot_2 then
            goto p24
        end
        slot_2 = (#slot_1)
        slot_2 = slot_2 % 4
        slot_2 = (slot_2 == 0)
        goto p24
        ::p57::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == "string")
        if not slot_2 then
            goto p41
        end
        goto p26
    end
end
