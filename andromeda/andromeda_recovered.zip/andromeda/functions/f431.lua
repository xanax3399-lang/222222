-- Recovered function f431; author names are unavailable.
F.f431 = function(function_metadata, upvalues)
    local operand_i, operand_g, code_metadata, operand_k = function_metadata[2], function_metadata[6], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f431")
        tick(1)
        goto p101
        ::p9::
        tick(9)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = upvalues[1]
        registers[5] = registers[3]
        goto p123
        ::p13::
        tick(13)
        do
            return 
        end
        ::p25::
        tick(25)
        m, x = pack_returns(registers[4](unpack_range(6, registers, 5)))
        z = 0
        for f = 4, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(4)]
        n = registers[5]
        U = registers[6]
        goto p121
        ::p27::
        tick(27)
        registers[7] = registers[3]
        registers[(4)](unpack_range(7, registers, 5))
        z = registers[3]
        registers[5] = z;
        registers[(4)] = z["gmatch"]
        registers[6] = "[%w%+/%=_%-]+"
        goto p25
        ::p48::
        tick(48)
        if registers[4] ~= registers[3] then
            goto p97
        end
        goto p96
        ::p50::
        tick(50)
        registers[10] = registers[6]
        registers[(7)](unpack_range(10, registers, 8))
        goto p112
        ::p63::
        tick(63)
        branch_taken = false
        if registers[4] ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p65
        end
        goto p13
        ::p65::
        registers[4] = upvalues[0]
        registers[5] = registers[1]
        registers[6] = registers[2]
        goto p27
        ::p69::
        tick(69)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p72::
        tick(72)
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(5)]
        n = registers[6]
        U = registers[7]
        goto p112
        registers[28] = operand_k
        registers[26] = operand_g
        registers[22] = code_metadata
        registers[27] = operand_i
        registers[26][90] = 7
        registers[27][90] = 0
        registers[22][90] = 7
        registers[28][83] = 111
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        registers[28] = nil
        goto p112
        ::p90::
        tick(90)
        registers[7] = upvalues[0]
        registers[8] = registers[1]
        registers[9] = registers[2]
        goto p50
        ::p96::
        tick(96)
        do
            return 
        end
        ::p97::
        registers[5] = upvalues[0]
        registers[6] = registers[1]
        registers[7] = registers[2]
        goto p106
        ::p101::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = environment["type"]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p63
        ::p106::
        registers[8] = registers[4]
        registers[(5)](unpack_range(8, registers, 6))
        z = registers[4]
        registers[6] = z;
        registers[(5)] = z["gmatch"]
        registers[7] = "[%w%+/%=_%-]+"
        m, x = pack_returns(registers[5](unpack_range(7, registers, 6)))
        z = 0
        for f = 5, 7 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p72
        ::p112::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[6] = z;
            registers[7] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p90
        end
        goto p69
        ::p121::
        tick(121)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[5] = z;
            registers[6] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p126
        end
        goto p9
        ::p123::;
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] == registers[0] then
            goto p96
        end
        goto p48
        ::p126::
        registers[6] = upvalues[0]
        registers[7] = registers[1]
        registers[8] = registers[2]
        registers[9] = registers[5]
        registers[(6)](unpack_range(9, registers, 7))
        goto p121
    end
end
