-- Recovered function f34; author names are unavailable.
F.f34 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_11, slot_12, slot_13, slot_14, slot_15, slot_16, slot_17, slot_18, slot_19, slot_20, slot_21 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f34")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = ""
        slot_4 = (1)
        goto p53
        ::p7::
        tick(7)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_7 = v
            branch_taken = true
        end
        if branch_taken then
            goto p48
        end
        goto p80
        ::p18::
        tick(18)
        slot_20 = constant_cache[7]
        slot_21 = "\182L";
        slot_20 = slot_20(slot_21)
        slot_19 = slot_19 + slot_20
        slot_19 = 31665 + slot_19
        slot_19 = slot_19 + -31666
        slot_17[50] = slot_19
        slot_18[52] = 47
        slot_11 = nil
        slot_12 = nil
        slot_13 = nil
        slot_14 = nil
        slot_15 = nil
        slot_16 = nil
        slot_17 = nil
        slot_18 = nil
        slot_19 = nil
        slot_20 = nil
        slot_21 = nil
        goto p48
        ::p29::
        tick(29)
        slot_19 = (150)
        goto p18
        ::p31::
        tick(31)
        slot_9 = (slot_1 - slot_8)
        slot_1 = slot_9 / 256
        goto p7
        ::p48::
        slot_8 = slot_1 % 256
        slot_9 = upvalues[0][slot_8]
        slot_3 = (slot_9..slot_3)
        goto p31
        ::p53::
        slot_5 = slot_2
        slot_6 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_6 + 0
        n = (slot_5 + 0)
        v = (slot_4 - U)
        goto p7
        if slot_19 then
            goto p18
        end
        goto p29
        ::p80::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_4 = slot_3
        do
            return slot_4
        end
    end
end
