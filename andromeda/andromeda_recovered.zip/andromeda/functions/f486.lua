-- Recovered function f486; author names are unavailable.
F.f486 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f486")
        tick(1)
        goto p113
        ::p25::
        tick(25)
        registers[5] = registers[5]["viewmodel_offset_y"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_float"]
        a = registers
        z = 7
        q = registers
        q = q[3]
        a[z] = q;
        registers[5](registers[6], registers[7])
        registers[5] = environment["cvar"]
        registers[5] = registers[5]["viewmodel_offset_z"]
        goto p47
        ::p36::
        tick(36)
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        a = registers
        z = 5
        q = upvalues
        q = q[3]
        a[z] = q
        registers[6] = registers[1]
        registers[(5)](registers[6])
        registers[5] = environment["cvar"]
        registers[5] = registers[5]["viewmodel_fov"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_float"]
        goto p71
        ::p47::
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_float"]
        registers[7] = registers[4];
        registers[5](registers[6], registers[7])
        goto p131
        ::p51::
        tick(51)
        if registers[2] == registers[0] then
            goto p131
        end
        goto p129
        ::p54::
        tick(54)
        a = registers
        z = (4)
        q = environment
        q = q["cvar"]
        a[z] = q
        registers[4] = registers[4]["viewmodel_offset_z"]
        if registers[4] ~= registers[0] then
            goto p152
        end
        goto p128
        ::p71::
        registers[7] = upvalues[4]
        registers[8] = upvalues[0]["viewmodel_fov"];
        registers[(7)] = registers[(7)](registers[8])
        registers[7] = (registers[7] * 0.1);
        registers[5](registers[6], registers[7])
        goto p51
        ::p77::
        tick(77)
        registers[2] = environment["cvar"]
        registers[2] = registers[2]["viewmodel_offset_x"]
        if registers[2] == registers[0] then
            goto p128
        end
        goto p140
        ::p81::
        tick(81)
        a = upvalues[5];
        registers[1] = a[2][a[1]]
        if not registers[1] then
            goto p117
        end
        goto p123
        ::p103::
        tick(103)
        registers[5] = environment["cvar"]
        registers[5] = registers[5]["viewmodel_offset_x"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_float"]
        registers[7] = registers[2];
        registers[5](registers[6], registers[7])
        registers[5] = environment["cvar"]
        goto p25
        ::p113::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_fov"]
        if registers[1] == registers[0] then
            goto p128
        end
        goto p77
        ::p117::
        tick(117)
        do
            return 
        end
        ::p118::
        tick(118)
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        registers[2] = upvalues[2]
        registers[3] = registers[1]
        goto p36
        ::p123::
        registers[1] = upvalues[6]
        registers[(1)]()
        a = upvalues[5]
        a[2][a[1]] = (false)
        goto p117
        ::p128::
        tick(128)
        do
            return 
        end
        ::p129::
        if registers[3] == registers[0] then
            goto p131
        end
        goto p144
        ::p131::
        tick(131)
        a = upvalues[5]
        a[2][a[1]] = (true)
        goto p117
        ::p140::
        registers[3] = environment["cvar"]
        registers[3] = registers[3]["viewmodel_offset_y"]
        if registers[3] == registers[0] then
            goto p128
        end
        goto p54
        ::p144::
        if registers[4] == registers[0] then
            goto p131
        end
        goto p103
        ::p152::
        registers[1] = upvalues[0]["viewmodel"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if not registers[1] then
            goto p81
        end
        goto p118
    end
end
