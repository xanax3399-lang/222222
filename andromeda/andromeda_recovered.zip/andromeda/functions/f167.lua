-- Recovered function f167; author names are unavailable.
F.f167 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f167")
        tick(1)
        goto p19
        ::p17::
        tick(17)
        if not slot_3 then
            goto p65
        end
        goto p82
        ::p19::
        a = {
            ...,
        }
        slot_1 = a[1]
        a = upvalues[0];
        slot_2 = a[2][a[1]]["current"]
        if slot_2 ~= "Air-crouch" then
            goto p73
        end
        goto p39
        ::p30::
        tick(30)
        slot_4 = slot_1["body_yaw"]
        slot_4 = slot_4["inverter"]
        slot_4 = not slot_4
        do
            return slot_4
        end
        ::p39::
        slot_2 = upvalues[1]["builder"]
        a = upvalues[0];
        slot_3 = a[2][a[1]]["current"]
        slot_2 = slot_2[slot_3]
        slot_3 = (slot_2 ~= slot_0)
        goto p17
        ::p65::
        tick(65)
        if slot_3 then
            goto p114
        end
        goto p92
        ::p73::
        slot_2 = slot_1["body_yaw"]
        slot_2 = slot_2["inverter"]
        do
            return slot_2
        end
        ::p82::
        slot_3 = slot_2["body_yaw"]
        goto p65
        ::p92::
        slot_3 = nil
        goto p114
        ::p103::
        tick(103)
        slot_4 = slot_3["type"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["get"];
        slot_4 = slot_4(slot_5)
        if slot_4 ~= "Jitter" then
            goto p30
        end
        slot_4 = slot_1["body_yaw"]
        slot_4 = slot_4["inverter"]
        do
            return slot_4
        end
        ::p114::
        if slot_3 == slot_0 then
            goto p30
        end
        goto p103
    end
end
