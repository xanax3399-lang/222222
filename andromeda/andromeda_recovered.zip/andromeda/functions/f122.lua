-- Recovered function f122; author names are unavailable.
F.f122 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f122")
        tick(1)
        goto p263
        ::p2::
        tick(2)
        if registers[8] then
            goto p117
        end
        goto p144
        ::p5::
        tick(5)
        registers[12] = registers[9]
        goto p130
        ::p7::
        tick(7)
        registers[6] = registers[6] + registers[3]
        registers[6] = (registers[6] - registers[2])
        registers[6] = registers[6] + registers[3]
        goto p303
        ::p12::
        tick(12)
        if registers[12] then
            goto p150
        end
        goto p52
        ::p14::
        tick(14)
        registers[7] = (registers[7] - registers[6])
        registers[7] = registers[7] + registers[6]
        registers[7] = (registers[7] - registers[5])
        goto p126
        ::p18::
        tick(18)
        registers[9] = -132947751 + registers[9]
        registers[10] = (registers[4] - registers[3])
        registers[10] = registers[10] + registers[5]
        goto p33
        ::p22::
        tick(22)
        registers[12] = registers[12] + registers[8]
        registers[12] = (registers[12] - registers[6])
        registers[12] = (registers[12] - registers[2])
        registers[12] = (registers[12] >= registers[6])
        goto p260
        ::p27::
        tick(27)
        registers[8] = registers[8] == registers[2]
        if not registers[8] then
            goto p2
        end
        goto p55
        ::p31::
        tick(31)
        registers[9] = registers[3]
        goto p140
        ::p33::
        registers[10] = (registers[10] - registers[7])
        registers[10] = (registers[10] - registers[7])
        registers[10] = (registers[10] - registers[5])
        registers[10] = registers[10] + registers[8]
        registers[10] = registers[10] + registers[9]
        goto p318
        ::p52::
        registers[12] = registers[1]
        goto p150
        ::p55::
        registers[8] = registers[5]
        goto p2
        ::p64::
        tick(64)
        if registers[12] then
            goto p243
        end
        goto p316
        ::p66::
        tick(66)
        if registers[12] then
            goto p289
        end
        goto p216
        ::p69::
        tick(69)
        if not registers[7] then
            goto p124
        end
        goto p222
        ::p71::
        tick(71)
        if registers[9] then
            goto p140
        end
        goto p31
        ::p73::
        tick(73)
        if registers[12] then
            goto p130
        end
        goto p5
        ::p83::
        tick(83)
        if registers[7] then
            goto p238
        end
        goto p187
        ::p85::
        tick(85)
        registers[7] = registers[1]
        goto p299
        ::p89::
        tick(89)
        registers[12] = registers[12] < registers[6]
        if not registers[12] then
            goto p73
        end
        goto p108
        ::p101::
        tick(101)
        if registers[12] then
            goto p22
        end
        registers[12] = registers[3]
        goto p22
        ::p108::
        registers[12] = registers[2]
        goto p73
        ::p111::
        tick(111)
        if registers[12] then
            goto p175
        end
        registers[12] = registers[1]
        goto p175
        ::p117::
        tick(117)
        registers[8] = (registers[8] - registers[6])
        registers[8] = registers[8] + registers[4]
        registers[8] = (registers[8] - registers[4])
        registers[8] = registers[8] + registers[7]
        registers[8] = -1107389522 + registers[8]
        registers[9] = registers[6] + registers[2]
        goto p157
        ::p124::
        tick(124)
        if registers[7] then
            goto p299
        end
        goto p85
        ::p126::
        registers[7] = 855350131 + registers[7]
        registers[8] = registers[3] + registers[1]
        registers[8] = registers[8] + registers[4]
        goto p268
        ::p130::
        registers[11] = registers[11] + registers[12]
        a = registers
        z = (11)
        q = (20319177570)
        m = registers
        x = 11
        m = m[x]
        q = q + m
        a[z] = q
        do
            return registers[11]
        end
        ::p136::
        tick(136)
        registers[12] = registers[5]
        goto p101
        ::p138::
        tick(138)
        registers[7] = registers[4]
        goto p178
        ::p140::
        registers[9] = (registers[9] - registers[1])
        registers[9] = (registers[9] - registers[7])
        registers[9] = (registers[9] - registers[8])
        goto p276
        ::p144::
        registers[8] = registers[6]
        goto p117
        ::p146::
        tick(146)
        registers[12] = registers[8]
        goto p64
        ::p148::
        tick(148)
        registers[12] = registers[5]
        goto p66
        ::p150::
        registers[12] = (registers[12] - registers[3])
        registers[12] = (registers[12] - registers[6])
        registers[12] = registers[12] > registers[9]
        if not registers[12] then
            goto p64
        end
        goto p146
        ::p155::
        tick(155)
        registers[7] = registers[2]
        goto p14
        ::p157::
        registers[9] = (registers[9] - registers[7])
        registers[9] = registers[9] + registers[4]
        registers[9] = (registers[9] <= registers[1])
        if not registers[9] then
            goto p71
        end
        goto p207
        ::p175::
        registers[12] = (registers[12] <= registers[8])
        if not registers[12] then
            goto p101
        end
        goto p136
        ::p178::
        tick(178)
        if registers[7] then
            goto p14
        end
        goto p155
        ::p180::
        tick(180)
        registers[12] = registers[5]
        goto p111
        ::p182::
        tick(182)
        registers[12] = registers[4]
        goto p12
        ::p185::
        tick(185)
        if not registers[12] then
            goto p111
        end
        goto p180
        ::p187::
        registers[7] = registers[1]
        goto p238
        ::p207::
        registers[9] = registers[8]
        goto p71
        ::p216::
        a = registers
        z = 12
        q = registers
        q = q[10]
        a[z] = q
        goto p289
        ::p220::
        tick(220)
        if not registers[7] then
            goto p83
        end
        goto p235
        ::p222::
        registers[7] = registers[3]
        goto p124
        ::p235::
        registers[7] = registers[4]
        goto p83
        ::p238::
        registers[7] = (registers[7] - registers[5])
        registers[7] = (registers[7] - registers[5])
        registers[7] = (registers[7] ~= registers[3])
        if not registers[7] then
            goto p178
        end
        goto p138
        ::p243::
        tick(243)
        registers[12] = (registers[12] ~= registers[2])
        if not registers[12] then
            goto p66
        end
        goto p148
        ::p260::
        if not registers[12] then
            goto p12
        end
        goto p182
        ::p263::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = registers[4] + registers[1]
        registers[6] = (registers[6] - registers[4])
        registers[6] = registers[6] + registers[4]
        goto p272
        ::p268::
        registers[8] = registers[8] + registers[3]
        registers[8] = registers[8] + registers[7]
        registers[8] = (registers[8] - registers[4])
        goto p27
        ::p272::
        registers[6] = (registers[6] - registers[4])
        registers[6] = registers[6] + registers[2]
        registers[6] = registers[6] + registers[1]
        goto p7
        ::p276::
        registers[9] = (registers[9] - registers[3])
        registers[9] = registers[9] + registers[8]
        registers[9] = registers[9] + registers[3]
        goto p18
        ::p281::
        tick(281)
        registers[11] = (0 * 4503599627370495)
        a = registers
        z = 12
        q = registers
        q = q[6]
        m = registers
        x = 8
        m = m[x]
        q = q + m
        a[z] = q
        registers[12] = registers[12] + registers[5]
        registers[12] = registers[12] > registers[1]
        goto p185
        ::p289::
        registers[12] = (registers[12] - registers[4])
        registers[12] = registers[12] + registers[5]
        registers[12] = registers[12] + registers[8]
        registers[12] = (registers[12] - registers[9])
        registers[12] = registers[12] + registers[5]
        registers[12] = (registers[12] - registers[10])
        registers[12] = registers[12] + registers[8]
        goto p89
        ::p299::
        registers[7] = registers[7] + registers[3]
        registers[7] = registers[7] + registers[2]
        registers[7] = registers[7] < registers[5]
        goto p220
        ::p303::
        registers[6] = registers[6] + registers[5]
        registers[6] = -4966425099 + registers[6]
        registers[7] = (registers[5] >= registers[1])
        goto p69
        ::p316::
        registers[12] = registers[1]
        goto p243
        ::p318::
        registers[10] = registers[10] + registers[7]
        registers[10] = registers[10] + registers[3]
        registers[10] = registers[10] + registers[7]
        registers[10] = 3688927203 + registers[10]
        goto p281
    end
end
