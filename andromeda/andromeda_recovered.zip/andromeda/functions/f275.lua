-- Recovered function f275; author names are unavailable.
F.f275 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f275")
        tick(1)
        goto p9
        ::p3::
        tick(3)
        slot_2 = upvalues[0]["swap_buffers"]
        slot_2()
        upvalues[0]["capture_frame"] = slot_1
        upvalues[0]["capture_count"] = 0
        do
            return 
        end
        ::p9::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["capture_frame"]
        if slot_2 ~= slot_1 then
            goto p3
        end
        do
            return 
        end
    end
end
