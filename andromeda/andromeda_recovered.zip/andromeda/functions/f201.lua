-- Recovered function f201; author names are unavailable.
F.f201 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f201")
        tick(1)
        goto p560
        ::p4::
        tick(4)
        registers[1] = upvalues[8]["ragebot"]
        registers[1] = registers[1]["log_spread"]
        if registers[1] == registers[0] then
            goto p258
        end
        goto p249
        ::p10::
        tick(10)
        if not registers[12] then
            goto p762
        end
        goto p595
        ::p12::
        tick(12)
        registers[10] = (registers[9] == "Onetap")
        goto p241
        ::p14::
        tick(14);
        registers[13](registers[14], registers[15])
        goto p850
        ::p16::
        tick(16)
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p360
        ::p20::
        tick(20)
        if registers[9] then
            goto p814
        end
        goto p40
        ::p23::
        tick(23);
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= "Configs" then
            goto p299
        end
        goto p679
        ::p26::
        tick(26)
        registers[11] = registers[7]
        goto p493
        ::p28::
        tick(28)
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p614
        ::p40::
        registers[9] = "CS2"
        goto p814
        ::p42::
        tick(42)
        registers[1] = upvalues[10]["switch_type"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[1] = (registers[1] == "Gamesense")
        goto p636
        ::p47::
        tick(47)
        registers[9] = registers[5]["native_indicators"]
        if registers[9] == registers[0] then
            goto p870
        end
        goto p791
        ::p50::
        tick(50)
        if registers[9] == registers[0] then
            goto p923
        end
        goto p662
        ::p52::
        tick(52)
        registers[9] = registers[5]["manual_arrows_offset"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[4]
        if not registers[11] then
            goto p185
        end
        goto p821
        ::p65::
        tick(65)
        registers[9] = registers[5]["aimbot_logs_gradient"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p714
        ::p69::
        tick(69)
        registers[9] = registers[5]["watermark_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p20
        ::p73::
        tick(73)
        if not registers[11] then
            goto p926
        end
        goto p151
        ::p78::
        tick(78)
        registers[9] = registers[5]["thirdperson"]
        if registers[9] == registers[0] then
            goto p499
        end
        goto p629
        ::p81::
        tick(81)
        registers[9] = registers[5]["feature_indicators_offset"]
        if registers[9] == registers[0] then
            goto p428
        end
        goto p597
        ::p84::
        tick(84)
        if registers[11] then
            goto p440
        end
        goto p535
        ::p87::
        tick(87)
        registers[10] = (registers[9] == 5)
        goto p764
        ::p90::
        tick(90)
        if registers[10] then
            goto p380
        end
        goto p875
        ::p95::
        tick(95)
        registers[12] = registers[6]
        goto p735
        ::p97::
        tick(97)
        registers[11] = registers[6]
        goto p404
        ::p99::
        tick(99)
        registers[9] = registers[5]["native_indicators_gradient"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p724
        ::p103::
        tick(103)
        registers[9] = registers[5]["aimbot_logs"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p411
        ::p108::
        tick(108)
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p388
        ::p112::
        tick(112)
        registers[11] = registers[6]
        goto p397
        ::p114::
        tick(114)
        registers[10] = (registers[9] == "First")
        goto p775
        ::p116::
        tick(116)
        registers[11] = registers[6]
        goto p163
        ::p118::
        tick(118);
        registers[10](registers[11], registers[12])
        goto p482
        ::p120::
        tick(120)
        registers[9] = registers[5]["viewmodel_offset_z"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p809
        end
        goto p886
        ::p125::
        tick(125)
        registers[9] = registers[5]["aimbot_logs_hit_label"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p784
        ::p129::
        tick(129);
        registers[9](registers[10], registers[11])
        goto p823
        ::p131::
        tick(131);
        registers[1](registers[2], registers[3])
        registers[1] = upvalues[10]["switch"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"]
        goto p244
        ::p135::
        tick(135)
        if registers[9] then
            goto p375
        end
        goto p719
        ::p138::
        tick(138);
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = registers[2]
        registers[8] = registers[5]["feature_indicators"];
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = registers[2]
        registers[9] = registers[5]["manual_arrows"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = registers[5]["watermark"]
        goto p899
        ::p147::
        tick(147)
        registers[(1)]()
        registers[1] = upvalues[8]["ragebot"]
        if not registers[1] then
            goto p258
        end
        goto p4
        ::p151::
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p926
        ::p155::
        tick(155)
        registers[9] = registers[5]["watermark"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p634
        ::p159::
        tick(159)
        registers[12] = registers[6]
        goto p407
        ::p161::
        tick(161)
        if registers[9] then
            goto p766
        end
        goto p347
        ::p163::
        tick(163);
        registers[9](registers[10], registers[11])
        goto p759
        ::p165::
        tick(165)
        registers[12] = (registers[9] == "CS2")
        goto p710
        ::p167::
        tick(167)
        registers[11] = (registers[9] == "TeamSkeet")
        goto p344
        ::p175::
        tick(175)
        registers[15] = registers[12]
        goto p14
        ::p177::
        tick(177)
        a = D.f202
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[2] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[3] = upvalues[10]["switch"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = (registers[3] == "Other")
        registers[4] = upvalues[10]["switch"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"]
        goto p423
        ::p185::
        tick(185);
        registers[9](registers[10], registers[11])
        goto p469
        ::p187::
        tick(187)
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p933
        ::p191::
        tick(191)
        registers[9] = registers[5]["feature_indicators"]
        if registers[9] == registers[0] then
            goto p81
        end
        goto p689
        ::p194::
        tick(194)
        registers[13] = registers[5]["manual_arrows_ts_cl2"]
        if registers[13] == registers[0] then
            goto p721
        end
        goto p928
        ::p198::
        tick(198)
        registers[9] = registers[5]["viewmodel_options"]
        if registers[9] == registers[0] then
            goto p607
        end
        goto p207
        ::p201::
        tick(201)
        if not registers[15] then
            goto p786
        end
        goto p224
        ::p203::
        tick(203)
        registers[9] = registers[5]["aimbot_logs_miss_color"]
        if registers[9] == registers[0] then
            goto p341
        end
        goto p226
        ::p207::
        registers[9] = registers[5]["viewmodel_options"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p905
        end
        goto p807
        ::p212::
        tick(212)
        if not registers[15] then
            goto p201
        end
        goto p616
        ::p214::
        tick(214)
        registers[2] = upvalues[9]["traverse"]
        registers[3] = upvalues[8]["antiaim"]
        registers[3] = registers[3]["other"]
        goto p706
        ::p218::
        tick(218)
        registers[9] = registers[5]["aimbot_logs_got_label"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        a = registers
        z = 11
        q = registers
        q = q[3]
        a[z] = q
        goto p911
        ::p224::
        registers[15] = registers[10]
        goto p786
        ::p226::
        registers[9] = registers[5]["aimbot_logs_miss_color"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p537
        ::p230::
        tick(230);
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = registers[2]
        registers[9] = registers[5]["viewmodel"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = registers[5]["aspect_ratio"]
        goto p50
        ::p237::
        tick(237)
        registers[11] = registers[2]
        registers[12] = registers[5]["native_indicators"];
        registers[(11)] = registers[(11)](registers[12])
        goto p129
        ::p241::
        tick(241)
        registers[11] = (registers[9] == 3)
        if registers[11] then
            goto p502
        end
        goto p582
        ::p244::;
        registers[(1)] = registers[(1)](registers[2])
        registers[1] = (registers[1] == "Anti-Aim")
        if not registers[1] then
            goto p826
        end
        goto p853
        ::p248::
        tick(248)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p249::
        registers[1] = upvalues[8]["ragebot"]
        registers[1] = registers[1]["log_spread"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_visible"]
        registers[3] = (false);
        registers[1](registers[2], registers[3])
        goto p258
        ::p255::
        tick(255)
        registers[9] = registers[5]["manual_arrows_offset"]
        if registers[9] == registers[0] then
            goto p469
        end
        goto p52
        ::p258::
        registers[1] = upvalues[9]["traverse"]
        registers[2] = upvalues[8]["antiaim"]
        registers[2] = registers[2]["angles"]
        a = D.f203
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[3] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p131
        ::p263::
        tick(263)
        registers[9] = registers[5]["watermark_cs2_gradient"]
        if registers[9] == registers[0] then
            goto p716
        end
        goto p846
        ::p266::
        tick(266)
        registers[1] = upvalues[4]
        registers[(1)]()
        registers[1] = upvalues[5]
        registers[(1)]()
        registers[1] = upvalues[6]
        registers[(1)]()
        registers[1] = upvalues[7]
        goto p147
        ::p274::
        tick(274)
        registers[11] = registers[8]
        goto p584
        ::p276::
        tick(276)
        registers[5] = upvalues[10]["visuals"]
        registers[5] = registers[5]["stubs"]
        registers[6] = registers[2]
        registers[7] = registers[5]["watermark"]
        goto p138
        ::p281::
        tick(281)
        registers[6] = "4E4E4EFF"
        registers[(5)](registers[6])
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p291::
        tick(291)
        registers[9] = "CS2"
        goto p779
        ::p293::
        tick(293)
        registers[15] = registers[8]
        goto p305
        ::p295::
        tick(295)
        registers[13] = registers[5]["manual_arrows_ts_cl1"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["set_visible"]
        registers[15] = registers[4]
        goto p489
        ::p299::
        if not registers[1] then
            goto p177
        end
        goto p214
        ::p301::
        tick(301)
        if not registers[11] then
            goto p308
        end
        goto p612
        ::p303::
        tick(303);
        registers[9](registers[10], registers[11])
        goto p203
        ::p305::
        tick(305)
        if not registers[15] then
            goto p373
        end
        goto p564
        ::p308::
        tick(308);
        registers[9](registers[10], registers[11])
        goto p452
        ::p310::
        tick(310)
        registers[10] = (registers[9] == "Fifth")
        goto p90
        ::p314::
        tick(314)
        registers[9] = registers[5]["aimbot_logs_got_color"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p73
        ::p318::
        tick(318)
        registers[1] = upvalues[2]
        registers[2] = (true)
        registers[(1)](registers[2])
        registers[1] = upvalues[3]
        registers[(1)]()
        goto p266
        ::p341::
        tick(341)
        registers[9] = registers[5]["aimbot_logs_got_label"]
        if registers[9] == registers[0] then
            goto p362
        end
        goto p218
        ::p344::
        tick(344)
        if registers[11] then
            goto p603
        end
        goto p677
        ::p347::
        registers[9] = nil
        goto p766
        ::p349::
        tick(349)
        registers[11] = (registers[9] == "Third")
        goto p84
        ::p351::
        tick(351)
        registers[9] = registers[5]["watermark_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p135
        ::p355::
        tick(355)
        registers[9] = registers[5]["viewmodel_offset_x"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p584
        end
        goto p274
        ::p360::
        tick(360);
        registers[9](registers[10], registers[11])
        goto p390
        ::p362::
        tick(362)
        registers[9] = registers[5]["aimbot_logs_got_color"]
        if registers[9] == registers[0] then
            goto p732
        end
        goto p314
        ::p365::
        tick(365)
        registers[9] = registers[5]["viewmodel_fov"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p393
        end
        goto p777
        ::p370::
        tick(370)
        registers[9] = registers[5]["viewmodel_fov"]
        if registers[9] == registers[0] then
            goto p737
        end
        goto p365
        ::p373::
        tick(373);
        registers[13](registers[14], registers[15])
        goto p194
        ::p375::
        tick(375)
        registers[10] = registers[5]["watermark_display"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["set_visible"]
        registers[12] = registers[3]
        if not registers[12] then
            goto p407
        end
        goto p159
        ::p380::
        tick(380)
        if registers[10] then
            goto p525
        end
        goto p513
        ::p382::
        tick(382)
        if not registers[15] then
            goto p528
        end
        goto p467
        ::p384::
        tick(384)
        registers[9] = registers[5]["aimbot_logs_miss_label"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p495
        ::p388::
        tick(388);
        registers[9](registers[10], registers[11])
        goto p655
        ::p390::
        tick(390)
        registers[9] = registers[5]["aimbot_logs_hit_label"]
        if registers[9] == registers[0] then
            goto p626
        end
        goto p125
        ::p393::
        tick(393);
        registers[9](registers[10], registers[11])
        goto p737
        ::p395::
        tick(395)
        registers[10] = (registers[9] == "Second")
        goto p586
        ::p397::
        tick(397);
        registers[9](registers[10], registers[11])
        goto p78
        ::p399::
        tick(399)
        registers[9] = registers[5]["thirdperson_distance"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p301
        ::p404::
        tick(404);
        registers[9](registers[10], registers[11])
        goto p191
        ::p407::
        if not registers[12] then
            goto p118
        end
        goto p844
        ::p411::
        tick(411)
        registers[9] = registers[5]["aimbot_logs_gradient"]
        if registers[9] == registers[0] then
            goto p390
        end
        goto p65
        ::p414::
        tick(414)
        registers[9] = registers[5]["watermark_style"]
        registers[9] = (registers[9] ~= registers[0])
        if not registers[9] then
            goto p909
        end
        goto p531
        ::p418::
        tick(418)
        registers[9] = registers[5]["damage_indicator"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p47
        ::p423::;
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "Anti-Aim")
        if not registers[4] then
            goto p740
        end
        goto p541
        ::p428::
        tick(428)
        registers[9] = registers[5]["damage_indicator"]
        if registers[9] == registers[0] then
            goto p47
        end
        goto p418
        ::p431::
        tick(431)
        registers[9] = registers[5]["manual_arrows_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[4]
        goto p895
        ::p436::
        tick(436)
        if not registers[15] then
            goto p14
        end
        goto p175
        ::p440::
        tick(440)
        if registers[11] then
            goto p344
        end
        goto p167
        ::p450::
        tick(450)
        registers[11] = registers[8]
        goto p465
        ::p452::
        tick(452)
        registers[9] = registers[5]["viewmodel"]
        if registers[9] == registers[0] then
            goto p370
        end
        goto p588
        ::p460::
        tick(460)
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p497
        ::p465::
        tick(465);
        registers[9](registers[10], registers[11])
        goto p857
        ::p467::
        registers[15] = registers[11]
        goto p528
        ::p469::
        registers[9] = registers[5]["manual_arrows_style"]
        registers[9] = (registers[9] ~= registers[0])
        if not registers[9] then
            goto p161
        end
        goto p658
        ::p482::
        tick(482)
        registers[9] = registers[5]["watermark_accent_color"]
        if registers[9] == registers[0] then
            goto p263
        end
        goto p414
        ::p489::
        if not registers[15] then
            goto p305
        end
        goto p293
        ::p492::
        tick(492)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p493::
        tick(493);
        registers[9](registers[10], registers[11])
        goto p428
        ::p495::
        if not registers[11] then
            goto p303
        end
        goto p913
        ::p497::
        tick(497);
        registers[9](registers[10], registers[11])
        goto p626
        ::p499::
        tick(499)
        registers[9] = registers[5]["thirdperson_distance"]
        if registers[9] == registers[0] then
            goto p452
        end
        goto p399
        ::p502::
        tick(502)
        if registers[11] then
            goto p84
        end
        goto p349
        ::p504::
        tick(504)
        registers[9] = registers[5]["watermark_style"]
        if registers[9] == registers[0] then
            goto p759
        end
        goto p672
        ::p509::
        tick(509)
        registers[9] = registers[5]["watermark_style"]
        registers[9] = (registers[9] ~= registers[0])
        if not registers[9] then
            goto p135
        end
        goto p351
        ::p513::
        registers[10] = (registers[9] == "Invictus")
        goto p525
        ::p515::
        tick(515);
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[9]["traverse"]
        registers[3] = upvalues[8]["antiaim"]
        goto p917
        ::p525::
        if registers[10] then
            goto p241
        end
        goto p12
        ::p528::;
        registers[13](registers[14], registers[15])
        goto p721
        ::p531::
        registers[9] = registers[5]["watermark_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p909
        ::p535::
        registers[11] = (registers[9] == "Fourth")
        goto p440
        ::p537::
        if not registers[11] then
            goto p933
        end
        goto p187
        ::p541::
        registers[4] = upvalues[11];
        registers[4] = registers[4]()
        goto p740
        ::p544::
        tick(544)
        registers[15] = registers[8]
        goto p436
        ::p560::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p666
        end
        goto p492
        ::p564::
        registers[15] = registers[11]
        goto p373
        ::p566::
        tick(566)
        registers[5] = upvalues[10]["visuals"]
        registers[5] = registers[5]["widgets"]
        registers[6] = registers[2]
        registers[7] = registers[5]["aspect_ratio"];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = registers[2]
        registers[8] = registers[5]["thirdperson"]
        goto p230
        ::p574::
        tick(574)
        registers[5] = upvalues[10]["visuals"]
        registers[5] = registers[5]["stubs"]
        if not registers[5] then
            goto p721
        end
        goto p276
        ::p578::
        tick(578)
        registers[15] = registers[8]
        goto p382
        ::p580::
        tick(580);
        registers[2](registers[3], registers[4])
        goto p177
        ::p582::
        registers[11] = (registers[9] == 4)
        goto p502
        ::p584::;
        registers[9](registers[10], registers[11])
        goto p694
        ::p586::
        tick(586)
        if registers[10] then
            goto p90
        end
        goto p310
        ::p588::
        registers[9] = registers[5]["viewmodel"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p370
        ::p593::
        tick(593)
        registers[12] = (registers[9] == "CS2")
        goto p861
        ::p595::
        registers[12] = (registers[9] == "CS2")
        goto p762
        ::p597::
        registers[9] = registers[5]["feature_indicators_offset"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p493
        end
        goto p26
        ::p603::
        tick(603)
        registers[12] = (registers[9] == 6)
        if registers[12] then
            goto p861
        end
        goto p593
        ::p607::
        tick(607)
        registers[5] = upvalues[12]["new"]
        registers[6] = "00000078"
        registers[(5)](registers[6])
        registers[5] = upvalues[12]["new"]
        goto p281
        ::p612::
        registers[11] = registers[7]
        goto p308
        ::p614::
        tick(614);
        registers[9](registers[10], registers[11])
        goto p362
        ::p616::
        registers[15] = registers[8]
        goto p201
        ::p619::
        tick(619)
        registers[2] = upvalues[9]["traverse"]
        registers[3] = upvalues[8]["antiaim"]
        registers[3] = registers[3]["other"]
        registers[3] = registers[3]["slow_motion"]
        a = D.f204
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[2](registers[3], registers[4])
        goto p177
        ::p626::
        registers[9] = registers[5]["aimbot_logs_hit_color"]
        if registers[9] == registers[0] then
            goto p655
        end
        goto p697
        ::p629::
        registers[9] = registers[5]["thirdperson"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p499
        ::p634::;
        registers[9](registers[10], registers[11])
        goto p504
        ::p636::
        tick(636)
        registers[2] = upvalues[9]["traverse"]
        registers[3] = upvalues[8]["antiaim"]
        a = registers
        z = (3)
        q = registers
        q = q[3]
        q = q["fakelag"]
        a[z] = q
        a = D.f205
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p515
        ::p655::
        registers[9] = registers[5]["aimbot_logs_miss_label"]
        if registers[9] == registers[0] then
            goto p203
        end
        goto p384
        ::p658::
        registers[9] = registers[5]["manual_arrows_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p161
        ::p662::
        registers[9] = registers[5]["aspect_ratio"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        goto p789
        ::p666::
        registers[1] = upvalues[1][108];
        registers[1] = registers[1]()
        if registers[1] then
            goto p318
        end
        goto p248
        ::p670::
        tick(670);
        registers[9](registers[10], registers[11])
        goto p255
        ::p672::
        registers[9] = registers[5]["watermark_style"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p163
        end
        goto p116
        ::p677::
        registers[11] = (registers[9] == "TeamSkeet Velocity")
        goto p603
        ::p679::
        registers[2] = upvalues[9]["traverse"]
        registers[3] = upvalues[8]["antiaim"]
        registers[3] = registers[3]["other"]
        a = D.f206
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p580
        ::p684::
        tick(684)
        registers[9] = registers[5]["aspect_ratio_value"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p397
        end
        goto p112
        ::p689::
        registers[9] = registers[5]["feature_indicators"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p81
        ::p694::
        tick(694)
        registers[9] = registers[5]["viewmodel_offset_y"]
        if registers[9] == registers[0] then
            goto p857
        end
        goto p881
        ::p697::
        registers[9] = registers[5]["aimbot_logs_hit_color"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p388
        end
        goto p108
        ::p704::
        tick(704)
        registers[11] = registers[8]
        goto p670
        ::p706::
        registers[3] = registers[3]["on_shot_antiaim"]
        a = D.f207
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[2](registers[3], registers[4])
        goto p619
        ::p710::
        tick(710);
        registers[10](registers[11], registers[12])
        goto p263
        ::p712::
        tick(712)
        registers[10] = (registers[9] == 2)
        goto p828
        ::p714::
        if not registers[11] then
            goto p360
        end
        goto p16
        ::p716::
        tick(716)
        registers[9] = registers[5]["watermark_position"]
        if registers[9] == registers[0] then
            goto p191
        end
        goto p727
        ::p719::
        registers[9] = "CS2"
        goto p375
        ::p721::
        tick(721)
        registers[5] = upvalues[10]["visuals"]
        if not registers[5] then
            goto p607
        end
        goto p935
        ::p724::
        if not registers[11] then
            goto p129
        end
        goto p237
        ::p727::
        registers[9] = registers[5]["watermark_position"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p404
        end
        goto p97
        ::p732::
        tick(732)
        registers[9] = registers[5]["manual_arrows"]
        if registers[9] == registers[0] then
            goto p749
        end
        goto p888
        ::p735::
        tick(735)
        if not registers[12] then
            goto p710
        end
        goto p165
        ::p737::
        registers[9] = registers[5]["viewmodel_offset_x"]
        if registers[9] == registers[0] then
            goto p694
        end
        goto p355
        ::p740::
        registers[5] = upvalues[10]["visuals"]
        if not registers[5] then
            goto p721
        end
        goto p574
        ::p749::
        tick(749)
        registers[9] = registers[5]["manual_arrows_style"]
        if registers[9] == registers[0] then
            goto p255
        end
        goto p431
        ::p753::
        tick(753)
        registers[13] = registers[5]["manual_arrows_cs2_color"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["set_visible"]
        registers[15] = registers[4]
        if not registers[15] then
            goto p436
        end
        goto p544
        ::p759::
        registers[9] = registers[5]["watermark_display"]
        if registers[9] == registers[0] then
            goto p482
        end
        goto p509
        ::p762::;
        registers[10](registers[11], registers[12])
        goto p716
        ::p764::
        tick(764)
        if registers[10] then
            goto p775
        end
        goto p114
        ::p766::
        registers[10] = (registers[9] == 1)
        if registers[10] then
            goto p828
        end
        goto p712
        ::p775::
        if registers[10] then
            goto p586
        end
        goto p395
        ::p777::
        registers[11] = registers[8]
        goto p393
        ::p779::
        tick(779)
        registers[10] = registers[5]["watermark_accent_color"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["set_visible"]
        registers[12] = registers[3]
        if not registers[12] then
            goto p735
        end
        goto p95
        ::p784::
        if not registers[11] then
            goto p497
        end
        goto p460
        ::p786::;
        registers[13](registers[14], registers[15])
        goto p811
        ::p789::;
        registers[9](registers[10], registers[11])
        goto p923
        ::p791::
        registers[9] = registers[5]["native_indicators"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3];
        registers[9](registers[10], registers[11])
        goto p870
        ::p796::
        tick(796)
        registers[12] = registers[6]
        goto p10
        ::p807::
        registers[11] = registers[8]
        goto p905
        ::p809::
        tick(809);
        registers[9](registers[10], registers[11])
        goto p198
        ::p811::
        tick(811)
        registers[13] = registers[5]["manual_arrows_cs2_color"]
        if registers[13] == registers[0] then
            goto p850
        end
        goto p753
        ::p814::
        registers[10] = registers[5]["watermark_cs2_gradient"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["set_visible"]
        a = registers
        z = 12
        q = registers
        q = q[3]
        a[z] = q
        if not registers[12] then
            goto p10
        end
        goto p796
        ::p821::
        registers[11] = registers[8]
        goto p185
        ::p823::
        tick(823)
        registers[9] = registers[5]["aimbot_logs"]
        if registers[9] == registers[0] then
            goto p411
        end
        goto p103
        ::p826::
        tick(826)
        if not registers[1] then
            goto p636
        end
        goto p42
        ::p828::
        if registers[10] then
            goto p764
        end
        goto p87
        ::p844::
        registers[12] = (registers[9] == "CS2")
        goto p118
        ::p846::
        registers[9] = registers[5]["watermark_style"]
        registers[9] = (registers[9] ~= registers[0])
        if not registers[9] then
            goto p20
        end
        goto p69
        ::p850::
        registers[13] = registers[5]["manual_arrows_ts_cl1"]
        if registers[13] == registers[0] then
            goto p194
        end
        goto p295
        ::p853::
        registers[1] = upvalues[10]["switch_type"]
        registers[1] = (registers[1] ~= registers[0])
        goto p826
        ::p857::
        registers[9] = registers[5]["viewmodel_offset_z"]
        if registers[9] == registers[0] then
            goto p198
        end
        goto p120
        ::p861::
        registers[13] = registers[5]["manual_arrows_color"]
        if registers[13] == registers[0] then
            goto p811
        end
        goto p901
        ::p870::
        registers[9] = registers[5]["native_indicators_gradient"]
        if registers[9] == registers[0] then
            goto p823
        end
        goto p99
        ::p875::
        registers[10] = (registers[9] == "Triangle")
        goto p380
        ::p881::
        registers[9] = registers[5]["viewmodel_offset_y"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[3]
        if not registers[11] then
            goto p465
        end
        goto p450
        ::p886::
        registers[11] = registers[8]
        goto p809
        ::p888::
        registers[9] = registers[5]["manual_arrows"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_visible"]
        registers[11] = registers[4];
        registers[9](registers[10], registers[11])
        goto p749
        ::p895::
        if not registers[11] then
            goto p670
        end
        goto p704
        ::p899::
        if registers[9] == registers[0] then
            goto p504
        end
        goto p155
        ::p901::
        registers[13] = registers[5]["manual_arrows_color"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["set_visible"]
        registers[15] = registers[4]
        goto p212
        ::p905::;
        registers[9](registers[10], registers[11])
        goto p607
        ::p909::
        if registers[9] then
            goto p779
        end
        goto p291
        ::p911::
        if not registers[11] then
            goto p614
        end
        goto p28
        ::p913::
        registers[11] = registers[2]
        registers[12] = registers[5]["aimbot_logs"];
        registers[(11)] = registers[(11)](registers[12])
        goto p303
        ::p917::
        registers[3] = registers[3]["other"]
        a = D.f208
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[10]["switch"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"]
        goto p23
        ::p923::
        registers[9] = registers[5]["aspect_ratio_value"]
        if registers[9] == registers[0] then
            goto p78
        end
        goto p684
        ::p926::;
        registers[9](registers[10], registers[11])
        goto p732
        ::p928::
        registers[13] = registers[5]["manual_arrows_ts_cl2"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["set_visible"]
        registers[15] = registers[4]
        if not registers[15] then
            goto p382
        end
        goto p578
        ::p933::;
        registers[9](registers[10], registers[11])
        goto p341
        ::p935::
        registers[5] = upvalues[10]["visuals"]
        registers[5] = registers[5]["widgets"]
        if not registers[5] then
            goto p607
        end
        goto p566
    end
end
