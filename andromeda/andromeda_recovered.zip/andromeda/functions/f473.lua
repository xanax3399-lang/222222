-- Recovered function f473; author names are unavailable.
F.f473 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f473")
        tick(1)
        slot_1 = upvalues[0]["skip_native_cleanup"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p6
        end
        do
            return 
        end
        ::p6::
        slot_1 = upvalues[1]["reset"]
        slot_1()
        do
            return 
        end
    end
end
