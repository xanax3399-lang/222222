-- Recovered function f390; author names are unavailable.
F.f390 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f390")
        tick(1)
        goto p104
        ::p2::
        tick(2)
        registers[10] = registers[10](registers[11], registers[12])
        registers[11] = upvalues[2]
        registers[12] = registers[1]
        goto p54
        ::p6::
        tick(6)
        registers[10] = (0)
        registers[11] = (255);
        registers[8] = registers[8](unpack_range(11, registers, 9))
        goto p36
        ::p10::
        tick(10)
        do
            return 
        end
        ::p13::
        tick(13)
        registers[9] = registers[9] + 0.5
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[0][162]
        registers[8] = registers[6]
        registers[9] = upvalues[0][154]
        registers[10] = (registers[3] * 0.5)
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[6] = registers[7]
        registers[7] = upvalues[0][151]
        goto p172
        ::p26::
        tick(26)
        registers[(11)](unpack_range(18, registers, 12))
        registers[11] = upvalues[0][129]
        registers[12] = registers[1]
        registers[13] = registers[9]
        registers[14] = registers[6]
        goto p165
        ::p32::
        tick(32)
        registers[14] = registers[6]
        registers[15] = registers[10]
        registers[16] = (0)
        goto p88
        ::p36::
        registers[9] = registers[2] + 1
        registers[10] = upvalues[0][151]
        registers[11] = (1)
        registers[12] = (registers[4] - 2)
        goto p2
        ::p41::
        tick(41)
        registers[22] = (0)
        registers[23] = (0)
        registers[24] = (true)
        registers[(11)](unpack_range(24, registers, 12))
        registers[11] = upvalues[2]
        registers[12] = registers[1]
        registers[13] = registers[2] + registers[4]
        registers[13] = (registers[13] - 1)
        registers[14] = registers[3]
        registers[15] = registers[6]
        registers[16] = registers[7]
        goto p182
        ::p54::
        registers[13] = registers[2]
        registers[14] = registers[3]
        registers[15] = registers[6]
        registers[16] = registers[7]
        registers[17] = (1)
        registers[18] = (210)
        goto p26
        ::p78::
        tick(78)
        do
            return 
        end
        ::p79::
        tick(79)
        registers[21] = (0)
        registers[22] = (0)
        registers[23] = registers[8]
        registers[24] = (true)
        goto p108
        ::p85::
        tick(85)
        if registers[9] then
            goto p6
        end
        goto p95
        ::p88::
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = registers[8]
        registers[20] = (0)
        registers[21] = (0)
        goto p41
        ::p95::
        registers[9] = (110)
        goto p6
        ::p104::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        if registers[3] <= 0 then
            goto p10
        end
        goto p133
        ::p108::
        registers[(11)](unpack_range(24, registers, 12))
        if not (0 < registers[7]) then
            goto p119
        end
        goto p154
        ::p112::
        tick(112)
        registers[(11)](unpack_range(19, registers, 12))
        ::p119::
        registers[11] = upvalues[0][129]
        registers[12] = registers[1] + registers[6]
        registers[12] = registers[12] + registers[7]
        registers[13] = registers[9]
        goto p32
        ::p133::
        if not (registers[4] <= 0) then
            goto p160
        end
        goto p10
        ::p135::
        tick(135)
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[1]["clamp"]
        registers[9] = registers[5]
        goto p85
        ::p154::
        registers[11] = upvalues[0][128]
        registers[12] = registers[1] + registers[6]
        registers[13] = registers[9]
        registers[14] = registers[7]
        registers[15] = registers[10]
        goto p177
        ::p160::
        registers[6] = upvalues[0][151]
        registers[7] = (4)
        registers[8] = upvalues[0][154]
        registers[9] = (registers[3] * 0.08)
        goto p13
        ::p165::
        registers[15] = registers[10]
        registers[16] = (0)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        goto p79
        ::p172::
        registers[8] = (0)
        registers[9] = (registers[6] * 2)
        registers[9] = (registers[3] - registers[9])
        goto p135
        ::p177::
        registers[16] = (0)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = registers[8]
        goto p112
        ::p182::
        registers[17] = (1)
        registers[18] = (210)
        registers[(11)](unpack_range(18, registers, 12))
        goto p78
    end
end
