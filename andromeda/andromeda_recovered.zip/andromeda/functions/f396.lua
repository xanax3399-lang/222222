-- Recovered function f396; author names are unavailable.
F.f396 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f396")
        tick(1)
        goto p114
        ::p2::
        tick(2)
        registers[4] = registers[4](registers[5], registers[6])
        registers[5] = upvalues[1]["icon_paths"]
        registers[6] = registers[1]["kind"]
        registers[5] = registers[5][registers[6]]
        registers[5] = (registers[5] ~= registers[0])
        registers[6] = registers[5]
        if not registers[6] then
            goto p62
        end
        goto p135
        ::p11::
        tick(11)
        registers[8] = upvalues[0][151]
        registers[9] = upvalues[1]["px"]
        registers[10] = (34)
        goto p107
        ::p49::
        tick(49)
        registers[6] = upvalues[1]["px"]
        registers[7] = (12)
        registers[8] = registers[3]
        registers[6] = registers[6](registers[7], registers[8])
        goto p80
        ::p59::
        tick(59)
        if registers[6] then
            goto p62
        end
        goto p102
        ::p62::
        tick(62)
        if registers[6] then
            goto p80
        end
        goto p49
        ::p65::
        tick(65)
        if registers[6] then
            goto p2
        end
        goto p124
        ::p67::
        tick(67)
        registers[4] = (0)
        goto p11
        ::p71::
        tick(71)
        registers[6] = upvalues[1]["px"]
        registers[7] = (42)
        registers[8] = registers[3]
        registers[6] = registers[6](registers[7], registers[8])
        goto p59
        ::p76::
        tick(76)
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = environment["type"]
        registers[9] = registers[4]
        goto p121
        ::p80::
        registers[7] = upvalues[1]["px"]
        registers[8] = (9)
        registers[9] = registers[3]
        goto p76
        ::p102::
        registers[6] = upvalues[1]["px"]
        registers[7] = (40)
        registers[8] = registers[3]
        registers[6] = registers[6](registers[7], registers[8])
        goto p62
        ::p107::
        registers[11] = registers[3]
        registers[9] = registers[9](registers[10], registers[11])
        registers[10] = registers[6] + registers[4]
        registers[10] = registers[10] + registers[7]
        do
            return registers[(8)](unpack_range(10, registers, 9))
        end
        ::p114::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0][136]
        registers[5] = registers[2]
        registers[6] = registers[1]["text"]
        goto p65
        ::p121::;
        registers[(8)] = registers[(8)](registers[9])
        branch_taken = false
        if registers[8] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p11
        end
        goto p67
        ::p124::
        registers[6] = ""
        goto p2
        ::p135::
        registers[6] = upvalues[1]["is_bomb_indicator_kind"]
        registers[7] = registers[1]["kind"];
        registers[(6)] = registers[(6)](registers[7])
        if not registers[6] then
            goto p59
        end
        goto p71
    end
end
