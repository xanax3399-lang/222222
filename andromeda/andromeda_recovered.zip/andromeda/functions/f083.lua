-- Recovered function f83; author names are unavailable.
F.f83 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f83")
        tick(1)
        goto p154
        ::p3::
        tick(3)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[9] = environment["pcall"]
        registers[10] = environment["string"]
        goto p33
        ::p7::
        tick(7)
        registers[25] = constant_cache[10]
        registers[26] = "<\195Y"
        registers[27] = (3)
        registers[28] = (3);
        registers[25] = registers[25](unpack_range(28, registers, 26))
        registers[24] = registers[24] + registers[25]
        registers[24] = 866 + registers[24]
        registers[24] = registers[24] + -1282
        registers[23][62] = registers[24]
        registers[23][84] = 60
        registers[16] = nil
        registers[17] = nil
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        registers[28] = nil
        goto p61
        ::p20::
        tick(20)
        registers[14] = (#registers[6])
        registers[14] = registers[14] + 1
        registers[6][registers[14]] = registers[5]
        goto p28
        ::p24::
        tick(24)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p25::
        tick(25)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[12] = v
            branch_taken = true
        end
        if branch_taken then
            goto p101
        end
        goto p3
        ::p28::
        registers[14] = registers[13].."%"
        registers[14] = "function:builtin#"..registers[14]
        registers[14] = (registers[13]..registers[14])
        registers[8] = (registers[8]..registers[14])
        goto p82
        ::p33::
        registers[10] = registers[10]["format"]
        registers[11] = registers[7]
        registers[12] = environment["table"]
        registers[12] = registers[12]["unpack"]
        registers[13] = registers[6]
        goto p95
        ::p54::
        tick(54)
        registers[11] = upvalues[0]
        registers[12] = {
        }
        registers[13] = upvalues[1]["CHECK_16_FAILED"]
        registers[12]["ban_num"] = registers[13]
        registers[12]["ban_info"] = "copy [fp][0x01]"
        registers[(11)](registers[12])
        goto p24
        ::p61::
        tick(61)
        registers[11] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[11] + 0
        n = (registers[10] + 0)
        v = (registers[9] - U)
        goto p82
        ::p63::
        tick(63)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[9] = (1)
        registers[10] = registers[4]
        goto p91
        ::p82::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[12] = v
            branch_taken = true
        end
        if branch_taken then
            goto p104
        end
        goto p63
        ::p91::
        registers[11] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[11] + 0
        n = (registers[10] + 0)
        v = (registers[9] - U)
        goto p25
        if registers[24] then
            goto p7
        end
        goto p141
        ::p95::
        registers[14] = (1)
        registers[15] = (registers[4] * 4)
        m, x = pack_returns(registers[12](unpack_range(15, registers, 13)))
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[9](unpack_range(top, registers, 10)))
        z = 0
        for f = 9, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        if not registers[9] then
            goto p54
        end
        goto p143
        ::p101::
        registers[7] = registers[7].."%s%%"
        registers[8] = registers[8].."nil%"
        goto p25
        ::p104::
        registers[7] = registers[7].."%s%s"
        registers[13] = registers[3]
        registers[14] = (123);
        registers[(13)] = registers[(13)](registers[14])
        goto p20
        ::p120::
        tick(120)
        registers[8] = ""
        registers[9] = (1)
        registers[10] = registers[4]
        goto p61
        ::p141::
        registers[24] = (336)
        goto p7
        ::p143::
        registers[11] = (#registers[10])
        branch_taken = false
        if not (not (registers[11] < 100)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p24
        end
        goto p54
        ::p154::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = registers[1]
        a = D.f84
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[3] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[4] = registers[1] / 4
        registers[4] = registers[4] / 4
        a = D.f85
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[5] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[6] = {
        }
        registers[7] = ""
        goto p120
    end
end
