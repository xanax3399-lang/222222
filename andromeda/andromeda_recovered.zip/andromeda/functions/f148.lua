-- Recovered function f148; author names are unavailable.
F.f148 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f148")
        tick(1)
        goto p101
        ::p5::
        tick(5)
        registers[15] = environment["table"]
        registers[15] = registers[15]["remove"]
        registers[16] = registers[1]["configs_db"]
        registers[16] = registers[16]["cfg_list"]
        registers[17] = registers[13]
        goto p189
        ::p11::
        tick(11)
        registers[14] = registers[1]["configs_db"]
        registers[14] = registers[14]["cfg_list"]
        registers[14] = registers[14][registers[13]]
        goto p208
        ::p16::
        tick(16)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p225
        ::p18::
        tick(18)
        registers[8] = (#registers[7])
        registers[9] = (#registers[5])
        registers[8] = (registers[8] ~= registers[9])
        goto p213
        ::p24::
        tick(24)
        registers[8] = (registers[8] ~= registers[9])
        if registers[8] then
            goto p213
        end
        goto p18
        ::p27::
        tick(27)
        registers[14] = registers[12][1]
        registers[7][registers[13]] = registers[14]
        goto p331
        ::p30::
        tick(30)
        registers[4] = {
        }
        goto p215
        ::p40::
        tick(40)
        registers[16] = registers[12][2]
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        registers[6][registers[13]] = registers[14]
        registers[13] = (#registers[7])
        registers[13] = registers[13] + 1
        goto p27
        ::p46::
        tick(46)
        registers[4] = (0)
        goto p267
        ::p48::
        tick(48)
        registers[13] = registers[4][registers[12]]
        registers[14] = environment["type"]
        registers[15] = registers[13];
        registers[(14)] = registers[(14)](registers[15])
        if registers[14] ~= "table" then
            goto p222
        end
        goto p117
        ::p62::
        tick(62)
        if registers[14] ~= "string" then
            goto p331
        end
        goto p108
        ::p66::
        tick(66)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if registers[9] then
            goto p232
        end
        goto p187
        ::p69::
        tick(69)
        if registers[17] ~= registers[18] then
            goto p222
        end
        goto p323
        ::p71::
        tick(71)
        registers[6] = {
        }
        registers[7] = {
        }
        registers[8] = (1)
        goto p291
        ::p75::
        tick(75)
        if registers[15] ~= registers[16] then
            goto p222
        end
        goto p239
        ::p77::
        tick(77)
        registers[5] = registers[5]["cfg_list"];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "table")
        goto p271
        ::p81::
        tick(81)
        if not registers[3] then
            goto p307
        end
        goto p232
        ::p83::
        tick(83)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[8] = (#registers[6])
        registers[9] = (#registers[4])
        goto p24
        ::p87::
        tick(87)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p11
        end
        goto p66
        ::p90::
        tick(90)
        if registers[4] then
            goto p215
        end
        goto p30
        ::p101::
        a = {
            ...,
        }
        registers[1] = a[1]
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["read_db"]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = environment["type"]
        registers[5] = registers[2]
        goto p319
        ::p108::
        registers[15] = environment["type"]
        registers[16] = registers[12][2];
        registers[(15)] = registers[(15)](registers[16])
        if registers[15] ~= "string" then
            goto p331
        end
        goto p315
        ::p113::
        tick(113)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[11] + 0
        n = (registers[10] + 0)
        v = (registers[9] - U)
        goto p295
        ::p114::
        tick(114)
        registers[5] = {
        }
        goto p71
        ::p117::
        registers[15] = registers[13][1]
        registers[16] = registers[6][registers[12]]
        registers[16] = registers[16][1]
        goto p75
        ::p127::
        tick(127)
        if registers[4] then
            goto p297
        end
        goto p273
        ::p130::
        tick(130)
        registers[12] = registers[4][registers[11]]
        registers[13] = environment["type"]
        registers[14] = registers[12];
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "table" then
            goto p331
        end
        goto p198
        ::p136::
        tick(136)
        registers[4] = registers[2]
        goto p90
        ::p160::
        tick(160)
        registers[17] = registers[12][1]
        branch_taken = false
        if registers[17] ~= "Default - Admin" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p331
        end
        goto p286
        ::p163::
        tick(163)
        registers[16] = registers[14][1]
        if registers[16] ~= "Default - Admin" then
            goto p87
        end
        goto p5
        ::p185::
        tick(185)
        if registers[5] then
            goto p71
        end
        goto p114
        ::p187::
        if registers[8] then
            goto p232
        end
        goto p81
        ::p189::;
        registers[15](registers[16], registers[17])
        registers[15] = environment["table"]
        registers[15] = registers[15]["remove"]
        registers[16] = registers[1]["configs_db"]
        registers[16] = registers[16]["menu_list"]
        registers[17] = registers[13];
        registers[15](registers[16], registers[17])
        registers[9] = (true)
        goto p87
        ::p198::
        registers[14] = environment["type"]
        registers[15] = registers[12][1];
        registers[(14)] = registers[(14)](registers[15])
        goto p62
        ::p208::
        registers[15] = environment["type"]
        registers[16] = registers[14];
        registers[(15)] = registers[(15)](registers[16])
        if registers[15] ~= "table" then
            goto p87
        end
        goto p163
        ::p213::
        if registers[8] then
            goto p225
        end
        goto p275
        ::p215::
        registers[1]["configs_db"] = registers[4]
        registers[4] = environment["tonumber"]
        registers[5] = registers[1]["configs_db"]
        registers[5] = registers[5]["revision"];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p267
        end
        goto p46
        ::p222::
        tick(222)
        registers[8] = (true)
        goto p16
        ::p225::
        registers[9] = registers[1]["configs_db"]
        registers[9]["cfg_list"] = registers[6]
        registers[9] = registers[1]["configs_db"]
        registers[9]["menu_list"] = registers[7]
        registers[9] = (false)
        goto p263
        ::p232::
        z = registers[1]
        registers[11] = z;
        registers[(10)] = z["write_db"]
        registers[(10)](registers[11])
        goto p307
        ::p236::
        tick(236)
        registers[5] = registers[1]["configs_db"]
        registers[5] = registers[5]["menu_list"]
        goto p185
        ::p239::
        registers[17] = registers[13][2]
        registers[18] = registers[6][registers[12]]
        registers[18] = registers[18][2]
        goto p69
        ::p251::
        tick(251)
        registers[11] = (1)
        registers[12] = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p87
        goto p71
        ::p263::
        registers[10] = registers[1]["configs_db"]
        registers[10] = registers[10]["cfg_list"]
        registers[10] = (#registers[10])
        goto p251
        ::p267::
        registers[1]["write_revision"] = registers[4]
        registers[4] = environment["type"]
        registers[5] = registers[1]["configs_db"]
        goto p77
        ::p271::
        if not registers[4] then
            goto p127
        end
        goto p304
        ::p273::
        registers[4] = {
        }
        goto p297
        ::p275::
        registers[9] = (1)
        registers[10] = (#registers[6])
        registers[11] = (1)
        goto p113
        ::p286::
        registers[13] = (#registers[6])
        registers[13] = registers[13] + 1
        registers[14] = new_frame(2)
        registers[15] = registers[12][1]
        goto p40
        ::p291::
        registers[9] = (#registers[4])
        registers[10] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[10] + 0
        n = (registers[9] + 0)
        v = (registers[8] - U)
        goto p331
        goto p24
        ::p295::
        tick(295)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[12] = v
            branch_taken = true
        end
        if branch_taken then
            goto p48
        end
        goto p16
        ::p297::
        registers[5] = environment["type"]
        registers[6] = registers[1]["configs_db"]
        registers[6] = registers[6]["menu_list"]
        goto p327
        ::p304::
        registers[4] = registers[1]["configs_db"]
        registers[4] = registers[4]["cfg_list"]
        goto p127
        ::p307::
        do
            return 
        end
        ::p315::
        registers[16] = registers[12][1]
        branch_taken = false
        if registers[16] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p331
        end
        goto p160
        ::p319::;
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "table")
        if not registers[4] then
            goto p90
        end
        goto p136
        ::p323::
        registers[19] = registers[5][registers[12]]
        registers[20] = registers[7][registers[12]]
        if registers[19] == registers[20] then
            goto p295
        end
        goto p222
        ::p327::;
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] == "table")
        if not registers[5] then
            goto p185
        end
        goto p236
        ::p331::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[11] = v
            branch_taken = true
        end
        if branch_taken then
            goto p130
        end
        goto p83
    end
end
