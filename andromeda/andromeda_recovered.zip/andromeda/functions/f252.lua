-- Recovered function f252; author names are unavailable.
F.f252 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f252")
        tick(1)
        goto p59
        ::p8::
        tick(8)
        registers[6] = (2)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p10::
        tick(10)
        if not (0 < registers[3]) then
            goto p77
        end
        goto p63
        ::p14::
        tick(14)
        registers[3] = environment["type"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "string" then
            goto p77
        end
        goto p115
        ::p33::
        tick(33)
        registers[7] = (2)
        do
            return registers[(4)](unpack_range(7, registers, 5))
        end
        ::p35::
        tick(35)
        registers[3] = upvalues[1]["clamp"]
        registers[4] = registers[2]
        registers[5] = (0.5)
        goto p8
        ::p39::
        tick(39)
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p54::
        tick(54)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["dpi"]
        goto p94
        ::p59::
        registers[1] = upvalues[0]["visuals"]
        if not registers[1] then
            goto p94
        end
        goto p54
        ::p63::
        registers[4] = upvalues[1]["clamp"]
        registers[5] = (registers[3] * 0.01)
        registers[6] = (0.5)
        goto p33
        ::p77::
        tick(77)
        registers[3] = (1)
        do
            return registers[3]
        end
        ::p94::
        if registers[1] ~= registers[0] then
            goto p96
        end
        goto p39
        ::p96::
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = environment["type"]
        goto p105
        ::p103::
        tick(103)
        if not (10 < registers[2]) then
            goto p35
        end
        goto p122
        ::p105::
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "number" then
            goto p14
        end
        goto p103
        ::p115::
        registers[3] = environment["tonumber"]
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["match"]
        registers[6] = "(%d+%.?%d*)"
        m, x = pack_returns(registers[4](unpack_range(6, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] == registers[0] then
            goto p77
        end
        goto p10
        ::p122::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = (registers[2] * 0.01)
        registers[5] = (0.5)
        registers[6] = (2)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
    end
end
