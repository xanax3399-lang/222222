-- Recovered function f158; author names are unavailable.
F.f158 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f158")
        tick(1)
        goto p78
        ::p32::
        tick(32)
        registers[1] = (registers[1] - registers[2])
        registers[2] = upvalues[2]["clamp"]
        registers[3] = upvalues[0]["planting_duration"]
        registers[3] = (registers[1] / registers[3])
        registers[4] = (0)
        goto p47
        ::p45::
        tick(45)
        registers[1] = (0)
        do
            return registers[1]
        end
        ::p47::
        registers[5] = (1)
        do
            return registers[(2)](unpack_range(5, registers, 3))
        end
        ::p58::
        tick(58)
        registers[1] = upvalues[1][30];
        registers[1] = registers[1]()
        registers[2] = upvalues[0]["planting_start_time"]
        goto p32
        ::p78::
        registers[1] = upvalues[0]["planting_start_time"]
        if registers[1] ~= registers[0] then
            goto p58
        end
        goto p45
    end
end
