-- Recovered function f429; author names are unavailable.
F.f429 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f429")
        tick(1)
        goto p4
        ::p2::
        tick(2)
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[2](unpack_range(top, registers, 3))
        end
        ::p4::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["string"]
        registers[2] = registers[2]["char"]
        registers[3] = environment["tonumber"]
        registers[4] = registers[1]
        registers[5] = (16)
        goto p2
    end
end
