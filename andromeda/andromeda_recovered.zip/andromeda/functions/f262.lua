-- Recovered function f262; author names are unavailable.
F.f262 = function(function_metadata, upvalues)
    local operand_g, code_metadata, operand_k = function_metadata[6], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f262")
        tick(1)
        goto p105
        ::p2::
        tick(2)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p139
        end
        goto p117
        ::p17::
        tick(17)
        registers[3] = nil
        goto p28
        ::p20::
        tick(20)
        if registers[3] then
            goto p28
        end
        goto p17
        ::p22::
        tick(22);
        registers[(3)] = registers[(3)](registers[4])
        goto p20
        ::p24::
        tick(24)
        registers[(11)](unpack_range(14, registers, 12))
        goto p113
        ::p28::
        a = D.f263
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[5] = (1)
        registers[6] = upvalues[4]
        registers[6] = (#registers[6])
        registers[7] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p2
        registers[27] = code_metadata
        registers[31] = operand_g
        registers[33] = operand_k
        registers[31][62] = 14
        registers[33][62] = 14
        registers[27][62] = 82
        registers[33][19] = 64
        registers[26] = nil
        registers[27] = nil
        registers[28] = nil
        registers[29] = nil
        registers[30] = nil
        registers[31] = nil
        registers[32] = nil
        registers[33] = nil
        goto p119
        ::p49::
        tick(49)
        registers[12] = registers[10]["yaw"]
        registers[12] = registers[12]["builder_type"]
        if registers[12] == registers[0] then
            goto p113
        end
        goto p160
        ::p62::
        tick(62)
        registers[14] = registers[14]["builder_type"]
        registers[(11)](unpack_range(14, registers, 12))
        goto p2
        ::p69::
        tick(69)
        registers[12] = registers[10]["yaw_modifiers"]
        registers[12] = registers[12]["builder_type"]
        if registers[12] == registers[0] then
            goto p2
        end
        goto p119
        ::p101::
        tick(101)
        registers[3] = upvalues[1]["antiaim"]
        registers[3] = registers[3]["conditions"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"]
        goto p22
        ::p105::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        goto p186
        ::p111::
        tick(111)
        if registers[10] == registers[0] then
            goto p2
        end
        goto p156
        ::p113::
        tick(113)
        registers[11] = registers[10]["yaw_modifiers"]
        if registers[11] == registers[0] then
            goto p2
        end
        goto p69
        ::p117::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p119::
        registers[11] = registers[4]
        registers[12] = registers[9]
        registers[13] = "yaw_modifiers"
        registers[14] = registers[10]["yaw_modifiers"]
        goto p62
        ::p131::
        tick(131)
        registers[3] = upvalues[1]["antiaim"]
        registers[3] = registers[3]["conditions"]
        registers[3] = (registers[3] ~= registers[0])
        ::p136::
        tick(136)
        if not registers[3] then
            goto p20
        end
        goto p101
        ::p139::
        registers[9] = upvalues[4][registers[8]]
        registers[10] = upvalues[1]["builder"]
        registers[10] = (registers[10] ~= registers[0])
        goto p184
        ::p151::
        tick(151)
        if registers[10] then
            goto p111
        end
        goto p168
        ::p153::
        tick(153)
        registers[10] = upvalues[1]["builder"]
        registers[10] = registers[10][registers[9]]
        goto p151
        ::p156::
        registers[11] = registers[10]["yaw"]
        if registers[11] == registers[0] then
            goto p113
        end
        goto p49
        ::p160::
        registers[11] = registers[4]
        a = registers
        z = 12
        q = registers
        q = q[9]
        a[z] = q
        registers[13] = "yaw"
        registers[14] = registers[10]["yaw"]
        registers[14] = registers[14]["builder_type"]
        goto p24
        ::p168::
        registers[10] = nil
        goto p111
        ::p184::
        if not registers[10] then
            goto p151
        end
        goto p153
        ::p186::
        registers[3] = upvalues[1]["antiaim"]
        registers[3] = (registers[3] ~= registers[0])
        if not registers[3] then
            goto p136
        end
        goto p131
    end
end
