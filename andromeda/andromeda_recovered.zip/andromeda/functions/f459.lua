-- Recovered function f459; author names are unavailable.
F.f459 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local tick = new_tick("f459")
        tick(1)
        goto p27
        ::p20::
        tick(20)
        slot_3 = (125)
        slot_1 = slot_1(slot_2, slot_3)
        slot_1 = slot_1 > 0
        goto p44
        ::p24::
        tick(24)
        slot_2 = upvalues[1]["ragebot"]
        slot_2 = slot_2["overpredict"]
        goto p20
        ::p27::
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["ragebot"]
        if not slot_2 then
            goto p20
        end
        goto p24
        ::p44::
        do
            return slot_1
        end
    end
end
