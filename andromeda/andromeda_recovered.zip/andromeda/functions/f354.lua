-- Recovered function f354; author names are unavailable.
F.f354 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f354")
        tick(1)
        goto p222
        ::p11::
        tick(11)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p19::
        tick(19)
        registers[24] = registers[21]
        registers[(24)]()
        goto p25
        ::p23::
        tick(23)
        registers[11] = (1)
        goto p34
        ::p25::
        tick(25)
        a = upvalues[2];
        registers[24] = a[2][a[1]]["packets"]
        registers[25] = registers[9]["next_switch_packet"]
        branch_taken = false
        if not (not (registers[25] <= registers[24])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p44
        end
        goto p380
        ::p29::
        tick(29)
        if registers[6] ~= "Double" then
            goto p365
        end
        goto p151
        ::p31::
        tick(31)
        a = upvalues[0];
        registers[8] = a[2][a[1]]["current"]
        if registers[8] then
            goto p316
        end
        goto p247
        ::p34::
        tick(34)
        registers[12] = upvalues[3]["is_double_tap"]
        registers[13] = "key";
        registers[(12)] = registers[(12)](registers[13])
        if registers[12] then
            goto p39
        end
        goto p191
        ::p39::
        tick(39)
        registers[13] = registers[12]
        if not registers[13] then
            goto p340
        end
        goto p178
        ::p42::
        tick(42)
        branch_taken = false
        if registers[7] ~= "Solo" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p31
        end
        goto p331
        ::p44::
        registers[24] = registers[1]["body_yaw"]
        registers[25] = registers[9]["side"]
        registers[25] = (registers[25] == true)
        registers[24]["inverter"] = registers[25]
        registers[24] = registers[9]["switch_count"]
        registers[1]["delay_switch_count"] = registers[24]
        goto p203
        ::p51::
        tick(51)
        registers[9]["side"] = registers[23]
        registers[1]["delay_packets"] = 0
        registers[23] = registers[9]["switch_count"]
        registers[1]["delay_switch_count"] = registers[23]
        a = upvalues[2];
        registers[23] = a[2][a[1]]["packets"]
        registers[23] = registers[23] + 1
        registers[1]["delay_next_switch_packet"] = registers[23]
        goto p215
        ::p66::
        tick(66)
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["get"]
        m, x = pack_returns(registers[12](unpack_range(13, registers, 13)))
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        if registers[11] then
            goto p34
        end
        goto p23
        ::p83::
        tick(83)
        registers[9]["signature"] = registers[23]
        registers[9]["switch_count"] = 0
        registers[24] = registers[1]["body_yaw"]
        goto p359
        ::p103::
        tick(103)
        registers[1]["delay_switch_count"] = registers[23]
        registers[23] = registers[21]
        registers[(23)]()
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p108::
        tick(108)
        registers[23] = registers[20];
        registers[23] = registers[23]()
        registers[24] = registers[9]["signature"]
        if registers[24] == registers[23] then
            goto p314
        end
        goto p83
        ::p121::
        tick(121)
        registers[1]["inverts"] = registers[24]
        registers[24] = registers[21]
        registers[(24)]()
        goto p11
        ::p125::
        tick(125)
        registers[24] = registers[2]["chokedcommands"]
        branch_taken = false
        if registers[24] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p396
        end
        goto p198
        ::p128::
        tick(128)
        registers[6] = "Default"
        goto p278
        ::p130::
        tick(130)
        registers[23] = registers[1]["body_yaw"]
        registers[23] = registers[23]["inverter"]
        registers[23] = (registers[23] == true)
        goto p51
        ::p134::
        tick(134)
        registers[25] = (registers[25] == true)
        registers[24]["inverter"] = registers[25]
        registers[1]["delay_packets"] = 0
        goto p293
        ::p143::
        tick(143)
        registers[11] = registers[11] + 1
        registers[10]["next_switch_packet"] = registers[11]
        registers[10]["switch_count"] = 0
        registers[10]["signature"] = registers[0]
        registers[9] = registers[10]
        goto p372
        ::p151::
        registers[6] = "Fluctuate"
        goto p278
        ::p165::
        tick(165)
        registers[6] = registers[5]["type"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"];
        registers[(6)] = registers[(6)](registers[7])
        branch_taken = false
        if registers[6] ~= "Solo" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p128
        end
        goto p245
        ::p178::
        a = upvalues[2];
        registers[13] = a[2][a[1]]["exploits"]
        registers[13] = registers[13]["charged"]
        registers[13] = (registers[13] == true)
        goto p340
        ::p182::
        tick(182)
        a = upvalues[2];
        registers[10] = a[2][a[1]]["exploits"]
        registers[10] = registers[10]["charged"]
        registers[10] = (registers[10] == true)
        if not registers[10] then
            goto p264
        end
        goto p324
        ::p187::
        tick(187)
        registers[22] = registers[1]["last_exploit_key_active"]
        registers[22] = (registers[22] ~= registers[0])
        if not registers[22] then
            goto p408
        end
        goto p346
        ::p191::
        registers[12] = upvalues[3]["is_on_shot_antiaim"]
        registers[13] = "no dt";
        registers[(12)] = registers[(12)](registers[13])
        goto p39
        ::p198::
        registers[24] = registers[1]["body_yaw"]
        registers[25] = registers[9]["side"]
        registers[25] = (registers[25] == true)
        registers[24]["inverter"] = registers[25]
        goto p339
        ::p203::
        registers[24] = registers[9]["next_switch_packet"]
        registers[1]["delay_next_switch_packet"] = registers[24]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p215::
        registers[1]["delay_signature"] = registers[0]
        a = upvalues[2];
        registers[23] = a[2][a[1]]["packets"]
        registers[23] = registers[23] + 1
        registers[9]["next_switch_packet"] = registers[23]
        registers[9]["signature"] = registers[0]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p222::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = registers[3]["delay"]
        registers[5] = registers[4]["builder_type"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"]
        goto p320
        ::p227::
        tick(227)
        registers[7] = "Solo"
        goto p42
        ::p230::
        tick(230)
        registers[22] = registers[1]["last_exploit_charged"]
        registers[22] = (registers[22] ~= registers[13])
        goto p408
        ::p234::
        tick(234)
        registers[6] = "Default"
        goto p278
        ::p245::
        if registers[6] ~= "Static" then
            goto p29
        end
        goto p128
        ::p247::
        registers[8] = upvalues[1][1]
        goto p316
        ::p249::
        tick(249)
        branch_taken = false
        if registers[7] ~= "Custom" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p31
        end
        goto p306
        ::p260::
        tick(260)
        registers[1]["delay_packets"] = 0
        registers[24] = registers[21]
        registers[(24)]()
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p264::
        tick(264)
        registers[11] = environment["tonumber"]
        registers[12] = upvalues[3]["ragebot"]
        registers[12] = registers[12]["double_tap_fl"]
        goto p66
        ::p276::
        tick(276)
        if not registers[10] then
            goto p108
        end
        goto p399
        ::p278::
        tick(278)
        registers[7] = registers[5]["values"]
        registers[7] = (registers[7] ~= registers[0])
        if not registers[7] then
            goto p328
        end
        goto p375
        ::p283::
        tick(283)
        registers[10] = {
        }
        registers[11] = registers[1]["body_yaw"]
        registers[11] = registers[11]["inverter"]
        registers[11] = (registers[11] == true)
        registers[10]["side"] = registers[11]
        a = upvalues[2];
        registers[11] = a[2][a[1]]["packets"]
        goto p143
        ::p290::
        tick(290)
        registers[10] = upvalues[3]["is_on_shot_antiaim"];
        registers[10] = registers[10]()
        goto p264
        ::p293::
        registers[24.0] = registers[9]["switch_count"]
        registers[24] = registers[24] + 1
        registers[9]["switch_count"] = registers[24]
        goto p403
        ::p300::
        tick(300)
        registers[23] = registers[1]["body_yaw"]
        registers[23] = registers[23]["inverter"]
        registers[23] = (registers[23] == true)
        goto p352
        ::p306::
        registers[7] = "Solo"
        goto p31
        ::p314::
        if registers[2] == registers[0] then
            goto p396
        end
        goto p125
        ::p316::
        registers[9] = registers[1]["delay_states"]
        registers[9] = registers[9][registers[8]]
        if registers[9] ~= registers[0] then
            goto p182
        end
        goto p283
        ::p320::;
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] == "Hidden")
        if not registers[5] then
            goto p350
        end
        goto p388
        ::p324::
        registers[10] = upvalues[3]["is_double_tap"];
        registers[10] = registers[10]()
        if registers[10] then
            goto p264
        end
        goto p290
        ::p328::
        tick(328)
        if registers[7] then
            goto p42
        end
        goto p227
        ::p331::
        branch_taken = false
        if registers[7] ~= "Double" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p31
        end
        goto p249
        ::p339::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p340::
        a = D.f355
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f356
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[15] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f357
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f358
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[17] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f359
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[18] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p367
        ::p346::
        registers[22] = registers[1]["last_exploit_key_active"]
        registers[22] = (registers[22] ~= registers[12])
        if registers[22] then
            goto p408
        end
        goto p230
        ::p350::
        tick(350)
        if registers[5] then
            goto p165
        end
        goto p386
        ::p352::
        registers[9]["side"] = registers[23]
        registers[23] = registers[1]["body_yaw"]
        registers[24] = registers[9]["side"]
        registers[24] = (registers[24] == true)
        registers[23]["inverter"] = registers[24]
        registers[23] = registers[9]["switch_count"]
        goto p103
        ::p359::
        registers[24] = registers[24]["inverter"]
        registers[24] = (registers[24] == true)
        registers[9]["side"] = registers[24]
        registers[1]["delay_signature"] = registers[23]
        registers[1]["delay_switch_count"] = 0
        goto p260
        ::p365::
        if registers[6] ~= "Custom" then
            goto p278
        end
        goto p234
        ::p367::
        a = D.f360
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[19] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f361
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f362
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[21] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p187
        ::p372::
        registers[10] = registers[1]["delay_states"]
        registers[10][registers[8]] = registers[9]
        goto p182
        ::p375::
        registers[7] = registers[5]["values"]
        z = registers[7]
        registers[8] = z;
        registers[(7)] = z["get"];
        registers[(7)] = registers[(7)](registers[8])
        goto p328
        ::p380::
        registers[24] = registers[9]["side"]
        registers[24] = not registers[24]
        registers[9]["side"] = registers[24]
        registers[24] = registers[1]["body_yaw"]
        registers[25] = registers[9]["side"]
        goto p134
        ::p386::
        registers[5] = registers[4]
        goto p165
        ::p388::
        registers[5] = registers[4]["hidden"]
        goto p350
        ::p396::
        registers[24] = registers[9]["next_switch_packet"]
        if registers[24] ~= registers[0] then
            goto p25
        end
        goto p19
        ::p399::
        a = upvalues[2];
        registers[23] = a[2][a[1]]["fakelag"]
        if not (registers[11] < registers[23]) then
            goto p108
        end
        goto p130
        ::p403::
        registers[24] = registers[9]["switch_count"]
        registers[1]["delay_switch_count"] = registers[24]
        registers[24] = registers[1]["inverts"]
        registers[24] = registers[24] + 1
        goto p121
        ::p408::
        registers[1]["last_exploit_key_active"] = registers[12]
        registers[1]["last_exploit_charged"] = registers[13]
        if not registers[22] then
            goto p276
        end
        goto p300
    end
end
