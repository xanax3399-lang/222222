-- Recovered function f181; author names are unavailable.
F.f181 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f181")
        tick(1)
        goto p141
        ::p4::
        tick(4)
        registers[8] = registers[2][3]
        goto p135
        ::p6::
        tick(6)
        registers[4] = registers[3][1]
        registers[5] = registers[4]["r"]
        if registers[5] == registers[0] then
            goto p125
        end
        goto p186
        ::p10::
        tick(10)
        registers[8] = registers[3][4]
        if registers[8] then
            goto p93
        end
        goto p104
        ::p21::
        tick(21)
        registers[7] = registers[3][3]
        if registers[7] then
            goto p10
        end
        goto p130
        ::p24::
        tick(24)
        registers[8] = registers[4][3]
        if registers[8] then
            goto p138
        end
        goto p171
        ::p27::
        tick(27)
        registers[6] = registers[2][1]
        goto p155
        ::p64::
        tick(64)
        registers[6] = registers[2][1]
        goto p176
        ::p74::
        tick(74)
        registers[7] = registers[2][2]
        goto p24
        ::p77::
        tick(77)
        registers[7] = registers[2][2]
        goto p89
        ::p79::
        tick(79)
        registers[4] = new_frame(4)
        registers[5] = registers[3][1]
        if registers[5] then
            goto p159
        end
        goto p106
        ::p84::
        tick(84)
        registers[5] = new_frame(4)
        registers[6] = registers[4][1]
        if registers[6] then
            goto p176
        end
        goto p64
        ::p89::
        tick(89)
        registers[8] = registers[4]["b"]
        if registers[8] then
            goto p135
        end
        goto p4
        ::p93::
        tick(93)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        q[3] = registers[7]
        q[4] = registers[8]
        do
            return registers[4]
        end
        ::p95::
        tick(95)
        registers[3] = registers[2]
        do
            return registers[3]
        end
        ::p98::
        tick(98)
        registers[6] = registers[2][2]
        goto p21
        ::p101::
        tick(101)
        registers[9] = registers[2][4]
        goto p132
        ::p104::
        registers[8] = registers[2][4]
        goto p93
        ::p106::
        registers[5] = registers[2][1]
        goto p159
        ::p109::
        tick(109)
        registers[3] = {
        }
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["get"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(3)]
        for f = 1, top - (3) do
            q[(0) + f] = registers[(3) + f]
        end
        registers[4] = environment["type"]
        registers[5] = registers[3][1];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= "table" then
            goto p167
        end
        goto p6
        ::p125::
        registers[5] = registers[4][1]
        if registers[5] == registers[0] then
            goto p167
        end
        goto p84
        ::p128::
        tick(128)
        if registers[4] ~= "number" then
            goto p163
        end
        goto p79
        ::p130::
        tick(130)
        registers[7] = registers[2][3]
        goto p10
        ::p132::
        tick(132)
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        do
            return registers[5]
        end
        ::p135::
        registers[9] = registers[4]["a"]
        if registers[9] then
            goto p132
        end
        goto p101
        ::p138::
        tick(138)
        registers[9] = registers[4][4]
        if registers[9] then
            goto p173
        end
        goto p165
        ::p141::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[1] ~= registers[0] then
            goto p109
        end
        goto p95
        ::p155::
        tick(155)
        registers[7] = registers[4]["g"]
        if registers[7] then
            goto p89
        end
        goto p77
        ::p159::
        registers[6] = registers[3][2]
        if registers[6] then
            goto p21
        end
        goto p98
        ::p163::
        registers[4] = registers[2]
        do
            return registers[4]
        end
        ::p165::
        registers[9] = registers[2][4]
        goto p173
        ::p167::
        registers[4] = environment["type"]
        registers[5] = registers[3][1];
        registers[(4)] = registers[(4)](registers[5])
        goto p128
        ::p171::
        registers[8] = registers[2][3]
        goto p138
        ::p173::
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        do
            return registers[5]
        end
        ::p176::
        registers[7] = registers[4][2]
        if registers[7] then
            goto p24
        end
        goto p74
        ::p186::
        registers[5] = new_frame(4)
        registers[6] = registers[4]["r"]
        if registers[6] then
            goto p155
        end
        goto p27
    end
end
