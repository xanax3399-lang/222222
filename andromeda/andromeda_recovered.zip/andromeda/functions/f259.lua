-- Recovered function f259; author names are unavailable.
F.f259 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f259")
        tick(1)
        goto p15
        ::p11::
        tick(11)
        slot_3 = upvalues[0]["set_int"]
        if slot_3 ~= slot_0 then
            goto p26
        end
        goto p23
        ::p15::
        tick(15)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        if slot_2 == slot_0 then
            goto p23
        end
        goto p11
        ::p19::
        tick(19);
        slot_2(slot_3, slot_4)
        do
            return 
        end
        ::p23::
        do
            return 
        end
        ::p26::
        slot_2 = upvalues[0]
        z = slot_2
        slot_3 = z;
        slot_2 = z["set_int"]
        slot_4 = slot_1
        if not slot_4 then
            goto p55
        end
        slot_4 = (0)
        ::p55::
        if slot_4 then
            goto p19
        end
        slot_4 = (1)
        goto p19
    end
end
