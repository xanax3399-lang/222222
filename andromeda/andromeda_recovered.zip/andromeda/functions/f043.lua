-- Recovered function f43; author names are unavailable.
F.f43 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f43")
        tick(1)
        goto p98
        ::p89::
        tick(89)
        registers[2] = registers[2](registers[3], registers[4])
        registers[2] = upvalues[0][registers[2]]
        do
            return registers[2]
        end
        ::p98::
        a = {
            ...,
        }
        registers[1] = a[1]
        a = registers
        z = (2)
        q = environment
        q = q["tonumber"]
        a[z] = q
        registers[3] = registers[1]
        registers[4] = (16)
        goto p89
    end
end
