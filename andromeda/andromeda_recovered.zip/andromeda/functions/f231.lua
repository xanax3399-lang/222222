-- Recovered function f231; author names are unavailable.
F.f231 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f231")
        tick(1)
        goto p121
        ::p2::
        tick(2)
        registers[14] = "bayonet"
        registers[15] = "knife";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        registers[14] = "g3sg1"
        registers[15] = "autosnipers"
        goto p116
        ::p9::
        tick(9)
        branch_taken = false
        if registers[10] ~= "sniper" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        goto p166
        ::p11::
        tick(11)
        do
            return 
        end
        ::p14::
        tick(14)
        registers[15] = upvalues[0][26];
        registers[15] = registers[15]()
        registers[15] = registers[12] < registers[15]
        goto p241
        ::p18::
        tick(18)
        z = registers[5]
        registers[7] = z;
        registers[(6)] = z["get_anim_state"];
        registers[(6)] = registers[(6)](registers[7])
        if registers[6] then
            goto p256
        end
        goto p48
        ::p23::
        tick(23)
        registers[8] = registers[8]["band"]
        a = upvalues[5];
        registers[9] = a[2][a[1]]
        a = upvalues[6];
        registers[10] = a[2][a[1]]
        registers[11] = environment["bit"]
        goto p69
        ::p29::
        tick(29)
        registers[9] = registers[1]["allow_send_packet"]
        if not registers[9] then
            goto p44
        end
        goto p126
        ::p40::
        tick(40)
        branch_taken = false
        if registers[10] ~= "knife" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        goto p9
        ::p44::
        tick(44)
        registers[9] = registers[8] > 0.5
        a = upvalues[4];
        a[2][a[1]]["ducked"] = registers[9]
        a = upvalues[4];
        a[2][a[1]]["duck_amount"] = registers[8]
        goto p50
        ::p48::
        do
            return 
        end
        ::p50::
        a = upvalues[4];
        registers[9] = a[2][a[1]]["packets"]
        registers[9] = registers[9] + 1
        a = upvalues[4];
        a[2][a[1]]["packets"] = registers[9]
        goto p245
        ::p60::
        tick(60)
        a = upvalues[7];
        registers[9] = a[2][a[1]]
        a = upvalues[4];
        a[2][a[1]]["fakelag"] = registers[9]
        goto p136
        ::p64::
        tick(64)
        registers[12] = upvalues[0][47]
        registers[13] = registers[3]
        registers[14] = "m_flNextSecondaryAttack"
        goto p94
        ::p69::
        registers[11] = registers[11]["lshift"]
        registers[12] = (1)
        registers[13] = (0)
        m, x = pack_returns(registers[11](unpack_range(13, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[8] = (registers[8] == 0)
        goto p153
        ::p77::
        tick(77)
        do
            return 
        end
        ::p78::
        tick(78)
        a = upvalues[4];
        a[2][a[1]]["weapon_ready"] = registers[15]
        do
            return 
        end
        ::p80::
        tick(80)
        registers[14] = "_.*"
        registers[15] = "";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        goto p2
        ::p85::
        tick(85)
        registers[5] = upvalues[2]
        registers[6] = registers[2];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p18
        end
        goto p244
        ::p90::
        tick(90)
        registers[10] = registers[4]["weapon_type_int"]
        registers[10] = upvalues[10][registers[10]]
        registers[11] = registers[4]["console_name"]
        goto p40
        ::p94::
        registers[12] = registers[12](registers[13], registers[14])
        registers[13] = upvalues[0][47]
        registers[14] = registers[3]
        registers[15] = "m_flNextPrimaryAttack"
        registers[13] = registers[13](registers[14], registers[15])
        registers[14] = upvalues[0][47]
        registers[15] = registers[2]
        registers[16] = "m_flNextAttack"
        registers[14] = registers[14](registers[15], registers[16])
        registers[15] = upvalues[0][26];
        registers[15] = registers[15]()
        registers[15] = registers[14] < registers[15]
        goto p151
        ::p116::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        registers[14] = "scar20"
        registers[15] = "autosnipers"
        goto p209
        ::p121::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        if registers[2] then
            goto p276
        end
        goto p143
        ::p126::
        registers[9] = upvalues[8]
        registers[10] = registers[2]
        registers[11] = registers[1]
        registers[9] = registers[9](registers[10], registers[11])
        a = upvalues[4];
        a[2][a[1]]["body_yaw"] = registers[9]
        goto p44
        ::p132::
        tick(132)
        registers[12] = registers[9]
        registers[10] = registers[10](registers[11], registers[12])
        a = upvalues[4];
        a[2][a[1]]["peeking"] = registers[10]
        goto p90
        ::p136::
        tick(136)
        registers[9] = registers[6]["m_velocity"]
        a = upvalues[4];
        a[2][a[1]]["velocity"] = registers[9]
        registers[9] = registers[1]["chokedcommands"]
        a = upvalues[7]
        a[2][a[1]] = registers[9]
        registers[9] = registers[1]["chokedcommands"]
        if registers[9] ~= 0 then
            goto p245
        end
        goto p29
        ::p143::
        do
            return 
        end
        ::p145::
        tick(145)
        z = registers[11]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        registers[14] = "weapon_"
        registers[15] = "";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        goto p80
        ::p151::
        if not registers[15] then
            goto p241
        end
        goto p14
        ::p153::
        a = upvalues[4];
        a[2][a[1]]["air"] = registers[8]
        registers[8] = registers[6]["hit_in_ground_animation"]
        registers[8] = (registers[8] == true)
        goto p212
        ::p157::
        tick(157)
        registers[15] = upvalues[0][26];
        registers[15] = registers[15]()
        registers[15] = registers[13] < registers[15]
        goto p78
        ::p161::
        tick(161)
        registers[4] = upvalues[1]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p85
        end
        goto p77
        ::p166::
        z = registers[11]
        registers[13] = z;
        registers[(12)] = z["gsub"]
        registers[14] = "weapon_"
        registers[15] = "";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        branch_taken = false
        if registers[12] ~= "deagle" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        registers[13.0] = registers[4]["is_revolver"]
        if not registers[13] then
            goto p274
        end
        goto p145
        ::p209::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        a = upvalues[4];
        a[2][a[1]]["weapon_group"] = registers[12]
        goto p64
        ::p212::
        a = upvalues[4];
        a[2][a[1]]["on_land"] = registers[8]
        registers[8] = upvalues[0][47]
        registers[9] = registers[2]
        registers[10] = "m_flDuckAmount"
        registers[8] = registers[8](registers[9], registers[10])
        goto p251
        ::p218::
        tick(218)
        m, x = pack_returns(registers[8](unpack_range(10, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        z = registers[7]
        registers[9] = z;
        registers[(8)] = z["length2dsqr"];
        registers[(8)] = registers[(8)](registers[9])
        registers[8] = registers[8] > 25
        a = upvalues[4];
        a[2][a[1]]["moving"] = registers[8]
        registers[8] = environment["bit"]
        goto p23
        ::p241::
        if not registers[15] then
            goto p78
        end
        goto p157
        ::p244::
        do
            return 
        end
        ::p245::
        registers[9] = upvalues[0][52];
        registers[9] = registers[9]()
        registers[10] = upvalues[9]
        registers[11] = registers[2]
        goto p132
        ::p251::
        a = upvalues[7];
        registers[9] = a[2][a[1]]
        registers[10] = registers[1]["chokedcommands"]
        if not (registers[10] < registers[9]) then
            goto p136
        end
        goto p60
        ::p256::
        registers[7] = upvalues[3]
        registers[8] = upvalues[0][47]
        registers[9] = registers[2]
        registers[10] = "m_vecVelocity"
        goto p218
        ::p274::
        a = upvalues[4];
        a[2][a[1]]["weapon_group"] = registers[10]
        goto p64
        ::p276::
        registers[3] = upvalues[0][37]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p161
        end
        goto p11
    end
end
