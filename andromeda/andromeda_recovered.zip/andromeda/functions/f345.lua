-- Recovered function f345; author names are unavailable.
F.f345 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f345")
        tick(1)
        goto p585
        ::p2::
        tick(2)
        if registers[2] ~= registers[0] then
            goto p581
        end
        goto p144
        ::p5::
        tick(5);
        registers[(27)] = registers[(27)](registers[28])
        branch_taken = false
        if not (not (2 <= registers[27])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p649
        end
        goto p652
        ::p8::
        tick(8)
        registers[30] = (0)
        goto p642
        ::p10::
        tick(10)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[5] = z;
            registers[6] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p563
        end
        goto p448
        ::p13::
        tick(13)
        registers[27] = registers[27] + 1
        registers[28] = (8)
        registers[26] = registers[26](registers[27], registers[28])
        goto p373
        ::p17::
        tick(17)
        registers[27] = upvalues[1][161]
        registers[28] = registers[18]["cur_yaw"];
        registers[(27)] = registers[(27)](registers[28])
        goto p620
        ::p21::
        tick(21)
        registers[26] = registers[26] + registers[27]
        registers[27] = (12)
        registers[25] = registers[25](registers[26], registers[27])
        registers[14]["jitter_ticks"] = registers[25]
        goto p91
        ::p26::
        tick(26)
        registers[13] = upvalues[9]
        registers[14] = registers[6]
        registers[(13)](registers[14])
        goto p10
        ::p31::
        tick(31)
        registers[16] = (registers[16] * 120)
        registers[16] = (registers[16] - 59)
        registers[17] = {
        }
        registers[18] = upvalues[12]
        registers[19] = registers[6]
        registers[20] = registers[11]
        registers[18] = registers[18](registers[19], registers[20])
        goto p66
        ::p39::
        tick(39)
        registers[23] = registers[18]["eye_yaw"]
        registers[22] = (registers[22] - registers[23])
        registers[22] = registers[22] + 180
        registers[23] = (180)
        registers[21] = registers[21](registers[22], registers[23])
        registers[21] = (registers[21] * -1)
        registers[22] = registers[14]["n_yaw"]
        if registers[22] ~= registers[0] then
            goto p664
        end
        goto p289
        ::p48::
        tick(48)
        registers[14]["negative_votes"] = registers[26]
        goto p126
        ::p50::
        tick(50)
        registers[32] = upvalues[1][161]
        registers[33] = registers[14]["last_angle"]
        registers[33] = (registers[30] - registers[33]);
        registers[(32)] = registers[(32)](registers[33])
        branch_taken = false
        if not (not (registers[32] < 7)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p574
        end
        goto p318
        ::p61::
        tick(61)
        registers[27] = (registers[27] - 1)
        registers[28] = (0)
        registers[26] = registers[26](registers[27], registers[28])
        registers[14]["positive_votes"] = registers[26]
        goto p138
        ::p66::
        registers[17]["max_yaw"] = registers[18]
        registers[17]["cur_yaw"] = registers[16]
        registers[17]["head"] = registers[12]
        registers[18] = registers[11]["eye_angles_y"]
        if registers[18] then
            goto p173
        end
        goto p392
        ::p72::
        tick(72)
        registers[14]["stable_side"] = registers[27]
        goto p649
        ::p74::
        tick(74)
        if registers[26] then
            goto p407
        end
        goto p579
        ::p76::
        tick(76)
        registers[27] = -1
        goto p72
        ::p81::
        tick(81)
        registers[26] = (registers[26] - 1)
        registers[27] = (0)
        registers[25] = registers[25](registers[26], registers[27])
        goto p180
        ::p85::
        tick(85)
        registers[13]["force_body"] = registers[32]
        registers[14]["last_angle"] = registers[30]
        registers[14]["n_yaw"] = registers[21]
        goto p10
        ::p89::
        tick(89)
        if registers[11] ~= registers[0] then
            goto p601
        end
        goto p655
        ::p91::
        tick(91)
        registers[25] = registers[14]["yaw_update_tick"]
        registers[26] = upvalues[1][23];
        registers[26] = registers[26]()
        registers[25] = registers[25] > registers[26]
        if registers[25] then
            goto p209
        end
        goto p201
        ::p97::
        tick(97)
        registers[25] = (0)
        goto p500
        ::p100::
        tick(100)
        registers[27] = registers[14]["last_side"]
        goto p346
        ::p103::
        tick(103)
        registers[3] = upvalues[6]["ragebot"]
        registers[3] = registers[3]["enemy_resolver_generate"]
        registers[3] = registers[3] == registers[0]
        if registers[3] then
            goto p494
        end
        goto p386
        ::p108::
        tick(108)
        registers[13]["yaw"] = registers[30]
        registers[30] = upvalues[18]["clamp"]
        registers[31] = registers[18]["max_yaw"]
        registers[31] = registers[31] * registers[27]
        goto p506
        ::p115::
        tick(115)
        registers[30] = registers[18]["eye_yaw"]
        registers[31] = registers[20]["y"]
        registers[30] = (registers[30] - registers[31])
        goto p108
        ::p120::
        tick(120)
        branch_taken = false
        if not (not (registers[20] < 1)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p680
        end
        goto p246
        ::p122::
        tick(122)
        registers[32] = registers[31] <= 55
        goto p266
        ::p124::
        tick(124)
        registers[27] = (0)
        goto p450
        ::p126::
        tick(126)
        registers[26] = registers[14]["positive_votes"]
        if registers[26] then
            goto p632
        end
        goto p396
        ::p136::
        tick(136)
        registers[31] = (registers[31] >= 3)
        goto p645
        ::p138::
        registers[26] = upvalues[1][151]
        registers[27] = registers[14]["negative_votes"]
        if registers[27] then
            goto p466
        end
        goto p238
        ::p142::
        tick(142)
        registers[31] = registers[22] > 1
        goto p569
        ::p144::
        tick(144)
        registers[3] = upvalues[3]["reset"]
        registers[(3)]()
        do
            return 
        end
        ::p148::
        tick(148)
        registers[28] = upvalues[15]
        registers[29] = registers[6];
        registers[(28)] = registers[(28)](registers[29])
        registers[27] = registers[28]
        goto p613
        ::p169::
        tick(169)
        registers[27] = (0)
        goto p672
        ::p171::
        tick(171)
        registers[26] = (14)
        goto p17
        ::p173::
        tick(173)
        registers[17]["eye_yaw"] = registers[18]
        registers[15][registers[8]] = registers[17]
        registers[17] = registers[15][registers[9]]
        registers[18] = registers[15][registers[8]]
        registers[19] = registers[18]["head"]
        if registers[17] == registers[0] then
            goto p680
        end
        goto p332
        ::p180::
        registers[14]["jitter_ticks"] = registers[25]
        goto p91
        ::p182::
        tick(182)
        registers[31] = (registers[31] >= 5)
        if registers[31] then
            goto p645
        end
        goto p272
        ::p185::
        tick(185)
        registers[12] = registers[12](registers[13], registers[14])
        if registers[12] ~= registers[0] then
            goto p228
        end
        goto p26
        ::p188::
        tick(188)
        registers[29] = upvalues[1][161]
        registers[30] = (registers[28] - registers[21]);
        registers[(29)] = registers[(29)](registers[30])
        registers[30] = upvalues[1][161]
        registers[31] = registers[18]["cur_yaw"]
        goto p282
        ::p194::
        tick(194)
        registers[26] = (9)
        goto p240
        ::p197::
        tick(197)
        registers[27] = upvalues[15]
        registers[28] = registers[6];
        registers[(27)] = registers[(27)](registers[28])
        goto p260
        ::p201::
        registers[25] = registers[14]["jitter_ticks"]
        if registers[25] then
            goto p500
        end
        goto p97
        ::p209::
        tick(209)
        registers[26] = upvalues[1][161]
        registers[27] = registers[21];
        registers[(26)] = registers[(26)](registers[27])
        goto p567
        ::p213::
        tick(213)
        registers[29] = (registers[22] - 1)
        registers[30] = upvalues[17]
        registers[30] = (#registers[30])
        registers[29] = registers[29] % registers[30]
        registers[29] = registers[29] + 1
        registers[30] = registers[14]["stored_eye_angles"]
        registers[30] = registers[30][registers[28]]
        if registers[30] then
            goto p108
        end
        goto p115
        ::p222::
        tick(222)
        registers[14]["yaw_update_tick"] = registers[25]
        registers[25] = upvalues[1][162]
        registers[26] = registers[14]["jitter_ticks"]
        goto p74
        ::p228::
        registers[13] = upvalues[11]
        registers[14] = registers[6]
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        z = 0
        for f = 13, 15 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[16] = upvalues[1][47]
        goto p543
        ::p238::
        registers[27] = (0)
        goto p466
        ::p240::
        tick(240)
        if registers[26] then
            goto p17
        end
        goto p171
        ::p242::
        tick(242)
        registers[27] = 0.1879 / registers[27];
        registers[(26)] = registers[(26)](registers[27])
        registers[25] = registers[25] + registers[26]
        goto p222
        ::p246::
        registers[21] = registers[18]["head"]
        registers[22] = registers[17]["head"]
        registers[21] = (registers[21] - registers[22])
        registers[21] = (registers[21] / registers[20])
        goto p596
        ::p251::
        tick(251)
        m, x = pack_returns(registers[25](unpack_range(27, registers, 26)))
        m = m + 25 - 1
        top = m
        z = 0
        for f = 25, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[24] = registers[24](unpack_range(top, registers, 25))
        registers[14]["last_yaw_delta"] = registers[24]
        registers[25] = upvalues[1][151]
        registers[26] = registers[22] > 1
        if not registers[26] then
            goto p240
        end
        goto p194
        ::p258::
        tick(258)
        if registers[3] ~= true then
            goto p144
        end
        goto p2
        ::p260::
        tick(260)
        if not registers[3] then
            goto p613
        end
        goto p390
        ::p262::
        tick(262)
        registers[26] = upvalues[1][162]
        registers[27] = registers[14]["negative_votes"]
        if registers[27] then
            goto p672
        end
        goto p169
        ::p266::
        tick(266)
        if registers[32] then
            goto p85
        end
        goto p640
        ::p270::
        tick(270)
        registers[22] = (1)
        goto p291
        ::p272::
        registers[31] = upvalues[1][161]
        registers[32] = registers[26];
        registers[(31)] = registers[(31)](registers[32])
        goto p136
        ::p277::
        tick(277)
        registers[32] = upvalues[1][161]
        registers[33] = registers[30];
        registers[(32)] = registers[(32)](registers[33])
        registers[32] = registers[32] > 52
        goto p659
        ::p282::;
        registers[(30)] = registers[(30)](registers[31])
        registers[30] = (registers[30] * 0.46)
        if not (registers[30] < registers[29]) then
            goto p516
        end
        goto p334
        ::p286::
        tick(286)
        registers[27] = registers[14]["stable_side"]
        if registers[27] then
            goto p346
        end
        goto p100
        ::p289::
        registers[14]["n_yaw"] = registers[21]
        goto p664
        ::p291::
        tick(291)
        registers[23] = registers[22] > 1
        if not registers[23] then
            goto p432
        end
        goto p429
        ::p294::
        tick(294)
        registers[19] = registers[22] + registers[23]
        goto p680
        ::p296::
        tick(296)
        registers[27] = (0)
        ::p301::
        tick(301)
        registers[27] = (registers[27] - 1)
        registers[28] = (0)
        registers[26] = registers[26](registers[27], registers[28])
        registers[14]["positive_votes"] = registers[26]
        goto p126
        ::p306::
        tick(306)
        registers[27] = (0)
        goto p61
        ::p308::
        tick(308)
        registers[8] = registers[7][1]
        registers[9] = registers[7][2]
        registers[10] = upvalues[8]
        registers[11] = registers[6];
        registers[(10)] = registers[(10)](registers[11])
        goto p637
        ::p314::
        tick(314)
        registers[31] = registers[14]["jitter_ticks"]
        if registers[31] then
            goto p182
        end
        goto p483
        ::p318::
        registers[30] = registers[14]["last_angle"]
        goto p574
        ::p322::
        tick(322)
        if registers[27] then
            goto p72
        end
        goto p76
        ::p332::
        if registers[18] == registers[0] then
            goto p680
        end
        goto p361
        ::p334::
        tick(334)
        registers[29] = registers[14]["stored_eye_angles"]
        registers[30] = registers[18]["eye_yaw"]
        registers[31] = registers[20]["y"]
        goto p368
        ::p339::
        tick(339)
        registers[24] = upvalues[1][161]
        registers[25] = upvalues[14]
        registers[26] = registers[14]["n_yaw"]
        registers[26] = (registers[21] - registers[26])
        registers[27] = (180)
        goto p251
        ::p346::
        tick(346)
        if registers[27] then
            goto p260
        end
        goto p197
        ::p348::
        tick(348)
        if registers[27] then
            goto p21
        end
        goto p661
        ::p350::
        tick(350)
        registers[16] = (0.5)
        goto p31
        ::p354::
        tick(354)
        registers[30] = (#registers[30])
        registers[30] = registers[30] + 1
        registers[29][registers[30]] = registers[21]
        registers[28] = registers[21]
        goto p213
        ::p359::
        tick(359)
        registers[27] = (0)
        goto p13
        ::p361::
        registers[20] = (registers[8] - registers[9])
        if not (0 < registers[20]) then
            goto p680
        end
        goto p120
        ::p364::
        tick(364)
        registers[26] = (registers[26] - registers[27])
        registers[27] = upvalues[1][161]
        registers[28] = registers[26]
        goto p5
        ::p368::
        registers[30] = (registers[30] - registers[31])
        registers[29][registers[21]] = registers[30]
        registers[29] = registers[14]["stored_yaw_sp"]
        goto p523
        ::p373::
        registers[14]["positive_votes"] = registers[26]
        registers[26] = upvalues[1][151]
        registers[27] = registers[14]["negative_votes"]
        if registers[27] then
            goto p450
        end
        goto p124
        ::p386::
        registers[3] = upvalues[6]["ragebot"]
        registers[3] = registers[3]["enemy_resolver_generate"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"]
        goto p513
        ::p390::
        branch_taken = false
        if registers[25] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p613
        end
        goto p148
        ::p392::
        registers[18] = (0)
        goto p173
        ::p394::
        tick(394)
        registers[27] = (1)
        goto p322
        ::p396::
        registers[26] = (0)
        goto p632
        ::p398::
        tick(398)
        registers[32] = registers[25]
        if not registers[32] then
            goto p659
        end
        goto p277
        ::p401::
        tick(401)
        registers[31] = registers[31](registers[32], registers[33])
        if registers[31] then
            goto p470
        end
        goto p611
        ::p405::
        tick(405)
        registers[11] = nil
        goto p89
        ::p407::
        tick(407)
        registers[27] = registers[22] > 1
        if not registers[27] then
            goto p348
        end
        goto p521
        ::p410::
        tick(410)
        registers[27] = (0)
        goto p364
        ::p413::
        tick(413)
        if not (0 < registers[21]) then
            goto p262
        end
        goto p455
        ::p415::
        tick(415)
        if registers[11] then
            goto p89
        end
        goto p405
        ::p417::
        tick(417)
        registers[1] = upvalues[1][32];
        registers[1] = registers[1]()
        registers[2] = upvalues[2]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        goto p594
        ::p423::
        tick(423)
        registers[25] = upvalues[1][23];
        registers[25] = registers[25]()
        registers[26] = upvalues[1][154]
        registers[27] = upvalues[1][28];
        registers[27] = registers[27]()
        goto p242
        ::p429::
        registers[23] = (0.34)
        ::p432::
        if registers[23] then
            goto p339
        end
        goto p477
        ::p434::
        tick(434);
        registers[30] = registers[30](unpack_range(33, registers, 31))
        registers[31] = registers[14]["last_angle"]
        if registers[31] == registers[0] then
            goto p574
        end
        goto p50
        ::p445::
        tick(445)
        do
            return 
        end
        ::p448::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p450::
        registers[27] = (registers[27] - 1)
        registers[28] = (0)
        registers[26] = registers[26](registers[27], registers[28])
        registers[14]["negative_votes"] = registers[26]
        goto p126
        ::p455::
        registers[26] = upvalues[1][162]
        registers[27] = registers[14]["positive_votes"]
        if registers[27] then
            goto p13
        end
        goto p359
        ::p466::
        registers[27] = (registers[27] - 1)
        registers[28] = (0)
        registers[26] = registers[26](registers[27], registers[28])
        goto p48
        ::p470::
        tick(470)
        registers[32] = (registers[22] >= 4)
        if registers[32] then
            goto p266
        end
        goto p398
        ::p473::
        tick(473)
        registers[3] = upvalues[5]
        registers[4] = registers[1]
        registers[(3)](registers[4])
        goto p445
        ::p477::
        registers[23] = (0.52)
        goto p339
        ::p479::
        tick(479)
        registers[25] = upvalues[1][151]
        registers[26] = registers[14]["jitter_ticks"]
        if registers[26] then
            goto p81
        end
        goto p635
        ::p483::
        registers[31] = (0)
        goto p182
        ::p494::
        tick(494)
        registers[4] = environment["ipairs"]
        registers[5] = upvalues[7]
        m, x = pack_returns(registers[5]())
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[4](unpack_range(top, registers, 5)))
        z = 0
        for f = 4, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(4)]
        n = registers[5]
        U = registers[6]
        goto p10
        goto p413
        ::p500::
        registers[25] = registers[25] > 1
        goto p209
        ::p502::
        tick(502)
        registers[26] = upvalues[1][151]
        registers[27] = registers[14]["positive_votes"]
        if registers[27] then
            goto p61
        end
        goto p306
        ::p506::
        registers[32] = upvalues[17][registers[29]]
        registers[31] = registers[31] * registers[32]
        registers[32] = -58
        registers[33] = (58)
        goto p434
        ::p513::;
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = (registers[3] == "Adaptive")
        goto p494
        ::p516::
        registers[29] = registers[14]["stored_yaw_sp"]
        registers[30] = registers[14]["stored_yaw_sp"]
        registers[30] = registers[30][registers[28]]
        if registers[30] then
            goto p642
        end
        goto p8
        ::p521::
        registers[27] = (3)
        goto p348
        ::p523::
        registers[29][registers[21]] = 1
        registers[29] = registers[14]["stored_yaw_angles"]
        registers[30] = registers[14]["stored_yaw_angles"]
        goto p354
        ::p534::
        tick(534)
        z = registers[10]
        registers[12] = z;
        registers[(11)] = z["get_anim_state"];
        registers[(11)] = registers[(11)](registers[12])
        goto p415
        ::p543::
        registers[17] = registers[6]
        registers[18] = "m_flPoseParameter"
        registers[19] = (11)
        goto p668
        ::p563::
        registers[7] = upvalues[3]["sim_store"]
        registers[7] = registers[7][registers[6]]
        if registers[7] ~= registers[0] then
            goto p308
        end
        goto p10
        ::p567::
        if not (6 < registers[26]) then
            goto p502
        end
        goto p413
        ::p569::
        tick(569)
        registers[13]["active"] = registers[31]
        registers[31] = upvalues[1][47]
        registers[32] = registers[6]
        registers[33] = "m_iHealth"
        goto p401
        ::p574::
        registers[13]["angle"] = registers[30]
        registers[13]["jitter"] = registers[25]
        registers[31] = registers[25]
        if not registers[31] then
            goto p645
        end
        goto p314
        ::p579::
        registers[26] = (0)
        goto p407
        ::p581::
        registers[3] = upvalues[4];
        registers[3] = registers[3]()
        if registers[3] ~= "Auto" then
            goto p103
        end
        goto p473
        ::p585::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p417
        end
        goto p625
        ::p594::
        if registers[1] == registers[0] then
            goto p144
        end
        goto p605
        ::p596::
        registers[22] = registers[18]["head"]
        registers[23] = upvalues[1][28];
        registers[23] = registers[23]()
        registers[23] = registers[21] * registers[23]
        goto p294
        ::p601::
        registers[12] = upvalues[10]
        registers[13] = registers[6]
        registers[14] = (0)
        goto p185
        ::p605::
        registers[3] = upvalues[1][50]
        registers[4] = registers[1];
        registers[(3)] = registers[(3)](registers[4])
        goto p258
        ::p611::
        registers[31] = (100)
        goto p470
        ::p613::
        registers[14]["last_side"] = registers[27]
        registers[28] = upvalues[16]
        registers[29] = registers[14]["stored_yaw_angles"]
        registers[30] = registers[21]
        registers[28] = registers[28](registers[29], registers[30])
        if registers[28] == registers[0] then
            goto p334
        end
        goto p188
        ::p620::
        registers[27] = registers[27] * registers[23]
        registers[25] = registers[25](registers[26], registers[27])
        if not (registers[25] < registers[24]) then
            goto p479
        end
        goto p423
        ::p625::
        do
            return 
        end
        ::p632::
        registers[27] = registers[14]["negative_votes"]
        if registers[27] then
            goto p364
        end
        goto p410
        ::p635::
        registers[26] = (0)
        goto p81
        ::p637::
        registers[11] = (registers[10] ~= registers[0])
        if not registers[11] then
            goto p415
        end
        goto p534
        ::p640::
        registers[32] = registers[31] <= 35
        goto p85
        ::p642::
        registers[30] = registers[30] + 1
        registers[29][registers[28]] = registers[30]
        goto p213
        ::p645::
        registers[13]["high_confidence"] = registers[31]
        registers[31] = registers[13]["high_confidence"]
        if registers[31] then
            goto p569
        end
        goto p142
        ::p649::
        registers[27] = registers[25]
        if not registers[27] then
            goto p346
        end
        goto p286
        ::p652::
        registers[27] = registers[26] > 0
        if not registers[27] then
            goto p322
        end
        goto p394
        ::p655::
        registers[12] = upvalues[9]
        registers[13] = registers[6]
        registers[(12)](registers[13])
        goto p10
        ::p659::
        if not registers[32] then
            goto p266
        end
        goto p122
        ::p661::
        registers[27] = (2)
        goto p21
        ::p664::
        registers[22] = upvalues[3]["miss_counter"]
        registers[22] = registers[22][registers[6]]
        if registers[22] then
            goto p291
        end
        goto p270
        ::p668::;
        registers[16] = registers[16](unpack_range(19, registers, 17))
        if registers[16] then
            goto p31
        end
        goto p350
        ::p672::
        registers[27] = registers[27] + 1
        registers[28] = (8)
        registers[26] = registers[26](registers[27], registers[28])
        registers[14]["negative_votes"] = registers[26]
        registers[26] = upvalues[1][151]
        registers[27] = registers[14]["positive_votes"]
        if registers[27] then
            goto p301
        end
        goto p296
        ::p680::
        registers[20] = upvalues[13]
        registers[21] = registers[2]
        registers[22] = registers[19]
        registers[20] = registers[20](registers[21], registers[22])
        registers[21] = upvalues[14]
        registers[22] = registers[20]["y"]
        goto p39
    end
end
