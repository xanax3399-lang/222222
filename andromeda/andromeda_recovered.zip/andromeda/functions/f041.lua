-- Recovered function f41; author names are unavailable.
F.f41 = function(function_metadata, upvalues)
    local operand_i, operand_g, operand_k = function_metadata[2], function_metadata[6], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f41")
        tick(1)
        goto p195
        ::p2::
        tick(2)
        registers[19] = registers[19](registers[20], registers[21])
        a = registers
        z = (20)
        q = environment
        q = q["bit"]
        a[z] = q
        registers[20] = registers[20]["ror"]
        registers[21] = registers[5]
        registers[22] = (22)
        m, x = pack_returns(registers[20](unpack_range(22, registers, 21)))
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[17] = registers[17](unpack_range(top, registers, 18))
        registers[18] = environment["bit"]
        registers[18] = registers[18]["bxor"]
        goto p282
        ::p15::
        tick(15)
        registers[12] = registers[23]
        goto p27
        ::p17::
        tick(17)
        registers[14] = registers[14] + registers[11]
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        goto p394
        ::p21::
        tick(21)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p296
        end
        goto p157
        ::p23::
        tick(23)
        registers[22] = environment["bit"]
        registers[22] = registers[22]["band"]
        registers[23] = registers[9]
        goto p111
        ::p27::
        tick(27)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p399
        end
        goto p53
        ::p29::
        tick(29)
        registers[14] = registers[3][1]
        registers[14] = registers[14] + registers[5]
        registers[15] = (4294967295)
        goto p163
        ::p33::
        tick(33)
        registers[12] = registers[12]["bxor"]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["ror"]
        goto p224
        ::p37::
        tick(37)
        registers[17] = (10)
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        registers[11] = registers[11] + registers[12]
        registers[4][registers[8]] = registers[11]
        goto p426
        ::p49::
        tick(49)
        registers[23] = registers[23]["band"]
        registers[24] = environment["bit"]
        registers[24] = registers[24]["bnot"]
        goto p323
        ::p53::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        goto p29
        ::p58::
        tick(58)
        registers[9] = (registers[8] - 15)
        registers[9] = registers[4][registers[9]]
        registers[10] = environment["bit"]
        goto p421
        ::p69::
        tick(69)
        registers[3][6] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][7]
        goto p17
        ::p84::
        tick(84)
        registers[8] = registers[28]
        registers[9] = registers[26]
        registers[10] = registers[25]
        registers[11] = registers[24]
        goto p15
        ::p90::
        tick(90)
        registers[8] = registers[3][4]
        registers[9] = registers[3][5]
        registers[10] = registers[3][6]
        registers[11] = registers[3][7]
        goto p191
        ::p95::
        tick(95)
        registers[14] = registers[14] + registers[8]
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        registers[3][4] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][5]
        registers[14] = registers[14] + registers[9]
        goto p129
        ::p111::
        registers[24] = registers[10]
        registers[22] = registers[22](registers[23], registers[24])
        registers[23] = environment["bit"]
        goto p49
        ::p115::
        tick(115)
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        registers[3][2] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][3]
        registers[14] = registers[14] + registers[7]
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        goto p135
        ::p125::
        tick(125)
        registers[20] = registers[20](registers[21], registers[22])
        registers[21] = environment["bit"]
        registers[21] = registers[21]["band"]
        goto p181
        ::p129::
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        registers[3][5] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        goto p317
        ::p135::
        registers[3][3] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][4]
        goto p95
        ::p147::
        tick(147)
        registers[21] = registers[6]
        registers[19] = registers[19](registers[20], registers[21])
        registers[20] = environment["bit"]
        goto p378
        ::p157::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[5] = (17)
        registers[6] = (64)
        registers[7] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p426
        ::p163::
        registers[13] = registers[13](registers[14], registers[15])
        a = registers
        z = (3)
        a = a[z]
        z = (1)
        q = registers
        m = 13
        q = q[m]
        a[z] = q
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][2]
        registers[14] = registers[14] + registers[6]
        goto p115
        ::p181::
        registers[22] = registers[6]
        registers[23] = registers[7]
        m, x = pack_returns(registers[21](unpack_range(23, registers, 22)))
        m = m + 21 - 1
        top = m
        z = 0
        for f = 21, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[18] = registers[18](unpack_range(top, registers, 19))
        registers[19] = registers[17] + registers[18]
        registers[20] = environment["bit"]
        goto p366
        ::p191::
        registers[12] = registers[3][8]
        registers[13] = (1)
        registers[14] = (64)
        goto p392
        ::p195::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = {
        }
        registers[5] = (1)
        registers[6] = (16)
        registers[7] = (1)
        goto p208
        ::p203::
        tick(203)
        registers[23] = registers[4][registers[16]]
        registers[22] = registers[22] + registers[23]
        registers[23] = registers[11]
        registers[24] = registers[10]
        goto p218
        ::p208::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p21
        registers[51] = operand_i
        registers[50] = operand_g
        registers[52] = operand_k
        registers[52][230] = 3
        registers[50][230] = 0
        registers[51][230] = 13
        registers[52][322] = 229
        registers[45] = nil
        registers[46] = nil
        registers[47] = nil
        registers[48] = nil
        registers[49] = nil
        registers[50] = nil
        registers[51] = nil
        registers[52] = nil
        goto p230
        ::p218::
        registers[25] = registers[9]
        registers[26] = registers[8] + registers[22]
        registers[28] = registers[7]
        registers[29] = registers[6]
        registers[30] = registers[5]
        goto p327
        ::p224::
        registers[14] = registers[9]
        registers[15] = (17)
        registers[13] = registers[13](registers[14], registers[15])
        registers[14] = environment["bit"]
        registers[14] = registers[14]["ror"]
        goto p349
        ::p230::
        tick(230)
        m, x = pack_returns(registers[13](unpack_range(15, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        a = registers
        z = 11
        q = registers
        q = q[8]
        m = 2
        q = q - m;
        a[z] = q
        registers[9] = registers[4][registers[11]]
        registers[11] = (registers[8] - 16)
        goto p310
        ::p252::
        tick(252)
        registers[14] = registers[14] + registers[12]
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        registers[3][8] = registers[13]
        goto p403
        ::p257::
        tick(257)
        registers[23] = environment["bit"]
        registers[23] = registers[23]["ror"]
        registers[24] = registers[9]
        registers[25] = (25)
        m, x = pack_returns(registers[23](unpack_range(25, registers, 24)))
        m = m + 23 - 1
        top = m
        z = 0
        for f = 23, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[20] = registers[20](unpack_range(top, registers, 21))
        registers[21] = environment["bit"]
        registers[21] = registers[21]["bxor"]
        goto p23
        ::p282::
        registers[19] = environment["bit"]
        registers[19] = registers[19]["band"]
        registers[20] = registers[5]
        goto p147
        ::p286::
        tick(286)
        registers[13] = (7)
        registers[11] = registers[11](registers[12], registers[13])
        a = registers
        z = (12)
        q = environment
        q = q["bit"]
        a[z] = q
        registers[12] = registers[12]["ror"]
        registers[13] = registers[9]
        registers[14] = (18)
        registers[12] = registers[12](registers[13], registers[14])
        goto p344
        ::p296::
        registers[9] = upvalues[0]
        registers[10] = registers[1]
        registers[11] = (registers[8] - 1)
        goto p339
        ::p310::
        registers[11] = registers[4][registers[11]]
        registers[11] = registers[11] + registers[10]
        registers[12] = (registers[8] - 7)
        registers[12] = registers[4][registers[12]]
        registers[11] = registers[11] + registers[12]
        registers[12] = environment["bit"]
        goto p33
        ::p317::
        registers[14] = registers[3][6]
        registers[14] = registers[14] + registers[10]
        registers[15] = (4294967295)
        registers[13] = registers[13](registers[14], registers[15])
        goto p69
        ::p323::
        registers[25] = registers[9];
        registers[(24)] = registers[(24)](registers[25])
        registers[25] = registers[11]
        goto p382
        ::p327::
        registers[31] = registers[22] + registers[19]
        registers[5] = registers[31]
        registers[6] = registers[30]
        registers[7] = registers[29]
        goto p84
        ::p333::
        tick(333)
        registers[18] = registers[18](registers[19], registers[20])
        registers[19] = environment["bit"]
        registers[19] = registers[19]["ror"]
        registers[20] = registers[5]
        registers[21] = (13)
        goto p2
        ::p339::
        registers[11] = (registers[11] * 4)
        registers[11] = registers[2] + registers[11]
        registers[9] = registers[9](registers[10], registers[11])
        registers[4][registers[8]] = registers[9]
        goto p21
        ::p344::
        registers[13] = environment["bit"]
        registers[13] = registers[13]["rshift"]
        registers[14] = registers[9]
        registers[15] = (3)
        goto p230
        ::p349::
        registers[15] = registers[9]
        registers[16] = (19)
        registers[14] = registers[14](registers[15], registers[16])
        registers[15] = environment["bit"]
        registers[15] = registers[15]["rshift"]
        registers[16] = registers[9]
        goto p37
        ::p356::
        tick(356)
        registers[18] = registers[18]["ror"]
        registers[19] = registers[5]
        registers[20] = (2)
        goto p333
        ::p366::
        registers[20] = registers[20]["bxor"]
        registers[21] = environment["bit"]
        registers[21] = registers[21]["ror"]
        registers[22] = registers[9]
        registers[23] = (6)
        registers[21] = registers[21](registers[22], registers[23])
        registers[22] = environment["bit"]
        registers[22] = registers[22]["ror"]
        registers[23] = registers[9]
        registers[24] = (11)
        registers[22] = registers[22](registers[23], registers[24])
        goto p257
        ::p378::
        registers[20] = registers[20]["band"]
        registers[21] = registers[5]
        registers[22] = registers[7]
        goto p125
        ::p382::
        m, x = pack_returns(registers[23](unpack_range(25, registers, 24)))
        m = m + 23 - 1
        top = m
        z = 0
        for f = 23, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[21] = registers[21](unpack_range(top, registers, 22))
        a = registers
        z = 22
        q = registers
        q = q[12]
        m = registers
        x = 20
        m = m[x]
        q = q + m
        a[z] = q
        registers[22] = registers[22] + registers[21]
        registers[23] = upvalues[1][registers[16]]
        registers[22] = registers[22] + registers[23]
        goto p203
        ::p392::
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p27
        ::p394::
        registers[3][7] = registers[13]
        registers[13] = environment["bit"]
        registers[13] = registers[13]["band"]
        registers[14] = registers[3][8]
        goto p252
        ::p399::
        registers[17] = environment["bit"]
        registers[17] = registers[17]["bxor"]
        registers[18] = environment["bit"]
        goto p356
        ::p403::
        do
            return 
        end
        ::p411::
        tick(411)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[5] = registers[3][1]
        registers[6] = registers[3][2]
        registers[7] = registers[3][3]
        goto p90
        ::p421::
        registers[10] = registers[10]["bxor"]
        registers[11] = environment["bit"]
        registers[11] = registers[11]["ror"]
        registers[12] = registers[9]
        goto p286
        ::p426::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p58
        end
        goto p411
    end
end
