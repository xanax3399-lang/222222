-- Recovered function f260; author names are unavailable.
F.f260 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local z = nil
        local tick = new_tick("f260")
        tick(1)
        goto p25
        ::p11::
        tick(11)
        slot_2 = (slot_1 == 0)
        do
            return slot_2
        end
        ::p23::
        tick(23)
        slot_2 = (slot_1 == "Builder")
        do
            return slot_2
        end
        ::p25::
        slot_1 = upvalues[0]["switch_type"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= "number" then
            goto p23
        end
        goto p11
    end
end
