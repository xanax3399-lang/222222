-- Recovered function f112; author names are unavailable.
F.f112 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f112")
        tick(1)
        goto p38
        ::p2::
        tick(2)
        slot_3 = (slot_3 * 2)
        ::p6::
        tick(6)
        if not (0 < slot_1) then
            goto p63
        end
        goto p35
        ::p17::
        tick(17)
        slot_4 = slot_4 + slot_3
        goto p74
        ::p35::
        if not (0 < slot_2) then
            goto p63
        end
        goto p91
        ::p38::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p6
        ::p42::
        tick(42)
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 2
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 2
        goto p2
        ::p47::
        tick(47)
        slot_1 = slot_2
        goto p67
        ::p60::
        tick(60)
        slot_5 = slot_1 % 2
        if not (0 < slot_5) then
            goto p74
        end
        goto p17
        ::p63::
        if not (slot_1 < slot_2) then
            goto p67
        end
        goto p47
        ::p65::
        tick(65)
        slot_4 = slot_4 + slot_3
        goto p42
        ::p67::
        tick(67)
        if not (0 < slot_1) then
            goto p71
        end
        goto p60
        ::p71::
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p74::
        slot_6 = (slot_1 - slot_5)
        slot_1 = slot_6 / 2
        slot_3 = (slot_3 * 2)
        goto p67
        ::p91::
        slot_5 = slot_1 % 2
        slot_6 = slot_2 % 2
        if slot_5 == slot_6 then
            goto p42
        end
        goto p65
    end
end
