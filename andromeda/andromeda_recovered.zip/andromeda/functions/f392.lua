-- Recovered function f392; author names are unavailable.
F.f392 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f392")
        tick(1)
        goto p14
        ::p3::
        tick(3)
        if registers[1] == registers[0] then
            goto p109
        end
        goto p137
        ::p5::
        tick(5)
        registers[4] = (0)
        registers[5] = (153)
        registers[6] = (255)
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        do
            return unpack_range(2, registers, (1))
        end
        ::p10::
        tick(10)
        registers[1] = upvalues[2]["antiaim"]
        registers[1] = (registers[1] ~= registers[0])
        if not registers[1] then
            goto p176
        end
        goto p165
        ::p14::
        registers[1] = upvalues[0]["is_quick_peek"];
        registers[1] = registers[1]()
        if registers[1] then
            goto p62
        end
        goto p32
        ::p21::
        tick(21)
        registers[5] = (139)
        registers[6] = (230)
        registers[7] = (255)
        goto p35
        ::p32::
        a = upvalues[1];
        registers[1] = a[2][a[1]]
        if registers[1] == registers[0] then
            goto p184
        end
        goto p156
        ::p35::
        q = registers[(3)]
        q[1] = registers[4]
        q[2] = registers[5]
        q[3] = registers[6]
        q[4] = registers[7]
        do
            return unpack_range(3, registers, (2))
        end
        ::p38::
        tick(38)
        registers[3] = registers[1]["freestanding"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        if not registers[3] then
            goto p109
        end
        goto p67
        ::p50::
        tick(50)
        a = upvalues[1];
        registers[2] = a[2][a[1]]["manual"]
        if registers[2] == registers[0] then
            goto p10
        end
        goto p128
        ::p53::
        tick(53)
        if registers[1] then
            goto p3
        end
        goto p107
        ::p62::
        tick(62)
        registers[1] = "E-PEEK"
        registers[2] = new_frame(4)
        registers[3] = (255)
        goto p5
        ::p67::
        registers[2] = "FREESTANDING"
        registers[3] = new_frame(4)
        registers[4] = (209)
        goto p21
        ::p107::
        registers[1] = nil
        goto p3
        ::p109::
        tick(109)
        registers[2] = "DYNAMIC"
        registers[3] = new_frame(4)
        registers[4] = (177)
        registers[5] = (151)
        registers[6] = (255)
        registers[7] = (255)
        goto p182
        ::p128::
        registers[1] = "MANUAL"
        registers[2] = new_frame(4)
        registers[3] = (209)
        registers[4] = (139)
        registers[5] = (230)
        registers[6] = (255)
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        do
            return unpack_range(2, registers, (1))
        end
        ::p137::
        registers[2] = registers[1]["freestanding"]
        if registers[2] == registers[0] then
            goto p109
        end
        goto p38
        ::p156::
        a = upvalues[1];
        registers[2] = a[2][a[1]]["e_peek"]
        if registers[2] ~= true then
            goto p184
        end
        goto p62
        ::p165::
        registers[1] = upvalues[2]["antiaim"]
        registers[1] = registers[1]["features"]
        registers[1] = (registers[1] ~= registers[0])
        ::p176::
        if not registers[1] then
            goto p53
        end
        registers[1] = upvalues[2]["antiaim"]
        registers[1] = registers[1]["features"]
        registers[1] = registers[1]["hotkeys"]
        goto p53
        ::p182::
        q = registers[(3)]
        q[1] = registers[4]
        q[2] = registers[5]
        q[3] = registers[6]
        q[4] = registers[7]
        do
            return unpack_range(3, registers, (2))
        end
        ::p184::
        a = upvalues[1];
        registers[1] = a[2][a[1]]
        if registers[1] == registers[0] then
            goto p10
        end
        goto p50
    end
end
