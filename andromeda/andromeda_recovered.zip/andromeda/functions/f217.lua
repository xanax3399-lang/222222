-- Recovered function f217; author names are unavailable.
F.f217 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f217")
        tick(1)
        goto p67
        ::p17::
        tick(17)
        registers[5] = upvalues[3]
        registers[6] = upvalues[4]["normalize"]
        registers[7] = registers[3]["eye_angles_y"]
        registers[7] = (registers[7] - registers[4])
        registers[8] = -180
        goto p80
        ::p23::
        tick(23)
        registers[3] = nil
        do
            return registers[3]
        end
        ::p30::
        tick(30)
        registers[5] = nil
        do
            return registers[5]
        end
        ::p50::
        tick(50)
        registers[4] = nil
        do
            return registers[4]
        end
        ::p53::
        tick(53)
        registers[2] = nil
        do
            return registers[2]
        end
        ::p55::
        tick(55)
        if registers[4] ~= registers[0] then
            goto p17
        end
        goto p30
        ::p63::
        tick(63)
        registers[4] = upvalues[2]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        goto p55
        ::p67::
        registers[1] = upvalues[0][32];
        registers[1] = registers[1]()
        if registers[1] ~= registers[0] then
            goto p120
        end
        goto p53
        ::p80::
        registers[9] = (180)
        m, x = pack_returns(registers[6](unpack_range(9, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[5](unpack_range(top, registers, 6))
        end
        ::p109::
        tick(109)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["get_anim_state"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= registers[0] then
            goto p63
        end
        goto p50
        ::p120::
        registers[2] = upvalues[1]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= registers[0] then
            goto p109
        end
        goto p23
    end
end
