-- Recovered function f214; author names are unavailable.
F.f214 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f214")
        tick(1)
        tick(2)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0][161]
        slot_4 = (slot_2 - slot_1);
        slot_3 = slot_3(slot_4)
        slot_3 = slot_3 <= 2
        do
            return slot_3
        end
    end
end
