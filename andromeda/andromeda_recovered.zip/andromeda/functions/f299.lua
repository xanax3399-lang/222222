-- Recovered function f299; author names are unavailable.
F.f299 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f299")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][154]
        slot_3 = slot_1
        goto p30
        ::p9::
        tick(9)
        do
            return slot_3
        end
        ::p28::
        tick(28)
        slot_3 = slot_2
        goto p69
        ::p30::;
        slot_2 = slot_2(slot_3)
        slot_1 = slot_2
        slot_2 = slot_1 + 1
        slot_2 = upvalues[1][slot_2]
        if slot_2 then
            goto p88
        end
        goto p83
        ::p69::
        tick(69)
        if slot_3 then
            goto p9
        end
        slot_3 = nil
        goto p9
        ::p83::
        slot_2 = upvalues[1][slot_1]
        goto p88
        ::p85::
        tick(85)
        slot_3 = (slot_3 == "string")
        if not slot_3 then
            goto p69
        end
        goto p28
        ::p88::
        slot_3 = environment["type"]
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        goto p85
    end
end
