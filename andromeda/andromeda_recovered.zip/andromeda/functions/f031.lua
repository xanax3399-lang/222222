-- Recovered function f31; author names are unavailable.
F.f31 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f31")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_1[1] = 1779033703
        slot_1[2] = 3144134277
        goto p62
        ::p58::
        tick(58)
        slot_1[8] = 1541459225
        slot_2 = slot_1
        do
            return slot_2
        end
        ::p62::
        slot_1[3] = 1013904242
        slot_1[4] = 2773480762
        slot_1[5] = 1359893119
        slot_1[6] = 2600822924
        slot_1[7] = 528734635
        goto p58
    end
end
