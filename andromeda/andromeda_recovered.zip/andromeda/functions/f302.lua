-- Recovered function f302; author names are unavailable.
F.f302 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f302")
        tick(1)
        goto p353
        ::p2::
        tick(2)
        registers[17] = upvalues[2][141]
        registers[18] = registers[1]
        registers[19] = "Force body yaw"
        registers[20] = (true)
        goto p420
        ::p7::
        tick(7)
        registers[14] = (registers[14] ~= registers[0])
        if not registers[14] then
            goto p269
        end
        goto p156
        ::p18::
        tick(18)
        registers[16] = (0)
        if registers[13] ~= "JITTER" then
            goto p40
        end
        goto p121
        ::p21::
        tick(21)
        registers[16] = (58)
        goto p307
        ::p23::
        tick(23)
        registers[22] = registers[22](registers[23], registers[24])
        if registers[21] == registers[22] then
            goto p365
        end
        goto p99
        ::p26::
        tick(26)
        registers[13] = "JITTER[2]"
        goto p127
        ::p31::
        tick(31)
        registers[2] = registers[2][registers[1]]
        registers[3] = upvalues[0]["wraith"]
        registers[3] = registers[3]["prev"]
        registers[3] = registers[3][registers[1]]
        goto p104
        ::p36::
        tick(36)
        registers[6] = upvalues[1]
        registers[7] = registers[1]
        registers[(6)](registers[7])
        goto p204
        ::p40::
        registers[17] = registers[3]["yaw"]
        registers[18] = upvalues[3]
        registers[19] = registers[2]["yaw"]
        registers[19] = (registers[19] - registers[6])
        registers[20] = (180)
        registers[18] = registers[18](registers[19], registers[20])
        if registers[17] == registers[18] then
            goto p321
        end
        goto p372
        ::p49::
        tick(49)
        registers[10] = registers[4]["yaw"]
        registers[9] = (registers[9] - registers[10])
        registers[10] = (180)
        goto p227
        ::p63::
        tick(63)
        registers[27] = registers[4]["yaw"]
        registers[28] = registers[2]["yaw"]
        if registers[27] ~= registers[28] then
            goto p288
        end
        goto p370
        ::p67::
        tick(67)
        registers[10] = upvalues[3]
        registers[11] = registers[3]["yaw"]
        registers[12] = registers[4]["yaw"]
        goto p263
        ::p84::
        tick(84)
        registers[16] = upvalues[1]
        registers[17] = registers[1]
        registers[(16)](registers[17])
        goto p203
        ::p95::
        tick(95)
        registers[17] = upvalues[2][161]
        registers[18] = registers[9];
        registers[(17)] = registers[(17)](registers[18])
        goto p109
        ::p99::
        registers[23] = registers[4]["yaw"]
        registers[24] = registers[2]["yaw"]
        if registers[23] ~= registers[24] then
            goto p288
        end
        goto p365
        ::p103::
        tick(103)
        do
            return 
        end
        ::p104::
        registers[4] = upvalues[0]["wraith"]
        registers[4] = registers[4]["pre_prev"]
        registers[4] = registers[4][registers[1]]
        registers[5] = upvalues[0]["wraith"]
        goto p161
        ::p109::
        branch_taken = false
        if not (not (registers[17] < 15)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p175
        end
        goto p165
        ::p112::
        tick(112)
        if registers[19] == registers[0] then
            goto p2
        end
        goto p167
        ::p114::
        tick(114)
        if registers[13] ~= "JITTER[2]" then
            goto p84
        end
        goto p18
        ::p116::
        tick(116)
        registers[12] = registers[12](registers[13], registers[14])
        registers[13] = nil
        registers[14] = registers[2]["last_shot_time"]
        goto p7
        ::p121::
        if not (0 < registers[7]) then
            goto p225
        end
        goto p239
        ::p125::
        tick(125)
        if not registers[15] then
            goto p256
        end
        goto p311
        ::p127::
        tick(127)
        registers[16] = upvalues[0]["wraith"]
        registers[16] = registers[16]["flags"]
        registers[16][registers[1]] = registers[13]
        registers[16] = registers[2]["pitch"]
        branch_taken = false
        if not (not (78 <= registers[16])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p84
        end
        goto p417
        ::p134::
        tick(134)
        registers[16] = upvalues[2][154]
        registers[17] = upvalues[2][28];
        registers[17] = registers[17]()
        goto p358
        ::p139::
        tick(139)
        registers[12] = upvalues[3]
        registers[13] = registers[5]["yaw"]
        registers[14] = registers[2]["yaw"]
        registers[13] = (registers[13] - registers[14])
        registers[14] = (180)
        goto p116
        ::p145::
        tick(145)
        registers[9] = (180)
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[3]
        registers[9] = registers[2]["yaw"]
        goto p49
        ::p151::
        tick(151)
        registers[6] = upvalues[2][161]
        registers[7] = upvalues[3]
        registers[8] = registers[2]["yaw"]
        registers[9] = registers[3]["yaw"]
        goto p392
        ::p156::
        registers[14] = upvalues[2][26];
        registers[14] = registers[14]()
        registers[15] = registers[2]["last_shot_time"]
        registers[14] = (registers[14] - registers[15])
        goto p269
        ::p161::
        registers[5] = registers[5]["pre_pre_prev"]
        registers[5] = registers[5][registers[1]]
        if registers[2] == registers[0] then
            goto p36
        end
        goto p346
        ::p165::
        registers[13] = "JITTER"
        goto p127
        ::p167::
        registers[17] = upvalues[0]["wraith"]
        registers[17] = registers[17]["miss_side"]
        registers[16] = registers[17][registers[1]]
        goto p2
        ::p171::
        tick(171)
        registers[15] = upvalues[2][28];
        registers[15] = registers[15]()
        registers[15] = (registers[14] / registers[15])
        goto p134
        ::p175::
        tick(175)
        registers[16] = upvalues[2][161]
        registers[17] = registers[7];
        registers[(16)] = registers[(16)](registers[17])
        if 15 < registers[16] then
            goto p26
        end
        goto p278
        ::p180::
        tick(180)
        registers[14] = nil
        goto p222
        ::p191::
        tick(191)
        registers[21] = registers[21] + registers[6]
        registers[22] = (180)
        registers[20] = registers[20](registers[21], registers[22])
        if registers[19] ~= registers[20] then
            goto p288
        end
        goto p321
        ::p196::
        tick(196)
        branch_taken = false
        if registers[13] ~= "JITTER" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p18
        end
        goto p114
        ::p198::
        tick(198)
        registers[16] = upvalues[2][161]
        registers[17] = registers[8];
        registers[(16)] = registers[(16)](registers[17])
        branch_taken = false
        if not (not (registers[16] < 15)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p175
        end
        goto p95
        ::p203::
        do
            return 
        end
        ::p204::
        do
            return 
        end
        ::p222::
        tick(222)
        registers[15] = (registers[14] ~= registers[0])
        if not registers[15] then
            goto p125
        end
        goto p171
        ::p225::
        branch_taken = false
        if not (not (registers[7] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p307
        end
        goto p399
        ::p227::
        registers[8] = registers[8](registers[9], registers[10])
        registers[9] = upvalues[3]
        registers[10] = registers[3]["yaw"]
        goto p301
        ::p231::
        tick(231)
        if registers[4] == registers[0] then
            goto p36
        end
        goto p376
        ::p239::
        registers[16] = (58)
        goto p307
        ::p241::
        tick(241)
        registers[17] = registers[2]["pitch"]
        registers[18] = registers[3]["pitch"]
        if not (registers[17] < registers[18]) then
            goto p256
        end
        goto p271
        ::p252::
        tick(252)
        registers[8] = registers[2]["yaw"]
        registers[9] = registers[3]["yaw"]
        registers[8] = (registers[8] - registers[9])
        goto p145
        ::p256::
        tick(256)
        registers[16] = upvalues[2][161]
        registers[17] = registers[2]["pitch"];
        registers[(16)] = registers[(16)](registers[17])
        if not (60 < registers[16]) then
            goto p127
        end
        goto p407
        ::p263::
        registers[11] = (registers[11] - registers[12])
        registers[12] = (180)
        registers[10] = registers[10](registers[11], registers[12])
        goto p334
        ::p267::
        tick(267)
        if registers[17] then
            goto p282
        end
        goto p351
        ::p269::
        if registers[14] then
            goto p222
        end
        goto p180
        ::p271::
        registers[13] = "ON SHOT"
        goto p127
        ::p278::
        registers[17] = upvalues[2][161]
        registers[18] = registers[10];
        registers[(17)] = registers[(17)](registers[18])
        goto p286
        ::p282::
        tick(282)
        registers[18] = upvalues[2][23];
        registers[18] = registers[18]()
        branch_taken = false
        if not (not (registers[18] <= registers[17])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p2
        end
        goto p297
        ::p286::
        if 15 < registers[17] then
            goto p26
        end
        goto p402
        ::p288::
        registers[17] = registers[2]["yaw"]
        branch_taken = false
        if not (not (registers[17] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p306
        end
        goto p21
        ::p297::
        registers[19] = upvalues[0]["wraith"]
        registers[19] = registers[19]["miss_side"]
        registers[19] = registers[19][registers[1]]
        goto p112
        ::p301::
        registers[11] = registers[5]["yaw"]
        registers[10] = (registers[10] - registers[11])
        registers[11] = (180)
        registers[9] = registers[9](registers[10], registers[11])
        goto p67
        ::p306::
        registers[16] = -58
        ::p307::
        tick(307)
        registers[17] = upvalues[0]["wraith"]
        registers[17] = registers[17]["miss_until"]
        registers[17] = registers[17][registers[1]]
        goto p267
        ::p311::
        registers[16] = upvalues[2][161]
        registers[17] = upvalues[2][161]
        registers[18] = registers[2]["pitch"];
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = upvalues[2][161]
        registers[19] = registers[3]["pitch"];
        registers[(18)] = registers[(18)](registers[19])
        registers[17] = (registers[17] - registers[18]);
        registers[(16)] = registers[(16)](registers[17])
        goto p349
        ::p321::
        registers[21] = registers[4]["yaw"]
        registers[22] = upvalues[3]
        registers[23] = registers[2]["yaw"]
        registers[23] = registers[23] + registers[6]
        registers[24] = (180)
        goto p23
        ::p327::
        tick(327)
        registers[19] = upvalues[2][161]
        registers[20] = registers[12];
        registers[(19)] = registers[(19)](registers[20])
        if not (15 < registers[19]) then
            goto p127
        end
        goto p26
        ::p334::
        registers[11] = upvalues[3]
        registers[12] = registers[4]["yaw"]
        registers[13] = registers[5]["yaw"]
        registers[12] = (registers[12] - registers[13])
        registers[13] = (180)
        registers[11] = registers[11](registers[12], registers[13])
        goto p139
        ::p341::
        tick(341)
        registers[17] = registers[17]["last_value"]
        registers[17][registers[1]] = registers[16]
        registers[17] = upvalues[0]["applied"]
        registers[17][registers[1]] = true
        goto p103
        ::p346::
        if registers[3] == registers[0] then
            goto p36
        end
        goto p231
        ::p349::
        if not (30 < registers[16]) then
            goto p256
        end
        goto p241
        ::p351::
        registers[17] = (0)
        goto p282
        ::p353::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["wraith"]
        registers[2] = registers[2]["cur"]
        goto p31
        ::p358::
        registers[17] = 0.2 / registers[17];
        registers[(16)] = registers[(16)](registers[17])
        registers[15] = (registers[15] <= registers[16])
        goto p125
        ::p365::
        registers[25] = registers[4]["yaw"]
        registers[26] = upvalues[3]
        registers[27] = registers[2]["yaw"]
        registers[27] = registers[27] + registers[6]
        goto p378
        ::p370::
        tick(370)
        registers[16] = (0)
        goto p307
        ::p372::
        registers[19] = registers[3]["yaw"]
        registers[20] = upvalues[3]
        registers[21] = registers[2]["yaw"]
        goto p191
        ::p376::
        if registers[5] ~= registers[0] then
            goto p151
        end
        goto p36
        ::p378::
        registers[28] = (180)
        registers[26] = registers[26](registers[27], registers[28])
        if registers[25] == registers[26] then
            goto p370
        end
        goto p63
        ::p392::
        registers[8] = (registers[8] - registers[9])
        registers[9] = (180)
        m, x = pack_returns(registers[7](unpack_range(9, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[3]
        goto p252
        ::p399::
        registers[16] = -58
        goto p307
        ::p402::
        registers[18] = upvalues[2][161]
        registers[19] = registers[11];
        registers[(18)] = registers[(18)](registers[19])
        if 15 < registers[18] then
            goto p26
        end
        goto p327
        ::p407::
        if not (30 < registers[6]) then
            goto p175
        end
        goto p198
        ::p417::
        registers[17] = registers[3]["pitch"]
        if not (78 < registers[17]) then
            goto p84
        end
        goto p196
        ::p420::
        registers[(17)](unpack_range(20, registers, 18))
        registers[17] = upvalues[2][141]
        registers[18] = registers[1]
        registers[19] = "Force body yaw value"
        registers[20] = registers[16]
        registers[(17)](unpack_range(20, registers, 18))
        registers[17] = upvalues[0]["wraith"]
        goto p341
    end
end
