-- Recovered function f445; author names are unavailable.
F.f445 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f445")
        tick(1)
        goto p34
        ::p3::
        tick(3)
        slot_3 = slot_3 < slot_4
        do
            return slot_3
        end
        ::p15::
        tick(15)
        slot_4 = slot_2["order"]
        if slot_4 then
            goto p3
        end
        goto p22
        ::p20::
        tick(20)
        slot_3 = (0)
        goto p15
        ::p22::
        slot_4 = (0)
        goto p3
        ::p34::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = slot_1["order"]
        if slot_3 then
            goto p15
        end
        goto p20
    end
end
