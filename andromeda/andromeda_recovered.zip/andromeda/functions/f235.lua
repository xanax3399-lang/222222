-- Recovered function f235; author names are unavailable.
F.f235 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f235")
        tick(1)
        goto p113
        ::p10::
        tick(10)
        registers[2] = upvalues[0]["ragebot"]
        registers[2] = registers[2]["double_tap"]
        registers[2] = registers[2][1]
        registers[2] = registers[2]["hotkey"]
        goto p77
        ::p22::
        tick(22)
        registers[2] = upvalues[0]["ragebot"]
        registers[2] = registers[2]["double_tap"]
        registers[2] = registers[2][1]
        registers[2] = registers[2]["hotkey"]
        goto p57
        ::p32::
        tick(32)
        registers[2] = upvalues[0]["is_fake_duck"];
        registers[2] = registers[2]()
        registers[2] = not registers[2]
        goto p116
        ::p43::
        tick(43)
        registers[2] = upvalues[0]["ragebot"]
        registers[2] = registers[2]["double_tap"]
        a = registers
        z = (2)
        q = registers
        q = q[2]
        q = q[(1)]
        a[z] = q
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        goto p74
        ::p53::
        tick(53)
        registers[2] = upvalues[0]["is_fake_duck"];
        registers[2] = registers[2]()
        registers[2] = not registers[2]
        goto p81
        ::p57::
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        if not registers[2] then
            goto p74
        end
        goto p43
        ::p74::
        if not registers[2] then
            goto p81
        end
        goto p53
        ::p77::
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        if not registers[2] then
            goto p116
        end
        goto p32
        ::p81::
        do
            return registers[2]
        end
        ::p113::
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] ~= "key" then
            goto p22
        end
        goto p10
        ::p116::
        do
            return registers[2]
        end
    end
end
