-- Recovered function f3; author names are unavailable.
F.f3 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f3")
        tick(1)
        goto p7
        ::p2::
        tick(2)
        if not (0 < slot_2) then
            goto p85
        end
        goto p94
        ::p4::
        tick(4)
        slot_2 = slot_7 / 2
        slot_3 = (slot_3 * 2)
        goto p15
        ::p7::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p15
        ::p12::
        tick(12)
        slot_4 = slot_4 + slot_3
        goto p55
        ::p15::
        if not (0 < slot_1) then
            goto p85
        end
        goto p2
        ::p17::
        tick(17)
        slot_4 = slot_4 + slot_3
        goto p99
        ::p44::
        tick(44)
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p46::
        tick(46)
        slot_1 = slot_2
        goto p89
        ::p55::
        tick(55)
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 2
        slot_7 = (slot_2 - slot_6)
        goto p4
        ::p85::
        if not (slot_1 < slot_2) then
            goto p89
        end
        goto p46
        ::p89::
        tick(89)
        if not (0 < slot_1) then
            goto p44
        end
        slot_5 = slot_1 % 2
        if not (0 < slot_5) then
            goto p99
        end
        goto p17
        ::p94::
        slot_5 = slot_1 % 2
        slot_6 = slot_2 % 2
        if slot_5 == slot_6 then
            goto p55
        end
        goto p12
        ::p99::
        slot_6 = (slot_1 - slot_5)
        slot_1 = slot_6 / 2
        slot_3 = (slot_3 * 2)
        goto p89
    end
end
