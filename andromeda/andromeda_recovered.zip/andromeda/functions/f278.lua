-- Recovered function f278; author names are unavailable.
F.f278 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f278")
        tick(1)
        goto p37
        ::p2::
        tick(2)
        if not (0 < slot_2) then
            goto p15
        end
        goto p41
        ::p5::
        tick(5)
        slot_7 = slot_7[slot_6]
        slot_7 = slot_7 * slot_3
        slot_4 = slot_4 + slot_7
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 16
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 16
        slot_3 = (slot_3 * 16)
        goto p34
        ::p15::
        tick(15)
        slot_5 = slot_1 * slot_3
        slot_5 = slot_4 + slot_5
        slot_6 = slot_2 * slot_3
        goto p69
        ::p34::
        tick(34)
        if not (0 < slot_1) then
            goto p15
        end
        goto p2
        ::p37::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p34
        ::p41::
        slot_5 = slot_1 % 16
        slot_6 = slot_2 % 16
        slot_7 = upvalues[0][slot_5]
        goto p5
        ::p69::
        slot_5 = slot_5 + slot_6
        do
            return slot_5
        end
    end
end
