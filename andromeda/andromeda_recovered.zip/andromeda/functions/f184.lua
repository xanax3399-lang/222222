-- Recovered function f184; author names are unavailable.
F.f184 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f184")
        tick(1)
        goto p36
        ::p2::
        tick(2)
        registers[18] = (0.92);
        registers[15] = registers[15](unpack_range(18, registers, 16))
        registers[14] = registers[14] * registers[15]
        goto p137
        ::p6::
        tick(6)
        registers[13] = upvalues[2][78]
        registers[14] = registers[1]
        registers[15] = registers[2]["x"]
        registers[16] = registers[2]["y"]
        goto p250
        ::p36::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[1] == registers[0] then
            goto p86
        end
        goto p53
        ::p39::
        tick(39);
        registers[17] = registers[17]()
        registers[17] = registers[17] + 2
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[13] = registers[13](unpack_range(top, registers, 14))
        registers[11] = registers[13]
        goto p226
        ::p45::
        tick(45)
        registers[14] = (registers[12] - registers[2])
        registers[15] = upvalues[4]["clamp"]
        registers[16] = (registers[13] * 0.84)
        registers[17] = (0)
        goto p2
        ::p51::
        tick(51)
        if registers[11] then
            goto p290
        end
        goto p92
        ::p53::
        if registers[2] ~= registers[0] then
            goto p70
        end
        goto p86
        ::p63::
        tick(63)
        registers[14] = environment["type"]
        registers[15] = registers[13];
        registers[(14)] = registers[(14)](registers[15])
        if registers[14] ~= "number" then
            goto p259
        end
        goto p164
        ::p68::
        tick(68)
        registers[5] = registers[2]
        do
            return registers[5]
        end
        ::p70::
        registers[4] = upvalues[0]
        registers[5] = registers[1]
        registers[6] = "m_vecVelocity"
        registers[4] = registers[4](registers[5], registers[6])
        if registers[4] ~= registers[0] then
            goto p128
        end
        goto p68
        ::p76::
        tick(76)
        registers[11] = registers[5]["velocity"]
        registers[11] = (registers[4] - registers[11])
        registers[9] = (registers[11] / registers[10])
        goto p168
        ::p80::
        tick(80)
        registers[7] = registers[7]["get_simtime"]
        registers[8] = registers[1]
        m, x = pack_returns(registers[7](unpack_range(8, registers, 8)))
        z = 0
        for f = 7, 8 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = nil
        goto p147
        ::p86::
        registers[4] = registers[2]
        do
            return registers[4]
        end
        ::p89::
        tick(89)
        registers[5]["simtime"] = registers[7]
        if registers[12] == registers[0] then
            goto p206
        end
        goto p241
        ::p92::
        registers[11] = (800)
        goto p290
        ::p94::
        tick(94)
        if not (0 < registers[6]) then
            goto p226
        end
        goto p219
        ::p96::
        tick(96)
        registers[11] = registers[3]
        registers[12] = environment["type"]
        registers[13] = registers[7]
        goto p350
        ::p101::
        tick(101)
        registers[13] = registers[5]["simtime"]
        if not (registers[13] < registers[7]) then
            goto p168
        end
        registers[10] = registers[5]["simtime"]
        registers[10] = (registers[7] - registers[10])
        if not (0 < registers[10]) then
            goto p168
        end
        goto p269
        ::p119::
        tick(119)
        registers[13] = (1)
        registers[11] = registers[11](registers[12], registers[13])
        if registers[11] ~= 0 then
            goto p96
        end
        goto p195
        ::p123::
        tick(123)
        registers[14] = environment["type"]
        registers[15] = registers[6];
        registers[(14)] = registers[(14)](registers[15])
        if registers[14] ~= "number" then
            goto p226
        end
        goto p94
        ::p128::
        registers[5] = upvalues[1]["player_state"]
        registers[5] = registers[5][registers[1]]
        if registers[5] ~= registers[0] then
            goto p160
        end
        goto p277
        ::p132::
        tick(132)
        registers[13] = environment["type"]
        registers[14] = registers[8];
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "number" then
            goto p226
        end
        goto p123
        ::p137::
        registers[14] = registers[2] + registers[14]
        do
            return registers[14]
        end
        ::p147::
        registers[10] = registers[5]["velocity"]
        if registers[10] == registers[0] then
            goto p168
        end
        goto p303
        ::p160::
        tick(160)
        registers[6] = upvalues[2][28];
        registers[6] = registers[6]()
        registers[7] = environment["entity"]
        goto p80
        ::p164::
        if not (registers[13] <= 0.99) then
            goto p259
        end
        goto p208
        ::p168::
        tick(168)
        registers[10] = upvalues[2][47]
        registers[11] = registers[1]
        registers[12] = "m_fFlags"
        registers[10] = registers[10](registers[11], registers[12])
        if registers[10] then
            goto p286
        end
        goto p243
        ::p184::
        tick(184)
        registers[17] = registers[9];
        registers[12] = registers[12](unpack_range(17, registers, 13))
        registers[5]["origin"] = registers[2]
        goto p89
        ::p189::
        tick(189)
        if not registers[11] then
            goto p51
        end
        goto p200
        ::p191::
        tick(191)
        registers[12] = upvalues[3]
        registers[13] = registers[9]["x"]
        registers[14] = registers[9]["y"]
        goto p210
        ::p195::
        registers[12] = environment["type"]
        registers[13] = registers[6];
        registers[(12)] = registers[(12)](registers[13])
        if registers[12] ~= "number" then
            goto p96
        end
        goto p294
        ::p200::
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["sv_gravity"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get_float"];
        registers[(11)] = registers[(11)](registers[12])
        goto p51
        ::p206::
        tick(206)
        registers[13] = registers[12]
        do
            return registers[13]
        end
        ::p208::
        if not (0.18 < registers[13]) then
            goto p292
        end
        goto p45
        ::p210::
        registers[15] = registers[9]["z"]
        registers[16] = (registers[11] * 0.35)
        registers[15] = (registers[15] - registers[16]);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p328
        ::p215::
        tick(215)
        registers[13] = upvalues[2][151]
        registers[14] = registers[11]
        if registers[14] then
            goto p296
        end
        goto p300
        ::p219::
        registers[12] = upvalues[4]["clamp"]
        registers[13] = upvalues[2][154]
        registers[14] = (registers[7] - registers[8])
        registers[14] = (registers[14] / registers[6])
        registers[14] = registers[14] + 0.5;
        registers[(13)] = registers[(13)](registers[14])
        goto p324
        ::p226::
        tick(226)
        registers[12] = upvalues[1]["predict_vector"]
        registers[13] = registers[2]
        registers[14] = registers[4]
        registers[15] = registers[11]
        registers[16] = registers[1]
        goto p184
        ::p241::
        if registers[12] ~= registers[2] then
            goto p6
        end
        goto p206
        ::p243::
        registers[10] = (0)
        goto p286
        ::p245::
        tick(245)
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["sv_gravity"]
        registers[11] = (registers[11] ~= registers[0])
        goto p189
        ::p250::
        registers[17] = registers[2]["z"]
        registers[18] = registers[12]["x"]
        registers[19] = registers[12]["y"]
        registers[20] = registers[12]["z"];
        registers[13] = registers[13](unpack_range(20, registers, 14))
        goto p63
        ::p257::
        tick(257)
        if not (1 < registers[12]) then
            goto p226
        end
        goto p215
        ::p259::
        registers[14] = registers[12]
        do
            return registers[14]
        end
        ::p269::
        branch_taken = false
        if not (not (registers[10] < 0.35)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p168
        end
        goto p76
        ::p271::
        tick(271)
        registers[12] = upvalues[3]
        registers[13] = (0)
        registers[14] = (0)
        registers[15] = -registers[11]
        registers[15] = (registers[15] * 0.45)
        goto p283
        ::p277::
        registers[6] = {
        }
        registers[6]["velocity"] = registers[0]
        registers[6]["simtime"] = registers[0]
        goto p316
        ::p283::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[9] = registers[12]
        goto p96
        ::p286::
        registers[11] = environment["bit"]
        registers[11] = registers[11]["band"]
        registers[12] = registers[10]
        goto p119
        ::p290::
        if registers[9] ~= registers[0] then
            goto p191
        end
        goto p271
        ::p292::
        registers[14] = registers[2]
        do
            return registers[14]
        end
        ::p294::
        if not (0 < registers[6]) then
            goto p96
        end
        goto p245
        ::p296::
        tick(296)
        registers[15] = upvalues[2][162]
        registers[16] = registers[12] + 1
        registers[17] = upvalues[1]["get_ticks"]
        goto p39
        ::p300::
        registers[14] = (0)
        goto p296
        ::p303::
        registers[11] = registers[5]["simtime"]
        if registers[11] == registers[0] then
            goto p168
        end
        goto p338
        ::p310::
        tick(310)
        registers[5] = registers[6]
        registers[6] = upvalues[1]["player_state"]
        registers[6][registers[1]] = registers[5]
        goto p160
        ::p316::
        registers[6]["origin"] = registers[0]
        registers[6]["penalty_until"] = 0
        registers[6]["boost_until"] = 0
        registers[6]["stable_ticks"] = 0
        registers[6]["hit_streak"] = 0
        registers[6]["miss_streak"] = 0
        goto p310
        ::p324::
        registers[14] = (0)
        registers[15] = (7);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p257
        ::p328::
        registers[9] = registers[12]
        goto p96
        ::p338::
        registers[12] = environment["type"]
        registers[13] = registers[7];
        registers[(12)] = registers[(12)](registers[13])
        if registers[12] ~= "number" then
            goto p168
        end
        goto p101
        ::p350::;
        registers[(12)] = registers[(12)](registers[13])
        if registers[12] ~= "number" then
            goto p226
        end
        goto p132
    end
end
