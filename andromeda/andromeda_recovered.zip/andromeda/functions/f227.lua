-- Recovered function f227; author names are unavailable.
F.f227 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f227")
        tick(1)
        goto p103
        ::p2::
        tick(2)
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        goto p31
        ::p6::
        tick(6)
        do
            return 
        end
        ::p7::
        tick(7)
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p6
        end
        goto p54
        ::p10::
        tick(10)
        do
            return 
        end
        ::p11::
        tick(11)
        registers[2] = upvalues[0]["reset"]
        registers[(2)]()
        goto p10
        ::p31::
        registers[3] = "player_connect_full"
        registers[4] = upvalues[0]["player_connect_full"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[2]
        registers[(2)]()
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p10
        end
        goto p11
        ::p39::
        tick(39)
        registers[4] = upvalues[0]["reset"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "level_init"
        registers[4] = upvalues[0]["reset"]
        goto p2
        ::p46::
        tick(46)
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "post_render"
        registers[4] = upvalues[0]["post_render"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        goto p58
        ::p54::
        registers[2] = upvalues[0]["reset"]
        registers[(2)]()
        goto p6
        ::p58::
        registers[3] = "pre_render"
        registers[4] = upvalues[0]["pre_render"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "aim_miss"
        registers[4] = upvalues[0]["aim_miss"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        goto p108
        ::p87::
        tick(87)
        upvalues[0]["active"] = registers[1]
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "net_update_end"
        registers[4] = upvalues[0]["net_update_end"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        goto p46
        ::p103::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[1] = (registers[1] == true)
        registers[2] = upvalues[0]["active"]
        if registers[2] ~= registers[1] then
            goto p87
        end
        goto p7
        ::p108::
        registers[3] = "aim_hit"
        registers[4] = upvalues[0]["aim_hit"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "round_start"
        goto p39
    end
end
