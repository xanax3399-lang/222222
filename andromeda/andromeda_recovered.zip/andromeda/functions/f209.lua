-- Recovered function f209; author names are unavailable.
F.f209 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f209")
        tick(1)
        goto p55
        ::p3::
        tick(3)
        branch_taken = false
        if not (not (registers[1] < 100)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p80
        end
        goto p86
        ::p11::
        tick(11)
        registers[5] = (51)
        registers[6] = (255)
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        goto p54
        ::p17::
        tick(17)
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        do
            return registers[2]
        end
        ::p26::
        tick(26)
        registers[2] = new_frame(4)
        registers[3] = (146)
        registers[4] = (183)
        goto p11
        ::p54::
        do
            return registers[2]
        end
        ::p55::
        registers[1] = upvalues[0][151]
        registers[2] = (0)
        registers[3] = upvalues[0][154]
        registers[4] = upvalues[0][67];
        registers[4] = registers[4]()
        registers[4] = (registers[4] * 1000)
        registers[4] = registers[4] + 0.5
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[1] = registers[1](unpack_range(top, registers, 2))
        branch_taken = false
        if not (not (registers[1] < 40)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p3
        end
        goto p26
        ::p76::
        tick(76)
        registers[6] = (255)
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        do
            return registers[2]
        end
        ::p80::
        registers[2] = new_frame(4)
        registers[3] = (139)
        registers[4] = (31)
        registers[5] = (31)
        registers[6] = (255)
        goto p17
        ::p86::
        registers[2] = new_frame(4)
        registers[3] = (183)
        registers[4] = (121)
        registers[5] = (51)
        goto p76
    end
end
