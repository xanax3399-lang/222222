-- Recovered function f366; author names are unavailable.
F.f366 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f366")
        tick(1)
        goto p37
        ::p2::
        tick(2)
        registers[8] = upvalues[3][registers[8]]
        if registers[8] then
            goto p50
        end
        goto p86
        ::p6::
        tick(6)
        registers[7] = registers[1];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = registers[3]
        a = upvalues[4];
        registers[8] = a[2][a[1]]["current"]
        goto p2
        ::p11::
        tick(11)
        registers[4] = upvalues[1]
        registers[5] = upvalues[2][161]
        registers[6] = registers[1];
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = -registers[5]
        registers[6] = upvalues[2][161]
        goto p6
        ::p32::
        tick(32)
        registers[9] = (1)
        goto p43
        ::p37::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0]["randomize"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        if not (registers[3] <= 0) then
            goto p11
        end
        goto p88
        ::p43::
        tick(43)
        registers[8] = registers[8] + registers[9]
        registers[9] = upvalues[5];
        registers[4] = registers[4](unpack_range(9, registers, 5))
        registers[5] = upvalues[6]["clamp"]
        registers[6] = registers[1] + registers[4]
        goto p90
        ::p50::
        tick(50)
        registers[9] = registers[2]
        if registers[9] then
            goto p43
        end
        goto p32
        ::p86::
        registers[8] = (1)
        goto p50
        ::p88::
        registers[4] = registers[1]
        do
            return registers[4]
        end
        ::p90::
        registers[7] = -180
        registers[8] = (180)
        do
            return registers[(5)](unpack_range(8, registers, 6))
        end
    end
end
