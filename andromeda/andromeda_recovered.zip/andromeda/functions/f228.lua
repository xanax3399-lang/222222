-- Recovered function f228; author names are unavailable.
F.f228 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_13, slot_14, slot_15 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f228")
        tick(1)
        goto p84
        ::p2::
        tick(2)
        slot_11 = -1
        goto p35
        ::p4::
        tick(4)
        if slot_12 then
            goto p111
        end
        goto p10
        ::p6::
        tick(6)
        slot_14 = (slot_14 - slot_15)
        slot_14 = slot_14 * slot_12
        slot_13 = slot_13 + slot_14
        goto p162
        ::p10::
        slot_12 = (1)
        goto p111
        ::p12::
        tick(12)
        slot_8 = (0)
        goto p120
        ::p15::
        tick(15)
        slot_1["initialized"] = true
        slot_11 = upvalues[1]["random_int"]
        slot_12 = slot_7
        slot_13 = slot_8
        goto p171
        ::p21::
        tick(21)
        slot_8 = slot_3
        if slot_8 then
            goto p120
        end
        goto p12
        ::p31::
        tick(31)
        slot_9 = (0)
        goto p44
        ::p33::
        tick(33)
        if not slot_12 then
            goto p4
        end
        goto p141
        ::p35::
        tick(35)
        if slot_11 then
            goto p194
        end
        goto p175
        ::p38::
        tick(38)
        slot_12 = (0)
        slot_13 = (1)
        slot_11 = slot_11(slot_12, slot_13)
        slot_11 = (slot_11 == 0)
        if not slot_11 then
            goto p35
        end
        goto p2
        ::p44::
        tick(44)
        slot_10 = upvalues[0][151]
        slot_11 = slot_5
        if slot_11 then
            goto p177
        end
        goto p192
        ::p57::
        tick(57)
        slot_11 = slot_1["initialized"]
        if slot_11 then
            goto p219
        end
        goto p15
        ::p84::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = a[4]
        slot_5 = a[5]
        slot_6 = upvalues[0][30];
        slot_6 = slot_6()
        goto p181
        ::p88::
        tick(88)
        slot_12 = upvalues[0][162]
        slot_13 = (slot_11 / slot_10)
        slot_14 = (1)
        goto p208
        ::p111::
        slot_1["spin_dir"] = slot_12
        slot_12 = slot_1["base_yaw"]
        slot_13 = slot_1["spin_dir"]
        goto p200
        ::p120::
        slot_9 = slot_4
        if slot_9 then
            goto p44
        end
        goto p31
        ::p129::
        tick(129)
        slot_12 = upvalues[1]["random_int"]
        slot_13 = slot_7
        slot_14 = slot_8
        slot_12 = slot_12(slot_13, slot_14)
        slot_1["base_yaw"] = slot_12
        slot_12 = upvalues[1]["random_int"]
        slot_13 = (0)
        goto p223
        ::p137::
        tick(137)
        slot_11 = slot_11 + slot_12
        slot_1["target_yaw"] = slot_11
        slot_1["start_time"] = slot_6
        goto p219
        ::p141::
        slot_12 = -1
        goto p4
        ::p160::
        tick(160)
        slot_7 = (0)
        goto p21
        ::p162::
        do
            return slot_13
        end
        ::p171::
        slot_11 = slot_11(slot_12, slot_13)
        slot_1["base_yaw"] = slot_11
        slot_11 = upvalues[1]["random_int"]
        goto p38
        ::p175::
        slot_11 = (1)
        goto p194
        ::p177::
        tick(177)
        slot_11 = slot_11 / 10
        slot_12 = (0.01)
        slot_10 = slot_10(slot_11, slot_12)
        goto p57
        ::p181::
        slot_7 = slot_2
        if slot_7 then
            goto p21
        end
        goto p160
        ::p192::
        slot_11 = (1)
        goto p177
        ::p194::
        slot_1["spin_dir"] = slot_11
        slot_11 = slot_1["base_yaw"]
        slot_12 = slot_1["spin_dir"]
        slot_12 = slot_9 * slot_12
        goto p137
        ::p200::
        slot_13 = slot_9 * slot_13
        slot_12 = slot_12 + slot_13
        slot_1["target_yaw"] = slot_12
        slot_1["start_time"] = slot_6
        slot_11 = (0)
        goto p88
        ::p208::
        slot_12 = slot_12(slot_13, slot_14)
        slot_13 = slot_1["base_yaw"]
        slot_14 = slot_1["target_yaw"]
        slot_15 = slot_1["base_yaw"]
        goto p6
        ::p219::
        slot_11 = slot_1["start_time"]
        slot_11 = (slot_6 - slot_11)
        branch_taken = false
        if not (not (slot_10 <= slot_11)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p88
        end
        goto p129
        ::p223::
        slot_14 = (1)
        slot_12 = slot_12(slot_13, slot_14)
        slot_12 = (slot_12 == 0)
        goto p33
    end
end
