-- Recovered function f134; author names are unavailable.
F.f134 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f134")
        tick(1)
        slot_1 = upvalues[0][32];
        slot_1 = slot_1()
        if slot_1 then
            goto p6
        end
        goto p12
        ::p6::
        slot_2 = upvalues[0][47]
        slot_3 = slot_1
        slot_4 = "m_fFlags"
        slot_2 = slot_2(slot_3, slot_4)
        a = upvalues[1]
        a[2][a[1]] = slot_2
        do
            return 
        end
        ::p12::
        do
            return 
        end
    end
end
