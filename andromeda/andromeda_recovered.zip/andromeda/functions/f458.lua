-- Recovered function f458; author names are unavailable.
F.f458 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f458")
        tick(1)
        goto p78
        ::p20::
        tick(20)
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p29::
        tick(29)
        registers[2] = upvalues[1]["ragebot"]
        registers[2] = registers[2]["overpredict"]
        goto p60
        ::p53::
        tick(53)
        registers[2] = upvalues[2]["clamp"]
        registers[3] = (registers[1] * 0.01)
        a = registers
        z = 4;
        a[z] = 1
        goto p88
        ::p60::
        tick(60)
        registers[3] = (125)
        registers[1] = registers[1](registers[2], registers[3])
        if not (registers[1] <= 0) then
            goto p53
        end
        goto p20
        ::p78::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]["ragebot"]
        if not registers[2] then
            goto p60
        end
        goto p29
        ::p88::
        registers[5] = (2)
        do
            return registers[(2)](unpack_range(5, registers, 3))
        end
    end
end
