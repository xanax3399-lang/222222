-- Recovered function f371; author names are unavailable.
F.f371 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f371")
        tick(1)
        goto p17
        ::p2::
        tick(2)
        slot_1 = upvalues[1]["update_callbacks"]
        slot_2 = (false)
        slot_1(slot_2)
        do
            return 
        end
        ::p17::
        slot_1 = upvalues[0]["skip_native_cleanup"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p2
        end
        do
            return 
        end
    end
end
