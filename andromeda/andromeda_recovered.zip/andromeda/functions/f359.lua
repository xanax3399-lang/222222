-- Recovered function f359; author names are unavailable.
F.f359 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f359")
        tick(1)
        goto p48
        ::p3::
        tick(3)
        registers[1] = upvalues[1][151]
        registers[2] = (2)
        registers[3] = upvalues[1][162]
        goto p42
        ::p9::
        tick(9)
        a = upvalues[0];
        registers[1] = a[2][a[1]]
        if registers[1] ~= "Custom" then
            goto p72
        end
        goto p3
        ::p42::
        registers[4] = (10)
        registers[5] = upvalues[1][154]
        registers[6] = upvalues[2]["custom"]
        goto p66
        ::p46::
        tick(46)
        registers[1] = (2)
        do
            return registers[1]
        end
        ::p48::
        a = upvalues[0];
        registers[1] = a[2][a[1]]
        if registers[1] ~= "Double" then
            goto p9
        end
        goto p46
        ::p66::
        registers[6] = registers[6]["count"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[5](unpack_range(top, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[3](unpack_range(top, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p72::
        registers[1] = (1)
        do
            return registers[1]
        end
    end
end
