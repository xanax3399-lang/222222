-- Recovered function f363; author names are unavailable.
F.f363 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8 = nil, nil, nil, nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f363")
        tick(1)
        goto p135
        ::p2::
        tick(2)
        slot_7 = slot_1["body_yaw"]
        slot_7 = slot_7["inverter"]
        if slot_7 then
            goto p31
        end
        goto p216
        ::p31::
        tick(31)
        slot_7 = slot_1["body_yaw"]
        slot_7["value"] = slot_6
        slot_7 = slot_1["yaw"]
        slot_7["body"] = 0
        goto p183
        ::p50::
        tick(50)
        if slot_7 ~= "Hidden" then
            goto p88
        end
        goto p178
        ::p53::
        tick(53)
        slot_6 = slot_1["body_yaw"]
        slot_6["type"] = "Static"
        slot_6 = slot_1["body_yaw"]
        slot_7 = slot_4["value"]
        goto p79
        ::p66::
        tick(66)
        slot_6["body"] = 0
        do
            return 
        end
        ::p68::
        tick(68)
        slot_6 = slot_4["value"]
        z = slot_6
        slot_7 = z;
        slot_6 = z["get"];
        slot_6 = slot_6(slot_7)
        slot_7 = slot_1["body_yaw"]
        slot_7["type"] = "Static"
        goto p131
        ::p74::
        tick(74)
        slot_6 = slot_4["type"]
        z = slot_6
        slot_7 = z;
        slot_6 = z["get"];
        slot_6 = slot_6(slot_7)
        if slot_6 ~= "Opposite" then
            goto p94
        end
        goto p123
        ::p79::
        z = slot_7
        slot_8 = z;
        slot_7 = z["get"];
        slot_7 = slot_7(slot_8)
        slot_6["value"] = slot_7
        goto p156
        ::p83::
        tick(83)
        slot_6 = slot_1["body_yaw"]
        slot_6["freestanding"] = false
        slot_6 = slot_1["yaw"]
        slot_6["body"] = 0
        goto p177
        ::p88::
        tick(88)
        slot_6 = slot_4["type"]
        z = slot_6
        slot_7 = z;
        slot_6 = z["get"];
        slot_6 = slot_6(slot_7)
        if slot_6 ~= "Off" then
            goto p186
        end
        goto p170
        ::p94::
        slot_6 = slot_4["type"]
        z = slot_6
        slot_7 = z;
        slot_6 = z["get"];
        slot_6 = slot_6(slot_7)
        goto p213
        ::p113::
        tick(113)
        if slot_6 == slot_0 then
            goto p88
        end
        goto p144
        ::p115::
        tick(115)
        slot_6 = -1
        goto p2
        ::p123::
        slot_6 = slot_1["body_yaw"]
        slot_6["type"] = "Opposite"
        slot_6 = slot_1["body_yaw"]
        slot_6["value"] = 0
        slot_6 = slot_1["body_yaw"]
        slot_6["freestanding"] = true
        slot_6 = slot_1["yaw"]
        goto p142
        ::p131::
        slot_7 = slot_1["body_yaw"]
        slot_7["freestanding"] = false
        if slot_6 ~= 0 then
            goto p2
        end
        goto p115
        ::p135::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = slot_3["body_yaw"]
        slot_5 = slot_3["yaw"]
        slot_6 = upvalues[0][32]
        slot_6()
        slot_6 = slot_4["builder_type"]
        goto p113
        ::p142::
        slot_6["body"] = 0
        do
            return 
        end
        ::p144::
        slot_7 = slot_4["builder_type"]
        z = slot_7
        slot_8 = z;
        slot_7 = z["get"];
        slot_7 = slot_7(slot_8)
        goto p50
        ::p149::
        tick(149)
        if slot_6 ~= "Static" then
            goto p74
        end
        goto p53
        ::p152::
        tick(152)
        slot_6["freestanding"] = false
        slot_6 = slot_1["yaw"]
        slot_6["body"] = 0
        do
            return 
        end
        ::p156::
        slot_6 = slot_1["body_yaw"]
        slot_6["freestanding"] = false
        slot_6 = slot_1["yaw"]
        goto p66
        ::p161::
        tick(161)
        do
            return 
        end
        ::p170::
        slot_6 = slot_1["body_yaw"]
        slot_6["type"] = "Off"
        slot_6 = slot_1["body_yaw"]
        slot_6["value"] = 0
        slot_6 = slot_1["body_yaw"]
        goto p152
        ::p177::
        do
            return 
        end
        ::p178::
        slot_6 = slot_1["body_yaw"]
        slot_6["type"] = "Off"
        slot_6 = slot_1["body_yaw"]
        slot_6["value"] = 0
        goto p83
        ::p183::
        tick(183)
        do
            return 
        end
        ::p186::
        slot_6 = slot_4["type"]
        z = slot_6
        slot_7 = z;
        slot_6 = z["get"];
        slot_6 = slot_6(slot_7)
        goto p149
        ::p213::
        if slot_6 ~= "Jitter" then
            goto p161
        end
        goto p68
        ::p216::
        slot_6 = -slot_6
        goto p31
    end
end
