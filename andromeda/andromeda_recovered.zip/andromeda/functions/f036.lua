-- Recovered function f36; author names are unavailable.
F.f36 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f36")
        tick(1)
        goto p90
        ::p2::
        tick(2)
        registers[9] = (4)
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[2]
        goto p160
        ::p39::
        tick(39)
        registers[5] = upvalues[2]
        registers[6] = registers[2][2]
        registers[7] = (4)
        goto p121
        ::p57::
        tick(57)
        registers[2] = upvalues[0]["initH256"]
        registers[3] = {
        };
        registers[(2)] = registers[(2)](registers[3])
        goto p154
        ::p73::
        tick(73)
        registers[7] = upvalues[0]["digestblock"]
        a = registers
        z = 8
        q = registers
        q = q[1]
        a[z] = q
        registers[9] = registers[6]
        registers[10] = registers[2]
        registers[(7)](unpack_range(10, registers, 8))
        goto p99
        ::p90::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["preproc"]
        registers[3] = registers[1]
        registers[4] = (#registers[1])
        registers[2] = registers[2](registers[3], registers[4])
        a = registers
        z = 1
        q = registers
        q = q[2]
        a[z] = q
        goto p57
        ::p99::
        tick(99)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p73
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[3] = upvalues[1]
        registers[4] = upvalues[2]
        goto p150
        ::p106::
        tick(106)
        registers[10] = registers[2][6]
        registers[11] = (4)
        registers[9] = registers[9](registers[10], registers[11])
        a = registers
        z = 10
        q = upvalues
        q = q[2]
        a[z] = q
        registers[11] = registers[2][7]
        registers[12] = (4)
        registers[10] = registers[10](registers[11], registers[12])
        registers[11] = upvalues[2]
        goto p135
        ::p121::
        registers[5] = registers[5](registers[6], registers[7])
        registers[6] = upvalues[2]
        registers[7] = registers[2][3]
        a = registers
        z = 8;
        a[z] = 4
        goto p146
        ::p135::
        registers[12] = registers[2][8]
        registers[13] = (4)
        registers[11] = registers[11](registers[12], registers[13])
        registers[10] = (registers[10]..registers[11])
        registers[9] = (registers[9]..registers[10])
        registers[8] = (registers[8]..registers[9])
        registers[7] = (registers[7]..registers[8])
        registers[6] = (registers[6]..registers[7])
        registers[5] = (registers[5]..registers[6])
        registers[4] = (registers[4]..registers[5])
        do
            return registers[(3)](registers[4])
        end
        ::p146::
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[2]
        registers[8] = registers[2][4]
        goto p2
        ::p150::
        registers[5] = registers[2][1]
        registers[6] = (4)
        registers[4] = registers[4](registers[5], registers[6])
        goto p39
        ::p154::
        registers[3] = (1)
        registers[4] = (#registers[1])
        registers[5] = (64)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p99
        goto p106
        ::p160::
        registers[9] = registers[2][5]
        registers[10] = (4)
        registers[8] = registers[8](registers[9], registers[10])
        registers[9] = upvalues[2]
        goto p106
    end
end
