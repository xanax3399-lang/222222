-- Recovered function f255; author names are unavailable.
F.f255 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f255")
        tick(1)
        goto p117
        ::p2::
        tick(2);
        registers[(9)] = registers[(9)](registers[10])
        registers[10] = registers[8]
        do
            return unpack_range(10, registers, (9))
        end
        ::p18::
        tick(18)
        if registers[3] ~= "Bottom Left" then
            goto p55
        end
        goto p40
        ::p29::
        tick(29)
        registers[10] = (registers[10] - registers[8])
        do
            return unpack_range(10, registers, (9))
        end
        ::p40::
        registers[9] = registers[7]
        registers[10] = (registers[6] - registers[2])
        registers[10] = (registers[10] - registers[8])
        do
            return unpack_range(10, registers, (9))
        end
        ::p55::
        if registers[3] ~= "Bottom Center" then
            goto p58
        end
        goto p140
        ::p58::
        if registers[3] ~= "Bottom Right" then
            goto p113
        end
        goto p109
        ::p63::
        tick(63)
        registers[9] = upvalues[0][154]
        registers[10] = (registers[5] - registers[1])
        registers[10] = (registers[10] * 0.5)
        registers[10] = registers[10] + 0.5
        goto p2
        ::p75::
        tick(75)
        registers[10] = (registers[6] - registers[2])
        registers[10] = (registers[10] - registers[8])
        do
            return unpack_range(10, registers, (9))
        end
        ::p87::
        tick(87)
        if registers[3] ~= "Top Center" then
            goto p18
        end
        goto p63
        ::p89::
        tick(89)
        registers[9] = registers[7]
        registers[10] = registers[8]
        do
            return unpack_range(10, registers, (9))
        end
        ::p109::
        registers[9] = (registers[5] - registers[1])
        registers[9] = (registers[9] - registers[7])
        registers[10] = (registers[6] - registers[2])
        goto p29
        ::p113::
        registers[9] = (registers[5] - registers[1])
        registers[9] = (registers[9] - registers[7])
        registers[10] = registers[8]
        do
            return unpack_range(10, registers, (9))
        end
        ::p117::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = upvalues[0][57]
        m, x = pack_returns(registers[5]())
        z = 0
        for f = 5, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = upvalues[0][151]
        registers[8] = (3)
        registers[9] = upvalues[0][154]
        registers[10] = 5 * registers[4]
        registers[10] = registers[10] + 0.5
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[8] = upvalues[0][151]
        registers[9] = (3)
        registers[10] = upvalues[0][154]
        registers[11] = 5 * registers[4]
        registers[11] = registers[11] + 0.5
        m, x = pack_returns(registers[10](unpack_range(11, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        if registers[3] ~= "Top Left" then
            goto p87
        end
        goto p89
        ::p140::
        registers[9] = upvalues[0][154]
        registers[10] = (registers[5] - registers[1])
        registers[10] = (registers[10] * 0.5)
        registers[10] = registers[10] + 0.5;
        registers[(9)] = registers[(9)](registers[10])
        goto p75
    end
end
