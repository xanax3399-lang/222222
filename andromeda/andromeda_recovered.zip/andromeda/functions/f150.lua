-- Recovered function f150; author names are unavailable.
F.f150 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local tick = new_tick("f150")
        tick(1)
        goto p4
        ::p2::
        tick(2)
        if not registers[11] then
            goto p113
        end
        goto p183
        ::p4::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[1]["safehead_active"] = false
        a = D.f151
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[3] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p141
        ::p8::
        tick(8)
        if not registers[13] then
            goto p113
        end
        goto p2
        ::p30::
        tick(30)
        registers[13] = upvalues[2];
        registers[13] = registers[13]()
        if registers[13] then
            goto p62
        end
        goto p179
        ::p36::
        tick(36)
        if not registers[7] then
            goto p8
        end
        goto p196
        ::p38::
        tick(38)
        registers[6] = upvalues[0][45]
        registers[7] = registers[5];
        registers[(6)] = registers[(6)](registers[7])
        if registers[6] then
            goto p117
        end
        registers[6] = ""
        goto p117
        ::p57::
        tick(57)
        registers[14] = registers[3]
        registers[15] = (false)
        registers[(14)](registers[15])
        registers[14] = (true)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[14]
        end
        ::p62::
        tick(62)
        registers[13] = (false)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[13]
        end
        ::p67::
        tick(67)
        registers[12] = "Knife"
        registers[10] = registers[10](registers[11], registers[12])
        z = registers[9]
        registers[12] = z;
        registers[(11)] = z["get"]
        registers[13] = "Zeus"
        registers[11] = registers[11](registers[12], registers[13])
        registers[12] = (registers[2] == "Move")
        if registers[12] then
            goto p62
        end
        goto p30
        ::p92::
        tick(92)
        registers[13] = (registers[2] == "Air-crouch")
        if not registers[13] then
            goto p8
        end
        goto p115
        ::p95::
        tick(95)
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p130
        end
        goto p128
        ::p109::
        tick(109)
        registers[18] = (0)
        registers[(14)](unpack_range(18, registers, 15))
        registers[14] = (true)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[14]
        end
        ::p113::
        tick(113)
        registers[14] = (false)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[14]
        end
        ::p115::
        if not registers[10] then
            goto p8
        end
        goto p36
        ::p117::
        registers[7] = environment["string"]
        registers[7] = registers[7]["find"]
        registers[8] = registers[6]
        registers[9] = "Knife"
        registers[10] = (1)
        registers[11] = (true);
        registers[7] = registers[7](unpack_range(11, registers, 8))
        registers[7] = (registers[7] ~= registers[0])
        registers[8] = (registers[6] == "CWeaponTaser")
        goto p202
        ::p128::
        tick(128)
        registers[5] = (false)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[5]
        end
        ::p130::
        registers[5] = upvalues[0][37]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p38
        end
        goto p185
        ::p136::
        tick(136)
        registers[5] = upvalues[1]["antiaim"]
        registers[5] = registers[5]["features"]
        registers[5] = registers[5]["safe_head"]
        registers[5] = registers[5]["enabled"]
        goto p95
        ::p141::
        registers[4] = upvalues[0][32];
        registers[4] = registers[4]()
        if registers[4] == registers[0] then
            goto p128
        end
        goto p190
        ::p179::
        a = upvalues[3];
        registers[13] = a[2][a[1]]["manual"]
        if registers[13] == registers[0] then
            goto p92
        end
        goto p62
        ::p183::
        if not registers[8] then
            goto p113
        end
        goto p57
        ::p185::
        registers[6] = (false)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[6]
        end
        ::p187::
        tick(187)
        if not registers[5] then
            goto p128
        end
        goto p136
        ::p190::
        registers[5] = upvalues[0][50]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        goto p187
        ::p196::
        registers[14] = registers[3]
        registers[15] = (false)
        registers[16] = (0)
        registers[17] = "Static"
        goto p109
        ::p202::
        registers[9] = upvalues[1]["antiaim"]
        registers[9] = registers[9]["features"]
        registers[9] = registers[9]["safe_head"]
        registers[9] = registers[9]["states"]
        z = registers[9]
        registers[11] = z;
        registers[(10)] = z["get"]
        goto p67
    end
end
