-- Recovered function f484; author names are unavailable.
F.f484 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f484")
        tick(1)
        goto p27
        ::p3::
        tick(3)
        registers[9] = upvalues[8]
        if registers[9] == registers[0] then
            goto p134
        end
        goto p142
        ::p6::
        tick(6)
        registers[12] = upvalues[6]
        registers[13] = (0)
        m, x = pack_returns(registers[11](unpack_range(13, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[9](unpack_range(top, registers, 10))
        goto p265
        ::p11::
        tick(11)
        registers[3] = (registers[3] * 0.1)
        a = registers
        z = 4
        q = upvalues
        q = q[3]
        a[z] = q
        registers[5] = upvalues[4]["viewmodel_offset_y"];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] * 0.1)
        registers[5] = upvalues[3]
        goto p49
        ::p21::
        tick(21)
        registers[3] = upvalues[0][50]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p115
        end
        goto p243
        ::p27::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        if registers[2] == registers[0] then
            goto p243
        end
        goto p21
        ::p32::
        tick(32)
        registers[12] = upvalues[7]
        registers[13] = (0)
        m, x = pack_returns(registers[11](unpack_range(13, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[9](unpack_range(top, registers, 10))
        goto p3
        ::p43::
        tick(43)
        registers[9] = registers[3]
        registers[10] = registers[4]
        registers[11] = registers[5]
        do
            return unpack_range(11, registers, (9))
        end
        ::p49::
        registers[6] = upvalues[4]["viewmodel_offset_z"];
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] * 0.1)
        registers[6] = upvalues[4]["viewmodel_options"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"]
        a = registers
        z = 8;
        a[z] = "CSS Animation"
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[4]["viewmodel_options"]
        goto p270
        ::p59::
        tick(59)
        registers[3] = registers[10]
        registers[10] = upvalues[11]["lerp"]
        registers[11] = registers[4]
        registers[12] = -5
        a = upvalues[2];
        registers[13] = a[2][a[1]]
        goto p287
        ::p65::
        tick(65)
        if not registers[7] then
            goto p207
        end
        goto p305
        ::p67::
        tick(67)
        registers[11] = upvalues[7]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["set_raw_float"]
        registers[13] = (0)
        goto p146
        ::p71::
        tick(71)
        registers[11] = upvalues[8]
        if registers[11] == registers[0] then
            goto p202
        end
        goto p158
        ::p74::
        tick(74)
        if registers[12] then
            goto p97
        end
        goto p200
        ::p94::
        tick(94)
        registers[9] = upvalues[6]
        if registers[9] == registers[0] then
            goto p265
        end
        goto p120
        ::p97::
        tick(97)
        registers[13] = (0.05);
        registers[10] = registers[10](unpack_range(13, registers, 11))
        a = upvalues[2]
        a[2][a[1]] = registers[10]
        registers[10] = upvalues[11]["lerp"]
        goto p129
        ::p111::
        tick(111)
        registers[11] = upvalues[7]
        if registers[11] == registers[0] then
            goto p71
        end
        goto p67
        ::p115::
        registers[3] = upvalues[3]
        registers[4] = upvalues[4]["viewmodel_offset_x"];
        registers[(3)] = registers[(3)](registers[4])
        goto p11
        ::p120::
        registers[9] = upvalues[6]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_float"]
        registers[11] = upvalues[10]
        goto p6
        ::p129::
        registers[11] = registers[3]
        registers[12] = -4.75
        a = upvalues[2];
        registers[13] = a[2][a[1]];
        registers[10] = registers[10](unpack_range(13, registers, 11))
        goto p59
        ::p134::
        tick(134)
        a = upvalues[9]
        a[2][a[1]] = (false)
        goto p65
        ::p136::
        tick(136)
        registers[12] = upvalues[8]
        registers[13] = (0)
        m, x = pack_returns(registers[11](unpack_range(13, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[9](unpack_range(top, registers, 10))
        goto p134
        ::p142::
        registers[9] = upvalues[8]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_float"]
        registers[11] = upvalues[10]
        goto p136
        ::p146::;
        registers[11](registers[12], registers[13])
        goto p71
        ::p154::
        tick(154)
        registers[9] = upvalues[12]
        registers[10] = registers[1]
        registers[(9)](registers[10])
        goto p43
        ::p158::
        registers[11] = upvalues[8]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["set_raw_float"]
        registers[13] = (0);
        registers[11](registers[12], registers[13])
        goto p202
        ::p163::
        tick(163)
        registers[12] = "m_vecVelocity"
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = registers[9](unpack_range(top, registers, 10))
        registers[10] = upvalues[0][162]
        registers[11] = (1)
        z = registers[9]
        registers[13] = z;
        registers[(12)] = z["length"];
        registers[(12)] = registers[(12)](registers[13])
        registers[12] = registers[12] / 300
        goto p259
        ::p180::
        tick(180)
        if registers[1] == registers[0] then
            goto p328
        end
        goto p154
        ::p182::
        tick(182)
        registers[5] = registers[10]
        goto p298
        ::p187::
        tick(187)
        registers[12] = (1)
        goto p74
        ::p189::
        tick(189)
        registers[11] = upvalues[0][163]
        registers[12] = upvalues[0][30];
        registers[12] = registers[12]()
        registers[12] = (registers[12] * 6);
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = registers[11] * registers[10]
        goto p221
        ::p196::
        tick(196)
        a = upvalues[2];
        registers[11] = a[2][a[1]]
        registers[12] = registers[9]
        if not registers[12] then
            goto p74
        end
        goto p187
        ::p200::
        registers[12] = (0)
        goto p97
        ::p202::
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["viewmodel_offset_y"]
        if registers[11] == registers[0] then
            goto p233
        end
        goto p253
        ::p207::
        a = upvalues[2]
        a[2][a[1]] = (0)
        goto p298
        ::p221::
        registers[11] = (registers[11] * 0.8)
        registers[4] = registers[4] + registers[11]
        registers[11] = upvalues[0][163]
        registers[12] = upvalues[0][30];
        registers[12] = registers[12]()
        registers[12] = (registers[12] * 3)
        goto p237
        ::p228::
        tick(228)
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["viewmodel_offset_z"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["set_raw_float"]
        registers[13] = registers[5]
        goto p300
        ::p233::
        tick(233)
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["viewmodel_offset_z"]
        if registers[11] == registers[0] then
            goto p189
        end
        goto p228
        ::p237::;
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = registers[11] * registers[10]
        registers[11] = (registers[11] * 0.2)
        registers[5] = registers[5] + registers[11]
        a = upvalues[9]
        a[2][a[1]] = (true)
        goto p65
        ::p243::
        registers[3] = upvalues[1]
        registers[(3)]()
        a = upvalues[2]
        a[2][a[1]] = (0)
        registers[3] = nil
        registers[4] = nil
        registers[5] = nil
        goto p275
        ::p248::
        tick(248)
        registers[11] = upvalues[6]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["set_raw_int"]
        registers[13] = (0);
        registers[11](registers[12], registers[13])
        goto p111
        ::p253::
        registers[11] = environment["cvar"]
        registers[11] = registers[11]["viewmodel_offset_y"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["set_raw_float"]
        registers[13] = registers[4];
        registers[11](registers[12], registers[13])
        goto p233
        ::p259::
        registers[10] = registers[10](registers[11], registers[12])
        registers[11] = upvalues[6]
        if registers[11] == registers[0] then
            goto p111
        end
        goto p248
        ::p265::
        registers[9] = upvalues[7]
        if registers[9] == registers[0] then
            goto p3
        end
        goto p353
        ::p268::
        tick(268)
        if not registers[6] then
            goto p335
        end
        goto p331
        ::p270::
        z = registers[7]
        registers[8] = z;
        registers[(7)] = z["get"]
        registers[9] = "CS2 Viewmodel Scope"
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = registers[7]
        goto p268
        ::p275::
        do
            return unpack_range(5, registers, (3))
        end
        ::p287::;
        registers[10] = registers[10](unpack_range(13, registers, 11))
        a = registers
        z = 4
        q = registers
        q = q[10]
        a[z] = q
        registers[10] = upvalues[11]["lerp"]
        registers[11] = registers[5]
        registers[12] = -2
        a = upvalues[2];
        registers[13] = a[2][a[1]];
        registers[10] = registers[10](unpack_range(13, registers, 11))
        goto p182
        ::p298::
        if not registers[8] then
            goto p328
        end
        goto p180
        ::p300::;
        registers[11](registers[12], registers[13])
        goto p189
        ::p305::
        registers[9] = upvalues[0][47]
        a = registers
        z = 10
        q = registers
        q = q[2]
        a[z] = q
        registers[11] = "m_bIsScoped"
        registers[9] = registers[9](registers[10], registers[11])
        registers[9] = (registers[9] == 1)
        registers[10] = upvalues[11]["lerp"]
        goto p196
        ::p328::
        registers[9] = upvalues[1]
        registers[(9)]()
        goto p43
        ::p331::
        registers[9] = upvalues[5]
        registers[10] = upvalues[0][47]
        registers[11] = registers[2]
        goto p163
        ::p335::
        a = upvalues[9];
        registers[9] = a[2][a[1]]
        if not registers[9] then
            goto p65
        end
        goto p94
        ::p353::
        registers[9] = upvalues[7]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["set_float"]
        registers[11] = upvalues[10]
        goto p32
    end
end
