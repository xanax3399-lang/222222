-- Recovered function f212; author names are unavailable.
F.f212 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9 = nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f212")
        tick(1)
        goto p10
        ::p2::
        tick(2)
        slot_8 = slot_4
        if slot_8 then
            goto p23
        end
        goto p20
        ::p5::
        tick(5)
        slot_8 = environment["string"]
        slot_8 = slot_8["lower"]
        slot_9 = slot_2;
        slot_8 = slot_8(slot_9)
        goto p17
        ::p10::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = a[4]
        slot_5 = a[5]
        slot_6 = (#slot_1)
        slot_6 = slot_6 + 1
        slot_7 = {
        }
        slot_7["text"] = slot_2
        slot_7["color"] = slot_3
        goto p2
        ::p17::
        tick(17)
        slot_7["legacy"] = slot_8
        slot_1[slot_6] = slot_7
        do
            return 
        end
        ::p20::
        slot_8 = (100)
        ::p23::
        slot_7["order"] = slot_8
        slot_8 = slot_5
        if slot_8 then
            goto p17
        end
        goto p5
    end
end
