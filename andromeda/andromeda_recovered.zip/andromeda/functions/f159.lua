-- Recovered function f159; author names are unavailable.
F.f159 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f159")
        tick(1)
        goto p28
        ::p20::
        tick(20)
        registers[3] = upvalues[0][66]
        registers[4] = registers[1]
        registers[5] = registers[2]
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p24::
        tick(24)
        registers[3] = registers[2]
        registers[2] = registers[1]
        registers[1] = registers[3]
        goto p20
        ::p28::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if not (registers[2] < registers[1]) then
            goto p20
        end
        goto p24
    end
end
