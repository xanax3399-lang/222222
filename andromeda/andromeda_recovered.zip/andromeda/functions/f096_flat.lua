-- Recovered function f96; author names are unavailable.
F.f96 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f96")
        tick(1)
        local arguments, argument_count = {
            ...,
        }, select("#", ...)
        goto p4870
        ::p2::
        tick(2)
        registers[47] = registers[21]["visuals"]
        registers[47] = registers[47]["stubs"]
        if registers[47] == registers[0] then
            goto p4385
        end
        goto p8767
        ::p6::
        tick(6)
        registers[42]["load"] = registers[43]
        a = D.f97
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42]["save"] = registers[43]
        goto p1773
        ::p10::
        tick(10)
        registers[41]["conditions"] = registers[42]
        registers[41] = registers[21]["antiaim"]
        registers[41] = registers[41]["conditions"]
        goto p8120
        ::p14::
        tick(14)
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_picker_color"
        a = D.f98
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3378
        ::p18::
        tick(18)
        a = D.f99
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[19] = "alpha_modulate"
        a = D.f100
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[19] = new_frame(9)
        registers[20] = "Stand"
        registers[21] = "Move"
        registers[22] = "Slow-motion"
        goto p5903
        ::p29::
        tick(29)
        registers[43] = registers[43](registers[44], registers[45])
        registers[41]["export"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Import"
        goto p2528
        ::p35::
        tick(35);
        registers[(16)] = registers[(16)](registers[17])
        registers[15] = registers[15] + registers[16]
        registers[15] = registers[15] + 281
        registers[15] = (registers[15] >= 478)
        if not registers[15] then
            goto p2970
        end
        goto p8489
        ::p48::
        tick(48)
        registers[50] = ""
        registers[51] = (1);
        registers[43] = registers[43](unpack_range(51, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"]
        registers[47] = new_frame(3)
        registers[48] = registers[42]["ground_legs"]
        registers[49] = "Jitter"
        registers[50] = "Jitter[2]"
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49]
        q[3] = registers[50];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        goto p2308
        ::p61::
        tick(61)
        registers[55] = environment["unpack"]
        a = registers
        z = 56
        q = registers
        q = q[48]
        a[z] = q
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["right"] = registers[50]
        goto p1095
        ::p69::
        tick(69)
        registers[54] = new_frame(2)
        registers[55] = registers[47]["values"]
        registers[56] = "Double"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        goto p6158
        ::p76::
        tick(76)
        registers[46] = registers[21]["ragebot"]
        registers[46] = registers[46]["enemy_resolver"]
        if registers[46] == registers[0] then
            goto p1025
        end
        goto p729
        ::p80::
        tick(80)
        registers[46] = registers[44]["def_yaw_spin_left_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p540
        ::p90::
        tick(90)
        registers[33] = "stomach"
        registers[34] = "left arm"
        registers[35] = "right arm"
        registers[36] = "left leg"
        registers[37] = "right leg"
        registers[38] = "neck"
        registers[39] = "?"
        registers[40] = "gear"
        goto p7047
        ::p99::
        tick(99)
        registers[52] = new_frame(4)
        registers[53] = registers[47]["type"]
        registers[54] = "Center"
        registers[55] = "Random"
        registers[56] = "Spin"
        goto p4175
        ::p105::
        tick(105)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[22] = z;
            registers[23] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p2682
        end
        goto p9728
        ::p107::
        tick(107)
        m, x = pack_returns(registers[41](unpack_range(42, registers, 42)))
        z = 0
        for f = 41, 43 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(41)]
        n = registers[42]
        U = registers[43]
        goto p7980
        ::p109::
        tick(109)
        registers[33] = {
        }
        registers[33]["type"] = "Default"
        registers[33]["value"] = 0
        registers[32]["pitch"] = registers[33]
        registers[33] = {
        }
        goto p2264
        ::p115::
        tick(115)
        a = D.f101
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = "apply_smooth_animfix"
        a = D.f102
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        goto p141
        ::p135::
        tick(135)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p4204
        ::p141::
        registers[43] = "pre_render"
        a = D.f103
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = "setup_command"
        a = D.f104
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p5429
        ::p147::
        tick(147)
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["extrapolation"] = registers[42]
        z = registers[22]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\012<gray>\012<func> \013Overpredict\010ragebot_extrapolation_overpredict"
        registers[45] = (0)
        registers[46] = (200)
        registers[47] = (125)
        registers[48] = (true)
        goto p6620
        ::p171::
        tick(171)
        registers[42] = {
        }
        goto p8134
        ::p175::
        tick(175)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p3349
        ::p180::
        tick(180);
        registers[46](registers[47], registers[48])
        goto p6506
        ::p182::
        tick(182)
        registers[57] = registers[48]
        m, x = pack_returns(registers[56](unpack_range(57, registers, 57)))
        m = m + 56 - 1
        top = m
        z = 0
        for f = 56, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[51] = registers[51](unpack_range(top, registers, 52))
        registers[50]["left"] = registers[51]
        goto p9399
        ::p187::
        tick(187)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p1421
        ::p191::
        tick(191)
        registers[52] = "Off"
        registers[53] = "Jitter"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        q[3] = registers[53]
        goto p6029
        ::p195::
        tick(195)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p5364
        ::p200::
        tick(200)
        registers[51] = "\010hidden_yaw_modifier_values_"..registers[43]
        registers[52] = new_frame(3)
        registers[53] = "Solo"
        registers[54] = "Double"
        registers[55] = "Custom"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        goto p5694
        ::p207::
        tick(207)
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_hit_label"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["color_picker"]
        registers[44] = "\010aimbot_logs_hit_color"
        registers[45] = (186)
        registers[46] = (255)
        registers[47] = (15)
        registers[48] = (255);
        registers[42] = registers[42](unpack_range(48, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p7743
        ::p220::
        tick(220)
        registers[26][2] = "Toggle"
        registers[26][3] = "Off hotkey"
        a = D.f105
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6905
        ::p224::
        tick(224)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p4731
        ::p229::
        tick(229);
        registers[42] = registers[42](unpack_range(46, registers, 43))
        registers[41]["watermark_accent_color"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["combobox"]
        goto p9736
        ::p242::
        tick(242)
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["cfg"]
        registers[43] = registers[43](registers[44], registers[45])
        registers[41]["load"] = registers[43]
        goto p1599
        ::p247::
        tick(247)
        a = D.f106
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "clear_table"
        goto p3811
        ::p253::
        tick(253)
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_row_background"
        a = D.f107
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3581
        ::p257::
        tick(257)
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_spin_speed"]
        goto p9008
        ::p264::
        tick(264)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\012<gray>\012<dot> \013Randomize \010delay_custom_randomize_"..registers[43]
        registers[53] = (0)
        goto p3842
        ::p269::
        tick(269);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p4656
        ::p271::
        tick(271)
        registers[6] = environment["client"]
        registers[6] = registers[6]["set_event_callback"]
        registers[7] = registers[5]
        a = D.f108
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[8] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3757
        ::p276::
        tick(276);
        registers[60] = registers[60](unpack_range(69, registers, 61))
        z = registers[60]
        registers[61] = z;
        registers[(60)] = z["depend"]
        registers[62] = registers[25]["ragebot"]
        goto p360
        ::p280::
        tick(280)
        registers[45] = "Aimbot"
        registers[46] = "Minimum hit chance";
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[44] = registers[1][99]
        goto p2422
        ::p285::
        tick(285)
        registers[27] = "Andro\011meda\013 Exclu\011sive"
        registers[25] = registers[25](registers[26], registers[27])
        a = registers
        z = (21)
        a = a[z]
        z = "switch_title"
        q = registers
        m = 25
        q = q[m]
        a[z] = q
        z = registers[22]
        registers[26] = z;
        registers[(25)] = z["combobox"]
        registers[27] = "\010menu_switch"
        registers[28] = new_frame(4)
        registers[29] = "Configs"
        registers[30] = "Ragebot"
        registers[31] = "Anti-Aim"
        registers[32] = "Other"
        q = registers[(28)]
        q[1] = registers[29]
        q[2] = registers[30]
        q[3] = registers[31]
        q[4] = registers[32];
        registers[25] = registers[25](unpack_range(28, registers, 26))
        registers[21]["switch"] = registers[25]
        z = registers[22]
        registers[26] = z;
        registers[(25)] = z["combobox"]
        registers[27] = "\010switch_type"
        registers[28] = new_frame(3)
        registers[29] = "Builder"
        registers[30] = "Gamesense"
        registers[31] = "Defensive"
        q = registers[(28)]
        q[1] = registers[29]
        q[2] = registers[30]
        q[3] = registers[31];
        registers[25] = registers[25](unpack_range(28, registers, 26))
        registers[21]["switch_type"] = registers[25]
        registers[25] = {
        }
        registers[26] = new_frame(2)
        registers[27] = registers[21]["switch_type"]
        goto p4218
        ::p316::
        tick(316)
        a = D.f115
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[9] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[7](registers[8], registers[9])
        registers[7] = (false)
        registers[8] = (0)
        registers[9] = nil
        a = D.f122
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11] = 423
        registers[11] = registers[11] + 91
        goto p5385
        ::p325::
        tick(325)
        registers[15] = "player esp"
        registers[16] = "name"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["name"] = registers[12]
        goto p1235
        ::p351::
        tick(351)
        registers[21] = environment["ipairs"]
        registers[22] = registers[19]
        m, x = pack_returns(registers[21](unpack_range(22, registers, 22)))
        z = 0
        for f = 21, 23 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(21)]
        n = registers[22]
        U = registers[23]
        goto p105
        ::p355::
        tick(355)
        registers[8] = "gamesense/clipboard";
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = environment["require"]
        registers[9] = "gamesense/msgpack"
        goto p1218
        ::p360::
        registers[63] = registers[42]["enabled"]
        registers[64] = registers[51]
        registers[65] = new_frame(2)
        registers[66] = registers[53]["options"]
        registers[67] = registers[58]
        q = registers[(65)]
        q[1] = registers[66]
        q[2] = registers[67];
        registers[60] = registers[60](unpack_range(65, registers, 61))
        goto p2191
        ::p368::
        tick(368)
        if registers[45] then
            goto p9384
        end
        goto p8040
        ::p370::
        tick(370)
        registers[37] = "build_maps"
        a = D.f123
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[37]] = registers[38]
        registers[37] = "serialize_group"
        goto p3763
        ::p375::
        tick(375);
        registers[47] = registers[47](unpack_range(50, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch"] = registers[47]
        goto p5772
        ::p383::
        tick(383)
        registers[46] = registers[42]["enabled"]
        registers[47] = new_frame(3)
        registers[48] = registers[42]["ground_legs"]
        registers[49] = "Jitter"
        registers[50] = "Jitter[2]"
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49]
        q[3] = registers[50];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[42]["legs_offset_1"] = registers[43]
        goto p9313
        ::p400::
        tick(400)
        a = D.f124
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "draw_background"
        a = D.f125
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "paint"
        goto p2588
        ::p407::
        tick(407)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Default"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p7975
        ::p411::
        tick(411)
        registers[30] = registers[21]["visuals"]
        registers[30] = registers[30]["stubs"]
        if registers[30] == registers[0] then
            goto p8300
        end
        goto p8497
        ::p415::
        tick(415)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[52] = v
            branch_taken = true
        end
        if branch_taken then
            goto p4772
        end
        goto p5437
        ::p424::
        tick(424)
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Disable Delay After Shot"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        goto p6496
        ::p429::
        tick(429)
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p5824
        ::p433::
        tick(433)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "multi-point scale";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p7399
        ::p441::
        tick(441)
        z = registers[22]
        registers[48] = z;
        registers[(47)] = z["combobox"]
        registers[49] = "\010invalid_tick_cleaner_"..registers[43]
        registers[50] = new_frame(2)
        goto p9320
        ::p445::
        tick(445)
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        registers[55] = (1)
        registers[56] = {
        }
        goto p9042
        ::p452::
        tick(452)
        registers[24]["pre_pre_prev"] = registers[25]
        registers[25] = {
        }
        registers[24]["flags"] = registers[25]
        goto p9117
        ::p459::
        tick(459)
        registers[42] = "Fluctuate"
        registers[43] = "Random"
        registers[44] = "Timing"
        q = registers[(38)]
        q[1] = registers[39]
        q[2] = registers[40]
        q[3] = registers[41]
        q[4] = registers[42]
        q[5] = registers[43]
        q[6] = registers[44]
        registers[39] = new_frame(3)
        goto p5510
        ::p465::
        tick(465)
        registers[15] = "aimbot"
        registers[16] = "double tap"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["double_tap"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        goto p2731
        ::p474::
        tick(474)
        registers[46] = registers[25]["antiaim"]
        registers[47] = registers[25]["builder"];
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[43]["right"] = registers[44]
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        registers[46] = "\012<gray>\012<func> \013Forward"
        registers[44] = registers[44](registers[45], registers[46])
        goto p7688
        ::p482::
        tick(482)
        registers[44] = environment["cvar"]
        registers[44] = registers[44]["c_mindistance"]
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["get_int"];
        registers[(44)] = registers[(44)](registers[45])
        if registers[44] then
            goto p8174
        end
        goto p8294
        ::p488::
        tick(488)
        registers[42] = registers[42]["animations"]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["checkbox"]
        registers[45] = "\012<gray>\012<func> \013Animations\010"
        registers[43] = registers[43](registers[44], registers[45])
        goto p946
        ::p493::
        tick(493)
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Double"
        goto p2193
        ::p498::
        tick(498)
        registers[42] = "shotgun"
        registers[43] = "sniper"
        registers[44] = "machinegun"
        registers[45] = "c4"
        goto p8622
        ::p503::
        tick(503)
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        q[3] = registers[48];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["antiaim"]
        goto p6130
        ::p508::
        tick(508)
        registers[47] = registers[44]
        registers[48] = (true)
        registers[(45)](unpack_range(48, registers, 46))
        goto p7529
        ::p512::
        tick(512)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p9000
        ::p516::
        tick(516)
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_SPINREFRACTION"..registers[43]
        registers[50] = -180
        goto p4921
        ::p526::
        tick(526)
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_refraction_spin"] = registers[47]
        goto p2835
        ::p532::
        tick(532)
        a = D.f126
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f127
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f128
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2348
        ::p536::
        tick(536)
        registers[57] = "%"
        registers[58] = (1);
        registers[50] = registers[50](unpack_range(58, registers, 51))
        goto p9629
        ::p540::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p8386
        ::p545::
        tick(545)
        registers[12] = (registers[12] - registers[13])
        registers[13] = environment["math"]
        registers[13] = registers[13]["floor"]
        registers[14] = environment["math"]
        goto p827
        ::p550::
        tick(550)
        a = D.f129
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[41] = "paint_ui"
        a = D.f133
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[42] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[27][registers[41]] = registers[42]
        registers[41] = registers[1][56]
        registers[42] = "paint_ui"
        goto p6402
        ::p557::
        tick(557)
        registers[53] = (true)
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p3646
        ::p561::
        tick(561)
        a = D.f134
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[42](registers[43], registers[44])
        registers[42] = registers[11]["set_callback"]
        registers[43] = "predict_command"
        a = D.f135
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1643
        ::p568::
        tick(568)
        registers[55] = registers[48]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[47]["solo"] = registers[49]
        registers[49] = {
        }
        goto p6530
        ::p574::
        tick(574)
        registers[42][registers[47]] = registers[48]
        registers[47] = "option_enabled"
        a = D.f136
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        goto p3726
        ::p579::
        tick(579)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Delayed"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p5909
        ::p587::
        tick(587)
        a = D.f137
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "get_selected_groups"
        goto p7650
        ::p591::
        tick(591)
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_distortion_minus"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p5241
        ::p598::
        tick(598)
        registers[59] = (1)
        registers[60] = registers[40];
        registers[51] = registers[51](unpack_range(60, registers, 52))
        z = registers[51]
        registers[52] = z;
        registers[(51)] = z["depend"]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["builder_type"]
        registers[55] = "Hidden"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = new_frame(6)
        registers[55] = registers[49]["type"]
        registers[56] = "Default"
        registers[57] = "Smart"
        registers[58] = "Fluctuate"
        goto p1533
        ::p612::
        tick(612)
        registers[51] = (8)
        registers[52] = (6)
        registers[53] = (true)
        goto p5381
        ::p631::
        tick(631)
        registers[46] = "\012<gray>\012<func> \013Right"
        registers[44] = registers[44](registers[45], registers[46])
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        goto p474
        ::p635::
        tick(635)
        registers[24][registers[38]] = registers[39]
        registers[38] = "decode"
        a = D.f139
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2965
        ::p639::
        tick(639)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[41] = registers[21]["visuals"]
        registers[42] = registers[21]["visuals"]
        registers[42] = registers[42]["stubs"]
        if registers[42] then
            goto p8134
        end
        goto p171
        ::p645::
        tick(645)
        registers[13] = "misc"
        registers[14] = "miscellaneous"
        registers[15] = "override fov";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["fov"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "misc"
        registers[14] = "miscellaneous"
        registers[15] = "clan tag spammer"
        goto p4440
        ::p655::
        tick(655)
        registers[48] = (235)
        registers[49] = (90)
        registers[50] = (170)
        goto p1926
        ::p659::
        tick(659)
        registers[55] = registers[49]["type"]
        a = registers
        z = 56;
        a[z] = "Default"
        registers[57] = "Smart"
        registers[58] = "Fluctuate"
        registers[59] = "Random"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        q[3] = registers[57]
        q[4] = registers[58]
        q[5] = registers[59]
        registers[55] = new_frame(2)
        registers[56] = registers[49]["values"]
        registers[57] = "Custom"
        q = registers[(55)]
        q[1] = registers[56]
        q[2] = registers[57]
        registers[56] = environment["unpack"]
        registers[57] = registers[48]
        m, x = pack_returns(registers[56](unpack_range(57, registers, 57)))
        m = m + 56 - 1
        top = m
        z = 0
        for f = 56, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[51] = registers[51](unpack_range(top, registers, 52))
        registers[50]["randomize"] = registers[51]
        goto p2169
        ::p676::
        tick(676)
        registers[44] = "\012<gray>\012<func> \013Damage Indicator"
        registers[45] = new_frame(4)
        a = registers
        z = 46;
        a[z] = 255
        goto p1955
        ::p683::
        tick(683)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[42][registers[49]] = registers[53]
        goto p2272
        ::p696::
        tick(696)
        registers[32]["manual"] = registers[0]
        registers[32]["e_peek"] = false
        registers[29] = registers[32]
        registers[32] = {
        }
        a = D.f140
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9409
        ::p702::
        tick(702)
        registers[53] = "reset_disable_fakelag"
        a = D.f141
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "is_player_standing"
        a = D.f142
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "update_disable_fakelag"
        a = D.f143
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2871
        ::p720::
        tick(720)
        registers[47] = registers[25]["ragebot"]
        registers[45] = registers[45](registers[46], registers[47])
        registers[42]["enabled"] = registers[45]
        goto p5528
        ::p725::
        tick(725)
        registers[50] = (1)
        registers[51] = (15)
        registers[52] = (6)
        goto p9069
        ::p729::
        a = registers
        z = (45)
        q = registers
        q = q[21]
        q = q["ragebot"]
        a[z] = q
        registers[45] = registers[45]["enemy_resolver"]
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["set_callback"]
        a = D.f144
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[48] = (true)
        registers[(45)](unpack_range(48, registers, 46))
        registers[45] = registers[23]["update_callbacks"]
        registers[46] = registers[21]["ragebot"]
        registers[46] = registers[46]["enemy_resolver"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["get"];
        registers[(46)] = registers[(46)](registers[47])
        registers[46] = (registers[46] == true)
        registers[(45)](registers[46])
        goto p1025
        ::p746::
        tick(746)
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        goto p3044
        ::p751::
        tick(751)
        registers[41]["aimbot_logs"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["label"]
        registers[44] = "\012<gray>\012<dot> \013Hit"
        goto p1550
        ::p755::
        tick(755)
        registers[53] = registers[48]["type"]
        registers[54] = "Center"
        registers[55] = "Random"
        goto p2628
        ::p759::
        tick(759)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_sway_left_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch sway right\010defensive_pitch_sway_right_value"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        goto p5678
        ::p774::
        tick(774)
        registers[47] = "\010manual_arrows_offset"
        registers[48] = (30)
        registers[49] = (140)
        registers[50] = (55)
        registers[51] = (true)
        registers[52] = "px"
        registers[53] = (1);
        registers[45] = registers[45](unpack_range(53, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        goto p6875
        ::p786::
        tick(786)
        registers[17] = "on shot anti-aim"
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["on_shot_antiaim"] = registers[13]
        registers[13] = {
        }
        goto p2817
        ::p792::
        tick(792)
        registers[15] = "effects"
        registers[16] = "force third person (alive)"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["thirdperson"] = registers[12]
        goto p1694
        ::p808::
        tick(808)
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p5596
        ::p814::
        tick(814)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p8066
        ::p820::
        tick(820)
        registers[47] = registers[42]["finish_command"];
        registers[45](registers[46], registers[47])
        registers[45] = registers[11]["set_callback"]
        registers[46] = "paint"
        registers[47] = registers[42]["paint"];
        registers[45](registers[46], registers[47])
        goto p8557
        ::p827::
        registers[14] = registers[14]["pi"];
        registers[(13)] = registers[(13)](registers[14])
        registers[12] = (registers[12] - registers[13])
        registers[12] = registers[12] > 450
        if not registers[12] then
            goto p4656
        end
        goto p4389
        ::p833::
        tick(833)
        registers[54] = (0)
        registers[55] = (true)
        registers[56] = "%"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        goto p2104
        ::p840::
        tick(840)
        do
            local f = (2)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[2] = environment["require"]
        registers[3] = "gamesense/pui";
        registers[(2)] = registers[(2)](registers[3])
        goto p1327
        ::p845::
        tick(845)
        registers[51] = environment["unpack"]
        registers[52] = registers[48]
        m, x = pack_returns(registers[51](unpack_range(52, registers, 52)))
        m = m + 51 - 1
        top = m
        z = 0
        for f = 51, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[47]["builder_type"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        goto p1638
        ::p853::
        tick(853)
        registers[53] = "update_invalid_tick_cleaner"
        a = D.f145
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "break_lc"
        a = D.f146
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "is_invalid_tick_cleaner_visible"
        a = D.f147
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2018
        ::p862::
        tick(862)
        registers[17] = "body yaw"
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["body_yaw"] = registers[13]
        registers[13] = registers[2]["reference"]
        goto p5202
        ::p868::
        tick(868)
        registers[42]["updated_this_tick"] = false
        registers[42]["indicator_value"] = registers[0]
        registers[43] = registers[1][99]
        registers[44] = "Rage"
        goto p280
        ::p873::
        tick(873)
        registers[51] = (180)
        registers[52] = -180
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p2014
        ::p882::
        tick(882)
        registers[23]["sim_store"] = registers[24]
        registers[24] = {
        }
        registers[23]["ent_store"] = registers[24]
        goto p6641
        ::p888::
        tick(888);
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_miss_color"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["label"]
        registers[44] = "\012<gray>\012<dot> \013Got Hit"
        registers[42] = registers[42](registers[43], registers[44])
        goto p4005
        ::p894::
        tick(894)
        registers[15] = environment["string"]
        registers[15] = registers[15]["len"]
        registers[16] = "j";
        registers[(15)] = registers[(15)](registers[16])
        registers[14] = (registers[14] - registers[15])
        registers[14] = (registers[14] - 176)
        registers[15] = environment["string"]
        registers[15] = registers[15]["len"]
        registers[16] = "\030";
        registers[(15)] = registers[(15)](registers[16])
        registers[14] = registers[14] + registers[15]
        registers[14] = (registers[14] ~= 320)
        if not registers[14] then
            goto p3273
        end
        goto p4183
        ::p908::
        tick(908)
        registers[38] = "ensure_defaults"
        a = D.f148
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "save_config"
        goto p3107
        ::p913::
        tick(913)
        registers[(46)](unpack_range(51, registers, 47))
        registers[46] = registers[44]["def_pitch_static_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p3081
        ::p920::
        tick(920)
        registers[19] = "get_entities"
        a = D.f149
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[18] = {
        }
        registers[19] = environment["entity"]
        goto p4575
        ::p926::
        tick(926)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p5923
        ::p936::
        tick(936)
        registers[52] = (60)
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p1366
        ::p946::
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[43] = registers[43](registers[44], registers[45])
        goto p2122
        ::p950::
        tick(950)
        registers[33]["last_flick_at"] = 0
        registers[32]["defensive_yaw_delayed_state"] = registers[33]
        registers[33] = {
        }
        registers[33]["start_angle"] = 0
        registers[33]["target_angle"] = 0
        registers[34] = registers[1][30];
        registers[34] = registers[34]()
        goto p9494
        ::p958::
        tick(958)
        registers[55] = new_frame(2)
        registers[56] = registers[49]["values"]
        registers[57] = "Double"
        q = registers[(55)]
        q[1] = registers[56]
        q[2] = registers[57]
        registers[56] = environment["unpack"]
        goto p6139
        ::p964::
        tick(964)
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch left\010defensive_pitch_left_value"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p4065
        ::p973::
        tick(973)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Fluctuate"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_fluctuate_value2"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p7762
        ::p985::
        tick(985)
        registers[32][registers[53]] = registers[54]
        registers[53] = "update_safehead"
        a = D.f150
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p5174
        ::p989::
        tick(989)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_right_value"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw double delay\010defensive_yaw_delay"..registers[43]
        registers[50] = (1)
        registers[51] = (16)
        goto p1178
        ::p997::
        tick(997)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p998::
        tick(998)
        registers[54] = (100)
        registers[55] = (0)
        registers[56] = (true)
        goto p4708
        ::p1007::
        tick(1007)
        registers[72] = "shutdown"
        a = D.f152
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[73] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[71](registers[72], registers[73])
        goto p6629
        ::p1011::
        tick(1011);
        registers[47] = registers[47](unpack_range(50, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p4858
        ::p1015::
        tick(1015)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_distortion_plus"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Distortion -\010defensive_yaw_distortion_minus"..registers[43]
        goto p7684
        ::p1021::
        tick(1021)
        registers[54] = (0)
        registers[55] = (100)
        registers[56] = (0)
        goto p9732
        ::p1025::
        tick(1025)
        registers[45] = registers[21]["visuals"]
        if registers[45] == registers[0] then
            goto p6728
        end
        goto p1871
        ::p1036::
        tick(1036)
        registers[50] = "\010yaw_global_"..registers[43]
        registers[51] = -180
        registers[52] = (180)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        goto p8721
        ::p1052::
        tick(1052)
        registers[33]["defensive"] = 0
        registers[32]["delay_ticks"] = registers[33]
        registers[33] = new_frame(7)
        registers[34] = (true)
        registers[35] = (true)
        registers[36] = (false)
        registers[37] = (true)
        goto p5859
        ::p1061::
        tick(1061)
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["yaw"] = registers[48]
        registers[47] = {
        }
        registers[44]["yaw"] = registers[47]
        registers[47] = registers[44]["yaw"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        goto p2700
        ::p1069::
        tick(1069)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[53] = {
        }
        z = registers[23]
        registers[55] = z;
        registers[(54)] = z["multiselect"]
        goto p4208
        ::p1073::
        tick(1073)
        registers[19]["entity"] = registers[20]
        registers[20] = registers[16]
        registers[21] = registers[11]
        registers[22] = environment["_SCRIPT_NAME"]
        goto p6781
        ::p1078::
        tick(1078)
        registers[53] = registers[48]["type"]
        registers[54] = "Static"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        goto p7839
        ::p1084::
        tick(1084);
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p8880
        ::p1095::
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\010delay_double_randomize_"..registers[43]
        registers[53] = (0)
        goto p998
        ::p1099::
        tick(1099)
        registers[55] = (true)
        a = registers
        z = 56;
        a[z] = "\194\176"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(4)
        registers[53] = registers[48]["type"]
        registers[54] = "Center"
        registers[55] = "Random"
        goto p6514
        ::p1114::
        tick(1114)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        goto p4375
        ::p1118::
        tick(1118)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[42] = z;
            registers[43] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p2366
        end
        goto p4829
        ::p1120::
        tick(1120)
        registers[5] = environment["require"]
        a = registers
        z = 6;
        a[z] = "gamesense/entity";
        registers[(5)] = registers[(5)](registers[6])
        goto p4607
        ::p1125::
        tick(1125)
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "anti-aimbot angles"
        registers[16] = "roll";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["roll"] = registers[13]
        goto p6764
        ::p1135::
        tick(1135)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p8924
        ::p1140::
        tick(1140)
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\012<gray>\012<dot> \013Cycle \010hidden_yaw_modifier_meta_delay_cycle_"..registers[43]
        registers[52] = (0)
        goto p4696
        ::p1144::
        tick(1144)
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Custom"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_left_value"]
        goto p6666
        ::p1156::
        tick(1156)
        registers[71] = registers[41]["viewmodel_offset_x"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[68]
        goto p6568
        ::p1160::
        tick(1160)
        a = D.f153
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f154
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[40] = "paint"
        a = D.f155
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[33][registers[40]] = registers[41]
        registers[40] = registers[1][56]
        registers[41] = "paint"
        registers[42] = registers[33]["paint"];
        registers[40](registers[41], registers[42])
        do
            local f = (34)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[34] = {
        }
        goto p7515
        ::p1178::
        registers[52] = (1)
        registers[53] = (true)
        registers[54] = ""
        registers[55] = (1)
        goto p5674
        ::p1183::
        tick(1183)
        registers[55] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[55] + 0
        n = (registers[54] + 0)
        v = (registers[53] - U)
        goto p6105
        registers[95] = operand_k
        registers[89] = code_metadata
        registers[89][9375] = 212
        registers[95][6949] = 4369
        registers[88] = nil
        registers[89] = nil
        registers[90] = nil
        registers[91] = nil
        registers[92] = nil
        registers[93] = nil
        registers[94] = nil
        registers[95] = nil
        goto p4370
        ::p1191::
        tick(1191)
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(4)
        goto p6694
        ::p1195::
        tick(1195)
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["combobox"]
        registers[44] = "\010enemy_resolver_mode"
        registers[45] = new_frame(2)
        goto p5731
        ::p1199::
        tick(1199)
        registers[47] = "Ping"
        registers[48] = "K/D ratio"
        registers[49] = "Clock"
        goto p4813
        ::p1203::
        tick(1203)
        registers[64] = (101)
        registers[65] = (35)
        registers[66] = (true)
        goto p2661
        ::p1207::
        tick(1207)
        registers[25][registers[26]] = registers[27]
        registers[26] = "update"
        a = D.f156
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p4411
        ::p1218::;
        registers[(8)] = registers[(8)](registers[9])
        a = registers
        z = 9
        q = registers
        q = q[3]
        a[z] = q
        registers[10] = registers[1][57]
        goto p6149
        ::p1224::
        tick(1224);
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["antiaim"]
        registers[46] = registers[25]["builder"]
        registers[47] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[42]["states"] = registers[43]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["multiselect"]
        registers[44] = "\012<gray>\012<dot> \013Disable Fakelag\010antiaim_disable_fakelag"
        registers[45] = new_frame(3)
        goto p3947
        ::p1235::
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "misc"
        goto p5851
        ::p1239::
        tick(1239)
        registers[51] = new_frame(4)
        registers[52] = registers[47]["type"]
        registers[53] = "Center"
        registers[54] = "Random"
        goto p7692
        ::p1244::
        tick(1244)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Delay"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p8917
        ::p1251::
        tick(1251)
        a = D.f157
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_planting_progress"
        a = D.f158
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9390
        ::p1256::
        tick(1256)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        z = registers[22]
        registers[52] = z;
        registers[(51)] = z["slider"]
        registers[53] = "\012<gray>\012<dot> \013Randomize \010hidden_delay_custom_randomize_"..registers[43]
        goto p1021
        ::p1260::
        tick(1260)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        goto p3230
        ::p1264::
        tick(1264)
        registers[41]["hotkeys"] = registers[43]
        registers[43] = registers[41]["hotkeys"]
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        registers[46] = "\012<gray>\012<func> \013Left"
        registers[44] = registers[44](registers[45], registers[46])
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        registers[46] = registers[25]["antiaim"]
        goto p6578
        ::p1273::
        tick(1273)
        registers[23] = {
        }
        registers[22]["shifted_players"] = registers[23]
        registers[23] = {
        }
        registers[22]["player_state"] = registers[23]
        registers[23] = {
        }
        registers[23]["tick"] = -1
        registers[23]["time"] = 0
        goto p7340
        ::p1281::
        tick(1281)
        registers[56] = "\194\176"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p1078
        ::p1291::
        tick(1291)
        registers[45] = registers[41]["viewmodel"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["viewmodel_fov"] = registers[42]
        goto p2800
        ::p1308::
        tick(1308)
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["multiselect"]
        registers[44] = "\010viewmodel_options"
        registers[45] = new_frame(3)
        registers[46] = "CSS Animation"
        registers[47] = "CS2 Viewmodel Scope"
        registers[48] = "Opposite Knife"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        q[3] = registers[48]
        goto p7995
        ::p1316::
        tick(1316)
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        registers[53] = "Double"
        goto p6674
        ::p1323::
        tick(1323)
        a = D.f159
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = "random_float"
        goto p6855
        ::p1327::
        registers[3] = environment["require"]
        registers[4] = "vector";
        registers[(3)] = registers[(3)](registers[4])
        goto p2546
        ::p1331::
        tick(1331)
        registers[27] = registers[26]["fakelag_exploit_tick"]
        if registers[27] == registers[0] then
            goto p7938
        end
        goto p3288
        ::p1334::
        tick(1334)
        registers[52] = "Fourth"
        registers[53] = "Fifth"
        registers[54] = "CS2"
        q = registers[(48)]
        q[1] = registers[49]
        q[2] = registers[50]
        q[3] = registers[51]
        q[4] = registers[52]
        q[5] = registers[53]
        q[6] = registers[54]
        goto p9529
        ::p1340::
        tick(1340)
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p3085
        ::p1346::
        tick(1346)
        registers[55] = registers[49]["type"]
        registers[56] = "Default"
        registers[57] = "Smart"
        registers[58] = "Fluctuate"
        goto p7194
        ::p1351::
        tick(1351)
        registers[24] = "predict_command"
        registers[25] = "run_command"
        registers[26] = "setup_command"
        registers[27] = "shutdown"
        registers[28] = "string_cmd"
        goto p3939
        ::p1357::
        tick(1357)
        registers[43] = "apply_air_legs"
        a = D.f160
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = "apply_ground_legs"
        goto p9721
        ::p1362::
        tick(1362)
        z = registers[51]
        registers[52] = z;
        registers[(51)] = z["depend"]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["builder_type"]
        goto p5043
        ::p1366::;
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p5345
        ::p1370::
        tick(1370)
        registers[11] = "is_quick_peek"
        a = D.f161
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = environment["defer"]
        a = D.f162
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[(11)](registers[12])
        goto p6785
        ::p1383::
        tick(1383)
        a = D.f166
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "is_left_side"
        a = D.f167
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        goto p702
        ::p1389::
        tick(1389)
        registers[49] = "\010Yaw zurab speed\010defensive_yaw_zurab_speed"..registers[43]
        registers[50] = (1)
        registers[51] = (20)
        goto p8960
        ::p1399::
        tick(1399)
        registers[42] = registers[21]["visuals"]
        z = registers[24]
        registers[44] = z;
        registers[(43)] = z["checkbox"]
        registers[45] = "\012<gray>\012<func> \013Fast Ladder"
        goto p2130
        ::p1403::
        tick(1403)
        registers[22][registers[25]] = registers[26]
        registers[25] = "restore_all"
        a = D.f168
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        goto p3035
        ::p1408::
        tick(1408)
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        registers[59] = "Timing"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        q[6] = registers[59]
        registers[54] = new_frame(2)
        goto p2684
        ::p1421::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p5506
        ::p1425::
        tick(1425)
        registers[55] = (true)
        registers[56] = ""
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Default"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p99
        ::p1435::
        tick(1435)
        registers[17] = environment["client"]
        registers[17] = registers[17]["set_event_callback"]
        registers[18] = "player_hint"
        registers[19] = registers[15]
        registers[17] = environment["client"]
        registers[17] = registers[17]["fire_event"]
        registers[18] = "player_request_hint"
        registers[19] = {
        }
        goto p7404
        ::p1445::
        tick(1445)
        registers[49] = "\010Yaw speed\010defensive_yaw_spin_speed"..registers[43]
        registers[50] = (1)
        registers[51] = (15)
        registers[52] = (6)
        goto p6670
        ::p1450::
        tick(1450)
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        goto p7360
        ::p1457::
        tick(1457)
        registers[44] = registers[43]["enabled"]
        if registers[44] == registers[0] then
            goto p8642
        end
        goto p3739
        ::p1460::
        tick(1460)
        registers[45] = (0)
        registers[46] = (1000)
        registers[47] = (680)
        registers[48] = (true)
        registers[49] = "\194\176"
        registers[50] = (0.1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p1291
        ::p1470::
        tick(1470)
        registers[49] = "\010Yaw delayed left\010defensive_yaw_delayed_left"..registers[43]
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (0)
        goto p6294
        ::p1475::
        tick(1475)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Delay"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_spin_left_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p3619
        ::p1483::
        tick(1483)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "target hitbox";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["target_hitbox"] = registers[12]
        goto p433
        ::p1495::
        tick(1495)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Distortion"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p2354
        ::p1499::
        tick(1499)
        registers[25] = registers[11]["set_callback"]
        registers[26] = "shutdown"
        a = D.f169
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9543
        ::p1503::
        tick(1503)
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_dpi_scale"
        a = D.f170
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2289
        ::p1507::
        tick(1507)
        registers[(44)](unpack_range(47, registers, 45))
        goto p8642
        ::p1509::
        tick(1509)
        registers[42] = (0)
        a = D.f171
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f172
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6465
        ::p1515::
        tick(1515)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "force safe point"
        goto p9615
        ::p1520::
        tick(1520)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Default"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(6)
        registers[53] = registers[47]["type"]
        goto p8104
        ::p1526::
        tick(1526);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        goto p8398
        ::p1533::
        registers[59] = "Random"
        registers[60] = "Timing"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        q[3] = registers[57]
        q[4] = registers[58]
        q[5] = registers[59]
        q[6] = registers[60]
        goto p958
        ::p1538::
        tick(1538)
        registers[49] = "px"
        registers[50] = (1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        goto p1788
        ::p1542::
        tick(1542)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_right_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p8232
        ::p1550::
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p207
        ::p1554::
        tick(1554)
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["values"] = registers[48]
        registers[48] = registers[47]["values"]
        goto p4767
        ::p1561::
        tick(1561)
        registers[50] = ""
        registers[51] = (1);
        registers[43] = registers[43](unpack_range(51, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        goto p383
        ::p1567::
        tick(1567)
        registers[46] = registers[44]["def_pitch"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["get"];
        registers[(46)] = registers[(46)](registers[47])
        if registers[46] ~= "Delay" then
            goto p6506
        end
        goto p2632
        ::p1578::
        tick(1578)
        registers[57] = "Spin"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        registers[54] = new_frame(2)
        goto p8288
        ::p1582::
        tick(1582)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["randomize"] = registers[48]
        registers[48] = {
        }
        goto p6851
        ::p1587::
        tick(1587)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p3720
        ::p1591::
        tick(1591)
        registers[35] = {
        }
        registers[36] = {
        }
        registers[37] = {
        }
        registers[38] = new_frame(6)
        registers[39] = "Off"
        registers[40] = "Default"
        registers[41] = "Smart"
        goto p459
        ::p1599::
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Save"
        a = D.f173
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["cfg"]
        registers[43] = registers[43](registers[44], registers[45])
        registers[41]["save"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Delete"
        goto p5351
        ::p1611::
        tick(1611)
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["type"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_modifier_skitter_"..registers[43]
        registers[52] = -180
        goto p5084
        ::p1625::
        tick(1625)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        a = registers
        z = (46)
        q = registers
        q = q[44]
        q = q["def_pitch_refraction_up"]
        a[z] = q
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p3174
        ::p1633::
        tick(1633)
        registers[27] = registers[21]["switch"]
        registers[28] = "Anti-Aim"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["antiaim"] = registers[26]
        goto p8761
        ::p1638::
        registers[51] = "\010delay_mode_"..registers[43]
        registers[52] = registers[38];
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        goto p5887
        ::p1643::;
        registers[42](registers[43], registers[44])
        registers[42] = registers[11]["set_callback"]
        registers[43] = "level_init"
        a = D.f174
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[42](registers[43], registers[44])
        do
            local f = (31)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[31] = {
        }
        registers[32] = (false)
        goto p2111
        ::p1658::
        tick(1658)
        do
            local f = (32)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[32] = {
        }
        registers[33] = {
        }
        registers[33]["base"] = "At targets"
        goto p6079
        ::p1663::
        tick(1663)
        registers[47] = (100)
        registers[48] = (100)
        registers[49] = (true)
        goto p1561
        ::p1667::
        tick(1667)
        registers[45] = new_frame(2)
        registers[46] = "Adaptive"
        registers[47] = "Freestanding"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        goto p2154
        ::p1672::
        tick(1672)
        registers[41]["gamesense"] = registers[42]
        registers[41] = registers[21]["antiaim"]
        z = registers[22]
        registers[43] = z;
        registers[(42)] = z["combobox"]
        registers[44] = "\010antiaim_preset_condition"
        registers[45] = {
        }
        registers[46] = environment["unpack"]
        registers[47] = registers[19]
        m, x = pack_returns(registers[46](unpack_range(47, registers, 47)))
        m = m + 46 - 1
        top = m
        z = 0
        for f = 46, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(45)]
        for f = 1, top - (45) do
            q[(0) + f] = registers[(45) + f]
        end
        registers[46] = nil
        registers[47] = (false);
        registers[42] = registers[42](unpack_range(47, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        goto p1741
        ::p1686::
        tick(1686);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["usercmd"] = registers[12]
        registers[10]["misc"] = registers[11]
        registers[11] = "is_fake_duck"
        goto p5169
        ::p1691::
        tick(1691)
        registers[51] = (10)
        registers[52] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[52] + 0
        n = (registers[51] + 0)
        v = (registers[50] - U)
        goto p7720
        ::p1694::
        registers[12] = registers[2]["reference"]
        registers[13] = "visuals"
        registers[14] = "colored models"
        registers[15] = "local player";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["local_chams"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "visuals"
        registers[14] = "effects"
        registers[15] = "remove scope overlay"
        goto p4429
        ::p1728::
        tick(1728)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_sway_speed"]
        goto p3480
        ::p1736::
        tick(1736)
        registers[54] = registers[48]["values"]
        registers[55] = "Solo"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = environment["unpack"]
        goto p7249
        ::p1741::
        registers[44] = registers[25]["antiaim"]
        registers[45] = registers[25]["builder_or_defensive"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        goto p10
        ::p1746::
        tick(1746)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Fluctuate"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p6478
        ::p1753::
        tick(1753)
        registers[35] = {
        }
        registers[35]["target"] = 0
        registers[36] = new_frame(2)
        goto p8791
        ::p1765::
        tick(1765)
        registers[(27)](unpack_range(30, registers, 28))
        goto p1331
        ::p1767::
        tick(1767)
        z = registers[22]
        registers[52] = z;
        registers[(51)] = z["slider"]
        registers[53] = "\010hidden_delay_custom_sliders_"..registers[43]
        registers[54] = (2)
        registers[55] = (10)
        registers[56] = (3)
        goto p9570
        ::p1773::
        a = D.f175
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42]["delete"] = registers[43]
        a = D.f176
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42]["export"] = registers[43]
        goto p3368
        ::p1778::
        tick(1778)
        do
            local f = (18)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[18] = {
        }
        registers[19] = "new"
        a = D.f177
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[19] = "clone"
        goto p5555
        ::p1785::
        tick(1785)
        registers[53] = registers[46][registers[52]]
        registers[48][registers[52]] = registers[53]
        goto p4223
        ::p1788::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["feature_indicators"]
        goto p6053
        ::p1792::
        tick(1792)
        registers[49] = registers[47]["type"]
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["set"]
        registers[51] = "Default"
        goto p9666
        ::p1796::
        tick(1796)
        a = D.f178
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = "round"
        a = D.f179
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8436
        ::p1801::
        tick(1801)
        registers[56] = registers[11]["set_callback"]
        registers[57] = "level_init"
        a = D.f180
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[56](registers[57], registers[58])
        do
            local f = (33)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[33] = {
        }
        registers[34] = {
        }
        a = D.f181
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f182
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f183
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1160
        ::p1814::
        tick(1814)
        registers[22][registers[25]] = registers[26]
        registers[25] = "predict_player_position"
        a = D.f184
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1403
        ::p1818::
        tick(1818)
        registers[51] = "\010hidden_yaw_modifier_randomize_"..registers[43]
        registers[52] = (0)
        registers[53] = (100)
        goto p833
        ::p1822::
        tick(1822)
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"]
        goto p4495
        ::p1826::
        tick(1826)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["left_randomize"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_right_"..registers[43]
        registers[51] = -180
        goto p5061
        ::p1833::
        tick(1833)
        registers[42][registers[47]] = registers[48]
        registers[47] = "unset_hitchance"
        a = D.f185
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "reset"
        a = D.f186
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2657
        ::p1840::
        tick(1840)
        registers[44] = new_frame(5)
        registers[45] = "In Air"
        registers[46] = "No Scope"
        registers[47] = "Hotkey"
        goto p8815
        ::p1845::
        tick(1845)
        registers[54] = "Double"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p3265
        ::p1849::
        tick(1849)
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        goto p3891
        ::p1856::
        tick(1856)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p3224
        ::p1861::
        tick(1861);
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[45] = {
        }
        registers[46] = {
        }
        registers[46][0] = "Always on"
        registers[46][1] = "On hotkey"
        goto p8189
        ::p1867::
        tick(1867)
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52];
        registers[47] = registers[47](unpack_range(50, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p1884
        ::p1871::
        registers[46] = registers[21]["visuals"]
        registers[46] = registers[46]["fps_optimization"]
        if registers[46] == registers[0] then
            goto p6728
        end
        goto p3695
        ::p1876::
        tick(1876);
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        goto p9645
        ::p1880::
        tick(1880)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[47]["type"] = registers[49]
        goto p1792
        ::p1884::
        registers[49] = registers[25]["antiaim"]
        registers[50] = registers[25]["builder_or_defensive"]
        registers[51] = registers[45];
        registers[47] = registers[47](unpack_range(51, registers, 48))
        registers[44]["force_defensive"] = registers[47]
        goto p441
        ::p1890::
        tick(1890)
        registers[52] = "Default"
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53];
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        goto p5998
        ::p1896::
        tick(1896)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p2053
        ::p1922::
        tick(1922)
        a = D.f187
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f188
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45] = registers[41]
        goto p2139
        ::p1926::
        registers[51] = (255);
        registers[45] = registers[45](unpack_range(51, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        goto p746
        ::p1930::
        tick(1930)
        if registers[50] then
            goto p3669
        end
        goto p8729
        ::p1932::
        tick(1932)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p1495
        ::p1947::
        tick(1947)
        a = D.f189
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "init"
        goto p9090
        ::p1951::
        tick(1951)
        registers[50] = (1)
        registers[51] = (16)
        registers[52] = (1)
        goto p5279
        ::p1955::
        registers[47] = (255)
        registers[48] = (255)
        registers[49] = (255)
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        q[3] = registers[48]
        q[4] = registers[49]
        goto p5544
        ::p1960::
        tick(1960)
        registers[47] = {
        }
        registers[44]["yaw_modifiers"] = registers[47]
        registers[47] = registers[44]["yaw_modifiers"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        registers[50] = "\012<gray>\012<func> \013Modifiers \010yaw_modifier_builder_type_"..registers[43]
        registers[51] = new_frame(2)
        goto p1890
        ::p1987::
        tick(1987)
        registers[36] = {
        }
        registers[35]["cache"] = registers[36]
        registers[36] = {
        }
        goto p2392
        ::p1991::
        tick(1991)
        registers[55] = new_frame(2)
        registers[56] = registers[49]["values"]
        registers[57] = "Double"
        q = registers[(55)]
        q[1] = registers[56]
        q[2] = registers[57]
        registers[56] = environment["unpack"]
        registers[57] = registers[48]
        m, x = pack_returns(registers[56](unpack_range(57, registers, 57)))
        m = m + 56 - 1
        top = m
        z = 0
        for f = 56, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[51] = registers[51](unpack_range(top, registers, 52))
        registers[50]["randomize"] = registers[51]
        registers[50] = {
        }
        registers[49]["custom"] = registers[50]
        registers[50] = registers[49]["custom"]
        goto p1767
        ::p2004::
        tick(2004)
        registers[46] = new_frame(2)
        registers[47] = "Lean"
        registers[48] = "Smooth"
        goto p2479
        ::p2008::
        tick(2008)
        registers[42][registers[47]] = registers[48]
        registers[47] = "get_distance"
        a = D.f195
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "is_on_ground"
        goto p7603
        ::p2014::
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_sway_left_value"] = registers[47]
        goto p8903
        ::p2018::
        registers[32][registers[53]] = registers[54]
        registers[53] = "paint_invalid_tick_cleaner"
        a = D.f196
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "update_hotkeys"
        a = D.f197
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p985
        ::p2026::
        tick(2026)
        registers[11] = "is_force_safe_point"
        a = D.f198
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = "is_ping_spike"
        a = D.f199
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        goto p1370
        ::p2033::
        tick(2033)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_fluctuate_speed"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["combobox"]
        registers[49] = "\010Fluctuate mode\010defensive_pitch_fluctuate_mode"..registers[43]
        registers[50] = new_frame(2)
        registers[51] = "Sinus"
        registers[52] = "Lerp"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52];
        registers[47] = registers[47](unpack_range(50, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_fluctuate_mode"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_PITCHUPREFRACTION"..registers[43]
        registers[50] = -89
        goto p2344
        ::p2053::
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_fluctuate_value1"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Fluctuate value 2\010defensive_pitch_fluctuate_value2"..registers[43]
        registers[50] = -89
        goto p445
        ::p2060::
        tick(2060);
        registers[42] = registers[42](unpack_range(48, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["aimbot_logs"]
        goto p888
        ::p2065::
        tick(2065)
        registers[29] = "get_dpi_scale"
        a = D.f200
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_hitgroup"
        goto p5326
        ::p2070::
        tick(2070)
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (0)
        goto p175
        ::p2074::
        tick(2074)
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_miss_label"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["color_picker"]
        registers[44] = "\010aimbot_logs_miss_color"
        registers[45] = (228)
        goto p2236
        ::p2081::
        tick(2081)
        registers[12] = environment["string"]
        registers[12] = registers[12]["byte"]
        registers[13] = "\218E\193\187\218"
        goto p7281
        ::p2085::
        tick(2085);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        goto p9707
        ::p2089::
        tick(2089)
        registers[57] = (registers[53]..registers[57])
        registers[57] = "] \010delay_custom_"..registers[57]
        registers[57] = (registers[53]..registers[57])
        registers[57] = "\012<gray>\012<dot> \013["..registers[57]
        registers[58] = (1)
        goto p2949
        ::p2095::
        tick(2095)
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "fake lag"
        registers[16] = "variance";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["variance"] = registers[13]
        goto p7701
        ::p2102::
        tick(2102)
        if registers[13] then
            goto p2551
        end
        goto p3870
        ::p2104::
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(4)
        registers[53] = registers[48]["type"]
        goto p3390
        ::p2111::
        registers[33] = (false)
        registers[34] = (false)
        registers[35] = {
        }
        registers[36] = {
        }
        registers[36][0] = true
        registers[36][1] = true
        goto p5815
        ::p2118::
        tick(2118)
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        goto p6926
        ::p2122::
        registers[42]["enabled"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["label"]
        registers[45] = "\010animations_enabled_spacer"
        goto p7821
        ::p2126::
        tick(2126)
        registers[57] = "Refraction"
        registers[58] = "Up Switch"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        q[3] = registers[53]
        q[4] = registers[54]
        q[5] = registers[55]
        q[6] = registers[56]
        q[7] = registers[57]
        q[8] = registers[58]
        goto p375
        ::p2130::
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[43] = registers[43](registers[44], registers[45])
        registers[42]["fast_ladder"] = registers[43]
        registers[42] = registers[21]["visuals"]
        z = registers[24]
        registers[44] = z;
        registers[(43)] = z["checkbox"]
        registers[45] = "\012<gray>\012<func> \013FPS Optimization"
        goto p7183
        ::p2139::
        registers[(45)]()
        registers[45] = registers[42]
        registers[(45)]()
        registers[45] = registers[43]
        registers[(45)]()
        registers[45] = registers[44]
        registers[(45)]()
        registers[45] = registers[1][56]
        registers[46] = "paint_ui"
        a = D.f201
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[45](registers[46], registers[47])
        do
            local f = (22)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[22] = {
        }
        registers[22]["active"] = false
        goto p1273
        ::p2154::;
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        registers[45] = registers[41]["enemy_resolver"]
        goto p7484
        ::p2161::
        tick(2161)
        registers[29] = nil
        registers[30] = {
        }
        a = D.f209
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32] = (0)
        a = D.f210
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f211
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f212
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6118
        ::p2169::
        registers[47] = (#registers[34])
        registers[47] = registers[47] + 1
        registers[48] = {
        }
        registers[48]["state_name"] = registers[43]
        registers[49] = registers[44]["delay"]
        goto p8365
        ::p2181::
        tick(2181)
        registers[11]["dormantesp"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "misc"
        registers[14] = "miscellaneous"
        registers[15] = "override zoom fov";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["zfov"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        goto p9483
        ::p2191::
        registers[59]["distance"] = registers[60]
        goto p5895
        ::p2193::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_right_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p2987
        ::p2201::
        tick(2201)
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw delayed delay\010defensive_yaw_delayed_delay"..registers[43]
        registers[50] = (1)
        goto p612
        ::p2205::
        tick(2205)
        registers[32]["apex_sub_counter"] = registers[0]
        registers[32]["apex_fluct_start_tick"] = registers[0]
        registers[32]["corrective_swing_data"] = registers[0]
        goto p8548
        ::p2209::
        tick(2209)
        registers[53] = environment["unpack"]
        a = registers
        z = 54
        q = registers
        q = q[46]
        a[z] = q
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["meta_mode"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_modifier_meta_offset_"..registers[43]
        registers[52] = -180
        registers[53] = (180)
        registers[54] = (0)
        goto p5970
        ::p2222::
        tick(2222)
        registers[52] = -180
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p8564
        ::p2226::
        tick(2226)
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_got_color"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\010aimbot_logs_gradient"
        registers[45] = (0)
        goto p7498
        ::p2236::
        registers[46] = (83)
        registers[47] = (78)
        registers[48] = (255)
        goto p2060
        ::p2240::
        tick(2240)
        registers[15] = (2)
        registers[16] = (3);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p545
        ::p2244::
        tick(2244)
        registers[53] = registers[39];
        registers[50] = registers[50](unpack_range(53, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        goto p3979
        ::p2250::
        tick(2250)
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p493
        ::p2256::
        tick(2256)
        registers[46] = (120)
        registers[47] = (25)
        registers[48] = (true)
        goto p1538
        ::p2260::
        tick(2260)
        registers[47] = registers[44]["spacers"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["label"]
        registers[50] = "\010spacer_body_yaw_"..registers[43]
        goto p6973
        ::p2264::
        registers[33]["type"] = "Off"
        registers[33]["value"] = 0
        registers[33]["inverter"] = false
        goto p3540
        ::p2268::
        tick(2268)
        registers[4] = environment["require"]
        registers[5] = "gamesense/csgo_weapons";
        registers[(4)] = registers[(4)](registers[5])
        goto p1120
        ::p2272::
        tick(2272)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[48] = v
            branch_taken = true
        end
        if branch_taken then
            goto p3410
        end
        goto p8911
        ::p2281::
        tick(2281)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["global"] = registers[48]
        goto p8228
        ::p2285::
        tick(2285)
        registers[29] = registers[21]["visuals"]
        registers[29] = registers[29]["stubs"]
        registers[29] = registers[29]["aimbot_logs"]
        goto p4844
        ::p2289::
        registers[45][registers[46]] = registers[47]
        registers[46] = "px"
        a = D.f213
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "read_icon"
        goto p247
        ::p2297::
        tick(2297)
        registers[46] = registers[21]["visuals"]
        registers[46] = registers[46]["fast_ladder"]
        if registers[46] == registers[0] then
            goto p7529
        end
        goto p6298
        ::p2301::
        tick(2301)
        registers[47] = registers[43]
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        registers[46] = new_frame(3)
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["defensive"]
        registers[49] = registers[45]
        goto p3238
        ::p2308::
        registers[42]["legs_offset_2"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["slider"]
        registers[45] = "\010animations_legs_jitter_time"
        registers[46] = (1)
        goto p8985
        ::p2313::
        tick(2313);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(4)
        registers[52] = registers[47]["type"]
        registers[53] = "Center"
        registers[54] = "Random"
        registers[55] = "Spin"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["values"]
        registers[54] = "Double"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        goto p6704
        ::p2331::
        tick(2331)
        registers[14] = "aa"
        registers[15] = "anti-aimbot angles"
        registers[16] = "enabled";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["enabled"] = registers[13]
        registers[13] = {
        }
        registers[14] = registers[2]["reference"]
        goto p3559
        ::p2339::
        tick(2339)
        registers[46] = registers[44]["def_yaw_static_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        goto p1144
        ::p2344::
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        goto p9346
        ::p2348::
        a = D.f214
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[49] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f215
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[50] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f216
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[51] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f217
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[52] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[53] = "get_defensive_yaw_double_side"
        goto p8160
        ::p2354::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_distortion_randomize"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p6920
        ::p2366::
        registers[44] = {
        }
        registers[45] = new_frame(2)
        registers[46] = registers[21]["antiaim"]
        registers[46] = registers[46]["conditions"]
        goto p2301
        ::p2371::
        tick(2371)
        registers[16] = environment["string"]
        registers[16] = registers[16]["byte"]
        registers[17] = "$"
        registers[18] = (1)
        registers[19] = (1);
        registers[16] = registers[16](unpack_range(19, registers, 17))
        registers[15] = (registers[15] - registers[16])
        registers[15] = (registers[15] - 405)
        registers[15] = 666947531 + registers[15];
        registers[10] = registers[10](unpack_range(15, registers, 11))
        goto p3507
        ::p2382::
        tick(2382)
        registers[45] = environment["cvar"]
        registers[45] = registers[45]["cl_csm_translucent_shadows"]
        registers[46] = environment["cvar"]
        registers[46] = registers[46]["cl_csm_entity_shadows"]
        registers[47] = environment["cvar"]
        goto p5008
        ::p2388::
        tick(2388)
        registers[23][registers[44]] = registers[45]
        registers[44] = "player_connect_full"
        a = D.f218
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2599
        ::p2392::
        registers[35]["active"] = registers[36]
        a = D.f219
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f220
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8955
        ::p2402::
        tick(2402)
        registers[56] = (registers[52]..registers[56])
        registers[56] = "] \010yaw_modifier_custom_"..registers[56]
        registers[56] = (registers[52]..registers[56])
        registers[56] = "\012<gray>\012<dot> \013["..registers[56]
        goto p9031
        ::p2407::
        tick(2407)
        registers[52] = -180
        registers[53] = (180)
        registers[54] = (0)
        goto p1099
        ::p2411::
        tick(2411)
        registers[24] = "AA"
        registers[25] = "Fake lag"
        registers[23] = registers[23](registers[24], registers[25])
        registers[24] = registers[2]["group"]
        goto p4255
        ::p2422::
        registers[45] = "Rage"
        registers[46] = "Weapon type"
        registers[47] = "Weapon type"
        goto p1861
        ::p2428::
        tick(2428)
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        goto p3004
        ::p2432::
        tick(2432)
        registers[55] = "Hidden"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = new_frame(5)
        registers[55] = registers[49]["type"]
        goto p2891
        ::p2443::
        tick(2443)
        registers[46] = registers[25]["antiaim"]
        registers[47] = registers[25]["builder"];
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[43]["edgeyaw"] = registers[44]
        goto p4979
        ::p2448::
        tick(2448)
        registers[45] = registers[41]["enemy_resolver"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["enemy_resolver_output"] = registers[42]
        registers[42] = {
        }
        registers[41]["hitchance"] = registers[42]
        registers[42] = registers[41]["hitchance"]
        goto p3877
        ::p2456::
        tick(2456)
        registers[45][registers[46]] = registers[47]
        registers[46] = "capture"
        a = D.f221
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p253
        ::p2463::
        tick(2463)
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        goto p4750
        ::p2467::
        tick(2467)
        registers[45] = registers[41]["watermark"]
        registers[46] = new_frame(2)
        registers[47] = registers[41]["watermark_style"]
        registers[48] = "CS2"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48];
        registers[42] = registers[42](unpack_range(46, registers, 43))
        goto p3951
        ::p2474::
        tick(2474)
        registers[51] = (14)
        registers[52] = (0)
        registers[53] = (true)
        goto p8375
        ::p2479::
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p2428
        ::p2483::
        tick(2483)
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Hidden"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p3099
        ::p2502::
        tick(2502)
        registers[53] = registers[46]
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["right"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_right_randomize_"..registers[43]
        goto p2858
        ::p2509::
        tick(2509)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p80
        ::p2519::
        tick(2519)
        registers[51] = "\012<gray>\012<dot> \013Time \010hidden_yaw_modifier_meta_delay_time_"..registers[43]
        registers[52] = (5)
        registers[53] = (30)
        goto p3314
        ::p2523::
        tick(2523)
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["viewmodel"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["viewmodel_offset_z"] = registers[42]
        goto p1308
        ::p2528::
        a = D.f222
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["cfg"]
        registers[43] = registers[43](registers[44], registers[45])
        goto p7365
        ::p2534::
        tick(2534)
        registers[56] = "Zurab"
        registers[57] = "Distortion"
        registers[58] = "Refraction"
        registers[59] = "Delayed"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        q[3] = registers[53]
        q[4] = registers[54]
        q[5] = registers[55]
        q[6] = registers[56]
        q[7] = registers[57]
        q[8] = registers[58]
        q[9] = registers[59]
        goto p1011
        ::p2540::
        tick(2540)
        registers[53] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[53] + 0
        n = (registers[52] + 0)
        v = (registers[51] - U)
        goto p5317
        ::p2542::
        tick(2542)
        registers[13] = environment["string"]
        registers[13] = registers[13]["byte"]
        registers[14] = "\020\168|"
        goto p2240
        ::p2546::
        registers[4] = environment["require"]
        registers[5] = "gamesense/entity"
        registers[(4)](registers[5])
        goto p2268
        ::p2551::
        tick(2551)
        registers[13] = registers[13] + 124
        registers[13] = 1323413325 + registers[13]
        registers[14] = environment["string"]
        registers[14] = registers[14]["byte"]
        registers[15] = "M\182G\131\024"
        registers[16] = (4)
        goto p8361
        ::p2558::
        tick(2558)
        registers[55] = (16)
        registers[56] = (1)
        registers[57] = (true)
        registers[58] = ""
        goto p4458
        ::p2568::
        tick(2568)
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["values"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        goto p7085
        ::p2583::
        tick(2583)
        registers[57] = "setup_command"
        a = D.f223
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[56](registers[57], registers[58])
        registers[56] = registers[11]["set_callback"]
        goto p8023
        ::p2588::
        a = D.f224
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "update"
        a = D.f225
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "shutdown"
        a = D.f226
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = registers[21]["visuals"]
        if registers[29] == registers[0] then
            goto p8300
        end
        goto p411
        ::p2599::
        registers[23][registers[44]] = registers[45]
        registers[44] = "update_callbacks"
        a = D.f227
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[23][registers[44]] = registers[45]
        registers[44] = registers[11]["set_callback"]
        registers[45.0] = "shutdown"
        goto p2982
        ::p2606::
        tick(2606)
        registers[49] = registers[44]["delay"]
        registers[49] = registers[49]["builder_type"]
        registers[48]["builder_type"] = registers[49]
        registers[35][registers[47]] = registers[48]
        registers[47] = (#registers[36])
        registers[47] = registers[47] + 1
        registers[48] = {
        }
        registers[48]["state_name"] = registers[43]
        registers[49] = registers[44]["yaw_modifiers"]
        goto p6736
        ::p2616::
        tick(2616)
        registers[43] = environment["cvar"]
        registers[43] = registers[43]["cam_idealdist"]
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["get_int"]
        goto p4010
        ::p2620::
        tick(2620)
        a = D.f228
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f229
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f230
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p532
        ::p2624::
        tick(2624)
        registers[43] = "setup_command"
        a = D.f231
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[42](registers[43], registers[44])
        goto p4472
        ::p2628::
        registers[56] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        registers[53] = new_frame(2)
        goto p9634
        ::p2632::
        registers[46] = registers[44]["def_pitch"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["set"]
        registers[48] = "Double"
        goto p180
        ::p2636::
        tick(2636)
        registers[61] = "\194\176"
        registers[62] = (1);
        registers[54] = registers[54](unpack_range(62, registers, 55))
        goto p8166
        ::p2640::
        tick(2640)
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        goto p7960
        ::p2644::
        tick(2644)
        registers[50] = "%"
        registers[51] = (1)
        registers[52] = {
        }
        goto p5746
        ::p2648::
        tick(2648)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[41] = registers[21]["config"]
        registers[42] = {
        }
        a = D.f232
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6
        ::p2653::
        tick(2653)
        registers[54] = "Random"
        registers[55] = "Spin"
        registers[56] = "Skitter"
        goto p6352
        ::p2657::
        registers[42][registers[47]] = registers[48]
        registers[47] = "get_weapon_type"
        a = D.f233
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2008
        ::p2661::
        registers[67] = "u"
        registers[68] = (1)
        registers[69] = {
        }
        registers[69][101] = "Inf"
        goto p276
        ::p2666::
        tick(2666)
        if registers[43] then
            goto p9177
        end
        goto p2926
        ::p2668::
        tick(2668)
        a = D.f234
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = "is_double_tap"
        a = D.f235
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        goto p2719
        ::p2682::
        registers[20][registers[23]] = registers[22]
        goto p105
        ::p2684::
        registers[55] = registers[47]["values"]
        registers[56] = "Double"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        registers[55] = environment["unpack"]
        goto p2810
        ::p2690::
        tick(2690)
        a = D.f236
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 42
        a = a[z]
        z = registers
        q = (47)
        z = z[q]
        q = registers
        m = 48
        q = q[m]
        a[z] = q
        registers[47] = "set_hitchance"
        a = D.f237
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1833
        ::p2700::
        registers[50] = "\012<gray>\012<func> \013Yaw \010yaw_builder_type_"..registers[43]
        registers[51] = new_frame(2)
        registers[52] = "Default"
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53];
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        goto p9285
        ::p2709::
        tick(2709)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "other"
        goto p4717
        ::p2714::
        tick(2714)
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p591
        ::p2719::
        registers[11] = "is_on_shot_antiaim"
        a = D.f238
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = "is_minimum_damage"
        a = D.f239
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6865
        ::p2726::
        tick(2726)
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        registers[50] = "\010yaw_modifier_type_"..registers[43]
        registers[51] = new_frame(5)
        registers[52] = "Off"
        goto p4153
        ::p2731::
        registers[15] = "force body aim";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["body_aim"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p5897
        ::p2736::
        tick(2736)
        registers[47] = registers[42]["reset"];
        registers[45](registers[46], registers[47])
        registers[45] = registers[11]["set_callback"]
        registers[46] = "shutdown"
        goto p7596
        ::p2741::
        tick(2741)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = environment["unpack"]
        goto p3414
        ::p2746::
        tick(2746)
        registers[53] = "Double"
        registers[54] = "Spin"
        registers[55] = "Sway"
        goto p2534
        ::p2750::
        tick(2750)
        registers[27] = (0.65)
        registers[28] = -0.65
        registers[29] = (0.35)
        goto p7625
        ::p2754::
        tick(2754)
        registers[55] = registers[50]["slots"]
        z = registers[22]
        registers[57] = z;
        registers[(56)] = z["slider"]
        registers[58] = "_"..registers[43]
        registers[58] = (registers[54]..registers[58])
        registers[58] = "] \010hidden_delay_custom_"..registers[58]
        registers[58] = (registers[54]..registers[58])
        registers[58] = "\012<gray>\012<dot> \013["..registers[58]
        registers[59] = (1)
        goto p5992
        ::p2763::
        tick(2763)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p8804
        ::p2767::
        tick(2767)
        registers[(46)](unpack_range(49, registers, 47))
        goto p4385
        ::p2769::
        tick(2769)
        registers[41]["aimbot_logs_got_label"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["color_picker"]
        registers[44] = "\010aimbot_logs_got_color"
        registers[45] = (201)
        registers[46] = (178)
        registers[47] = (88)
        registers[48] = (255);
        registers[42] = registers[42](unpack_range(48, registers, 43))
        goto p2226
        ::p2800::
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\012<gray>\012<dot> \013X"
        registers[45] = -100
        registers[46] = (100)
        goto p7092
        ::p2805::
        tick(2805)
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[56]
        registers[74] = (true)
        registers[(71)](unpack_range(74, registers, 72))
        goto p3269
        ::p2810::
        registers[56] = registers[48]
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["left"] = registers[50]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\010delay_double_right_"..registers[43]
        goto p4139
        ::p2817::
        registers[14] = registers[2]["reference"]
        a = registers
        z = 15;
        a[z] = "aa"
        registers[16] = "other"
        goto p6017
        ::p2822::
        tick(2822)
        registers[18] = "__zenit_render_guard"
        registers[19] = registers[15]
        registers[(16)](unpack_range(19, registers, 17))
        goto p8656
        ::p2826::
        tick(2826)
        registers[24][registers[38]] = registers[39]
        a = registers
        z = 38;
        a[z] = "remove_config"
        a = D.f240
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "load_config"
        a = D.f241
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        goto p8074
        ::p2835::
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_PITCHTIMER"..registers[43]
        registers[50] = (1)
        goto p7104
        ::p2839::
        tick(2839)
        registers[46] = registers[44]["def_yaw_distortion_minus"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p3203
        ::p2845::
        tick(2845)
        registers[53] = registers[47]["values"]
        registers[54] = "Double"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["right"] = registers[48]
        registers[48] = {
        }
        registers[47]["custom"] = registers[48]
        registers[48] = registers[47]["custom"]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        goto p7883
        ::p2858::
        registers[51] = (0)
        registers[52] = (100)
        registers[53] = (0)
        registers[54] = (true)
        goto p7075
        ::p2863::
        tick(2863)
        a = D.f242
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[18] = environment["entity"]
        goto p920
        ::p2867::
        tick(2867)
        a = D.f243
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25][registers[26]] = registers[27]
        registers[26] = "capture_original"
        goto p9560
        ::p2871::
        registers[32][registers[53]] = registers[54]
        registers[53] = "is_invalid_tick_cleaner_enabled"
        a = D.f244
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        goto p853
        ::p2876::
        tick(2876)
        registers[56] = "Custom"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        registers[55] = environment["unpack"]
        registers[56] = registers[48]
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["randomize"] = registers[50]
        registers[49] = {
        }
        registers[47]["hidden"] = registers[49]
        registers[49] = registers[47]["hidden"]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["combobox"]
        registers[52] = "\010hidden_delay_mode_"..registers[43]
        registers[53] = registers[38];
        registers[50] = registers[50](unpack_range(53, registers, 51))
        goto p2483
        ::p2891::
        registers[56] = "Default"
        registers[57] = "Smart"
        registers[58] = "Fluctuate"
        registers[59] = "Random"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        q[3] = registers[57]
        q[4] = registers[58]
        q[5] = registers[59]
        goto p1991
        ::p2905::
        tick(2905)
        registers[45] = (200)
        goto p368
        ::p2907::
        tick(2907)
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        goto p3295
        ::p2921::
        tick(2921)
        registers[40] = registers[40]["cl_csm_world_shadows"]
        registers[41] = environment["cvar"]
        registers[41] = registers[41]["cl_foot_contact_shadows"]
        registers[42] = environment["cvar"]
        goto p6023
        ::p2926::
        a = registers
        z = 43;
        a[z] = 150
        goto p9177
        ::p2929::
        tick(2929)
        registers[47] = (true)
        registers[(44)](unpack_range(47, registers, 45))
        goto p4516
        ::p2932::
        tick(2932)
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["label"]
        registers[50] = "\010spacer_yaw_"..registers[43]
        registers[48] = registers[48](registers[49], registers[50])
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = environment["unpack"]
        registers[51] = registers[46]
        goto p1061
        ::p2939::
        tick(2939)
        registers[46] = registers[44]["def_pitch_left_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p5819
        ::p2943::
        tick(2943)
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "weapon type"
        registers[15] = "weapon type";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p3574
        ::p2949::
        registers[59] = (16)
        registers[60] = (1)
        registers[61] = (true)
        goto p7079
        ::p2953::
        tick(2953)
        registers[46] = (0)
        registers[47] = (100)
        registers[48] = (100)
        registers[49] = (true)
        goto p7947
        ::p2965::
        registers[24][registers[38]] = registers[39]
        registers[38] = "read_db"
        a = D.f245
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        goto p908
        ::p2970::
        tick(2970)
        if registers[15] then
            goto p2371
        end
        goto p3293
        ::p2974::
        tick(2974)
        registers[55] = (true)
        registers[56] = "\194\176"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        goto p5425
        ::p2982::
        a = D.f246
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[44](registers[45], registers[46])
        registers[44] = registers[11]["set_callback"]
        registers[45] = "post_config_load"
        goto p4448
        ::p2987::
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p9679
        ::p2995::
        tick(2995)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[57] = v
            branch_taken = true
        end
        if branch_taken then
            goto p4509
        end
        goto p683
        ::p3004::
        registers[42]["options"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["slider"]
        registers[45] = "\010animations_move_lean"
        registers[46] = -1
        registers[47] = (100)
        registers[48] = -1
        registers[49] = (true)
        goto p2644
        ::p3012::
        tick(3012)
        registers[25]["builder_or_defensive"] = registers[26]
        registers[26] = new_frame(2)
        registers[27] = registers[21]["switch"]
        goto p8577
        ::p3022::
        tick(3022)
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p8345
        ::p3026::
        tick(3026)
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p7137
        ::p3031::
        tick(3031)
        registers[18] = "finish_command"
        registers[19] = registers[13];
        registers[17](registers[18], registers[19])
        goto p1435
        ::p3035::
        registers[25] = "clear_state"
        a = D.f247
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = "aim_miss"
        goto p4423
        ::p3040::
        tick(3040)
        registers[43]["reset"] = registers[44]
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        registers[46] = "\012<gray>\012<func> \013Freestanding"
        goto p3899
        ::p3044::
        registers[44]["manual_arrows_cs2_color"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["color_picker"]
        registers[47] = "\012<gray>\012<dot> \013Accent Color\010manual_arrows_ts_cl1"
        registers[48] = (175)
        goto p9137
        ::p3049::
        tick(3049)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[53] = v
            branch_taken = true
        end
        if branch_taken then
            goto p7569
        end
        goto p264
        ::p3051::
        tick(3051);
        registers[30] = registers[30]()
        a = D.f248
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f249
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[32] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f250
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f251
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f252
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f253
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f254
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f255
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f256
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p550
        ::p3062::
        tick(3062)
        registers[43] = registers[11]["clamp"]
        registers[44] = registers[1][154]
        a = registers
        z = (45)
        q = registers
        m = 42
        q = q[m]
        m = 0.5
        q = (q + m);
        a[z] = q;
        registers[(44)] = registers[(44)](registers[45])
        registers[45] = (16)
        registers[46] = (30);
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[42] = registers[43]
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["checkbox"]
        registers[45] = "\012<gray>\012<dot> \013Fakelag Exploit Tick"
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["antiaim"]
        goto p6968
        ::p3081::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p4681
        ::p3085::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Fluctuate"
        goto p8635
        ::p3089::
        tick(3089)
        registers[46] = {
        }
        registers[45]["textures"] = registers[46]
        registers[46] = {
        }
        registers[45]["visible_keys"] = registers[46]
        registers[46] = {
        }
        registers[45]["current_keys"] = registers[46]
        registers[45]["published_frame"] = -1
        registers[45]["published_count"] = 0
        registers[45]["planting_start_timee"] = registers[0]
        goto p3699
        ::p3099::
        registers[53] = environment["unpack"]
        registers[54] = registers[48]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["type"] = registers[50]
        registers[50] = registers[49]["type"]
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["set"]
        goto p5864
        ::p3107::
        a = D.f257
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "create_config"
        a = D.f258
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2826
        ::p3124::
        tick(3124);
        registers[26](registers[27], registers[28])
        registers[26] = {
        }
        registers[27] = environment["cvar"]
        registers[27] = registers[27]["sv_maxusrcmdprocessticks_holdaim"]
        registers[28] = "apply"
        a = D.f259
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[29] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p7707
        ::p3131::
        tick(3131)
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Distortion randomize\010defensive_yaw_distortion_randomize"..registers[43]
        registers[50] = (0)
        a = registers
        z = 51;
        a[z] = 100
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "%"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_distortion_randomize"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Distortion +\010defensive_yaw_distortion_plus"..registers[43]
        registers[50] = (0)
        goto p5930
        ::p3153::
        tick(3153)
        registers[47] = registers[44]["body_yaw"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        registers[50] = "\012<gray>\012<func> \013Body Yaw \010body_yaw_type_"..registers[43]
        registers[51] = new_frame(4)
        registers[52] = "Off"
        registers[53] = "Static"
        registers[54] = "Opposite"
        registers[55] = "Jitter"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        goto p5839
        ::p3167::
        tick(3167);
        registers[26](registers[27], registers[28])
        registers[26] = (false)
        a = D.f260
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f261
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[28] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[29] = {
        }
        a = D.f262
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8336
        ::p3174::
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p8124
        ::p3178::
        tick(3178)
        registers[22][registers[25]] = registers[26]
        registers[25] = "get_player_multiplier"
        a = D.f264
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6933
        ::p3187::
        tick(3187)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[48]["type"]
        registers[54] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        goto p9184
        ::p3195::
        tick(3195)
        a = D.f265
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25][registers[26]] = registers[27]
        registers[26] = "setup_command"
        a = D.f266
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25][registers[26]] = registers[27]
        registers[26] = "paint"
        a = D.f267
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1207
        ::p3203::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p926
        ::p3207::
        tick(3207)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["left"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_left_randomize_"..registers[43]
        goto p3406
        ::p3213::
        tick(3213)
        a = D.f268
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[37] = "add_handles"
        a = D.f269
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[37]] = registers[38]
        goto p370
        ::p3218::
        tick(3218)
        registers[48] = registers[42]
        registers[49] = (true)
        registers[50] = ""
        registers[51] = (1);
        registers[43] = registers[43](unpack_range(51, registers, 44))
        goto p9230
        ::p3224::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p9053
        ::p3230::
        registers[15] = "target selection";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["target_selection"] = registers[12]
        goto p1483
        ::p3234::
        tick(3234)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p4744
        ::p3238::
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        z = registers[22]
        registers[48] = z;
        registers[(47)] = z["checkbox"]
        registers[49] = "\010Toggle Builder \010D_"..registers[43]
        registers[47] = registers[47](registers[48], registers[49])
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["toggle_builder"] = registers[47]
        z = registers[22]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010defensive_duration"..registers[43]
        registers[50] = (1)
        registers[51] = (15)
        registers[52] = (15)
        registers[53] = (true)
        registers[54] = "t"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][15] = "Maximum";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p7172
        ::p3261::
        tick(3261)
        registers[13] = "is_quit"
        a = D.f270
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[12][registers[13]] = registers[14]
        goto p5053
        ::p3265::
        registers[46] = registers[44]["def_pitch_right_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p5649
        ::p3269::
        registers[71] = registers[41]["thirdperson_distance"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[56]
        goto p4887
        ::p3273::
        tick(3273)
        if registers[14] then
            goto p9022
        end
        goto p5057
        ::p3276::
        tick(3276)
        registers[65] = (0)
        registers[66] = (true)
        registers[67] = "%"
        registers[68] = (1);
        registers[60] = registers[60](unpack_range(68, registers, 61))
        z = registers[60]
        registers[61] = z;
        registers[(60)] = z["depend"]
        goto p9106
        ::p3283::
        tick(3283)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = {
        }
        registers[53] = (1)
        registers[54] = (#registers[44])
        goto p1183
        ::p3288::
        registers[27] = registers[26]["fakelag_exploit_tick"]
        z = registers[27]
        registers[28] = z;
        registers[(27)] = z["set_callback"]
        registers[29] = registers[25]["sync"];
        registers[27](registers[28], registers[29])
        goto p7938
        ::p3293::
        registers[15] = (187)
        goto p2371
        ::p3295::
        registers[53] = "Double"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        goto p1826
        ::p3314::
        registers[54] = (15)
        registers[55] = (true)
        registers[56] = "t"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        goto p2640
        ::p3324::
        tick(3324)
        registers[55] = "Spin"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        registers[52] = new_frame(2)
        goto p2845
        ::p3328::
        tick(3328)
        registers[49] = "\010Yaw zurab range\010defensive_yaw_zurab_range"..registers[43]
        registers[50] = (0)
        registers[51] = (180)
        goto p936
        ::p3332::
        tick(3332)
        registers[58] = "Random"
        a = registers
        z = 59;
        a[z] = "Timing"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        q[6] = registers[59]
        registers[54] = new_frame(2)
        registers[55] = registers[47]["values"]
        registers[56] = "Custom"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        registers[55] = environment["unpack"]
        registers[56] = registers[48]
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["count"] = registers[50]
        registers[50] = {
        }
        goto p5399
        ::p3347::
        tick(3347)
        if not registers[42] then
            goto p5590
        end
        goto p6240
        ::p3349::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_static_value"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw left\010defensive_yaw_left_value"..registers[43]
        registers[50] = -180
        goto p4685
        ::p3358::
        tick(3358)
        registers[38] = environment["cvar"]
        registers[38] = registers[38]["r_eyegloss"]
        registers[39] = environment["cvar"]
        registers[39] = registers[39]["r_eyes"]
        goto p6846
        ::p3363::
        tick(3363)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[(46)](unpack_range(51, registers, 47))
        goto p2339
        ::p3368::
        a = D.f271
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42]["import"] = registers[43]
        registers[41]["handlers"] = registers[42]
        z = registers[22]
        registers[43] = z;
        registers[(42)] = z["listbox"]
        registers[44] = "\012<gray>\012<func> \013Configs\010andromeda_config_list"
        goto p6841
        ::p3374::
        tick(3374)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p1475
        ::p3378::
        registers[28][registers[29]] = registers[30]
        registers[29] = "console_color"
        a = D.f272
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        goto p2065
        ::p3390::
        registers[54] = "Center"
        registers[55] = "Random"
        registers[56] = "Spin"
        goto p6660
        ::p3394::
        tick(3394)
        registers[43] = registers[19][1];
        registers[41](registers[42], registers[43])
        goto p4531
        ::p3398::
        tick(3398)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p1728
        ::p3406::
        registers[51] = (0)
        registers[52] = (100)
        registers[53] = (0)
        goto p6235
        ::p3410::
        registers[49] = registers[43][registers[48]]
        registers[50] = (registers[49] == "Auto Snipers")
        if registers[50] then
            goto p1930
        end
        goto p6769
        ::p3414::
        registers[52] = registers[46]
        m, x = pack_returns(registers[51](unpack_range(52, registers, 52)))
        m = m + 51 - 1
        top = m
        z = 0
        for f = 51, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["type"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        goto p1036
        ::p3420::
        tick(3420)
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["name"] = registers[42]
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Warmup Config"
        a = D.f273
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["cfg"]
        goto p4017
        ::p3429::
        tick(3429)
        registers[49] = ""
        registers[50] = (0.1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        goto p2523
        ::p3442::
        tick(3442);
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        goto p4360
        ::p3447::
        tick(3447)
        registers[45][registers[46]] = registers[47]
        registers[46] = "swap_buffers"
        a = D.f274
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "begin_capture_frame"
        a = D.f275
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6314
        ::p3461::
        tick(3461)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p2509
        ::p3465::
        tick(3465);
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["native_indicators_gradient"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        goto p5105
        ::p3475::
        tick(3475)
        registers[53] = "Double"
        registers[54] = "Spin"
        registers[55] = "Sway"
        registers[56] = "Fluctuate"
        goto p2126
        ::p3480::
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p8695
        ::p3491::
        tick(3491);
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aspect_ratio_value"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Thirdperson"
        goto p3026
        ::p3496::
        tick(3496)
        registers[46] = registers[44]["toggle_builder"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[(46)](unpack_range(50, registers, 47))
        registers[46] = registers[44]["duration"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p8057
        ::p3507::
        a = D.f276
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[12] = "Y\182\133\027\154\243\1719{H\021D\146\184Q2h9\177\225\014<8$\005xz\201\187\245\161H\158\0113H";
        registers[(11)] = registers[(11)](registers[12])
        a = D.f282
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6802
        ::p3512::
        tick(3512)
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        registers[46] = "\012<gray>\012<func> \013Edge yaw"
        registers[44] = registers[44](registers[45], registers[46])
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        goto p2443
        ::p3517::
        tick(3517)
        registers[35]["target"] = 0
        registers[36] = new_frame(11)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["r_shadows"]
        registers[38] = environment["cvar"]
        goto p6573
        ::p3523::
        tick(3523)
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        registers[44]["manual_arrows_color"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["color_picker"]
        registers[47] = "\012<gray>\012<dot> \013Color\010manual_arrows_cs2_color"
        goto p655
        ::p3529::
        tick(3529)
        registers[55] = (3)
        registers[56] = (true)
        registers[57] = ""
        registers[58] = (1);
        registers[50] = registers[50](unpack_range(58, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        goto p4096
        ::p3540::
        registers[33]["freestanding"] = false
        registers[32]["body_yaw"] = registers[33]
        registers[32]["freestanding"] = false
        registers[32]["freestanding_side"] = registers[0]
        registers[32]["edge_yaw"] = false
        registers[32]["force_defensive_active"] = false
        goto p3925
        ::p3547::
        tick(3547)
        registers[50] = (10)
        registers[51] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[51] + 0
        n = (registers[50] + 0)
        v = (registers[49] - U)
        goto p415
        ::p3550::
        tick(3550)
        registers[50] = environment["unpack"]
        registers[51] = registers[46]
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        a = registers
        z = (47)
        a = a[z]
        z = "modifiers"
        q = registers
        m = 48
        q = q[m]
        a[z] = q
        goto p1960
        ::p3559::
        registers[15] = "aa"
        registers[16] = "anti-aimbot angles"
        registers[17] = "pitch"
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["pitch"] = registers[13]
        goto p1125
        ::p3566::
        tick(3566)
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["feature_indicators"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\010feature_indicators_offset"
        registers[45] = -120
        goto p2256
        ::p3574::
        registers[11]["weapon_type"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "rage"
        registers[15] = "aimbot"
        goto p7457
        ::p3581::
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_item"
        a = D.f283
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p5249
        ::p3586::
        tick(3586)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_refraction_spin"]
        goto p6470
        ::p3591::
        tick(3591)
        registers[54] = new_frame(2)
        registers[55] = registers[49]["values"]
        registers[56] = "Solo"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        registers[55] = environment["unpack"]
        registers[56] = registers[48]
        goto p6038
        ::p3598::
        tick(3598)
        registers[51] = {
        }
        registers[51][0] = "Default";
        registers[42] = registers[42](unpack_range(51, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        goto p147
        ::p3605::
        tick(3605)
        registers[48]["builder_type"] = registers[49]
        registers[37][registers[47]] = registers[48]
        registers[47] = registers[44]["spacers"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["label"]
        goto p8474
        ::p3611::
        tick(3611)
        registers[40] = "reset"
        a = D.f284
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 23
        a = a[z]
        z = registers
        q = (40)
        z = z[q]
        q = registers
        m = 41
        q = q[m]
        a[z] = q
        goto p3785
        ::p3619::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        goto p9239
        ::p3628::
        tick(3628)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p9610
        ::p3633::
        tick(3633)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p224
        ::p3642::
        tick(3642)
        registers[25] = {
        }
        registers[24]["pre_prev"] = registers[25]
        registers[25] = {
        }
        goto p452
        ::p3646::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_sway_speed"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Fluctuate value 1\010defensive_pitch_fluctuate_value1"..registers[43]
        goto p6387
        ::p3655::
        tick(3655)
        registers[42] = (0)
        goto p5590
        ::p3657::
        tick(3657)
        registers[52] = (6)
        registers[53] = (true)
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p8353
        ::p3664::
        tick(3664)
        registers[28] = registers[11]["set_callback"]
        registers[29] = "shutdown"
        a = D.f285
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[28](registers[29], registers[30])
        goto p6834
        ::p3669::
        tick(3669)
        registers[51] = new_frame(2)
        registers[52] = registers[42]["weapon"]
        registers[53] = registers[49]
        goto p3283
        ::p3673::
        tick(3673)
        registers[46] = (#registers[43])
        registers[47] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[47] + 0
        n = (registers[46] + 0)
        v = (registers[45] - U)
        goto p2272
        registers[76] = code_metadata
        registers[82] = operand_k
        registers[83] = 57
        a = registers
        z = (83)
        q = registers
        m = 83
        q = q[m]
        m = 320
        q = (q + m);
        a[z] = q
        registers[83] = 5670 + registers[83]
        registers[83] = registers[83] + -5926
        registers[76][178] = registers[83]
        registers[82][5554] = 174
        registers[75] = nil
        registers[76] = nil
        registers[77] = nil
        registers[78] = nil
        registers[79] = nil
        registers[80] = nil
        registers[81] = nil
        registers[82] = nil
        registers[83] = nil
        registers[84] = nil
        registers[85] = nil
        registers[86] = nil
        registers[87] = nil
        goto p175
        ::p3690::
        tick(3690);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["double_tap_stop"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        goto p7727
        ::p3695::
        registers[45] = registers[21]["visuals"]
        registers[45] = registers[45]["fps_optimization"]
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["set_callback"]
        goto p5799
        ::p3699::
        registers[45]["planting_duration"] = 3.2
        registers[45]["last_capture_time"] = 0
        registers[45]["max_items"] = 12
        registers[46] = {
        }
        goto p6338
        ::p3704::
        tick(3704)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[43] + 0
        n = (registers[42] + 0)
        v = (registers[41] - U)
        goto p6956
        ::p3705::
        tick(3705)
        registers[22][registers[25]] = registers[26]
        registers[25] = "predict_vector"
        a = D.f286
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1814
        ::p3709::
        tick(3709)
        registers[25] = environment["unpack"]
        goto p6656
        ::p3711::
        tick(3711)
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (0)
        goto p8150
        ::p3716::
        tick(3716)
        registers[26] = registers[11]["set_callback"]
        registers[27] = "shutdown"
        a = D.f287
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[28] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3124
        ::p3720::
        registers[54] = "Zurab"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_distortion"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p1932
        ::p3726::
        registers[47] = "get_option_value"
        a = D.f288
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "get_value"
        goto p4643
        ::p3731::
        tick(3731)
        a = D.f289
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f290
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f291
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f292
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f293
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f294
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f295
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3611
        ::p3739::
        registers[44] = registers[43]["enabled"]
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["set_callback"]
        registers[46] = registers[31]["update_callback"]
        registers[47] = (true)
        goto p1507
        ::p3744::
        tick(3744);
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        goto p1520
        ::p3751::
        tick(3751)
        registers[32]["defensive_refraction_yaw_state"] = registers[33]
        registers[33] = {
        }
        registers[33]["base_pitch"] = 0
        registers[33]["target_pitch"] = 0
        registers[34] = registers[1][30]
        goto p6145
        ::p3757::
        a = D.f276
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[7] = "\155l]\018\\!^t\180jU\142\0064\143q\144\228\023\147\140,\015"
        goto p6860
        ::p3763::
        a = D.f296
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 24
        a = a[z]
        z = registers
        q = (37)
        z = z[q]
        q = registers
        m = 38
        q = q[m]
        a[z] = q
        a = D.f297
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[38] = "apply_group"
        goto p587
        ::p3781::
        tick(3781)
        registers[45] = environment["tostring"]
        registers[46] = registers[44];
        registers[(45)] = registers[(45)](registers[46])
        goto p8825
        ::p3785::
        a = D.f300
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f301
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f302
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[42] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f303
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[43] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[44] = "net_update_end"
        a = D.f304
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[23][registers[44]] = registers[45]
        goto p4876
        ::p3793::
        tick(3793)
        registers[46] = registers[44]["def_yaw"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p4236
        ::p3811::
        a = D.f305
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "reset_animation"
        a = D.f306
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3447
        ::p3816::
        tick(3816)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p7462
        ::p3822::
        tick(3822)
        registers[41]["viewmodel_offset_x"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\012<gray>\012<dot> \013Y"
        registers[45] = -100
        registers[46] = (100)
        registers[47] = (0)
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (0.1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["viewmodel"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["viewmodel_offset_y"] = registers[42]
        goto p4325
        ::p3838::
        tick(3838)
        registers[51] = (180)
        registers[52] = (180)
        registers[53] = (true)
        goto p9686
        ::p3842::
        registers[54] = (100)
        registers[55] = (0)
        registers[56] = (true)
        goto p536
        ::p3846::
        tick(3846)
        registers[38][15] = "tablet"
        registers[38][16] = "melee"
        registers[38][19] = "equipment"
        a = D.f307
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f308
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f309
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42] = registers[11]["set_callback"]
        goto p2624
        ::p3854::
        tick(3854)
        registers[46] = registers[44]["def_yaw_delayed_delay"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        goto p9768
        ::p3859::
        tick(3859)
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["randomize"] = registers[49]
        goto p2260
        ::p3863::
        tick(3863)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Delayed"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p8109
        ::p3870::
        registers[13] = (126)
        goto p2551
        ::p3872::
        tick(3872)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p257
        ::p3877::
        registers[43] = new_frame(6)
        registers[44] = "Auto Snipers"
        registers[45] = "Desert Eagle"
        registers[46] = "Revolver R8"
        registers[47] = "Pistols"
        goto p7951
        ::p3883::
        tick(3883)
        registers[14] = "paint_ui"
        registers[15] = "player_chat"
        registers[16] = "post_config_load"
        registers[17] = "post_config_save"
        registers[18] = "post_render"
        registers[19] = "pre_config_load"
        registers[20] = "pre_config_save"
        goto p8627
        ::p3891::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(3)
        registers[53] = registers[48]["type"]
        registers[54] = "Side"
        registers[55] = "Side Reworked"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        goto p7267
        ::p3899::
        registers[44] = registers[44](registers[45], registers[46])
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        registers[46] = registers[25]["antiaim"]
        goto p7055
        ::p3903::
        tick(3903)
        registers[46]["andromeda/cs2/person.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12Zm0 15c6 0 10 4 10 10v3H6v-3c0-6 4-10 10-10Z\"/></svg>"
        registers[46]["andromeda/cs2/freestanding.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 3 7 12h6v8H7l9 9 9-9h-6v-8h6L16 3Zm0 5.5 2.5 2.5h-5L16 8.5ZM15 13h2v6h-2v-6Zm1 10.5L13.5 21h5L16 23.5Z\"/></svg>"
        registers[46]["andromeda/cs2/warning.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 3 31 29H1L16 3Zm-2 9v9h4v-9h-4Zm0 11v4h4v-4h-4Z\"/></svg>"
        goto p9248
        ::p3907::
        tick(3907)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_refraction_down"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_SPINREFRACTION"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p526
        ::p3921::
        tick(3921)
        registers[53] = "Double"
        registers[54] = "Custom"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        goto p8444
        ::p3925::
        registers[32]["safehead_active"] = false
        registers[32]["delay_packets"] = 0
        registers[32]["delay_next_switch_packet"] = 1
        goto p7780
        ::p3929::
        tick(3929)
        registers[50] = (0)
        registers[51] = {
        }
        registers[52] = (false)
        registers[53] = (false)
        registers[54] = (false)
        a = D.f310
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[55] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f311
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[56] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f312
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f313
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6262
        ::p3939::
        registers[29] = "voice"
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        q[5] = registers[7]
        q[6] = registers[8]
        q[7] = registers[9]
        q[8] = registers[10]
        q[9] = registers[11]
        q[10] = registers[12]
        q[11] = registers[13]
        q[12] = registers[14]
        q[13] = registers[15]
        q[14] = registers[16]
        q[15] = registers[17]
        q[16] = registers[18]
        q[17] = registers[19]
        q[18] = registers[20]
        q[19] = registers[21]
        q[20] = registers[22]
        q[21] = registers[23]
        q[22] = registers[24]
        q[23] = registers[25]
        q[24] = registers[26]
        q[25] = registers[27]
        q[26] = registers[28]
        q[27] = registers[29]
        a = D.f314
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[3] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[4] = registers[3];
        registers[4] = registers[4]()
        registers[5] = registers[2][registers[4]]
        if registers[5] then
            goto p271
        end
        goto p8485
        ::p3947::
        registers[46] = "Double Tap"
        registers[47] = "Hide Shots"
        registers[48] = "Standing"
        goto p503
        ::p3951::
        registers[41]["watermark_cs2_gradient"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Crosshair Indicators"
        registers[42] = registers[42](registers[43], registers[44])
        goto p3566
        ::p3956::
        tick(3956)
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p6652
        ::p3969::
        tick(3969)
        registers[53] = "\010hidden_delay_double_randomize_"..registers[43]
        registers[54] = (0)
        registers[55] = (100)
        registers[56] = (0)
        registers[57] = (true)
        registers[58] = "%"
        goto p6224
        ::p3979::
        registers[54] = "Hidden"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = new_frame(6)
        a = registers
        z = (54)
        q = registers
        q = q[49]
        q = q["type"]
        a[z] = q
        registers[55] = "Default"
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        registers[59] = "Timing"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        q[6] = registers[59]
        registers[54] = environment["unpack"]
        registers[55] = registers[48]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["values"] = registers[50]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\010hidden_delay_solo_"..registers[43]
        goto p4275
        ::p4000::
        tick(4000);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        goto p4599
        ::p4005::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        goto p2769
        ::p4010::;
        registers[(43)] = registers[(43)](registers[44])
        if registers[43] then
            goto p2666
        end
        goto p9051
        ::p4013::
        tick(4013)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p989
        ::p4017::
        registers[43] = registers[43](registers[44], registers[45])
        registers[41]["warmup_config"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Load"
        a = D.f316
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        goto p242
        ::p4024::
        tick(4024)
        registers[46] = "\012<gray>\012<func> \013Reset"
        registers[44] = registers[44](registers[45], registers[46])
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        registers[46] = registers[25]["antiaim"]
        registers[47] = registers[25]["builder"];
        registers[44] = registers[44](unpack_range(47, registers, 45))
        goto p3040
        ::p4031::
        tick(4031)
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\010watermark_cs2_gradient"
        registers[45] = (0)
        registers[46] = (255)
        registers[47] = (110)
        goto p7115
        ::p4037::
        tick(4037)
        registers[33]["initialized"] = false
        registers[32]["defensive_refraction_pitch_state"] = registers[33]
        registers[33] = {
        }
        registers[32]["hidden_modifier_meta_states"] = registers[33]
        registers[32]["last_exploit_key_active"] = registers[0]
        goto p5450
        ::p4043::
        tick(4043)
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["slider"]
        registers[45] = "\010animations_legs_offset_1"
        registers[46] = (0)
        goto p1663
        ::p4049::
        tick(4049)
        registers[42] = registers[21]["visuals"]
        registers[43] = {
        }
        registers[42]["animations"] = registers[43]
        registers[42] = registers[21]["visuals"]
        goto p488
        ::p4054::
        tick(4054)
        registers[12]["edge_yaw"] = registers[13]
        registers[13] = {
        }
        registers[14] = registers[2]["reference"]
        goto p5013
        ::p4058::
        tick(4058)
        registers[14] = registers[2]["reference"]
        registers[15] = "aa"
        registers[16] = "other"
        registers[17] = "fake peek"
        goto p6870
        ::p4065::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_left_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch right\010defensive_pitch_right_value"..registers[43]
        goto p8975
        ::p4074::
        tick(4074)
        registers[56] = environment["unpack"]
        registers[57] = registers[48]
        m, x = pack_returns(registers[56](unpack_range(57, registers, 57)))
        m = m + 56 - 1
        top = m
        z = 0
        for f = 56, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[51] = registers[51](unpack_range(top, registers, 52))
        registers[50]["count"] = registers[51]
        registers[51] = {
        }
        registers[50]["slots"] = registers[51]
        registers[51] = (1)
        registers[52] = (10)
        goto p2540
        ::p4085::
        tick(4085)
        registers[62] = (registers[58.0]..registers[62])
        registers[62] = "\012<gray>\012<dot> \013"..registers[62]
        registers[63] = (0)
        registers[64] = (100)
        goto p3276
        ::p4092::
        tick(4092)
        registers[28][registers[29]] = registers[30]
        registers[29] = "clear"
        a = D.f317
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9604
        ::p4096::
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Hidden"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = new_frame(4)
        registers[54] = registers[48]["type"]
        registers[55] = "Center"
        registers[56] = "Random"
        goto p1578
        ::p4105::
        tick(4105)
        registers[27] = registers[21]["antiaim"]
        registers[27] = registers[27]["features"]
        if registers[27] == registers[0] then
            goto p7938
        end
        goto p8113
        ::p4109::
        tick(4109);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["yaw_base"] = registers[13]
        registers[13] = {
        }
        registers[14] = registers[2]["reference"]
        registers[15] = "aa"
        registers[16] = "anti-aimbot angles"
        registers[17] = "yaw"
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["yaw"] = registers[13]
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "anti-aimbot angles"
        registers[16] = "freestanding body yaw";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p7911
        ::p4126::
        tick(4126)
        registers[24] = new_frame(6)
        registers[25] = (1)
        registers[26] = -1
        goto p2750
        ::p4130::
        tick(4130)
        a = D.f318
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_planting_item"
        a = D.f319
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_centered_text"
        a = D.f320
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p8938
        ::p4139::
        registers[53] = (1)
        registers[54] = (16)
        registers[55] = (1)
        registers[56] = (true)
        registers[57] = ""
        registers[58] = (1)
        registers[59] = registers[40];
        registers[50] = registers[50](unpack_range(59, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Default"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p5485
        ::p4153::
        registers[53] = "Center"
        registers[54] = "Random"
        registers[55] = "Spin"
        registers[56] = "Skitter"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        q[5] = registers[56]
        goto p1876
        ::p4170::
        tick(4170)
        registers[16] = "enabled";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["on"] = registers[13]
        registers[13] = registers[2]["reference"]
        goto p6282
        ::p4175::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["values"]
        goto p4285
        ::p4179::
        tick(4179)
        registers[46] = "get_icon_size"
        a = D.f321
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p8210
        ::p4183::
        registers[14] = (167)
        goto p3273
        ::p4185::
        tick(4185)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p4821
        ::p4190::
        tick(4190)
        registers[42]["legs_jitter_time_spacer"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["multiselect"]
        registers[45] = "\010animations_options"
        goto p2004
        ::p4196::
        tick(4196)
        registers[48] = "CS2"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48];
        registers[42] = registers[42](unpack_range(46, registers, 43))
        registers[41]["watermark_display"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["color_picker"]
        registers[44] = "\012<gray>\012<dot> \013Accent Color\010watermark_accent_color"
        registers[45] = (186)
        goto p8452
        ::p4204::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p8306
        ::p4208::
        registers[56] = "\010hitchance_options_"..registers[49]
        registers[57] = registers[52];
        registers[54] = registers[54](unpack_range(57, registers, 55))
        z = registers[54]
        registers[55] = z;
        registers[(54)] = z["depend"]
        registers[56] = registers[25]["ragebot"]
        registers[57] = registers[42]["enabled"]
        registers[58] = registers[51];
        registers[54] = registers[54](unpack_range(58, registers, 55))
        registers[53]["options"] = registers[54]
        goto p4627
        ::p4218::
        registers[28] = "Builder"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["builder"] = registers[26]
        goto p8742
        ::p4223::
        tick(4223)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[52] = v
            branch_taken = true
        end
        if branch_taken then
            goto p1785
        end
        goto p8857
        ::p4225::
        tick(4225)
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["enemy_resolver"] = registers[42]
        goto p1195
        ::p4230::
        tick(4230)
        registers[55] = "Random"
        registers[56] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        goto p2568
        ::p4236::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p3363
        ::p4240::
        tick(4240)
        registers[13] = {
        }
        a = D.f322
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[15] = environment["rawget"]
        registers[16] = environment["_G"]
        goto p4902
        ::p4245::
        tick(4245)
        registers[28] = "Freestanding"
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        q[3] = registers[22]
        q[4] = registers[23]
        q[5] = registers[24]
        q[6] = registers[25]
        q[7] = registers[26]
        q[8] = registers[27]
        q[9] = registers[28]
        registers[20] = {
        }
        goto p351
        ::p4255::
        registers[25] = "AA"
        registers[26] = "Other"
        registers[24] = registers[24](registers[25], registers[26])
        goto p6808
        ::p4259::
        tick(4259)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_delayed_delay"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw delayed randomize\010defensive_yaw_delayed_randomize"..registers[43]
        goto p7025
        ::p4270::
        tick(4270)
        registers[50] = (1)
        registers[51] = (20)
        registers[52] = (0)
        registers[53] = (true)
        goto p7867
        ::p4275::
        registers[53] = (1)
        registers[54] = (16)
        registers[55] = (1)
        registers[56] = (true)
        registers[57] = ""
        registers[58] = (1)
        registers[59] = registers[40];
        registers[50] = registers[50](unpack_range(59, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        goto p9520
        ::p4285::
        registers[55] = "Custom"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        a = registers
        z = (54)
        q = environment
        q = q["unpack"]
        a[z] = q
        registers[55] = registers[46]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["count"] = registers[49]
        registers[49] = {
        }
        registers[48]["slots"] = registers[49]
        registers[49] = (1)
        goto p3547
        ::p4298::
        tick(4298)
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        goto p1316
        ::p4305::
        tick(4305)
        registers[63] = (1);
        registers[55] = registers[55](unpack_range(63, registers, 56))
        registers[54][registers[53]] = registers[55]
        goto p7720
        ::p4309::
        tick(4309)
        registers[19] = "get_weapon_reload"
        a = D.f323
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[18] = environment["entity"]
        registers[19] = "get_flag"
        a = D.f324
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[18] = environment["entity"]
        registers[19] = "lethal"
        goto p9756
        ::p4319::
        tick(4319)
        registers[32][registers[56]] = registers[57]
        registers[56] = "update_pitch"
        a = D.f325
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "set_aa"
        goto p6484
        ::p4325::
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\012<gray>\012<dot> \013Z"
        registers[45] = -100
        goto p8465
        ::p4329::
        tick(4329);
        registers[47] = registers[47](unpack_range(55, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p9576
        ::p4333::
        tick(4333)
        registers[38] = "write_db"
        a = D.f326
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "build_payload"
        a = D.f327
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8185
        ::p4344::
        tick(4344)
        if registers[25] == registers[0] then
            goto p1499
        end
        goto p9591
        ::p4346::
        tick(4346)
        registers[46]["andromeda/cs2/bullets.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M5 10h5v20H5V10Zm1-4h3l1 3H5l1-3Zm8 4h5v20h-5V10Zm1-4h3l1 3h-5l1-3Zm8 4h5v20h-5V10Zm1-4h3l1 3h-5l1-3ZM5 31h5v1H5v-1Zm9 0h5v1h-5v-1Zm9 0h5v1h-5v-1Z\"/></svg>"
        registers[46]["andromeda/cs2/ping.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M7 23h3v6H7v-6Zm5-5h3v11h-3V18Zm5-5h3v16h-3V13Zm5-6h3v22h-3V7Z\"/></svg>"
        registers[46]["andromeda/cs2/crosshair.svg"] = "<svg width=\"40\" height=\"40\" viewBox=\"0 0 40 40\" xmlns=\"http://www.w3.org/2000/svg\"><path stroke=\"white\" stroke-width=\"4\" d=\"M20 0v15M20 25v15M0 20h15M25 20h15\"/></svg>"
        registers[46]["andromeda/cs2/shield.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 1 29 5v10c0 8-5.4 13.4-13 16C8.4 28.4 3 23 3 15V5l13-4Zm0 4L7 7.8V15c0 5.8 3.5 9.7 9 11.8 5.5-2.1 9-6 9-11.8V7.8L16 5Z\"/></svg>"
        goto p3903
        ::p4354::
        tick(4354)
        registers[46] = "sort_items"
        a = D.f328
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_animation_key"
        a = D.f329
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9193
        ::p4360::
        registers[46] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[42]["ground_legs"] = registers[43]
        goto p4043
        ::p4364::
        tick(4364)
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_modifier_right_"..registers[43]
        registers[51] = -180
        registers[52] = (180)
        registers[53] = (0)
        goto p6248
        ::p4370::
        tick(4370)
        registers[44] = "\010aspect_ratio_value"
        registers[45] = (49)
        registers[46] = (200)
        registers[47] = (49)
        goto p9373
        ::p4375::
        registers[15] = "minimum hit chance";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["minimum_hitchance"] = registers[12]
        goto p7324
        ::p4379::
        tick(4379)
        registers[44] = "\010thirdperson_distance"
        a = registers
        z = 45;
        a[z] = 10
        registers[46] = (200)
        registers[47] = (100)
        goto p4953
        ::p4385::
        tick(4385)
        registers[46] = registers[11]["set_callback"]
        registers[47] = "paint_ui"
        registers[48] = registers[45]["update"]
        goto p5654
        ::p4389::
        registers[12] = environment["string"]
        registers[12] = registers[12]["byte"]
        registers[13] = "7G`"
        registers[14] = (3)
        registers[15] = (3)
        goto p269
        ::p4401::
        tick(4401)
        registers[54] = (0)
        registers[55] = (true)
        registers[56] = "\194\176"
        goto p1849
        ::p4405::
        tick(4405)
        registers[53] = registers[44]["def_yaw"]
        a = registers
        z = 54;
        a[z] = "Distortion"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p2839
        ::p4411::
        registers[25][registers[26]] = registers[27]
        registers[26] = registers[21]["antiaim"]
        if registers[26] == registers[0] then
            goto p7938
        end
        goto p4105
        ::p4423::
        a = D.f330
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = "aim_hit"
        goto p5982
        ::p4429::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["scope"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "misc"
        registers[14] = "settings"
        registers[15] = "dpi scale"
        goto p9478
        ::p4436::
        tick(4436)
        registers[46] = new_frame(4)
        registers[47] = "Off"
        registers[48] = "Static"
        goto p4907
        ::p4440::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["clantag"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "visuals"
        registers[14] = "player esp"
        registers[15] = "dormant";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p2181
        ::p4448::
        a = D.f331
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[44](registers[45], registers[46])
        registers[44] = registers[1][81]
        goto p9453
        ::p4453::
        tick(4453)
        registers[49] = registers[49]["hidden"]
        registers[48]["modifiers"] = registers[49]
        registers[49] = registers[44]["yaw_modifiers"]
        registers[49] = registers[49]["builder_type"]
        goto p3605
        ::p4458::
        registers[59] = (1)
        registers[60] = registers[40];
        registers[51] = registers[51](unpack_range(60, registers, 52))
        z = registers[51]
        registers[52] = z;
        registers[(51)] = z["depend"]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["builder_type"]
        registers[55] = "Hidden"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = new_frame(6)
        goto p1346
        ::p4468::
        tick(4468)
        registers[45] = "\010antiaim_fakelag_exploit_tick"
        registers[46] = (16)
        registers[47] = (30)
        goto p3218
        ::p4472::
        registers[42] = registers[11]["set_callback"]
        registers[43] = "run_command"
        a = D.f332
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8100
        ::p4491::
        tick(4491);
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p8872
        ::p4495::
        registers[47] = new_frame(2)
        a = registers
        z = (48)
        q = registers
        q = q[42]
        q = q["air_legs"]
        a[z] = q
        registers[49] = "Static"
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[42]["air_legs_weight"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["label"]
        registers[45] = "\010animations_air_legs_spacer"
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p8461
        ::p4509::
        registers[58] = registers[52][registers[57]]
        registers[59] = {
        }
        z = registers[23]
        registers[61] = z;
        registers[(60)] = z["slider"]
        registers[62] = "_"..registers[49]
        registers[62] = (registers[58]..registers[62])
        registers[62] = "\010hitchance_"..registers[62]
        goto p4085
        ::p4516::
        tick(4516)
        registers[44] = registers[11]["set_callback"]
        registers[45] = "pre_config_save"
        registers[46] = registers[31]["reset"];
        registers[44](registers[45], registers[46])
        goto p7532
        ::p4521::
        tick(4521)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        a = registers
        z = (49)
        q = environment
        q = q["unpack"]
        a[z] = q
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_spin_speed"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p6062
        ::p4531::
        tick(4531)
        registers[41] = {
        }
        registers[21]["builder"] = registers[41]
        registers[41] = environment["ipairs"]
        registers[42] = registers[19]
        m, x = pack_returns(registers[41](unpack_range(42, registers, 42)))
        z = 0
        for f = 41, 43 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(41)]
        n = registers[42]
        U = registers[43]
        goto p5147
        ::p4537::
        tick(4537)
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        registers[44]["manual_arrows_ts_cl1"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["color_picker"]
        a = registers
        z = 47;
        a[z] = "\012<gray>\012<dot> \013Desync Color\010manual_arrows_ts_cl2"
        registers[48] = (0)
        registers[49] = (200)
        registers[50] = (255)
        registers[51] = (255);
        registers[45] = registers[45](unpack_range(51, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        registers[44]["manual_arrows_ts_cl2"] = registers[45]
        do
            local f = (41)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[41] = registers[21]["antiaim"]
        registers[42] = {
        }
        goto p1672
        ::p4570::
        tick(4570)
        registers[57] = "Random"
        registers[58] = "Timing"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        q[5] = registers[57]
        q[6] = registers[58]
        registers[53] = new_frame(2)
        goto p8828
        ::p4575::
        registers[20] = "get_simtime"
        a = D.f333
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[21] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[19][registers[20]] = registers[21]
        goto p1778
        ::p4579::
        tick(4579)
        registers[51][200] = "21:9";
        registers[42] = registers[42](unpack_range(51, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["aspect_ratio"]
        goto p3491
        ::p4599::
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(4)
        registers[52] = registers[47]["type"]
        registers[53] = "Center"
        registers[54] = "Random"
        goto p3324
        ::p4607::
        registers[6] = environment["require"]
        registers[7] = "gamesense/base64";
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = environment["require"]
        goto p355
        ::p4612::
        tick(4612)
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw spin right\010defensive_yaw_spin_right_value"..registers[43]
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (180)
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p1084
        ::p4620::
        tick(4620)
        a = D.f334
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[23][registers[44]] = registers[45]
        registers[44] = "aim_miss"
        a = D.f335
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p5245
        ::p4627::
        registers[54] = (1)
        registers[55] = (#registers[52])
        registers[56] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[56] + 0
        n = (registers[55] + 0)
        v = (registers[54] - U)
        goto p2995
        ::p4631::
        tick(4631)
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        registers[51] = "\010hidden_yaw_mode_"..registers[43]
        registers[52] = new_frame(3)
        registers[53] = "Static"
        registers[54] = "Side"
        registers[55] = "Side Reworked"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55];
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        goto p8243
        ::p4643::
        a = D.f336
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "update_hitchance"
        a = D.f337
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "run_command"
        a = D.f338
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "finish_command"
        a = D.f339
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "paint"
        goto p6561
        ::p4656::
        if registers[12] then
            goto p6525
        end
        goto p7203
        ::p4658::
        tick(4658)
        registers[47] = (0)
        registers[48] = (true)
        registers[49] = "t"
        registers[50] = (1)
        goto p3598
        ::p4674::
        tick(4674)
        registers[13] = (478)
        goto p2102
        ::p4676::
        tick(4676)
        registers[12] = "set_callback"
        a = D.f340
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = "random_int"
        goto p1323
        ::p4681::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        goto p9534
        ::p4685::
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p7982
        ::p4690::
        tick(4690)
        registers[48] = (200)
        a = D.f341
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[49] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[(44)](unpack_range(49, registers, 45))
        do
            local f = (24)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[24] = {
        }
        goto p7795
        ::p4696::
        registers[53] = (200)
        registers[54] = (12)
        registers[55] = (true)
        registers[56] = "t"
        goto p8841
        ::p4701::
        tick(4701)
        registers[41]["list"] = registers[42]
        z = registers[22]
        registers[43] = z;
        registers[(42)] = z["textbox"]
        registers[44] = "\012<gray>\012<dot> \013Config name\010andromeda_config_name"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["cfg"]
        goto p3420
        ::p4708::
        registers[57] = "%"
        registers[58] = (1);
        registers[50] = registers[50](unpack_range(58, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Default"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p8591
        ::p4717::
        registers[15] = "duck peek assist";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        a = registers
        z = (11)
        a = a[z]
        z = "fakeduck"
        q = registers
        m = 12
        q = q[m]
        a[z] = q
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "other"
        registers[15] = "log misses due to spread";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["log_spread"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p8536
        ::p4731::
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Double"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_spin_speed"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p3461
        ::p4738::
        tick(4738)
        registers[45]["icon_path_prefixes"] = registers[46]
        registers[46] = {
        }
        registers[46]["andromeda/cs2/cancel.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 2a14 14 0 1 0 0 28 14 14 0 0 0 0-28Zm6.8 18.7-2.1 2.1L16 18.1l-4.7 4.7-2.1-2.1 4.7-4.7-4.7-4.7 2.1-2.1 4.7 4.7 4.7-4.7 2.1 2.1-4.7 4.7 4.7 4.7Z\"/></svg>"
        registers[46]["andromeda/cs2/hc.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><circle cx=\"16\" cy=\"16\" r=\"10\" fill=\"none\" stroke=\"white\" stroke-width=\"3\"/><path fill=\"none\" stroke=\"white\" stroke-width=\"3\" stroke-linecap=\"round\" d=\"M8 24 24 8\"/><path fill=\"none\" stroke=\"white\" stroke-width=\"2\" stroke-linecap=\"round\" d=\"M4 16h7M21 16h7\"/></svg>"
        registers[46]["andromeda/cs2/bomb_c4.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M12 3h8v3h-8V3Zm-2 5h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H10a3 3 0 0 1-3-3V11a3 3 0 0 1 3-3Zm1 5v8h10v-8H11Zm12-10 2 2-2 2-2-2 2-2ZM5 5l2-2 2 2-2 2-2-2Zm22 11h4v2h-4v-2ZM1 16h4v2H1v-2Zm22 10 2 2-2 2-2-2 2-2ZM7 26l2 2-2 2-2-2 2-2Z\"/></svg>"
        goto p4346
        ::p4744::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Sway"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p5392
        ::p4750::
        registers[42]["air_legs"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["slider"]
        registers[45] = "\010animations_air_legs_weight"
        goto p2953
        ::p4763::
        tick(4763)
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_gradient"] = registers[42]
        goto p4049
        ::p4767::
        registers[47]["switch"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_modifier_solo_value_"..registers[43]
        registers[51] = -180
        goto p9693
        ::p4772::
        registers[53] = registers[48]["slots"]
        z = registers[22]
        registers[55] = z;
        registers[(54)] = z["slider"]
        registers[56] = "_"..registers[43]
        goto p2402
        ::p4776::
        tick(4776)
        registers[13] = (156)
        goto p7771
        ::p4778::
        tick(4778)
        registers[52] = (1)
        registers[53] = (16)
        registers[54] = (1)
        registers[55] = (true)
        registers[56] = ""
        goto p5284
        ::p4784::
        tick(4784)
        registers[32][registers[56]] = registers[57]
        registers[56] = "update_yaw_jitter"
        a = D.f342
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "update_hidden"
        a = D.f343
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "update_yaw"
        a = D.f344
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p4319
        ::p4794::
        tick(4794)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        a = registers
        z = (48)
        q = registers
        q = q[25]
        q = q["antiaim"]
        a[z] = q
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p8493
        ::p4802::
        tick(4802)
        registers[46]["bomb_planting"] = "andromeda/cs2/bomb_c4.svg"
        registers[46]["dt"] = "andromeda/cs2/bullets.svg"
        registers[46]["ping"] = "andromeda/cs2/ping.svg"
        registers[46]["force"] = "andromeda/cs2/crosshair.svg"
        registers[46]["safe"] = "andromeda/cs2/shield.svg"
        registers[46]["body"] = "andromeda/cs2/person.svg"
        registers[46]["fs"] = "andromeda/cs2/freestanding.svg"
        registers[46]["fatal"] = "andromeda/cs2/warning.svg"
        registers[46]["damage"] = "andromeda/cs2/damage.svg"
        registers[46]["osaa"] = "andromeda/cs2/timer.svg"
        goto p9619
        ::p4813::
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        q[3] = registers[48]
        q[4] = registers[49];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["watermark"]
        registers[46] = new_frame(2)
        registers[47] = registers[41]["watermark_style"]
        goto p4196
        ::p4821::
        registers[53] = registers[48]["type"]
        registers[54] = "Skitter"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        goto p7519
        ::p4829::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[41] = environment["ipairs"]
        registers[42] = registers[19]
        goto p107
        ::p4839::
        tick(4839)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["violence_hblood"]
        q = registers[(36)]
        q[1] = registers[37]
        registers[35]["cvars"] = registers[36]
        goto p6360
        ::p4844::
        z = registers[29]
        registers[30] = z;
        registers[(29)] = z["set_callback"]
        registers[31] = registers[28]["update"]
        registers[32] = (true)
        registers[(29)](unpack_range(32, registers, 30))
        goto p8300
        ::p4849::
        tick(4849)
        q = registers[(36)]
        q[1] = registers[37]
        registers[35]["cvars"] = registers[36]
        registers[34]["Bloom"] = registers[35]
        registers[35] = {
        }
        registers[35]["target"] = 0
        registers[36] = new_frame(5)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["r_dynamic"]
        goto p3358
        ::p4858::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw value\010defensive_yaw_static_value"..registers[43]
        goto p2070
        ::p4870::
        a = {
            unpack(arguments, 1, argument_count),
        }
        registers[1] = a[1]
        registers[2] = nil
        a = upvalues[1]
        a[2][a[1]] = registers[2]
        a = upvalues[0]
        a[2][a[1]] = registers[0]
        a = upvalues[2];
        registers[2] = a[2][a[1]]
        goto p6634
        ::p4876::
        registers[44] = "post_render"
        a = D.f345
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[23][registers[44]] = registers[45]
        registers[44] = "pre_render"
        goto p4620
        ::p4881::
        tick(4881)
        if registers[27] == registers[0] then
            goto p1331
        end
        goto p8258
        ::p4883::
        tick(4883)
        registers[54] = registers[48]["values"]
        registers[55] = "Double"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        goto p9036
        ::p4887::;
        registers[71](registers[72], registers[73])
        registers[71] = registers[41]["viewmodel"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[66]
        registers[74] = (true)
        registers[(71)](unpack_range(74, registers, 72))
        registers[71] = registers[41]["viewmodel_fov"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[67];
        registers[71](registers[72], registers[73])
        goto p1156
        ::p4898::
        tick(4898)
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["yaw_jitter"] = registers[13]
        goto p8945
        ::p4902::
        registers[17] = "__zenit_render_guard"
        registers[15] = registers[15](registers[16], registers[17])
        registers[16] = environment["type"]
        goto p8899
        ::p4907::
        registers[49] = "Moonwalk"
        registers[50] = "Kangaroo"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        q[4] = registers[50];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p2463
        ::p4913::
        tick(4913)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(4)
        registers[52] = registers[47]["type"]
        registers[53] = "Center"
        goto p5988
        ::p4921::
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p4491
        ::p4926::
        tick(4926)
        registers[56] = registers[49]["values"]
        registers[57] = "Custom"
        q = registers[(55)]
        q[1] = registers[56]
        q[2] = registers[57]
        goto p4074
        ::p4930::
        tick(4930)
        registers[45] = registers[25]["cfg"]
        registers[43] = registers[43](registers[44], registers[45])
        registers[41]["delete"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["button"]
        goto p6006
        ::p4945::
        tick(4945)
        registers[57] = (registers[53]..registers[57])
        registers[57] = "] \010hidden_yaw_modifier_custom_"..registers[57]
        registers[57] = (registers[53]..registers[57])
        registers[57] = "\012<gray>\012<dot> \013["..registers[57]
        a = registers
        z = 58;
        a[z] = -180
        registers[59] = (180)
        goto p8224
        ::p4953::
        registers[48] = (true)
        registers[49] = "ft"
        registers[50] = (1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        goto p8215
        ::p4970::
        tick(4970)
        registers[5] = "aim_miss"
        registers[6] = "console_input"
        registers[7] = "finish_command"
        goto p5869
        ::p4979::
        registers[44] = registers[21]["visuals"]
        registers[45] = registers[21]["visuals"]
        registers[45] = registers[45]["stubs"]
        if registers[45] then
            goto p9266
        end
        goto p7000
        ::p4996::
        tick(4996)
        registers[32][registers[53]] = registers[54]
        registers[53] = "unset_aa"
        a = D.f346
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "is_hidden_enabled"
        goto p1383
        ::p5002::
        tick(5002)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p1542
        ::p5008::
        registers[47] = registers[47]["cl_csm_world_shadows_in_viewmodelcascade"]
        q = registers[(36)]
        q[1] = registers[37]
        q[2] = registers[38]
        q[3] = registers[39]
        q[4] = registers[40]
        q[5] = registers[41]
        q[6] = registers[42]
        q[7] = registers[43]
        q[8] = registers[44]
        q[9] = registers[45]
        q[10] = registers[46]
        q[11] = registers[47]
        registers[35]["cvars"] = registers[36]
        registers[34]["Shadows"] = registers[35]
        goto p8599
        ::p5013::
        registers[15] = "aa"
        a = registers
        z = 16;
        a[z] = "anti-aimbot angles"
        registers[17] = "yaw jitter"
        goto p4898
        ::p5018::
        tick(5018)
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["label"]
        registers[44] = "\012<gray>\012<dot> \013Miss"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p2074
        ::p5024::
        tick(5024)
        registers[45]["capture_items"] = registers[46]
        registers[46] = {
        }
        registers[45]["render_items"] = registers[46]
        goto p3089
        ::p5028::
        tick(5028)
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        registers[53] = "Skitter"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        goto p8155
        ::p5038::
        tick(5038)
        registers[41] = registers[21]["visuals"]
        registers[42] = {
        }
        registers[41]["widgets"] = registers[42]
        registers[41] = registers[21]["visuals"]
        goto p7408
        ::p5043::
        registers[55] = "Hidden"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = new_frame(6)
        goto p7660
        ::p5048::
        tick(5048)
        registers[16] = (1)
        a = registers
        z = 17;
        a[z] = 2;
        registers[14] = registers[14](unpack_range(17, registers, 15))
        goto p9022
        ::p5053::
        registers[13] = "skip_native_cleanup"
        a = D.f347
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[12][registers[13]] = registers[14]
        goto p4240
        ::p5057::
        registers[14] = environment["string"]
        registers[14] = registers[14]["byte"]
        registers[15] = "Em"
        goto p5048
        ::p5061::
        registers[52] = (180)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        goto p5516
        ::p5069::
        tick(5069);
        registers[46](registers[47], registers[48])
        goto p9394
        ::p5071::
        tick(5071)
        registers[54] = registers[47]["type"]
        registers[55] = "Default"
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        goto p3332
        ::p5076::
        tick(5076)
        if registers[41] ~= registers[0] then
            goto p4531
        end
        goto p5472
        ::p5078::
        tick(5078)
        registers[45] = environment["cvar"]
        registers[45] = registers[45]["c_maxdistance"]
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["get_int"];
        registers[(45)] = registers[(45)](registers[46])
        if registers[45] then
            goto p368
        end
        goto p2905
        ::p5084::
        registers[53] = (180)
        a = registers
        z = 54;
        a[z] = 0
        registers[55] = (true)
        registers[56] = "\194\176"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        goto p4185
        ::p5095::
        tick(5095);
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_spin_right_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch spin speed\010defensive_pitch_spin_speed"..registers[43]
        goto p725
        ::p5105::
        registers[44] = "\012<gray>\012<func> \013Aimbot Logs"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        goto p751
        ::p5113::
        tick(5113)
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["meta_delay_cycle"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        goto p2519
        ::p5119::
        tick(5119)
        registers[27] = registers[21]["switch"]
        registers[28] = "Ragebot"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["ragebot"] = registers[26]
        registers[26] = new_frame(2)
        goto p1633
        ::p5125::
        tick(5125)
        registers[44] = (10)
        goto p7111
        ::p5143::
        tick(5143)
        registers[29] = registers[21]["ragebot"]
        registers[29] = registers[29]["hold_aim_ticks"]
        if registers[29] == registers[0] then
            goto p3664
        end
        goto p7904
        ::p5147::
        tick(5147)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[42] = z;
            registers[43] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p8448
        end
        goto p8704
        ::p5149::
        tick(5149)
        registers[74] = (true)
        registers[(71)](unpack_range(74, registers, 72))
        a = registers
        z = (71)
        q = registers
        q = q[41]
        q = q["aspect_ratio_value"]
        a[z] = q
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[55];
        registers[71](registers[72], registers[73])
        registers[71] = registers[41]["thirdperson"]
        goto p2805
        ::p5160::
        tick(5160)
        a = D.f348
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[43][registers[45]] = registers[46]
        registers[45] = "update_callbacks"
        goto p7583
        ::p5164::
        tick(5164)
        registers[57] = "paint"
        a = D.f349
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[56](registers[57], registers[58])
        registers[56] = registers[11]["set_callback"]
        goto p2583
        ::p5169::
        a = D.f350
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = "is_slow_motion"
        goto p2668
        ::p5174::
        registers[32][registers[53]] = registers[54]
        a = D.f351
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[53] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f352
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f353
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[55] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[56] = "update_delay"
        a = D.f354
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "update_body_yaw"
        a = D.f363
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "get_hidden_meta_modifier_add"
        a = D.f364
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = "get_yaw_modifier_add"
        a = D.f365
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p4784
        ::p5190::
        tick(5190)
        registers[43] = environment["cvar"]
        registers[43] = registers[43]["cam_idealdist"]
        if not registers[43] then
            goto p2666
        end
        goto p2616
        ::p5202::
        registers[14] = "aa"
        registers[15] = "anti-aimbot angles"
        registers[16] = "freestanding";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p7943
        ::p5207::
        tick(5207)
        registers[13] = (registers[13] >= 476)
        if not registers[13] then
            goto p2102
        end
        goto p4674
        ::p5210::
        tick(5210)
        registers[33] = (0)
        registers[34] = (0)
        registers[35] = (0);
        registers[32] = registers[32](unpack_range(35, registers, 33))
        goto p7141
        ::p5222::
        tick(5222)
        registers[52] = (180)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        goto p5290
        ::p5232::
        tick(5232)
        do
            local f = (31)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[31] = {
        }
        registers[31]["weapon_type"] = ""
        registers[31]["weapon_ready"] = false
        registers[31]["peeking"] = false
        registers[31]["air"] = false
        registers[31]["on_land"] = false
        registers[31]["moving"] = false
        goto p6107
        ::p5241::
        registers[49] = "\010DEFENSIVE_LEFTREFRACTION"..registers[43]
        registers[50] = -180
        registers[51] = (180)
        goto p814
        ::p5245::
        registers[23][registers[44]] = registers[45]
        registers[44] = "aim_hit"
        a = D.f368
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[45] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2388
        ::p5249::
        registers[46] = "measure_planting_item"
        a = D.f369
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_planting_progress_circle"
        goto p4130
        ::p5254::
        tick(5254)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p973
        ::p5258::
        tick(5258)
        registers[51][0] = "Off";
        registers[42] = registers[42](unpack_range(51, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["overpredict"] = registers[42]
        goto p8544
        ::p5265::
        tick(5265)
        a = D.f370
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[43][registers[45]] = registers[46]
        do
            local f = (44)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[44] = registers[11]["set_callback"]
        registers[45] = "shutdown"
        a = D.f371
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[44](registers[45], registers[46])
        a = D.f372
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45] = registers[21]["visuals"]
        if registers[45] == registers[0] then
            goto p7529
        end
        goto p2297
        ::p5279::
        registers[53] = (true)
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p6045
        ::p5284::
        registers[57] = (1)
        registers[58] = registers[40];
        registers[49] = registers[49](unpack_range(58, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        goto p7041
        ::p5290::
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        registers[53] = "Double"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        goto p3207
        ::p5300::
        tick(5300)
        registers[42]["fps_optimization"] = registers[43]
        registers[42] = registers[21]["visuals"]
        z = registers[24]
        registers[44] = z;
        registers[(43)] = z["multiselect"]
        registers[45] = "\010fps_optimization_options"
        registers[46] = new_frame(7)
        registers[47] = "3D Sky"
        registers[48] = "Fog"
        registers[49] = "Shadows"
        registers[50] = "Blood"
        registers[51] = "Decals"
        registers[52] = "Bloom"
        registers[53] = "Other"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        q[4] = registers[50]
        q[5] = registers[51]
        q[6] = registers[52]
        q[7] = registers[53];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        goto p6192
        ::p5317::
        tick(5317)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[54] = v
            branch_taken = true
        end
        if branch_taken then
            goto p2754
        end
        goto p1256
        ::p5326::
        a = D.f373
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_player_name"
        a = D.f374
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6501
        ::p5331::
        tick(5331)
        registers[58] = "Timing"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        q[5] = registers[57]
        q[6] = registers[58]
        registers[53] = environment["unpack"]
        registers[54] = registers[48]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[47]["values"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010delay_solo_"..registers[43]
        goto p4778
        ::p5341::
        tick(5341)
        registers[56] = (1)
        registers[57] = (true)
        registers[58] = ""
        goto p598
        ::p5345::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_zurab_range"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p1389
        ::p5351::
        a = D.f375
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p4930
        ::p5355::
        tick(5355)
        registers[57] = "shutdown"
        a = D.f376
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[56](registers[57], registers[58])
        goto p1801
        ::p5359::
        tick(5359)
        registers[53] = registers[48]["type"]
        registers[54] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = environment["unpack"]
        goto p5113
        ::p5364::
        registers[46] = registers[44]["def_yaw_refraction_right"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p3956
        ::p5368::
        tick(5368)
        registers[45][registers[46]] = registers[47]
        registers[46] = "shutdown"
        a = D.f377
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = registers[21]["visuals"]
        if registers[46] == registers[0] then
            goto p4385
        end
        goto p2
        ::p5376::
        tick(5376)
        registers[29] = new_frame(11)
        registers[30] = "generic"
        registers[31] = "head"
        registers[32] = "chest"
        goto p90
        ::p5381::
        registers[54] = "t"
        registers[55] = (1);
        registers[47] = registers[47](unpack_range(55, registers, 48))
        goto p4259
        ::p5385::
        registers[11] = (registers[11] - 313)
        a = registers
        z = 11
        q = registers
        q = q[11]
        m = 417
        q = q - m;
        a[z] = q
        registers[11] = registers[11] + 426
        registers[11] = -138277198 + registers[11]
        goto p2081
        ::p5392::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_fluctuate_value1"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p5254
        ::p5399::
        registers[49]["slots"] = registers[50]
        registers[50] = (1)
        registers[51] = (10)
        registers[52] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[52] + 0
        n = (registers[51] + 0)
        v = (registers[50] - U)
        goto p3049
        registers[82] = operand_k
        registers[76] = code_metadata
        registers[83] = constant_cache[7]
        registers[84] = "\163";
        registers[(83)] = registers[(83)](registers[84])
        registers[83] = 133 - registers[83]
        registers[84] = constant_cache[7]
        registers[85] = "\221\175\148";
        registers[(84)] = registers[(84)](registers[85])
        registers[83] = (registers[83] - registers[84])
        registers[83] = 21405 + registers[83]
        registers[83] = registers[83] + -21322
        registers[76][5342] = registers[83]
        registers[82][8333] = 1345
        registers[75] = nil
        registers[76] = nil
        registers[77] = nil
        registers[78] = nil
        registers[79] = nil
        registers[80] = nil
        registers[81] = nil
        registers[82] = nil
        registers[83] = nil
        registers[84] = nil
        registers[85] = nil
        registers[86] = nil
        registers[87] = nil
        goto p1346
        ::p5420::
        tick(5420)
        registers[13] = "misc"
        registers[14] = "settings"
        registers[15] = "menu color";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        goto p8690
        ::p5425::
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        goto p7753
        ::p5429::
        registers[31][registers[43]] = registers[44]
        registers[43] = "update_callback"
        a = D.f378
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = registers[36];
        registers[43] = registers[43]()
        if registers[43] == registers[0] then
            goto p8642
        end
        goto p1457
        ::p5437::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_modifier_randomize_"..registers[43]
        goto p7151
        ::p5441::
        tick(5441)
        registers[47] = registers[21]["defensive"]
        registers[47][registers[43]] = registers[44]
        goto p1118
        ::p5446::
        tick(5446)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_sway_right_value"]
        goto p135
        ::p5450::
        registers[32]["last_exploit_charged"] = registers[0]
        registers[32]["inverts"] = 0
        registers[32]["updated"] = false
        registers[32]["simular_data"] = registers[0]
        registers[32]["apex_cycle_counter"] = registers[0]
        registers[32]["apex_phase"] = registers[0]
        goto p2205
        ::p5457::
        tick(5457)
        registers[29] = "aim_hit"
        a = D.f379
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 28
        a = a[z]
        z = registers
        q = (29)
        z = z[q]
        q = registers
        m = 30
        q = q[m]
        a[z] = q
        registers[29] = "aim_miss"
        goto p7563
        ::p5466::
        tick(5466)
        registers[15] = "aimbot"
        registers[16] = "enabled"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["enabled"] = registers[12]
        goto p2943
        ::p5472::
        registers[41] = registers[21]["antiaim"]
        registers[41] = registers[41]["conditions"]
        z = registers[41]
        registers[42] = z;
        registers[(41)] = z["set"]
        goto p3394
        ::p5485::
        registers[53] = new_frame(6)
        registers[54] = registers[47]["type"]
        registers[55] = "Default"
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        goto p5784
        ::p5502::
        tick(5502)
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[42]["move_lean"] = registers[43]
        goto p1399
        ::p5506::
        registers[54] = "Delayed"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p3854
        ::p5510::
        registers[40] = "Solo"
        registers[41] = "Double"
        registers[42] = "Custom"
        q = registers[(39)]
        q[1] = registers[40]
        q[2] = registers[41]
        q[3] = registers[42]
        registers[40] = {
        }
        goto p8381
        ::p5516::
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        goto p8414
        ::p5521::
        tick(5521);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["double_tap_fl"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "double tap quick stop"
        goto p3690
        ::p5528::
        z = registers[23]
        registers[46] = z;
        registers[(45)] = z["combobox"]
        registers[47] = "\010weapon_hitchance"
        registers[48] = registers[43];
        registers[45] = registers[45](unpack_range(48, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        goto p8328
        ::p5539::
        tick(5539)
        registers[41] = registers[41]["features"]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<dot> \013Avoid Backstab"
        registers[42] = registers[42](registers[43], registers[44])
        goto p7714
        ::p5544::;
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["damage_indicator"] = registers[42]
        goto p7231
        ::p5550::
        tick(5550)
        registers[53] = (true)
        registers[54] = "-\194\176"
        registers[55] = (1)
        goto p2714
        ::p5555::
        a = D.f380
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[19] = "to_hex"
        a = D.f381
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[19] = "lerp"
        goto p18
        ::p5562::
        tick(5562)
        registers[54] = "Solo"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        a = registers
        z = (53)
        q = environment
        q = q["unpack"]
        a[z] = q
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["offset"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_modifier_left_"..registers[43]
        registers[51] = -180
        registers[52] = (180)
        registers[53] = (0)
        goto p7019
        ::p5577::
        tick(5577)
        registers[49] = registers[45]
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        registers[47] = {
        }
        registers[44]["spacers"] = registers[47]
        registers[47] = registers[44]["spacers"]
        goto p2932
        ::p5583::
        tick(5583)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_refraction_timer"] = registers[47]
        goto p5942
        ::p5590::
        tick(5590)
        if registers[42] then
            goto p5190
        end
        goto p9228
        ::p5592::
        tick(5592)
        a = D.f382
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "update_planting_state"
        goto p1251
        ::p5596::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p9004
        ::p5606::
        tick(5606)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["set_callback"]
        registers[48] = registers[45]["update"]
        registers[49] = (true)
        goto p2767
        ::p5620::
        tick(5620)
        registers[29] = "push"
        a = D.f383
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "output_console"
        goto p8168
        ::p5625::
        tick(5625)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p6331
        ::p5632::
        tick(5632)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p3907
        ::p5636::
        tick(5636);
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        goto p3022
        ::p5645::
        tick(5645)
        registers[44] = "\010watermark_display"
        registers[45] = new_frame(4)
        registers[46] = "FPS"
        goto p1199
        ::p5649::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p8429
        ::p5654::;
        registers[46](registers[47], registers[48])
        registers[46] = registers[11]["set_callback"]
        registers[47] = "shutdown"
        a = D.f384
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[46](registers[47], registers[48])
        goto p5232
        ::p5660::
        tick(5660)
        registers[42] = registers[42](registers[43], registers[44])
        a = registers
        z = (41)
        a = a[z]
        z = "aspect_ratio"
        q = registers
        m = 42
        q = q[m]
        a[z] = q
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        goto p4370
        ::p5667::
        tick(5667)
        registers[25]["gamesense"] = registers[26]
        registers[25] = registers[2]["macros"]
        registers[25]["dot"] = "\226\128\162"
        registers[25] = registers[2]["macros"]
        registers[25]["func"] = "\194\187"
        z = registers[22]
        registers[26] = z;
        registers[(25)] = z["label"]
        goto p285
        ::p5674::
        registers[56] = registers[40];
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p8176
        ::p5678::
        registers[52] = (89)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_sway_right_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch sway speed\010defensive_pitch_sway_speed"..registers[43]
        registers[50] = (1)
        registers[51] = (15)
        registers[52] = (6)
        goto p557
        ::p5694::;
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(4)
        registers[53] = registers[48]["type"]
        registers[54] = "Center"
        goto p4230
        ::p5723::
        tick(5723)
        registers[48] = registers[47]["value"]
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["set_visible"]
        registers[50] = (false);
        registers[48](registers[49], registers[50])
        registers[47] = {
        }
        registers[44]["delay"] = registers[47]
        registers[47] = registers[44]["delay"]
        goto p7494
        ::p5731::
        registers[46] = "Custom"
        registers[47] = "Auto"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        goto p8420
        ::p5742::
        tick(5742)
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p2033
        ::p5746::
        registers[52][-1] = "Off";
        registers[43] = registers[43](unpack_range(52, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p8270
        ::p5751::
        tick(5751)
        registers[14] = "settings"
        registers[15] = "anti-untrusted";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["anti_untrusted"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p8868
        ::p5757::
        tick(5757)
        registers[57] = ""
        registers[58] = (1)
        registers[59] = registers[40];
        registers[50] = registers[50](unpack_range(59, registers, 51))
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        goto p407
        ::p5764::
        tick(5764)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["values"]
        goto p5562
        ::p5768::
        tick(5768);
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[43]["forward"] = registers[44]
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        goto p4024
        ::p5772::
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch value\010defensive_pitch_static_value"..registers[43]
        registers[50] = -89
        goto p808
        ::p5776::
        tick(5776);
        registers[(46)] = registers[(46)](registers[47])
        if registers[46] ~= "Left ~ Right" then
            goto p1567
        end
        goto p6098
        ::p5779::
        tick(5779)
        registers[49] = "First"
        registers[50] = "Second"
        registers[51] = "Third"
        goto p1334
        ::p5784::
        registers[59] = "Timing"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        q[6] = registers[59]
        registers[54] = new_frame(2)
        a = registers
        z = (55)
        q = registers
        q = q[47]
        q = q["values"]
        a[z] = q
        registers[56] = "Double"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        goto p61
        ::p5794::
        tick(5794)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p9469
        ::p5799::
        registers[47] = registers[41]
        registers[48] = (true)
        registers[(45)](unpack_range(48, registers, 46))
        goto p6728
        ::p5803::
        tick(5803)
        registers[46] = registers[21]["visuals"]
        registers[46] = registers[46]["fps_optimization_options"]
        if registers[46] == registers[0] then
            goto p7353
        end
        goto p6791
        ::p5807::
        tick(5807)
        registers[46] = "Flags"
        registers[47] = "Logging"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        goto p2448
        ::p5814::
        tick(5814)
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(41)]
        n = registers[42]
        U = registers[43]
        goto p1118
        ::p5815::
        registers[36][2] = true
        registers[36][3] = true
        registers[36][4] = true
        goto p6410
        ::p5819::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p7878
        ::p5824::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p4405
        ::p5832::
        tick(5832)
        registers[28]["items"] = registers[29]
        registers[29] = {
        }
        registers[28]["shots"] = registers[29]
        registers[28]["max_items"] = 5
        registers[28]["hold_time"] = 4.2
        goto p5376
        ::p5839::;
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = environment["unpack"]
        goto p6518
        ::p5843::
        tick(5843)
        registers[45][registers[46]] = registers[47]
        registers[46] = "update"
        a = D.f385
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p5368
        ::p5847::
        tick(5847)
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch sway left\010defensive_pitch_sway_left_value"..registers[43]
        registers[50] = -89
        goto p9439
        ::p5851::
        registers[15] = "miscellaneous"
        registers[16] = "ping spike"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["ping"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p645
        ::p5859::
        registers[38] = (true)
        registers[39] = (false)
        registers[40] = (true)
        q = registers[(33)]
        q[1] = registers[34]
        q[2] = registers[35]
        q[3] = registers[36]
        q[4] = registers[37]
        q[5] = registers[38]
        q[6] = registers[39]
        q[7] = registers[40]
        goto p7329
        ::p5864::
        registers[52] = "Default";
        registers[50](registers[51], registers[52])
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["combobox"]
        registers[52] = "\010hidden_delay_values_"..registers[43]
        goto p2244
        ::p5869::
        registers[8] = "indicator"
        registers[9] = "net_update_end"
        registers[10] = "net_update_start"
        goto p7656
        ::p5873::
        tick(5873)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p7899
        ::p5887::
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Default"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[48]
        goto p1880
        ::p5895::
        tick(5895)
        registers[53][registers[58]] = registers[59]
        goto p2995
        ::p5897::
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "force body aim on peek";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["body_aim_on_peek"] = registers[12]
        goto p6983
        ::p5903::
        registers[23] = "Air"
        registers[24] = "Air-crouch"
        registers[25] = "Crouch"
        registers[26] = "Crouch-move"
        registers[27] = "Manual"
        goto p4245
        ::p5909::
        registers[46] = registers[44]["def_yaw_delayed_right"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p187
        ::p5915::
        tick(5915)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p195
        ::p5919::
        tick(5919)
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "double tap fake lag limit"
        goto p5521
        ::p5923::
        registers[54] = "Distortion"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_refraction_left"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p6012
        ::p5930::
        registers[51] = (90)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "+\194\176"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][0] = "Off"
        goto p8950
        ::p5942::
        z = registers[22]
        registers[48] = z;
        registers[(47)] = z["label"]
        registers[49] = "\010"
        registers[47] = registers[47](registers[48], registers[49])
        registers[44]["def_pitch_separator"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["combobox"]
        goto p8772
        ::p5948::
        tick(5948)
        registers[38] = registers[38]["r_drawropes"]
        registers[39] = environment["cvar"]
        registers[39] = registers[39]["r_drawsprites"]
        q = registers[(36)]
        q[1] = registers[37]
        q[2] = registers[38]
        q[3] = registers[39]
        registers[35]["cvars"] = registers[36]
        registers[34]["Decals"] = registers[35]
        registers[35] = {
        }
        registers[35]["target"] = 1
        registers[36] = new_frame(1)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["mat_disable_bloom"]
        goto p4849
        ::p5970::
        registers[55] = (true)
        registers[56] = "\194\176"
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        goto p2118
        ::p5982::
        a = D.f386
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = "setup_command"
        a = D.f387
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        goto p6915
        ::p5988::
        registers[54] = "Random"
        registers[55] = "Spin"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        goto p1554
        ::p5992::
        registers[60] = (16)
        registers[61] = (1)
        registers[62] = (true)
        registers[63] = ""
        registers[64] = (1)
        goto p7956
        ::p5998::
        registers[50] = environment["unpack"]
        a = registers
        z = 51
        q = registers
        q = q[46]
        a[z] = q
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["builder_type"] = registers[48]
        goto p2726
        ::p6006::
        registers[45] = "Export"
        a = D.f388
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["cfg"]
        goto p29
        ::p6012::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p5915
        ::p6017::
        registers[17] = "slow motion"
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["slow_motion"] = registers[13]
        registers[13] = {
        }
        goto p4058
        ::p6023::
        registers[42] = registers[42]["cl_csm_viewmodel_shadows"]
        registers[43] = environment["cvar"]
        registers[43] = registers[43]["cl_csm_rope_shadows"]
        registers[44] = environment["cvar"]
        registers[44] = registers[44]["cl_csm_sprite_shadows"]
        goto p2382
        ::p6029::
        registers[48][registers[49]] = registers[50]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        registers[51] = "\010delay_builder_type_"..registers[43]
        registers[52] = new_frame(2)
        registers[53] = "Default"
        registers[54] = "Hidden"
        goto p9474
        ::p6036::
        tick(6036)
        registers[42] = (21)
        goto p3062
        ::p6038::
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["solo"] = registers[50]
        registers[50] = {
        }
        registers[49]["double"] = registers[50]
        registers[50] = registers[49]["double"]
        goto p9596
        ::p6045::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_delay"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch spin left\010defensive_pitch_spin_left_value"..registers[43]
        goto p8979
        ::p6053::;
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["feature_indicators_offset"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        goto p676
        ::p6062::
        registers[49] = "\010Yaw spin left\010defensive_yaw_spin_left_value"..registers[43]
        a = registers
        z = 50;
        a[z] = -180
        registers[51] = (180)
        goto p2222
        ::p6074::
        tick(6074)
        z = registers[23]
        registers[46] = z;
        registers[(45)] = z["hotkey"]
        registers[47] = "\012<gray>\012<dot> \013Hotkey"
        registers[45] = registers[45](registers[46], registers[47])
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        goto p8283
        ::p6079::
        registers[33]["type"] = "180"
        registers[33]["value"] = 0
        registers[33]["add"] = 0
        registers[33]["body"] = 0
        registers[32]["yaw"] = registers[33]
        goto p109
        ::p6098::
        registers[46] = registers[44]["def_pitch"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["set"]
        registers[48] = "Double";
        registers[46](registers[47], registers[48])
        goto p1567
        ::p6105::
        tick(6105)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[56] = v
            branch_taken = true
        end
        if branch_taken then
            goto p6778
        end
        goto p1069
        ::p6107::
        registers[31]["ducked"] = false
        registers[31]["duck_amount"] = 0
        registers[31]["body_yaw"] = 0
        registers[31]["packets"] = 0
        registers[31]["fakelag"] = 0
        registers[32] = registers[3]
        goto p5210
        ::p6114::
        tick(6114)
        registers[15] = "anti-aimbot angles"
        registers[16] = "edge yaw";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p4054
        ::p6118::
        a = D.f389
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f390
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f391
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f392
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f393
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f394
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1509
        ::p6125::
        tick(6125)
        registers[53] = (180)
        registers[54] = (0)
        registers[55] = (true)
        registers[56] = "\194\176"
        goto p7208
        ::p6130::
        registers[45] = registers[25]["builder"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["disable_fakelag"] = registers[42]
        registers[42] = registers[10]["misc"]
        registers[42] = registers[42]["usercmd"]
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["get"];
        registers[(42)] = registers[(42)](registers[43])
        registers[43] = environment["type"]
        goto p8731
        ::p6139::
        registers[57] = registers[48]
        m, x = pack_returns(registers[56](unpack_range(57, registers, 57)))
        m = m + 56 - 1
        top = m
        z = 0
        for f = 56, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[51] = registers[51](unpack_range(top, registers, 52))
        registers[50]["right"] = registers[51]
        z = registers[22]
        registers[52] = z;
        registers[(51)] = z["slider"]
        goto p3969
        ::p6145::;
        registers[34] = registers[34]()
        registers[33]["start_time"] = registers[34]
        registers[33]["spin_dir"] = 1
        goto p4037
        ::p6149::
        m, x = pack_returns(registers[10]())
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[9](unpack_range(top, registers, 10))
        registers[9] = nil
        registers[10] = {
        }
        registers[11] = {
        }
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "rage"
        goto p5466
        ::p6158::
        registers[55] = environment["unpack"]
        registers[56] = registers[48]
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["randomize"] = registers[50]
        registers[49] = {
        }
        registers[47]["custom"] = registers[49]
        registers[49] = registers[47]["custom"]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\010delay_custom_sliders_"..registers[43]
        registers[53] = (2)
        registers[54] = (10)
        registers[55] = (3)
        registers[56] = (true)
        registers[57] = ""
        registers[58] = (1);
        registers[50] = registers[50](unpack_range(58, registers, 51))
        goto p7168
        ::p6176::
        tick(6176)
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(4)
        goto p755
        ::p6181::
        tick(6181)
        registers[46] = "normalize_text"
        a = D.f395
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p8782
        ::p6187::
        tick(6187)
        a = D.f396
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "paint"
        a = D.f397
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p5843
        ::p6192::
        registers[46] = registers[21]["visuals"]
        registers[46] = registers[46]["fps_optimization"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[42]["fps_optimization_options"] = registers[43]
        goto p5038
        ::p6197::
        tick(6197)
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        registers[55] = (1)
        goto p7164
        ::p6224::
        registers[59] = (1);
        registers[51] = registers[51](unpack_range(59, registers, 52))
        z = registers[51]
        registers[52] = z;
        registers[(51)] = z["depend"]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["builder_type"]
        goto p2432
        ::p6230::
        tick(6230)
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "fake lag"
        goto p4170
        ::p6235::
        registers[54] = (true)
        registers[55] = "%"
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        goto p8145
        ::p6240::
        registers[42] = environment["cvar"]
        registers[42] = registers[42]["r_aspectratio"]
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["get_float"];
        registers[(42)] = registers[(42)](registers[43])
        if registers[42] then
            goto p5590
        end
        goto p3655
        ::p6246::
        tick(6246)
        if registers[28] == registers[0] then
            goto p3664
        end
        goto p5143
        ::p6248::
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1)
        goto p4000
        ::p6252::
        tick(6252)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_left_delay_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p6752
        ::p6260::
        tick(6260)
        registers[51] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[51] + 0
        n = (registers[50] + 0)
        v = (registers[49] - U)
        goto p4223
        ::p6262::
        a = D.f398
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[59] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f399
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[60] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f400
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[61] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f401
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[62] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p7851
        ::p6269::
        tick(6269)
        registers[45] = registers[41]["watermark"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["watermark_style"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["multiselect"]
        goto p5645
        ::p6274::
        tick(6274);
        registers[49] = registers[49](unpack_range(58, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p5359
        ::p6282::
        registers[14] = "aa"
        registers[15] = "fake lag"
        registers[16] = "amount";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["amount"] = registers[13]
        goto p2095
        ::p6288::
        tick(6288)
        registers[42]["air_legs_spacer"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["combobox"]
        registers[45] = "\012<gray>\012<dot> \013Ground legs\010animations_ground_legs"
        registers[46] = new_frame(6)
        goto p6302
        ::p6294::
        registers[53] = (true)
        registers[54] = "\194\176"
        registers[55] = (1)
        goto p4329
        ::p6298::
        registers[45] = registers[21]["visuals"]
        registers[45] = registers[45]["fast_ladder"]
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["set_callback"]
        goto p508
        ::p6302::
        registers[47] = "Off"
        registers[48] = "Static"
        registers[49] = "Jitter"
        goto p7123
        ::p6314::
        registers[45][registers[46]] = registers[47]
        registers[46] = "classify"
        a = D.f402
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p6181
        ::p6319::
        tick(6319)
        registers[9] = registers[31]
        registers[31] = nil
        registers[32] = nil
        registers[33] = nil
        registers[34] = (0)
        registers[35] = (0)
        registers[36] = (0)
        registers[37] = (0)
        registers[38] = new_frame(7)
        registers[38][0] = "knife"
        registers[39] = "pistols"
        registers[40] = "smg"
        registers[41] = "rifles"
        goto p498
        ::p6331::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Delayed"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p7980
        ::p6338::
        registers[46]["hc"] = "andromeda/cs2/hc.svg"
        registers[46]["bomb"] = "andromeda/cs2/bomb_c4.svg"
        registers[46]["planted_bomb"] = "andromeda/cs2/bomb_c4.svg"
        goto p4802
        ::p6342::
        tick(6342)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p8996
        ::p6352::
        registers[57] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        q[5] = registers[57];
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        goto p1611
        ::p6360::
        registers[34]["Blood"] = registers[35]
        registers[35] = {
        }
        registers[35]["target"] = 0
        registers[36] = new_frame(3)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["r_drawdecals"]
        registers[38] = environment["cvar"]
        goto p5948
        ::p6368::
        tick(6368)
        registers[14] = "aa"
        a = registers
        z = 15;
        a[z] = "other"
        registers[16] = "leg movement";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[12]["leg_movement"] = registers[13]
        registers[11]["other"] = registers[12]
        registers[10]["antiaim"] = registers[11]
        goto p7226
        ::p6377::
        tick(6377)
        registers[46] = (255)
        registers[47] = (110)
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["native_indicators"]
        goto p3465
        ::p6387::
        registers[50] = -89
        a = registers
        z = 51;
        a[z] = 89
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        goto p1896
        ::p6398::
        tick(6398)
        registers[52] = "\010hidden_yaw_modifier_custom_sliders_"..registers[43]
        registers[53] = (2)
        registers[54] = (10)
        goto p3529
        ::p6402::
        registers[43] = registers[27]["paint_ui"];
        registers[41](registers[42], registers[43])
        do
            local f = (28)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[28] = {
        }
        registers[28]["active"] = false
        registers[29] = {
        }
        goto p5832
        ::p6410::
        registers[36][5] = true
        registers[36][6] = true
        registers[36][7] = true
        registers[36][8] = true
        registers[36][9] = true
        registers[36][10] = true
        registers[36][11] = true
        registers[36][12] = true
        registers[36][13] = true
        registers[36][14] = true
        goto p8738
        ::p6421::
        tick(6421)
        a = D.f403
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17] = environment["client"]
        registers[17] = registers[17]["set_event_callback"]
        goto p3031
        ::p6425::
        tick(6425)
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_left_value"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p8572
        ::p6430::
        tick(6430)
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["meta_offset"] = registers[49]
        goto p1140
        ::p6436::
        tick(6436)
        registers[44] = registers[21]["defensive"]
        registers[44] = registers[44][registers[43]]
        registers[45] = new_frame(2)
        registers[46] = registers[21]["antiaim"]
        registers[46] = registers[46]["conditions"]
        registers[47] = registers[43]
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        registers[46] = registers[44]["def_pitch"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["get"]
        goto p5776
        ::p6446::
        tick(6446)
        registers[41] = environment["ipairs"]
        registers[42] = registers[19]
        m, x = pack_returns(registers[41](unpack_range(42, registers, 42)))
        z = 0
        for f = 41, 43 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p5814
        ::p6451::
        tick(6451)
        registers[46] = "is_enabled"
        a = D.f404
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_gradient_alpha"
        a = D.f405
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1503
        ::p6457::
        tick(6457)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p7591
        ::p6461::
        tick(6461)
        registers[54] = "Default"
        registers[55] = "Smart"
        registers[56] = "Fluctuate"
        goto p4570
        ::p6465::
        registers[45] = "damage_paint"
        a = D.f406
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[30][registers[45]] = registers[46]
        registers[45] = "paint"
        goto p7188
        ::p6470::
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        a = registers
        z = (48)
        q = registers
        q = q[25]
        q = q["antiaim"]
        a[z] = q
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p8042
        ::p6478::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_fluctuate_speed"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        goto p1340
        ::p6484::
        a = D.f407
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 32
        a = a[z]
        z = registers
        q = (56)
        z = z[q]
        q = registers
        m = 57
        q = q[m]
        a[z] = q
        registers[56] = "update_defensive"
        a = D.f408
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[57] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[56]] = registers[57]
        registers[56] = registers[11]["set_callback"]
        goto p5164
        ::p6496::
        registers[44] = registers[25]["ragebot"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["hold_aim_ticks"] = registers[42]
        z = registers[22]
        registers[43] = z;
        registers[(42)] = z["slider"]
        goto p8349
        ::p6501::
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_player_health"
        a = D.f409
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        goto p5620
        ::p6506::
        registers[46] = registers[44]["def_yaw"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["get"];
        registers[(46)] = registers[(46)](registers[47])
        if registers[46] ~= "Left ~ Right" then
            goto p9394
        end
        goto p9445
        ::p6514::
        registers[56] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        registers[53] = new_frame(2)
        goto p4883
        ::p6518::
        registers[51] = registers[46]
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["type"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010body_yaw_value_"..registers[43]
        goto p7747
        ::p6525::
        tick(6525)
        registers[12] = (registers[12] - 1)
        registers[12] = -2118390128 + registers[12]
        registers[13] = 229
        goto p7612
        ::p6530::
        registers[47]["double"] = registers[49]
        registers[49] = registers[47]["double"]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        registers[52] = "\010delay_double_left_"..registers[43]
        registers[53] = (1)
        registers[54] = (16)
        registers[55] = (1)
        registers[56] = (true)
        goto p5757
        ::p6541::
        tick(6541)
        registers[54] = registers[49]["slots"]
        z = registers[22]
        registers[56] = z;
        registers[(55)] = z["slider"]
        registers[57] = "_"..registers[43]
        goto p4945
        ::p6545::
        tick(6545)
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["r_3dsky"]
        q = registers[(36)]
        q[1] = registers[37]
        registers[35]["cvars"] = registers[36]
        registers[34]["3D Sky"] = registers[35]
        goto p1753
        ::p6551::
        tick(6551)
        registers[(25)](registers[26])
        registers[25] = {
        }
        registers[25]["choked_commands"] = 0
        registers[25]["active"] = false
        registers[25]["saved_usercmd"] = registers[0]
        goto p8749
        ::p6561::
        a = D.f410
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        do
            local f = (43)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[43] = {
        }
        registers[44] = (false)
        registers[45] = "is_enabled"
        goto p5160
        ::p6568::;
        registers[71](registers[72], registers[73])
        registers[71] = registers[41]["viewmodel_offset_y"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[69]
        goto p9329
        ::p6573::
        registers[38] = registers[38]["cl_csm_static_prop_shadows"]
        registers[39] = environment["cvar"]
        registers[39] = registers[39]["cl_csm_shadows"]
        registers[40] = environment["cvar"]
        goto p2921
        ::p6578::
        registers[47] = registers[25]["builder"];
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[43]["left"] = registers[44]
        z = registers[24]
        registers[45] = z;
        registers[(44)] = z["hotkey"]
        goto p631
        ::p6598::
        tick(6598)
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        registers[50] = "\010yaw_modifier_values_"..registers[43]
        registers[51] = new_frame(3)
        registers[52] = "Solo"
        goto p3921
        ::p6603::
        tick(6603)
        registers[46] = registers[25]["builder"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[42]["enabled"] = registers[43]
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["multiselect"]
        registers[45] = "\010safe_head_states"
        registers[46] = new_frame(2)
        registers[47] = "Knife"
        registers[48] = "Zeus"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        goto p1224
        ::p6620::
        registers[49] = "%"
        registers[50] = (1)
        registers[51] = {
        }
        goto p5258
        ::p6624::
        tick(6624)
        registers[32]["delay_states"] = registers[33]
        registers[32]["backtrack_cleaner_timer"] = 0
        registers[33] = {
        }
        goto p7632
        ::p6629::
        do
            local f = (41)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        a = D.f411
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f412
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[42] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p1922
        ::p6634::
        registers[(2)]()
        registers[2] = new_frame(27)
        registers[3] = "aim_fire"
        registers[4] = "aim_hit"
        goto p4970
        ::p6641::
        registers[24] = {
        }
        registers[23]["resolved"] = registers[24]
        registers[24] = {
        }
        registers[23]["records"] = registers[24]
        registers[24] = {
        }
        registers[23]["miss_counter"] = registers[24]
        registers[24] = {
        }
        registers[23]["applied"] = registers[24]
        registers[24] = {
        }
        registers[23]["applied_body"] = registers[24]
        goto p9508
        ::p6652::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Refraction"
        goto p3586
        ::p6656::
        tick(6656)
        registers[26] = {
        }
        registers[26][0] = "Always on"
        registers[26][1] = "On hotkey"
        goto p220
        ::p6660::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        a = registers
        z = (53)
        q = environment
        q = q["unpack"]
        a[z] = q
        registers[54] = registers[46]
        goto p3859
        ::p6666::
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        goto p2250
        ::p6670::
        registers[53] = (true)
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p4521
        ::p6674::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["right_randomize"] = registers[48]
        goto p7925
        ::p6694::
        registers[53] = registers[48]["type"]
        registers[54] = "Center"
        registers[55] = "Random"
        goto p7379
        ::p6704::
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["left"] = registers[48]
        goto p4364
        ::p6709::
        tick(6709)
        registers[25] = {
        }
        a = registers
        z = (24)
        a = a[z]
        z = "misses"
        q = registers
        m = 25
        q = q[m]
        a[z] = q
        registers[23]["wraith"] = registers[24]
        goto p4126
        ::p6724::
        tick(6724)
        registers[42] = {
        }
        registers[42]["active"] = false
        registers[42]["hotkey_active"] = false
        goto p868
        ::p6728::
        registers[45] = registers[21]["visuals"]
        if registers[45] == registers[0] then
            goto p7353
        end
        goto p5803
        ::p6731::
        tick(6731)
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_distortion_plus"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p429
        ::p6736::
        registers[48]["modifiers"] = registers[49]
        registers[36][registers[47]] = registers[48]
        registers[47] = (#registers[37])
        goto p8777
        ::p6740::
        tick(6740)
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["checkbox"]
        registers[51] = "\012<gray>\012<dot> \013Safe Yaw \010hidden_yaw_modifier_meta_safe_yaw_"..registers[43]
        registers[49] = registers[49](registers[50], registers[51])
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        goto p3187
        ::p6748::
        tick(6748)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = new_frame(5)
        registers[54] = registers[47]["type"]
        goto p7524
        ::p6752::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p1244
        ::p6757::
        tick(6757)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Distortion"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p6731
        ::p6764::
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "anti-aimbot angles"
        registers[16] = "yaw base"
        goto p4109
        ::p6769::
        registers[50] = (registers[49] == "Scout")
        goto p1930
        ::p6771::
        tick(6771)
        a = D.f413
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_animation_alpha"
        a = D.f414
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_animation_slide"
        goto p5592
        ::p6778::
        registers[57] = registers[44][registers[56]]
        if registers[50] then
            goto p8048
        end
        goto p8118
        ::p6781::
        registers[20] = registers[20](registers[21], registers[22])
        registers[19]["requester"] = registers[20]
        goto p840
        ::p6785::
        registers[11] = {
        }
        registers[12] = "closest_enemy"
        a = D.f415
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = "clamp"
        goto p1796
        ::p6791::
        registers[45] = registers[21]["visuals"]
        registers[45] = registers[45]["fps_optimization_options"]
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["set_callback"]
        registers[47] = registers[41];
        registers[45](registers[46], registers[47])
        goto p7353
        ::p6797::
        tick(6797);
        registers[(26)] = registers[(26)](registers[27])
        z = registers[26]
        registers[27] = z;
        registers[(26)] = z["to_hex"];
        registers[(26)] = registers[(26)](registers[27])
        registers[26] = "\007"..registers[26]
        goto p5667
        ::p6802::
        a = D.f416
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f424
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f425
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[15] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6421
        ::p6808::
        registers[25] = registers[2]["macros"]
        registers[26] = registers[18]["new"]
        registers[27] = "9FCA2BFF"
        goto p8201
        ::p6813::
        tick(6813)
        registers[21]["config"] = registers[22]
        registers[22] = {
        }
        registers[21]["ragebot"] = registers[22]
        registers[22] = {
        }
        registers[21]["antiaim"] = registers[22]
        goto p9095
        ::p6834::
        do
            local f = (27)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[27] = {
        }
        a = registers
        z = 28;
        a[z] = 0
        registers[29] = (0)
        registers[30] = registers[1][30]
        goto p3051
        ::p6841::
        registers[45] = new_frame(1)
        registers[46] = "No configs"
        q = registers[(45)]
        q[1] = registers[46];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        goto p7394
        ::p6846::
        registers[40] = environment["cvar"]
        registers[40] = registers[40]["r_drawtracers_firstperson"]
        registers[41] = environment["cvar"]
        registers[41] = registers[41]["r_dynamiclighting"]
        goto p8008
        ::p6851::
        registers[47]["hidden"] = registers[48]
        registers[48] = registers[47]["hidden"]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        goto p7587
        ::p6855::
        a = D.f426
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = {
        }
        registers[12]["quit_requested"] = false
        goto p3261
        ::p6860::;
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = environment["client"]
        registers[7] = registers[7]["set_event_callback"]
        registers[8] = "player_chat"
        goto p316
        ::p6865::
        registers[10][registers[11]] = registers[12]
        registers[11] = "is_force_baim"
        a = D.f427
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        goto p2026
        ::p6870::
        m, x = pack_returns(registers[14](unpack_range(17, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(13)]
        for f = 1, top - (13) do
            q[(0) + f] = registers[(13) + f]
        end
        registers[12]["fake_peek"] = registers[13]
        registers[13] = registers[2]["reference"]
        goto p6368
        ::p6875::
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        registers[44]["manual_arrows_offset"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["color_picker"]
        registers[47] = "\012<gray>\012<dot> \013Color\010manual_arrows_color"
        registers[48] = (0)
        registers[49] = (200)
        registers[50] = (255)
        goto p9699
        ::p6884::
        tick(6884)
        registers[33] = {
        }
        registers[33]["left"] = 0
        registers[33]["max"] = 0
        registers[32]["defensive"] = registers[33]
        registers[31]["exploits"] = registers[32]
        goto p6319
        ::p6890::
        tick(6890)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p9538
        ::p6895::
        tick(6895)
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        registers[59] = "Timing"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        q[6] = registers[59]
        goto p3591
        ::p6900::
        tick(6900);
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p7383
        ::p6905::
        a = D.f428
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[28] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f430
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[29] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f431
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f432
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f434
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[32] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f435
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f436
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f437
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3213
        ::p6915::
        registers[25] = "update_callbacks"
        a = D.f438
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = registers[21]["ragebot"]
        goto p4344
        ::p6920::
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p6757
        ::p6926::
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[48]["type"]
        registers[54] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p6430
        ::p6933::
        registers[22][registers[25]] = registers[26]
        registers[25] = "get_latency_time"
        a = D.f439
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3705
        ::p6937::
        tick(6937)
        registers[46] = registers[44]["def_yaw"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["set"]
        registers[48] = "Delayed"
        goto p7247
        ::p6941::
        tick(6941)
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["native_indicators"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\010native_indicators_gradient"
        registers[45] = (0)
        goto p6377
        ::p6950::
        tick(6950);
        registers[45] = registers[45](unpack_range(48, registers, 46))
        registers[44]["manual_arrows"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["combobox"]
        registers[47] = "\010manual_arrows_style"
        registers[48] = new_frame(6)
        goto p5779
        ::p6956::
        tick(6956)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[44] = v
            branch_taken = true
        end
        if branch_taken then
            goto p3781
        end
        goto p2648
        ::p6968::
        registers[46] = registers[25]["builder"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[41]["fakelag_exploit_enabled"] = registers[43]
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["slider"]
        goto p4468
        ::p6973::
        registers[48] = registers[48](registers[49], registers[50])
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = environment["unpack"]
        registers[51] = registers[46]
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["body_yaw"] = registers[48]
        registers[47] = {
        }
        registers[44]["body_yaw"] = registers[47]
        goto p3153
        ::p6983::
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        registers[15] = "prefer body aim disablers";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["prefer_body_aim_disablers"] = registers[12]
        goto p1515
        ::p7000::
        registers[45] = {
        }
        goto p9266
        ::p7002::
        tick(7002);
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["thirdperson_distance"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Viewmodel"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["viewmodel"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        registers[44] = "\012<gray>\012<dot> \013Fov"
        goto p1460
        ::p7014::
        tick(7014)
        registers[49] = registers[44]["manual_arrows"];
        registers[45] = registers[45](unpack_range(49, registers, 46))
        registers[44]["manual_arrows_style"] = registers[45]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["slider"]
        goto p774
        ::p7019::
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1)
        goto p2313
        ::p7025::
        registers[50] = (0)
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_delayed_randomize"] = registers[47]
        goto p5441
        ::p7041::
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Default"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(6)
        registers[53] = registers[47]["type"]
        goto p6461
        ::p7047::
        q = registers[(29)]
        q[1] = registers[30]
        q[2] = registers[31]
        q[3] = registers[32]
        q[4] = registers[33]
        q[5] = registers[34]
        q[6] = registers[35]
        q[7] = registers[36]
        q[8] = registers[37]
        q[9] = registers[38]
        q[10] = registers[39]
        q[11] = registers[40]
        registers[28]["hitgroups"] = registers[29]
        registers[29] = "is_enabled"
        a = D.f440
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_gradient_alpha"
        a = D.f441
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p14
        ::p7055::
        registers[47] = registers[25]["builder"];
        registers[44] = registers[44](unpack_range(47, registers, 45))
        registers[43]["freestanding"] = registers[44]
        goto p3512
        ::p7060::
        tick(7060)
        registers[72] = registers[41]["viewmodel_fov"]
        registers[(71)](registers[72])
        registers[71] = registers[59]
        registers[72] = registers[41]["viewmodel_offset_x"]
        registers[(71)](registers[72])
        registers[71] = registers[59]
        registers[72] = registers[41]["viewmodel_offset_y"]
        registers[(71)](registers[72])
        registers[71] = registers[59]
        registers[72] = registers[41]["viewmodel_offset_z"]
        registers[(71)](registers[72])
        registers[71] = registers[41]["aspect_ratio"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[55]
        goto p5149
        ::p7075::
        registers[55] = "%"
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        goto p4298
        ::p7079::
        registers[62] = ""
        registers[63] = (1)
        registers[64] = registers[40];
        registers[55] = registers[55](unpack_range(64, registers, 56))
        registers[54][registers[53]] = registers[55]
        goto p3049
        ::p7085::
        registers[51] = "\010hidden_yaw_modifier_solo_value_"..registers[43]
        registers[52] = -180
        registers[53] = (180)
        registers[54] = (0)
        registers[55] = (true)
        registers[56] = "\194\176"
        goto p8819
        ::p7092::
        registers[47] = (0)
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (0.1)
        goto p8851
        ::p7097::
        tick(7097)
        a = D.f442
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "update_list"
        a = D.f443
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "init_callbacks"
        goto p1947
        ::p7104::
        registers[51] = (20)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "sec"
        registers[55] = (0.1);
        registers[47] = registers[47](unpack_range(55, registers, 48))
        goto p5583
        ::p7111::
        tick(7111)
        registers[45] = environment["cvar"]
        registers[45] = registers[45]["c_maxdistance"]
        if not registers[45] then
            goto p368
        end
        goto p5078
        ::p7115::
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p2467
        ::p7123::
        registers[50] = "Moonwalk"
        registers[51] = "Kangaroo"
        registers[52] = "Jitter[2]"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        q[4] = registers[50]
        q[5] = registers[51]
        q[6] = registers[52]
        goto p3442
        ::p7137::
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["thirdperson"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["slider"]
        goto p4379
        ::p7141::
        registers[31]["velocity"] = registers[32]
        registers[32] = {
        }
        registers[32]["charged"] = false
        goto p6884
        ::p7145::
        tick(7145)
        registers[54] = "\194\176"
        registers[55] = (1);
        registers[47] = registers[47](unpack_range(55, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        goto p9101
        ::p7151::
        registers[51] = (0)
        registers[52] = (100)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "%"
        registers[56] = (1)
        goto p2085
        ::p7158::
        tick(7158)
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_spin_speed"] = registers[47]
        goto p5847
        ::p7164::
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        goto p8833
        ::p7168::
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        goto p7697
        ::p7172::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["duration"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["combobox"]
        registers[49] = "\011Pitch\010defensive_pitch_mode"..registers[43]
        registers[50] = new_frame(8)
        registers[51] = "Disabled"
        registers[52] = "Custom"
        goto p3475
        ::p7183::
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[43] = registers[43](registers[44], registers[45])
        goto p5300
        ::p7188::
        a = D.f444
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[30][registers[45]] = registers[46]
        registers[45] = registers[1][56]
        registers[46] = "paint"
        registers[47] = registers[30]["damage_paint"]
        goto p9259
        ::p7194::
        registers[59] = "Random"
        registers[60] = "Timing"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        q[3] = registers[57]
        q[4] = registers[58]
        q[5] = registers[59]
        q[6] = registers[60]
        registers[55] = new_frame(2)
        registers[56] = registers[49]["values"]
        registers[57] = "Double"
        q = registers[(55)]
        q[1] = registers[56]
        q[2] = registers[57]
        registers[56] = environment["unpack"]
        goto p182
        ::p7203::
        registers[12] = environment["string"]
        registers[12] = registers[12]["len"]
        registers[13] = "\233\250";
        registers[(12)] = registers[(12)](registers[13])
        goto p6525
        ::p7208::
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        goto p6176
        ::p7226::
        registers[11] = {
        }
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "visuals"
        goto p792
        ::p7231::
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Feature Indicators"
        registers[42] = registers[42](registers[43], registers[44])
        goto p6941
        ::p7235::
        tick(7235)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_refraction_timer"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p9124
        ::p7247::;
        registers[46](registers[47], registers[48])
        goto p3496
        ::p7249::
        registers[55] = registers[46]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["offset"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_modifier_left_"..registers[43]
        registers[52] = -180
        goto p6125
        ::p7257::
        tick(7257)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p579
        ::p7261::
        tick(7261)
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p8631
        ::p7267::
        registers[53] = environment["unpack"]
        a = registers
        z = 54
        q = registers
        q = q[46]
        a[z] = q
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["left"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        goto p8786
        ::p7276::
        tick(7276)
        z = registers[23]
        registers[46] = z;
        registers[(45)] = z["checkbox"]
        registers[47] = "\012<gray>\012<func> \013Hitchance Override"
        registers[45] = registers[45](registers[46], registers[47])
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        goto p720
        ::p7281::
        registers[14] = (5)
        registers[15] = (5);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[12] = 402 + registers[12]
        goto p2542
        ::p7304::
        tick(7304)
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["right"] = registers[49]
        goto p9367
        ::p7309::
        tick(7309)
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Per tick\010defensive_pitch_fluctuate_speed"..registers[43]
        registers[50] = (0)
        goto p2474
        ::p7319::
        tick(7319)
        registers[49] = "lua\\"
        registers[50] = "csgo/lua/"
        registers[51] = "csgo\\lua\\"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        q[3] = registers[49]
        q[4] = registers[50]
        q[5] = registers[51]
        goto p4738
        ::p7324::
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "rage"
        goto p465
        ::p7329::
        a = D.f446
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f447
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f448
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f449
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f450
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f451
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f452
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f453
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f454
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[42] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2620
        ::p7340::
        registers[22]["latency_cache"] = registers[23]
        a = D.f455
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[23] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f456
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[24] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25] = "get_ticks"
        a = D.f457
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = "get_overpredict_multiplier"
        a = D.f458
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[22][registers[25]] = registers[26]
        registers[25] = "is_overpredict_enabled"
        a = D.f459
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3178
        ::p7353::
        registers[45] = registers[11]["set_callback"]
        registers[46] = "run_command"
        registers[47] = registers[42]["run_command"];
        registers[45](registers[46], registers[47])
        registers[45] = registers[11]["set_callback"]
        registers[46] = "finish_command"
        goto p820
        ::p7360::
        registers[53] = "Solo"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        goto p2281
        ::p7365::
        registers[41]["import"] = registers[43]
        do
            local f = (41)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[41] = registers[21]["ragebot"]
        goto p424
        ::p7369::
        tick(7369)
        registers[35]["server_anim_states"] = registers[36]
        registers[35]["last_velocity"] = 0
        registers[35]["last_duck_amount"] = 0
        registers[35]["last_weapon"] = registers[0]
        a = D.f460
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f461
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[37] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f462
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f463
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f464
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p9165
        ::p7379::
        registers[56] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        q[4] = registers[56]
        registers[53] = new_frame(2)
        goto p1736
        ::p7383::
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_spin_left_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p9276
        ::p7394::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["cfg"]
        registers[42] = registers[42](registers[43], registers[44])
        goto p4701
        ::p7399::
        registers[11]["pointscale"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        registers[14] = "aimbot"
        goto p8028
        ::p7404::
        registers[20] = environment["entity"]
        registers[20] = registers[20]["get_local_player"];
        registers[20] = registers[20]()
        goto p1073
        ::p7408::
        registers[41] = registers[41]["widgets"]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Aspect Ratio"
        registers[42] = registers[42](registers[43], registers[44])
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p5660
        ::p7415::
        tick(7415)
        registers[45][registers[46]] = registers[47]
        registers[46] = "is_bomb_main_kind"
        a = D.f465
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "find_bomb_subitem_index"
        a = D.f466
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "measure_items"
        a = D.f467
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "measure_item"
        goto p6187
        ::p7427::
        tick(7427)
        registers[36] = registers[33];
        registers[34](registers[35], registers[36])
        registers[34] = registers[33]
        registers[(34)]()
        registers[34] = {
        }
        goto p1591
        ::p7443::
        tick(7443)
        registers[45] = registers[25]["antiaim"]
        registers[46] = registers[25]["builder"]
        registers[47] = registers[41]["fakelag_exploit_enabled"]
        goto p7507
        ::p7447::
        tick(7447)
        a = D.f468
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[43] = registers[43](unpack_range(46, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        goto p7443
        ::p7451::
        tick(7451)
        registers[45] = new_frame(2)
        registers[46] = "CS2"
        registers[47] = "Supremacy"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        goto p9363
        ::p7457::
        registers[16] = "quick stop"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["stop"] = registers[12]
        goto p1260
        ::p7462::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_refraction_spin"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p1856
        ::p7466::
        tick(7466)
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p8079
        ::p7470::
        tick(7470)
        registers[12]["limit"] = registers[13]
        registers[11]["fakelag"] = registers[12]
        registers[12] = {
        }
        registers[13] = {
        }
        registers[14] = registers[2]["reference"]
        registers[15] = "aa"
        registers[16] = "other"
        goto p786
        ::p7478::
        tick(7478)
        registers[49] = {
        }
        registers[48]["custom"] = registers[49]
        registers[49] = registers[48]["custom"]
        z = registers[22]
        registers[51] = z;
        registers[(50)] = z["slider"]
        goto p6398
        ::p7484::
        registers[46] = new_frame(2)
        registers[47] = registers[41]["enemy_resolver_mode"]
        registers[48] = "Custom"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48];
        registers[42] = registers[42](unpack_range(46, registers, 43))
        registers[41]["enemy_resolver_generate"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["multiselect"]
        registers[44] = "\010enemy_resolver_output"
        registers[45] = new_frame(2)
        goto p5807
        ::p7494::
        registers[48] = {
        }
        registers[49] = (1)
        registers[50] = (#registers[46])
        goto p6260
        ::p7498::
        registers[46] = (255)
        registers[47] = (95)
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (1);
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p4763
        ::p7507::;
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[41]["fakelag_exploit_force"] = registers[43]
        registers[43] = {
        }
        goto p1264
        ::p7511::
        tick(7511)
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p7257
        ::p7515::
        registers[35] = {
        }
        registers[35]["target"] = 0
        registers[36] = new_frame(1)
        goto p6545
        ::p7519::
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["global"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        goto p200
        ::p7524::
        registers[55] = "Default"
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        goto p8404
        ::p7529::
        registers[45] = registers[21]["ragebot"]
        if registers[45] == registers[0] then
            goto p1025
        end
        goto p76
        ::p7532::
        registers[44] = registers[11]["set_callback"]
        registers[45] = "shutdown"
        a = D.f469
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[44](registers[45], registers[46])
        goto p8682
        ::p7563::
        a = D.f470
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "player_hurt"
        a = D.f471
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p4092
        ::p7569::
        registers[54] = registers[49]["slots"]
        z = registers[22]
        registers[56] = z;
        registers[(55)] = z["slider"]
        registers[57] = "_"..registers[43]
        goto p2089
        ::p7573::
        tick(7573)
        registers[54] = registers[49]["type"]
        registers[55] = "Default"
        registers[56] = "Smart"
        goto p6895
        ::p7583::
        a = D.f472
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[46] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[43][registers[45]] = registers[46]
        registers[45] = "setup_command"
        goto p5265
        ::p7587::
        registers[51] = "\010hidden_yaw_modifier_type_"..registers[43]
        registers[52] = new_frame(5)
        registers[53] = "Center"
        goto p2653
        ::p7591::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Refraction"
        goto p7966
        ::p7596::
        a = D.f473
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[45](registers[46], registers[47])
        registers[45] = registers[11]["set_callback"]
        registers[46] = "pre_render"
        registers[47] = registers[41];
        registers[45](registers[46], registers[47])
        goto p7618
        ::p7603::
        a = D.f474
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 42
        a = a[z]
        z = registers
        q = (47)
        z = z[q]
        q = registers
        m = 48
        q = q[m]
        a[z] = q
        registers[47] = "is_crouched"
        a = D.f475
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p574
        ::p7612::
        registers[14] = environment["string"]
        registers[14] = registers[14]["len"]
        registers[15] = "\181\228<-";
        registers[(14)] = registers[(14)](registers[15])
        registers[13] = registers[13] + registers[14]
        goto p9436
        ::p7618::
        registers[45] = registers[11]["set_callback"]
        registers[46] = "shutdown"
        a = D.f476
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[45](registers[46], registers[47])
        do
            local f = (34)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        do
            local f = (2)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        goto p997
        ::p7625::
        registers[30] = -0.35
        q = registers[(24)]
        q[1] = registers[25]
        q[2] = registers[26]
        q[3] = registers[27]
        q[4] = registers[28]
        q[5] = registers[29]
        q[6] = registers[30]
        a = D.f477
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[25] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f478
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[26] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f479
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8408
        ::p7632::
        registers[32]["defensive_yaw_double_states"] = registers[33]
        registers[33] = {
        }
        registers[33]["flicker"] = false
        goto p950
        ::p7636::
        tick(7636);
        registers[51] = registers[51](unpack_range(59, registers, 52))
        z = registers[51]
        registers[52] = z;
        registers[(51)] = z["depend"]
        registers[53] = new_frame(2)
        registers[54] = registers[47]["builder_type"]
        registers[55] = "Hidden"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = new_frame(5)
        goto p659
        ::p7644::
        tick(7644)
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["checkbox"]
        registers[45] = "\012<gray>\012<dot> \013Safe Head"
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["antiaim"]
        goto p6603
        ::p7650::
        a = D.f480
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "encode"
        a = D.f481
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        goto p4333
        ::p7656::
        registers[11] = "output"
        registers[12] = "override_view"
        registers[13] = "paint"
        goto p3883
        ::p7660::
        registers[55] = registers[49]["type"]
        registers[56] = "Default"
        registers[57] = "Smart"
        registers[58] = "Fluctuate"
        registers[59] = "Random"
        goto p7971
        ::p7676::
        tick(7676)
        registers[49] = registers[25]["defensive"]
        a = registers
        z = 50
        q = registers
        q = q[45]
        a[z] = q
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p9515
        ::p7684::
        registers[50] = -90
        registers[51] = (0)
        registers[52] = (0)
        goto p5550
        ::p7688::
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["depend"]
        registers[46] = registers[25]["antiaim"]
        registers[47] = registers[25]["builder"]
        goto p5768
        ::p7692::
        registers[55] = "Spin"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        q[3] = registers[54]
        q[4] = registers[55]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        goto p1582
        ::p7697::
        registers[54] = "Default"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = new_frame(6)
        goto p5071
        ::p7701::
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        registers[15] = "fake lag"
        registers[16] = "limit";
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p7470
        ::p7707::
        registers[26][registers[28]] = registers[29]
        registers[28] = "update"
        a = D.f482
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[29] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[26][registers[28]] = registers[29]
        registers[28] = registers[21]["ragebot"]
        goto p6246
        ::p7714::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["antiaim"]
        registers[45] = registers[25]["builder"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["anti_backstab"] = registers[42]
        goto p8236
        ::p7720::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[53] = v
            branch_taken = true
        end
        if branch_taken then
            goto p6541
        end
        goto p8686
        ::p7722::
        tick(7722)
        registers[16] = {
        }
        registers[15] = registers[16]
        registers[16] = environment["rawset"]
        registers[17] = environment["_G"]
        goto p2822
        ::p7727::
        registers[14] = "rage"
        a = registers
        z = 15;
        a[z] = "other"
        registers[16] = "quick peek assist"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["quickpeek"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "rage"
        registers[15] = "other"
        registers[16] = "quick peek assist mode"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["quickpeekm"] = registers[12]
        goto p2709
        ::p7743::
        registers[45] = registers[41]["aimbot_logs"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["aimbot_logs_hit_color"] = registers[42]
        goto p5018
        ::p7747::
        registers[51] = -180
        registers[52] = (180)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        goto p9671
        ::p7753::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(3)
        registers[53] = registers[48]["type"]
        registers[54] = "Side"
        registers[55] = "Side Reworked"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        registers[53] = environment["unpack"]
        goto p7304
        ::p7762::
        registers[48] = registers[25]["antiaim"]
        a = registers
        z = (49)
        q = registers
        q = q[25]
        q = q["defensive"]
        a[z] = q
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p1746
        ::p7771::
        tick(7771)
        if registers[13] then
            goto p5207
        end
        goto p8719
        ::p7780::
        registers[32]["delay_switch_count"] = 0
        registers[32]["delay_signature"] = registers[0]
        registers[33] = {
        }
        goto p6624
        ::p7785::
        tick(7785)
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["type"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_static_"..registers[43]
        registers[52] = -180
        registers[53] = (180)
        registers[54] = (0)
        registers[55] = (true)
        goto p1281
        ::p7795::
        registers[24]["db"] = "andromeda_config_db"
        registers[24]["backup_db"] = "andromeda_config_db_backup"
        registers[24]["max_configs"] = 64
        registers[24]["version"] = 2
        registers[25] = {
        }
        registers[26] = {
        }
        registers[25]["antiaim"] = registers[26]
        registers[26] = {
        }
        registers[25]["visuals"] = registers[26]
        registers[24]["maps"] = registers[25]
        registers[25] = {
        }
        registers[24]["configs_db"] = registers[25]
        registers[24]["write_revision"] = 0
        registers[25] = environment["table"]
        registers[25] = registers[25]["unpack"]
        if registers[25] then
            goto p6656
        end
        goto p3709
        ::p7812::
        tick(7812)
        registers[46] = registers[46]["conditions"]
        registers[47] = registers[43]
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        registers[46] = new_frame(3)
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        goto p5577
        ::p7821::
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        a = registers
        z = (45)
        q = registers
        q = q[25]
        q = q["visuals"]
        a[z] = q
        registers[46] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        registers[42]["enabled_spacer"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["combobox"]
        registers[45] = "\012<gray>\012<dot> \013Air legs\010animations_air_legs"
        goto p4436
        ::p7839::
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["static"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_left_"..registers[43]
        registers[52] = -180
        registers[53] = (180)
        goto p4401
        ::p7847::
        tick(7847)
        registers[42]["option_list"] = registers[44]
        registers[42]["weapon_list"] = registers[43]
        registers[45] = (1)
        goto p3673
        ::p7851::
        a = D.f483
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[63] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f484
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[64] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f485
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[65] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f486
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[66] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f487
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[67] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f488
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[68] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f489
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[69] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f490
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[70] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[71] = registers[59]
        goto p7060
        ::p7867::
        registers[54] = "sec"
        registers[55] = (0.1);
        registers[47] = registers[47](unpack_range(55, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_refraction_timer"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p1470
        ::p7878::
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        goto p1845
        ::p7883::
        registers[51] = "\010yaw_modifier_custom_sliders_"..registers[43]
        registers[52] = (2)
        registers[53] = (10)
        registers[54] = (3)
        goto p1425
        ::p7899::
        registers[54] = "Zurab"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_zurab_speed"]
        goto p6342
        ::p7904::
        registers[28] = registers[21]["ragebot"]
        registers[28] = registers[28]["hold_aim_ticks"]
        z = registers[28]
        registers[29] = z;
        registers[(28)] = z["set_callback"]
        registers[30] = registers[26]["update"]
        registers[31] = (true)
        registers[(28)](unpack_range(31, registers, 29))
        goto p3664
        ::p7911::
        registers[12]["freestanding_body_yaw"] = registers[13]
        registers[13] = registers[2]["reference"]
        registers[14] = "aa"
        goto p6114
        ::p7915::
        tick(7915);
        registers[47] = registers[47](unpack_range(50, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = registers[25]["antiaim"]
        registers[50] = registers[25]["builder_or_defensive"]
        registers[51] = registers[45];
        registers[47] = registers[47](unpack_range(51, registers, 48))
        registers[44]["invalid_tick_cleaner"] = registers[47]
        registers[47] = registers[21]["builder"]
        registers[47][registers[43]] = registers[44]
        goto p5147
        ::p7925::
        registers[48] = {
        }
        registers[47]["hidden"] = registers[48]
        registers[48] = registers[47]["hidden"]
        goto p4631
        ::p7938::
        registers[26] = registers[11]["set_callback"]
        registers[27] = "post_config_load"
        registers[28] = registers[25]["update"];
        registers[26](registers[27], registers[28])
        goto p3716
        ::p7943::
        registers[12]["freestanding"] = registers[13]
        registers[11]["angles"] = registers[12]
        registers[12] = {
        }
        goto p6230
        ::p7947::
        registers[50] = "%"
        registers[51] = (1);
        registers[43] = registers[43](unpack_range(51, registers, 44))
        goto p1822
        ::p7951::
        registers[48] = "Scout"
        a = registers
        z = 49;
        a[z] = "AWP"
        q = registers[(43)]
        q[1] = registers[44]
        q[2] = registers[45]
        q[3] = registers[46]
        q[4] = registers[47]
        q[5] = registers[48]
        q[6] = registers[49]
        goto p1840
        ::p7956::
        registers[65] = registers[40];
        registers[56] = registers[56](unpack_range(65, registers, 57))
        registers[55][registers[54]] = registers[56]
        goto p5317
        ::p7960::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[48]["type"]
        registers[54] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p8755
        ::p7966::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_separator"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p3628
        ::p7971::
        registers[60] = "Timing"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        q[3] = registers[57]
        q[4] = registers[58]
        q[5] = registers[59]
        q[6] = registers[60]
        registers[55] = new_frame(2)
        goto p4926
        ::p7975::
        registers[53] = new_frame(6)
        registers[54] = registers[47]["type"]
        registers[55] = "Default"
        goto p1408
        ::p7980::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[42] = z;
            registers[43] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p6436
        end
        goto p639
        ::p7982::;
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p6425
        ::p7995::;
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["viewmodel"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["viewmodel_options"] = registers[42]
        registers[42] = environment["cvar"]
        registers[42] = registers[42]["r_aspectratio"]
        goto p3347
        ::p8004::
        tick(8004)
        z = registers[23]
        registers[61] = z;
        registers[(60)] = z["slider"]
        registers[62] = "\012<gray>\012<dot> \013Distance\010hitchance_no_scope_distance_"..registers[49]
        registers[63] = (5)
        goto p1203
        ::p8008::
        q = registers[(36)]
        q[1] = registers[37]
        q[2] = registers[38]
        q[3] = registers[39]
        q[4] = registers[40]
        q[5] = registers[41]
        registers[35]["cvars"] = registers[36]
        registers[34]["Other"] = registers[35]
        registers[35] = {
        }
        goto p1987
        ::p8013::
        tick(8013)
        registers[14] = "aimbot"
        registers[15] = "avoid unsafe hitboxes";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["avoid_unsafe_hitboxes"] = registers[12]
        registers[10]["ragebot"] = registers[11]
        goto p8276
        ::p8019::
        tick(8019)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p4013
        ::p8023::
        registers[57] = "pre_config_save"
        a = D.f491
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[58] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[56](registers[57], registers[58])
        registers[56] = registers[11]["set_callback"]
        goto p5355
        ::p8028::
        registers[15] = "minimum damage";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["minimum_damage"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "rage"
        registers[15] = "aimbot"
        registers[16] = "minimum damage override"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["minimum_damage_override"] = registers[12]
        goto p1114
        ::p8040::
        registers[45] = (200)
        goto p9384
        ::p8042::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        goto p7235
        ::p8048::
        tick(8048)
        registers[58] = (#registers[52])
        registers[58] = registers[58] + 1
        registers[52][registers[58]] = registers[57]
        goto p6105
        ::p8052::
        tick(8052)
        registers[36] = registers[33];
        registers[34](registers[35], registers[36])
        registers[34] = registers[21]["switch_type"]
        z = registers[34]
        registers[35] = z;
        registers[(34)] = z["set_callback"]
        goto p7427
        ::p8057::
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[(46)](unpack_range(51, registers, 47))
        registers[46] = registers[44]["def_pitch"]
        goto p7261
        ::p8066::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_refraction_left"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_RIGHTREFRACTION"..registers[43]
        goto p9160
        ::p8074::
        registers[38] = "export_config"
        a = D.f492
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        registers[38] = "import_config"
        goto p7097
        ::p8079::
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p9324
        ::p8083::
        tick(8083)
        m, x = pack_returns(registers[55](unpack_range(56, registers, 56)))
        m = m + 55 - 1
        top = m
        z = 0
        for f = 55, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[50] = registers[50](unpack_range(top, registers, 51))
        registers[49]["count"] = registers[50]
        registers[50] = {
        }
        registers[49]["slots"] = registers[50]
        registers[50] = (1)
        goto p1691
        ::p8096::
        tick(8096)
        registers[38][12] = "fists"
        registers[38][13] = "breachcharge"
        registers[38][14] = "bumpmine"
        goto p3846
        ::p8100::;
        registers[42](registers[43], registers[44])
        registers[42] = registers[11]["set_callback"]
        registers[43] = "pre_predict_command"
        goto p561
        ::p8104::
        registers[54] = "Default"
        registers[55] = "Smart"
        registers[56] = "Fluctuate"
        registers[57] = "Random"
        goto p5331
        ::p8109::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_delayed_randomize"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p5625
        ::p8113::
        registers[26] = registers[21]["antiaim"]
        registers[26] = registers[26]["features"]
        registers[27] = registers[26]["fakelag_exploit_enabled"]
        goto p4881
        ::p8118::
        branch_taken = false
        if registers[57] ~= "No Scope" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p6105
        end
        goto p8048
        ::p8120::
        z = registers[41]
        registers[42] = z;
        registers[(41)] = z["get"];
        registers[(41)] = registers[(41)](registers[42])
        registers[41] = registers[20][registers[41]]
        goto p5076
        ::p8124::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p9711
        ::p8134::
        registers[41]["stubs"] = registers[42]
        registers[41] = registers[21]["visuals"]
        registers[41] = registers[41]["stubs"]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Watermark"
        registers[42] = registers[42](registers[43], registers[44])
        goto p9659
        ::p8145::
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        goto p2907
        ::p8150::
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p9205
        ::p8155::
        registers[53] = registers[46]
        m, x = pack_returns(registers[52](unpack_range(53, registers, 53)))
        m = m + 52 - 1
        top = m
        z = 0
        for f = 52, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["global"] = registers[48]
        goto p6598
        ::p8160::
        a = D.f493
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[32][registers[53]] = registers[54]
        registers[53] = "update_defensive_yaw_double_delay"
        a = D.f495
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[54] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p4996
        ::p8166::
        registers[53][registers[52]] = registers[54]
        goto p415
        ::p8168::
        a = D.f496
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "aim_fire"
        a = D.f497
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        goto p5457
        ::p8174::
        tick(8174)
        if registers[44] then
            goto p7111
        end
        goto p5125
        ::p8176::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_delay"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p1445
        ::p8185::
        registers[24][registers[38]] = registers[39]
        registers[38] = "build_encoded_payload"
        a = D.f498
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p635
        ::p8189::
        registers[46][2] = "Toggle"
        registers[46][3] = "Off hotkey"
        registers[47] = "get_raw_value"
        a = D.f499
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[48] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[42][registers[47]] = registers[48]
        registers[47] = "is_enabled"
        goto p2690
        ::p8201::;
        registers[(26)] = registers[(26)](registers[27])
        z = registers[26]
        registers[27] = z;
        registers[(26)] = z["to_hex"];
        registers[(26)] = registers[(26)](registers[27])
        registers[26] = "\007"..registers[26]
        registers[25]["gray"] = registers[26]
        registers[25] = registers[2]["macros"]
        registers[26] = registers[18]["new"]
        registers[27] = "9FCA2BFF"
        goto p6797
        ::p8210::
        registers[46] = "get_icon_offset"
        a = D.f500
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_text_offset"
        goto p6771
        ::p8215::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["thirdperson"]
        goto p7002
        ::p8219::
        tick(8219)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Fluctuate"
        goto p1625
        ::p8224::
        registers[60] = (0)
        registers[61] = (true)
        registers[62] = "\194\176"
        goto p4305
        ::p8228::
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_left_"..registers[43]
        registers[51] = -180
        goto p5222
        ::p8232::
        registers[49] = "\010Pitch left delay\010defensive_pitch_left_delay_value"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        goto p1135
        ::p8236::
        registers[42] = {
        }
        a = registers
        z = (41)
        a = a[z]
        z = "safe_head"
        q = registers
        m = 42
        q = q[m]
        a[z] = q
        registers[42] = registers[41]["safe_head"]
        goto p7644
        ::p8243::
        registers[52] = registers[47]["builder_type"]
        registers[53] = "Hidden"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        registers[53] = registers[46]
        goto p7785
        ::p8249::
        tick(8249)
        registers[44] = registers[43]["options"]
        if registers[44] == registers[0] then
            goto p4516
        end
        goto p9254
        ::p8258::
        registers[27] = registers[26]["fakelag_exploit_enabled"]
        z = registers[27]
        registers[28] = z;
        registers[(27)] = z["set_callback"]
        registers[29] = registers[25]["update"]
        registers[30] = (true)
        goto p1765
        ::p8270::
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"]
        registers[47] = new_frame(2)
        registers[48] = registers[42]["options"]
        registers[49] = "Lean"
        goto p5502
        ::p8276::
        registers[11] = {
        }
        registers[12] = {
        }
        a = registers
        z = (13)
        q = registers
        q = q[2]
        q = q["reference"]
        a[z] = q
        goto p2331
        ::p8283::
        registers[47] = registers[25]["ragebot"]
        registers[48] = registers[42]["enabled"];
        registers[45] = registers[45](unpack_range(48, registers, 46))
        registers[42]["hotkey"] = registers[45]
        goto p7847
        ::p8288::
        registers[55] = registers[48]["values"]
        registers[56] = "Custom"
        q = registers[(54)]
        q[1] = registers[55]
        q[2] = registers[56]
        registers[55] = environment["unpack"]
        registers[56] = registers[46]
        goto p8083
        ::p8294::
        registers[44] = (10)
        goto p8174
        ::p8296::
        tick(8296)
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p3374
        ::p8300::
        tick(8300)
        registers[29] = registers[11]["set_callback"]
        registers[30] = "paint_ui"
        registers[31] = registers[28]["update"];
        registers[29](registers[30], registers[31])
        registers[29] = registers[11]["set_callback"]
        goto p8665
        ::p8306::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Sway"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_sway_speed"]
        goto p9172
        ::p8328::
        registers[47] = registers[25]["ragebot"]
        registers[48] = registers[42]["enabled"];
        registers[45] = registers[45](unpack_range(48, registers, 46))
        registers[42]["weapon"] = registers[45]
        goto p6074
        ::p8336::
        a = D.f501
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f502
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[32] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f503
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[33] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = (34)
        q = registers
        q = q[21]
        q = q["switch"]
        a[z] = q
        z = registers[34]
        registers[35] = z;
        registers[(34)] = z["set_callback"]
        goto p8052
        ::p8345::
        registers[53] = registers[48]["type"]
        registers[54] = "Meta"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        goto p2209
        ::p8349::
        registers[44] = "\012<gray>\012<func> \013Extrapolation\010ragebot_extrapolation"
        registers[45] = (0)
        registers[46] = (5)
        goto p4658
        ::p8353::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_sway_speed"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw sway left\010defensive_yaw_sway_left_value"..registers[43]
        registers[50] = -180
        goto p873
        ::p8361::
        registers[17] = (5);
        registers[14] = registers[14](unpack_range(17, registers, 15))
        registers[14] = (registers[14] - 236)
        goto p894
        ::p8365::
        registers[48]["delay"] = registers[49]
        registers[49] = registers[44]["delay"]
        registers[49] = registers[49]["builder_type"]
        registers[48]["builder_type"] = registers[49]
        registers[34][registers[47]] = registers[48]
        registers[47] = (#registers[35])
        registers[47] = registers[47] + 1
        registers[48] = {
        }
        registers[48]["state_name"] = registers[43]
        goto p8553
        ::p8375::
        registers[54] = "t"
        registers[55] = (1)
        registers[56] = {
        }
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        goto p5742
        ::p8381::
        registers[40][1] = "Jitter"
        registers[41] = (2)
        registers[42] = (16)
        registers[43] = (1)
        goto p3704
        ::p8386::
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        goto p8530
        ::p8391::
        tick(8391)
        registers[47] = new_frame(2)
        registers[48] = registers[42]["ground_legs"]
        registers[49] = "Jitter"
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        goto p4190
        ::p8398::
        registers[51] = new_frame(4)
        registers[52] = registers[47]["type"]
        registers[53] = "Center"
        registers[54] = "Random"
        registers[55] = "Spin"
        goto p5764
        ::p8404::
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        registers[54] = new_frame(2)
        registers[55] = registers[47]["values"]
        goto p2876
        ::p8408::
        a = D.f504
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[28] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f505
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[29] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f506
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f507
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f508
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[32] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p3731
        ::p8414::
        registers[51] = new_frame(2)
        registers[52] = registers[47]["type"]
        registers[53] = "Double"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = environment["unpack"]
        goto p2502
        ::p8420::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["ragebot"]
        registers[45] = registers[41]["enemy_resolver"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["enemy_resolver_mode"] = registers[42]
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["combobox"]
        registers[44] = "\010enemy_resolver_generate"
        goto p1667
        ::p8429::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Double"
        goto p6252
        ::p8436::
        registers[11][registers[12]] = registers[13]
        registers[12] = "normalize"
        a = D.f509
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        registers[12] = "lerp"
        a = D.f510
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11][registers[12]] = registers[13]
        goto p4676
        ::p8444::;
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        goto p4913
        ::p8448::
        registers[44] = {
        }
        registers[45] = new_frame(2)
        registers[46] = registers[21]["antiaim"]
        goto p7812
        ::p8452::
        registers[46] = (255)
        registers[47] = (15)
        registers[48] = (255);
        registers[42] = registers[42](unpack_range(48, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["watermark"]
        registers[46] = new_frame(2)
        goto p9498
        ::p8461::
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"];
        registers[43] = registers[43](unpack_range(46, registers, 44))
        goto p6288
        ::p8465::
        registers[46] = (100)
        registers[47] = (0)
        registers[48] = (true)
        goto p3429
        ::p8474::
        registers[50] = "\010spacer_force_defensive_"..registers[43]
        registers[48] = registers[48](registers[49], registers[50])
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = environment["unpack"]
        registers[51] = registers[46]
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["force_defensive"] = registers[48]
        z = registers[22]
        registers[48] = z;
        registers[(47)] = z["multiselect"]
        registers[49] = "\012<gray>\012<func>\013 Force Defensive\010force_defensive_"..registers[43]
        goto p8864
        ::p8485::
        registers[5] = "game_initialized"
        goto p271
        ::p8489::
        registers[15] = environment["math"]
        registers[15] = registers[15]["ceil"]
        registers[16] = environment["math"]
        goto p8708
        ::p8493::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p5873
        ::p8497::
        registers[31] = registers[21]["visuals"]
        registers[31] = registers[31]["stubs"]
        registers[31] = registers[31]["aimbot_logs"]
        if registers[31] == registers[0] then
            goto p8300
        end
        goto p2285
        ::p8511::
        tick(8511)
        registers[25] = registers[21]["ragebot"]
        registers[25] = registers[25]["extrapolation"]
        z = registers[25]
        registers[26] = z;
        registers[(25)] = z["set_callback"]
        registers[27] = registers[22]["update_callbacks"]
        registers[28] = (true)
        registers[(25)](unpack_range(28, registers, 26))
        goto p1499
        ::p8521::
        tick(8521)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        registers[51] = registers[47]["builder_type"]
        goto p5028
        ::p8530::
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_spin_right_value"]
        goto p3398
        ::p8536::
        registers[13] = "rage"
        registers[14] = "other"
        registers[15] = "delay shot";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["delay_shot"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "rage"
        goto p8013
        ::p8544::
        z = registers[24]
        registers[43] = z;
        registers[(42)] = z["checkbox"]
        registers[44] = "\012<gray>\012<func> \013Resolver"
        registers[42] = registers[42](registers[43], registers[44])
        goto p4225
        ::p8548::
        registers[32]["defensive_pitch_delay_side"] = false
        registers[32]["d_side"] = 1
        registers[33] = {
        }
        registers[33]["default"] = 0
        goto p1052
        ::p8553::
        registers[49] = registers[44]["delay"]
        registers[49] = registers[49]["hidden"]
        registers[48]["delay"] = registers[49]
        goto p2606
        ::p8557::
        registers[45] = registers[11]["set_callback"]
        registers[46] = "pre_config_save"
        registers[47] = registers[42]["reset"];
        registers[45](registers[46], registers[47])
        registers[45] = registers[11]["set_callback"]
        registers[46] = "post_config_load"
        goto p2736
        ::p8564::;
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_spin_left_value"] = registers[47]
        goto p4612
        ::p8572::
        registers[49] = "\010Yaw right\010defensive_yaw_right_value"..registers[43]
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (0)
        goto p8019
        ::p8577::
        registers[28] = "Configs"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["cfg"] = registers[26]
        registers[26] = new_frame(2)
        goto p5119
        ::p8582::
        tick(8582)
        registers[27] = registers[21]["switch_type"]
        registers[28] = "Defensive"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["defensive"] = registers[26]
        registers[26] = new_frame(2)
        registers[27] = registers[21]["switch_type"]
        a = D.f511
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[28] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        goto p3012
        ::p8591::
        registers[53] = new_frame(5)
        registers[54] = registers[47]["type"]
        registers[55] = "Default"
        registers[56] = "Smart"
        registers[57] = "Fluctuate"
        registers[58] = "Random"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        q[3] = registers[56]
        q[4] = registers[57]
        q[5] = registers[58]
        goto p69
        ::p8599::
        registers[35] = {
        }
        registers[35]["target"] = 0
        registers[36] = new_frame(1)
        goto p4839
        ::p8603::
        tick(8603)
        registers[50] = "t"
        registers[51] = (1);
        registers[43] = registers[43](unpack_range(51, registers, 44))
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"]
        registers[47] = new_frame(2)
        registers[48] = registers[42]["ground_legs"]
        registers[49] = "Jitter"
        q = registers[(47)]
        q[1] = registers[48]
        q[2] = registers[49];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[42]["legs_jitter_time"] = registers[43]
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["label"]
        registers[45] = "\010animations_legs_jitter_time_spacer"
        registers[43] = registers[43](registers[44], registers[45])
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["visuals"]
        registers[46] = registers[42]["enabled"]
        goto p8391
        ::p8622::
        q = registers[(38)]
        q[1] = registers[39]
        q[2] = registers[40]
        q[3] = registers[41]
        q[4] = registers[42]
        q[5] = registers[43]
        q[6] = registers[44]
        q[7] = registers[45]
        registers[38][9] = "grenade"
        registers[38][11] = "stackableitem"
        goto p8096
        ::p8627::
        registers[21] = "pre_predict_command"
        registers[22] = "pre_render"
        registers[23] = "pre_render_3d"
        goto p1351
        ::p8631::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p913
        ::p8635::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_fluctuate_mode"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p8811
        ::p8642::
        if registers[43] == registers[0] then
            goto p4516
        end
        goto p8249
        ::p8652::
        tick(8652)
        registers[18][registers[19]] = registers[20]
        registers[18] = environment["entity"]
        registers[19] = "get_peeking"
        goto p2863
        ::p8656::
        tick(8656)
        a = D.f512
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17] = {
        }
        a = D.f513
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[18] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17]["rounded_rectangle"] = registers[18]
        registers[18] = "clamp"
        a = D.f514
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[19] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17][registers[18]] = registers[19]
        registers[18] = environment["entity"]
        goto p4309
        ::p8665::
        registers[30] = "level_init"
        registers[31] = registers[28]["clear"];
        registers[29](registers[30], registers[31])
        registers[29] = registers[11]["set_callback"]
        registers[30] = "shutdown"
        a = D.f515
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[31] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[29](registers[30], registers[31])
        goto p2161
        ::p8675::
        tick(8675)
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        a = registers
        z = (46)
        q = registers
        q = q[44]
        q = q["def_yaw_zurab_range"]
        a[z] = q
        goto p4794
        ::p8682::
        do
            local f = (32)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[32] = {
        }
        registers[32]["current"] = "Stand"
        goto p696
        ::p8686::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        registers[51] = "\010hidden_yaw_modifier_meta_mode_"..registers[43]
        goto p9300
        ::p8690::
        registers[11]["clrmenu"] = registers[12]
        registers[12] = {
        }
        registers[13] = registers[2]["reference"]
        registers[14] = "visuals"
        goto p325
        ::p8695::
        registers[54] = "Sway"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p8712
        ::p8700::
        tick(8700)
        registers[48] = registers[48]["cl_bobamt_vert"]
        registers[49] = environment["cvar"]
        registers[49] = registers[49]["cl_righthand"]
        goto p3929
        ::p8704::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[41] = {
        }
        registers[21]["defensive"] = registers[41]
        goto p6446
        ::p8708::
        registers[16] = registers[16]["pi"];
        registers[(15)] = registers[(15)](registers[16])
        goto p2970
        ::p8712::
        registers[46] = registers[44]["def_yaw_sway_left_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p2763
        ::p8719::
        registers[13] = (385)
        goto p5207
        ::p8721::
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        goto p1450
        ::p8725::
        tick(8725)
        registers[24]["cur"] = registers[25]
        registers[25] = {
        }
        registers[24]["prev"] = registers[25]
        goto p3642
        ::p8729::
        registers[50] = (registers[49] == "AWP")
        goto p3669
        ::p8731::
        registers[44] = registers[42];
        registers[(43)] = registers[(43)](registers[44])
        branch_taken = false
        if registers[43] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p3062
        end
        goto p6036
        ::p8738::
        registers[36][15] = true
        registers[35]["layers"] = registers[36]
        registers[36] = {
        }
        goto p7369
        ::p8742::
        registers[26] = new_frame(2)
        registers[27] = registers[21]["switch_type"]
        registers[28] = "Gamesense"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["gamesense"] = registers[26]
        registers[26] = new_frame(2)
        goto p8582
        ::p8749::
        registers[25]["saved_limit"] = registers[0]
        registers[26] = "is_enabled"
        a = D.f516
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25][registers[26]] = registers[27]
        registers[26] = "sync"
        goto p2867
        ::p8755::
        registers[53] = environment["unpack"]
        registers[54] = registers[46]
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["meta_delay_time"] = registers[49]
        goto p6740
        ::p8761::
        registers[26] = new_frame(2)
        registers[27] = registers[21]["switch"]
        registers[28] = "Other"
        q = registers[(26)]
        q[1] = registers[27]
        q[2] = registers[28]
        registers[25]["visuals"] = registers[26]
        goto p9143
        ::p8767::
        registers[48] = registers[21]["visuals"]
        registers[48] = registers[48]["stubs"]
        registers[48] = registers[48]["native_indicators"]
        if registers[48] == registers[0] then
            goto p4385
        end
        goto p9405
        ::p8772::
        registers[49] = "\011Yaw\010defensive_yaw_mode"..registers[43]
        registers[50] = new_frame(9)
        registers[51] = "Disabled"
        registers[52] = "Custom"
        goto p2746
        ::p8777::
        registers[47] = registers[47] + 1
        registers[48] = {
        }
        registers[48]["state_name"] = registers[43]
        registers[49] = registers[44]["yaw_modifiers"]
        goto p4453
        ::p8782::
        registers[46] = "get_order"
        a = D.f517
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p4354
        ::p8786::
        registers[51] = "\010hidden_yaw_right_"..registers[43]
        registers[52] = -180
        registers[53] = (180)
        registers[54] = (0)
        goto p2974
        ::p8791::
        registers[37] = environment["cvar"]
        registers[37] = registers[37]["fog_enable"]
        registers[38] = environment["cvar"]
        a = registers
        z = (38)
        q = registers
        q = q[38]
        q = q["fog_enable_water_fog"]
        a[z] = q
        q = registers[(36)]
        q[1] = registers[37]
        q[2] = registers[38]
        registers[35]["cvars"] = registers[36]
        registers[34]["Fog"] = registers[35]
        registers[35] = {
        }
        goto p3517
        ::p8804::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Sway"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_sway_right_value"]
        goto p6890
        ::p8811::
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p9752
        ::p8815::
        registers[48] = "Crouch"
        registers[49] = "Peek Assist"
        q = registers[(44)]
        q[1] = registers[45]
        q[2] = registers[46]
        q[3] = registers[47]
        q[4] = registers[48]
        q[5] = registers[49]
        goto p7276
        ::p8819::
        registers[57] = (1);
        registers[49] = registers[49](unpack_range(57, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        registers[51] = new_frame(2)
        registers[52] = registers[47]["builder_type"]
        goto p1191
        ::p8825::
        registers[45] = registers[45].." t"
        registers[40][registers[44]] = registers[45]
        goto p6956
        ::p8828::
        registers[54] = registers[47]["values"]
        registers[55] = "Solo"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = environment["unpack"]
        goto p568
        ::p8833::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_distortion"] = registers[47]
        goto p3131
        ::p8841::
        registers[57] = (1)
        registers[58] = {
        }
        registers[58][0] = "Off"
        goto p6274
        ::p8845::
        tick(8845)
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw sway speed\010defensive_yaw_sway_speed"..registers[43]
        a = registers
        z = 50;
        a[z] = 1
        registers[51] = (15)
        goto p3657
        ::p8851::;
        registers[42] = registers[42](unpack_range(50, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["viewmodel"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        goto p3822
        ::p8857::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[49] = (#registers[48])
        registers[49] = registers[49] + 1
        registers[50] = new_frame(3)
        registers[51] = registers[44]["body_yaw"]
        registers[51] = registers[51]["type"]
        goto p191
        ::p8864::
        registers[50] = new_frame(2)
        registers[51] = "Double tap"
        registers[52] = "On shot anti-aim"
        goto p1867
        ::p8868::
        registers[13] = "MISC"
        registers[14] = "Settings"
        registers[15] = "sv_maxusrcmdprocessticks2"
        goto p1686
        ::p8872::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_refraction_spin"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_YAWTIMER"..registers[43]
        goto p4270
        ::p8880::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_spin_right_value"] = registers[47]
        goto p8845
        ::p8885::
        tick(8885)
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Delay"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_delay"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        goto p8296
        ::p8899::
        registers[17] = registers[15];
        registers[(16)] = registers[(16)](registers[17])
        branch_taken = false
        if registers[16] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p8656
        end
        goto p7722
        ::p8903::
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw sway right\010defensive_yaw_sway_right_value"..registers[43]
        registers[50] = -180
        goto p3838
        ::p8911::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[41] = registers[21]["antiaim"]
        registers[42] = {
        }
        registers[41]["features"] = registers[42]
        registers[41] = registers[21]["antiaim"]
        goto p5539
        ::p8917::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_right_delay_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p8885
        ::p8924::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_left_delay_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch right delay\010defensive_pitch_right_delay_value"..registers[43]
        goto p3711
        ::p8933::
        tick(8933)
        registers[46] = new_frame(5)
        registers[47] = ""
        registers[48] = "lua/"
        goto p7319
        ::p8938::
        registers[46] = "measure_bomb_group"
        a = D.f518
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "draw_bomb_group"
        a = D.f519
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p7415
        ::p8945::
        registers[13] = {
        }
        registers[14] = registers[2]["reference"]
        registers[15] = "aa"
        registers[16] = "anti-aimbot angles"
        goto p862
        ::p8950::;
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p1015
        ::p8955::
        a = D.f520
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[38] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f521
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f522
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[40] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f523
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p6724
        ::p8960::
        registers[52] = (8)
        a = registers
        z = 53;
        a[z] = true
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_zurab_speed"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Distortion yaw\010defensive_yaw_distortion"..registers[43]
        registers[50] = -180
        goto p6197
        ::p8975::
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (0)
        goto p5002
        ::p8979::
        registers[50] = -89
        registers[51] = (89)
        registers[52] = -89
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p6900
        ::p8985::
        registers[47] = (8)
        registers[48] = (2)
        registers[49] = (true)
        goto p8603
        ::p8996::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p1587
        ::p9000::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p3816
        ::p9004::
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_static_value"] = registers[47]
        goto p964
        ::p9008::
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p7466
        ::p9022::
        registers[14] = -999446527 + registers[14]
        registers[15] = environment["string"]
        registers[15] = registers[15]["len"]
        registers[16] = "\254f";
        registers[(15)] = registers[(15)](registers[16])
        goto p9675
        ::p9031::
        registers[57] = -180
        registers[58] = (180)
        registers[59] = (0)
        registers[60] = (true)
        goto p2636
        ::p9036::
        registers[54] = environment["unpack"]
        registers[55] = registers[46]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["right"] = registers[49]
        goto p7478
        ::p9042::
        registers[56][0] = "Off";
        registers[47] = registers[47](unpack_range(56, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_fluctuate_value2"] = registers[47]
        goto p7309
        ::p9051::
        registers[43] = (150)
        goto p2666
        ::p9053::
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_refraction_timer"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        goto p6457
        ::p9069::
        registers[53] = (true)
        registers[54] = "t";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        goto p7158
        ::p9080::
        tick(9080)
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_sway_right_value"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        goto p3328
        ::p9086::
        tick(9086)
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Sway"
        goto p8675
        ::p9090::
        a = D.f524
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[24][registers[38]] = registers[39]
        do
            local f = (25)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        z = registers[24]
        registers[26] = z;
        registers[(25)] = z["init"]
        goto p6551
        ::p9095::
        registers[22] = {
        }
        registers[21]["visuals"] = registers[22]
        registers[22] = {
        }
        registers[21]["esp"] = registers[22]
        registers[22] = registers[2]["group"]
        goto p9564
        ::p9101::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_delayed_right"] = registers[47]
        goto p2201
        ::p9106::
        registers[62] = registers[25]["ragebot"]
        registers[63] = registers[42]["enabled"]
        registers[64] = registers[51]
        registers[65] = new_frame(2)
        registers[66] = registers[53]["options"]
        registers[67] = registers[58]
        q = registers[(65)]
        q[1] = registers[66]
        q[2] = registers[67];
        registers[60] = registers[60](unpack_range(65, registers, 61))
        registers[59]["value"] = registers[60]
        if registers[58] ~= "No Scope" then
            goto p5895
        end
        goto p8004
        ::p9117::
        registers[25] = {
        }
        registers[24]["last_value"] = registers[25]
        registers[25] = {
        }
        registers[24]["miss_side"] = registers[25]
        registers[25] = {
        }
        registers[24]["miss_until"] = registers[25]
        goto p6709
        ::p9124::
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        a = registers
        z = (53)
        q = registers
        q = q[44]
        q = q["def_yaw"]
        a[z] = q
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_delayed_left"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p7511
        ::p9137::
        registers[49] = (255)
        registers[50] = (0)
        registers[51] = (255);
        registers[45] = registers[45](unpack_range(51, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        goto p4537
        ::p9143::
        registers[26] = registers[21]["switch_type"]
        z = registers[26]
        registers[27] = z;
        registers[(26)] = z["depend"]
        registers[28] = registers[25]["antiaim"]
        goto p3167
        ::p9147::
        tick(9147)
        registers[14] = "movement"
        registers[15] = "air strafe";
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["air_strafe"] = registers[12]
        registers[12] = registers[2]["reference"]
        registers[13] = "misc"
        goto p5751
        ::p9160::
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        goto p5794
        ::p9165::
        a = D.f525
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[41] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f526
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[42] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = registers
        z = 43;
        a[z] = "reset"
        a = D.f527
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        goto p1357
        ::p9172::
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p3234
        ::p9177::
        registers[44] = environment["cvar"]
        registers[44] = registers[44]["c_mindistance"]
        if not registers[44] then
            goto p8174
        end
        goto p482
        ::p9184::
        m, x = pack_returns(registers[53](unpack_range(54, registers, 54)))
        m = m + 53 - 1
        top = m
        z = 0
        for f = 53, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["meta_safe_yaw"] = registers[49]
        registers[49] = registers[48]["meta_safe_yaw"]
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["set"]
        registers[51] = (true);
        registers[49](registers[50], registers[51])
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        goto p1818
        ::p9193::
        registers[45][registers[46]] = registers[47]
        a = registers
        z = 46;
        a[z] = "is_bomb_indicator_kind"
        a = D.f528
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "is_dt_indicator_kind"
        a = D.f529
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_font_size"
        a = D.f530
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[45][registers[46]] = registers[47]
        goto p4179
        ::p9205::
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_right_delay_value"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Pitch double delay\010defensive_pitch_delay"..registers[43]
        goto p1951
        ::p9228::
        registers[42] = (0)
        goto p5190
        ::p9230::
        z = registers[43]
        registers[44] = z;
        registers[(43)] = z["depend"]
        registers[45] = registers[25]["antiaim"]
        registers[46] = registers[25]["builder"]
        registers[47] = registers[41]["fakelag_exploit_enabled"];
        registers[43] = registers[43](unpack_range(47, registers, 44))
        registers[41]["fakelag_exploit_tick"] = registers[43]
        z = registers[23]
        registers[44] = z;
        registers[(43)] = z["button"]
        registers[45] = "Force fakelag to value"
        goto p7447
        ::p9239::
        registers[54] = "Spin"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_spin_right_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        registers[49] = registers[25]["defensive"]
        registers[50] = registers[45]
        goto p3872
        ::p9248::
        registers[46]["andromeda/cs2/damage.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M14 2h4v7h-4V2Zm0 21h4v7h-4v-7ZM2 14h7v4H2v-4Zm21 0h7v4h-7v-4Zm-7-4a6 6 0 1 1 0 12 6 6 0 0 1 0-12Zm0 3a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z\"/></svg>"
        registers[46]["andromeda/cs2/timer.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M12 1h8v4h-8V1Zm4 6a12 12 0 1 1 0 24 12 12 0 0 1 0-24Zm0 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm1 2v6l5-3 1.5 2.5-7.5 4.5-2-1.2V12h3Z\"/></svg>"
        registers[46]["andromeda/cs2/alert.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M16 2 31 28H1L16 2Zm-1.5 9v9h3v-9h-3Zm0 11v3h3v-3h-3Z\"/></svg>"
        registers[46]["andromeda/cs2/duck.svg"] = "<svg width=\"32\" height=\"32\" viewBox=\"0 0 32 32\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"white\" d=\"M5 7h22v8c0 7-4.4 12-11 15C9.4 27 5 22 5 15V7Zm4 4v4c0 4.8 2.5 8.2 7 10.5 4.5-2.3 7-5.7 7-10.5v-4H9Zm2 7h10v3H11v-3Z\"/></svg>"
        registers[45]["icon_assets"] = registers[46]
        goto p6451
        ::p9254::
        registers[44] = registers[43]["options"]
        z = registers[44]
        registers[45] = z;
        registers[(44)] = z["set_callback"]
        registers[46] = registers[31]["update_callback"]
        goto p2929
        ::p9259::;
        registers[45](registers[46], registers[47])
        registers[45] = registers[1][56]
        registers[46] = "paint"
        registers[47] = registers[30]["paint"];
        registers[45](registers[46], registers[47])
        registers[45] = {
        }
        goto p9340
        ::p9266::
        registers[44]["stubs"] = registers[45]
        registers[44] = registers[21]["visuals"]
        registers[44] = registers[44]["stubs"]
        z = registers[24]
        registers[46] = z;
        registers[(45)] = z["checkbox"]
        registers[47] = "\012<gray>\012<func> \013Manual Arrows"
        registers[45] = registers[45](registers[46], registers[47])
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        goto p6950
        ::p9276::
        registers[49] = "\010Pitch spin right\010defensive_pitch_spin_right_value"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (89)
        registers[53] = (true)
        registers[54] = "\194\176"
        goto p5095
        ::p9285::
        registers[50] = environment["unpack"]
        registers[51] = registers[46]
        m, x = pack_returns(registers[50](unpack_range(51, registers, 51)))
        m = m + 50 - 1
        top = m
        z = 0
        for f = 50, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["builder_type"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["combobox"]
        registers[50] = "\010yaw_type_"..registers[43]
        registers[51] = new_frame(2)
        registers[52] = "Solo"
        registers[53] = "Double"
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53];
        registers[48] = registers[48](unpack_range(51, registers, 49))
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        registers[50] = new_frame(2)
        goto p2741
        ::p9300::
        registers[52] = new_frame(3)
        registers[53] = "2-Way"
        registers[54] = "3-Way"
        registers[55] = "5-Way"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        q[3] = registers[55]
        goto p5636
        ::p9313::
        z = registers[22]
        registers[44] = z;
        registers[(43)] = z["slider"]
        registers[45] = "\010animations_legs_offset_2"
        registers[46] = (0)
        registers[47] = (100)
        registers[48] = (100)
        registers[49] = (true)
        goto p48
        ::p9320::
        registers[51] = "Skeet"
        registers[52] = "Remove Backtrack"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        goto p7915
        ::p9324::
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_sway_left_value"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        registers[48] = registers[25]["antiaim"]
        goto p7676
        ::p9329::;
        registers[71](registers[72], registers[73])
        registers[71] = registers[41]["viewmodel_offset_z"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[70];
        registers[71](registers[72], registers[73])
        registers[71] = registers[41]["viewmodel_options"]
        z = registers[71]
        registers[72] = z;
        registers[(71)] = z["set_callback"]
        registers[73] = registers[66];
        registers[71](registers[72], registers[73])
        goto p9762
        ::p9340::
        registers[45]["active"] = false
        registers[45]["capture_frame"] = -1
        registers[45]["capture_count"] = 0
        registers[45]["render_count"] = 0
        registers[46] = {
        }
        goto p5024
        ::p9346::
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_pitch_refraction_up"] = registers[47]
        z = registers[23]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010DEFENSIVE_PITCHDOWNREFRACTION"..registers[43]
        registers[50] = -89
        registers[51] = (89)
        registers[52] = (0)
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p5632
        ::p9363::;
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        goto p6269
        ::p9367::
        registers[47] = registers[44]["spacers"]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["label"]
        registers[50] = "\010spacer_modifiers_"..registers[43]
        registers[48] = registers[48](registers[49], registers[50])
        z = registers[48]
        registers[49] = z;
        registers[(48)] = z["depend"]
        goto p3550
        ::p9373::
        registers[48] = (true)
        registers[49] = ""
        registers[50] = (0.01)
        registers[51] = {
        }
        registers[51][49] = "Off"
        registers[51][160] = "16:10"
        registers[51][180] = "16:9"
        registers[51][125] = "5:4"
        registers[51][133] = "4:3"
        registers[51][150] = "3:2"
        goto p4579
        ::p9384::
        registers[46] = environment["cvar"]
        registers[46] = registers[46]["cl_bobup"]
        registers[47] = environment["cvar"]
        registers[47] = registers[47]["cl_bobamt_lat"]
        registers[48] = environment["cvar"]
        goto p8700
        ::p9390::
        registers[45][registers[46]] = registers[47]
        registers[46] = "get_texture"
        a = D.f531
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[47] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p2456
        ::p9394::
        registers[46] = registers[44]["def_yaw"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["get"];
        registers[(46)] = registers[(46)](registers[47])
        if registers[46] ~= "Delay" then
            goto p3496
        end
        goto p6937
        ::p9399::
        z = registers[22]
        registers[52] = z;
        registers[(51)] = z["slider"]
        registers[53] = "\010hidden_delay_double_right_"..registers[43]
        a = registers
        z = 54;
        a[z] = 1
        registers[55] = (16)
        goto p5341
        ::p9405::
        registers[46] = registers[21]["visuals"]
        registers[46] = registers[46]["stubs"]
        registers[46] = registers[46]["native_indicators"]
        goto p5606
        ::p9409::
        a = D.f532
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[34] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f533
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[35] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f534
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[36] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[37] = registers[11]["set_callback"]
        registers[38] = "setup_command"
        a = D.f535
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[39] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[37](registers[38], registers[39])
        goto p1658
        ::p9436::
        registers[13] = (registers[13] == 441)
        if not registers[13] then
            goto p7771
        end
        goto p4776
        ::p9439::
        registers[51] = (89)
        registers[52] = -89
        registers[53] = (true)
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        goto p9600
        ::p9445::
        a = registers
        z = (46)
        q = registers
        q = q[44]
        q = q["def_yaw"]
        a[z] = q
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["set"]
        registers[48] = "Double"
        goto p5069
        ::p9453::
        registers[45] = "testing"
        registers[46] = (200)
        registers[47] = (200)
        goto p4690
        ::p9469::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_refraction_right"] = registers[47]
        goto p516
        ::p9474::
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54];
        registers[49] = registers[49](unpack_range(52, registers, 50))
        z = registers[49]
        registers[50] = z;
        registers[(49)] = z["depend"]
        goto p845
        ::p9478::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["dpi"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p5420
        ::p9483::
        registers[14] = "misc"
        registers[15] = "movement"
        registers[16] = "jump at edge"
        m, x = pack_returns(registers[13](unpack_range(16, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[11]["edge_jump"] = registers[12]
        registers[10]["visuals"] = registers[11]
        registers[11] = {
        }
        registers[12] = registers[2]["reference"]
        registers[13] = "misc"
        goto p9147
        ::p9494::
        registers[33]["start_time"] = registers[34]
        registers[33]["next_side"] = 1
        registers[33]["initialized"] = false
        goto p3751
        ::p9498::
        registers[47] = registers[41]["watermark_style"]
        registers[48] = "CS2"
        q = registers[(46)]
        q[1] = registers[47]
        q[2] = registers[48]
        goto p229
        ::p9508::
        registers[24] = {
        }
        registers[23]["correction_until"] = registers[24]
        registers[24] = {
        }
        registers[23]["freestand_cache"] = registers[24]
        registers[24] = {
        }
        registers[25] = {
        }
        goto p8725
        ::p9515::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Sway"
        goto p5446
        ::p9520::
        registers[52] = new_frame(2)
        a = registers
        z = (53)
        q = registers
        q = q[47]
        q = q["builder_type"]
        a[z] = q
        registers[54] = "Hidden"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[53] = new_frame(6)
        goto p7573
        ::p9529::;
        registers[45] = registers[45](unpack_range(48, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        goto p7014
        ::p9534::
        registers[54] = "Custom"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        goto p2939
        ::p9538::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        goto p9086
        ::p9543::;
        registers[25](registers[26], registers[27])
        do
            local f = (23)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        registers[23] = {
        }
        registers[23]["active"] = false
        registers[24] = {
        }
        goto p882
        ::p9560::
        a = D.f536
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[27] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[25][registers[26]] = registers[27]
        registers[26] = "restore_original"
        goto p3195
        ::p9564::
        registers[23] = "AA"
        registers[24] = "Anti-aimbot angles"
        registers[22] = registers[22](registers[23], registers[24])
        registers[23] = registers[2]["group"]
        goto p2411
        ::p9570::
        registers[57] = (true)
        registers[58] = ""
        registers[59] = (1);
        registers[51] = registers[51](unpack_range(59, registers, 52))
        goto p1362
        ::p9576::
        registers[50] = registers[46]
        m, x = pack_returns(registers[49](unpack_range(50, registers, 50)))
        m = m + 49 - 1
        top = m
        z = 0
        for f = 49, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[47] = registers[47](unpack_range(top, registers, 48))
        registers[44]["def_yaw_delayed_left"] = registers[47]
        z = registers[24]
        registers[48] = z;
        registers[(47)] = z["slider"]
        registers[49] = "\010Yaw delayed right\010defensive_yaw_delayed_right"..registers[43]
        registers[50] = -180
        registers[51] = (180)
        registers[52] = (0)
        registers[53] = (true)
        goto p7145
        ::p9591::
        registers[26] = registers[21]["ragebot"]
        registers[26] = registers[26]["extrapolation"]
        if registers[26] == registers[0] then
            goto p1499
        end
        goto p8511
        ::p9596::
        z = registers[22]
        registers[52] = z;
        registers[(51)] = z["slider"]
        registers[53] = "\010hidden_delay_double_left_"..registers[43]
        registers[54] = (1)
        goto p2558
        ::p9600::
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        registers[49] = environment["unpack"]
        registers[50] = registers[46]
        goto p759
        ::p9604::
        registers[28][registers[29]] = registers[30]
        registers[29] = "get_segment_color"
        a = D.f537
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[30] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[28][registers[29]] = registers[30]
        registers[29] = "measure_item"
        goto p400
        ::p9610::
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[(46)](unpack_range(51, registers, 47))
        goto p3793
        ::p9615::;
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["safe_point"] = registers[12]
        registers[12] = registers[2]["reference"]
        goto p5919
        ::p9619::
        registers[46]["dormant"] = "andromeda/cs2/alert.svg"
        registers[46]["duck"] = "andromeda/cs2/duck.svg"
        registers[45]["icon_paths"] = registers[46]
        goto p8933
        ::p9629::
        z = registers[50]
        registers[51] = z;
        registers[(50)] = z["depend"]
        registers[52] = new_frame(2)
        registers[53] = registers[47]["builder_type"]
        registers[54] = "Default"
        goto p6748
        ::p9634::
        registers[54] = registers[48]["values"]
        registers[55] = "Double"
        q = registers[(53)]
        q[1] = registers[54]
        q[2] = registers[55]
        registers[54] = environment["unpack"]
        registers[55] = registers[46]
        m, x = pack_returns(registers[54](unpack_range(55, registers, 55)))
        m = m + 54 - 1
        top = m
        z = 0
        for f = 54, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[49] = registers[49](unpack_range(top, registers, 50))
        registers[48]["left"] = registers[49]
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["slider"]
        registers[51] = "\010hidden_yaw_modifier_right_"..registers[43]
        goto p2407
        ::p9645::
        registers[51] = registers[47]["builder_type"]
        a = registers
        z = 52;
        a[z] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        registers[51] = environment["unpack"]
        registers[52] = registers[46]
        m, x = pack_returns(registers[51](unpack_range(52, registers, 52)))
        m = m + 51 - 1
        top = m
        z = 0
        for f = 51, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[48] = registers[48](unpack_range(top, registers, 49))
        registers[47]["type"] = registers[48]
        z = registers[22]
        registers[49] = z;
        registers[(48)] = z["slider"]
        registers[50] = "\010yaw_modifier_skitter_"..registers[43]
        registers[51] = -180
        registers[52] = (180)
        goto p8521
        ::p9659::
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[42] = registers[42](registers[43], registers[44])
        registers[41]["watermark"] = registers[42]
        z = registers[23]
        registers[43] = z;
        registers[(42)] = z["combobox"]
        registers[44] = "\010watermark_style"
        goto p7451
        ::p9666::;
        registers[49](registers[50], registers[51])
        z = registers[22]
        registers[50] = z;
        registers[(49)] = z["combobox"]
        registers[51] = "\010delay_values_"..registers[43]
        registers[52] = registers[39]
        goto p3744
        ::p9671::
        registers[56] = (1);
        registers[48] = registers[48](unpack_range(56, registers, 49))
        registers[47]["value"] = registers[48]
        goto p5723
        ::p9675::
        registers[16] = environment["string"]
        registers[16] = registers[16]["len"]
        registers[17] = "\180\198"
        goto p35
        ::p9679::
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_yaw"]
        registers[54] = "Double"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_yaw_delay"]
        goto p3633
        ::p9686::
        registers[54] = "\194\176";
        registers[47] = registers[47](unpack_range(54, registers, 48))
        z = registers[47]
        registers[48] = z;
        registers[(47)] = z["depend"]
        a = registers
        z = (49)
        q = environment
        q = q["unpack"]
        a[z] = q
        goto p9080
        ::p9693::
        registers[52] = (180)
        registers[53] = (0)
        registers[54] = (true)
        registers[55] = "\194\176"
        registers[56] = (1)
        goto p1526
        ::p9699::
        registers[51] = (255);
        registers[45] = registers[45](unpack_range(51, registers, 46))
        z = registers[45]
        registers[46] = z;
        registers[(45)] = z["depend"]
        registers[47] = registers[25]["antiaim"]
        registers[48] = registers[25]["builder"]
        goto p3523
        ::p9707::
        registers[51] = registers[47]["builder_type"]
        registers[52] = "Default"
        q = registers[(50)]
        q[1] = registers[51]
        q[2] = registers[52]
        goto p1239
        ::p9711::
        q = registers[(51)]
        q[1] = registers[52]
        q[2] = registers[53]
        registers[52] = new_frame(2)
        registers[53] = registers[44]["def_pitch"]
        registers[54] = "Refraction"
        q = registers[(52)]
        q[1] = registers[53]
        q[2] = registers[54]
        registers[(46)](unpack_range(52, registers, 47))
        registers[46] = registers[44]["def_pitch_refraction_down"]
        z = registers[46]
        registers[47] = z;
        registers[(46)] = z["depend"]
        goto p512
        ::p9721::
        a = D.f538
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = "apply_move_lean"
        a = D.f539
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[44] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[31][registers[43]] = registers[44]
        registers[43] = "capture_smooth_state"
        goto p115
        ::p9728::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[21] = {
        }
        registers[22] = {
        }
        goto p6813
        ::p9732::
        registers[57] = (true)
        registers[58] = "%"
        registers[59] = (1)
        goto p7636
        ::p9736::
        registers[44] = "\010watermark_position"
        registers[45] = new_frame(6)
        registers[46] = "Top Left"
        registers[47] = "Top Center"
        registers[48] = "Top Right"
        registers[49] = "Bottom Left"
        registers[50] = "Bottom Center"
        registers[51] = "Bottom Right"
        q = registers[(45)]
        q[1] = registers[46]
        q[2] = registers[47]
        q[3] = registers[48]
        q[4] = registers[49]
        q[5] = registers[50]
        q[6] = registers[51];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        z = registers[42]
        registers[43] = z;
        registers[(42)] = z["depend"]
        registers[44] = registers[25]["visuals"]
        registers[45] = registers[41]["watermark"];
        registers[42] = registers[42](unpack_range(45, registers, 43))
        registers[41]["watermark_position"] = registers[42]
        goto p4031
        ::p9752::
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        registers[53] = (true)
        goto p8219
        ::p9756::
        a = D.f540
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[18][registers[19]] = registers[20]
        registers[18] = environment["entity"]
        registers[19] = "extrapolate_position"
        a = D.f541
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[20] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p8652
        ::p9762::
        registers[71] = registers[11]["set_callback"]
        registers[72] = "pre_render"
        registers[73] = registers[66];
        registers[71](registers[72], registers[73])
        registers[71] = registers[11]["set_callback"]
        goto p1007
        ::p9768::
        registers[50] = registers[45]
        registers[51] = new_frame(2)
        registers[52] = registers[44]["toggle_builder"]
        goto p3863
    end
end
