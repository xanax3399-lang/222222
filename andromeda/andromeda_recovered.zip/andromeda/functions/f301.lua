-- Recovered function f301; author names are unavailable.
F.f301 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f301")
        tick(1)
        goto p46
        ::p9::
        tick(9)
        registers[12] = (registers[12] - registers[9])
        registers[13] = (180)
        m, x = pack_returns(registers[11](unpack_range(13, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[0][37]
        goto p264
        ::p17::
        tick(17)
        if registers[4] == registers[0] then
            goto p95
        end
        registers[5] = registers[4]["simtime"]
        registers[5] = (registers[3] - registers[5])
        branch_taken = false
        if not (not (registers[5] < 1)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p95
        end
        goto p259
        ::p25::
        tick(25)
        registers[4] = (0)
        goto p64
        ::p27::
        tick(27)
        registers[3] = upvalues[1]
        registers[4] = registers[2]
        registers[(3)](registers[4])
        do
            return 
        end
        ::p46::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0][50]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        goto p148
        ::p64::
        tick(64)
        registers[5] = upvalues[0][28];
        registers[5] = registers[5]()
        registers[4] = (registers[4] / registers[5])
        goto p142
        ::p68::
        tick(68)
        registers[14] = registers[14](registers[15], registers[16])
        goto p230
        ::p85::
        tick(85)
        registers[14] = (registers[11] ~= 0)
        goto p172
        ::p87::
        tick(87)
        registers[8] = upvalues[2]["wraith"]
        registers[8] = registers[8]["prev"]
        registers[8] = registers[8][registers[2]]
        goto p174
        ::p91::
        tick(91)
        registers[7] = upvalues[1]
        registers[8] = registers[2]
        registers[(7)](registers[8])
        do
            return 
        end
        ::p95::
        registers[5] = upvalues[3]
        registers[6] = registers[1];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[3]
        goto p109
        ::p103::
        tick(103)
        registers[12] = registers[12]["cur"]
        registers[13] = {
        }
        registers[14] = registers[7]
        if registers[14] then
            goto p269
        end
        goto p262
        ::p109::
        registers[7] = registers[2];
        registers[(6)] = registers[(6)](registers[7])
        if registers[5] == registers[0] then
            goto p91
        end
        goto p199
        ::p126::
        tick(126)
        m, x = pack_returns(registers[7](unpack_range(9, registers, 8)))
        z = 0
        for f = 7, 8 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = upvalues[0][154]
        registers[10] = upvalues[4]
        registers[11] = upvalues[5]
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[11] = registers[11](registers[12], registers[13])
        registers[12] = (180)
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = registers[9](unpack_range(top, registers, 10))
        registers[10] = upvalues[0][154]
        registers[11] = upvalues[4]
        registers[12] = registers[8]
        if registers[12] then
            goto p9
        end
        goto p190
        ::p142::
        registers[4] = 0.5 + registers[4];
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = upvalues[2]["wraith"]
        registers[4] = registers[4]["cur"]
        registers[4] = registers[4][registers[2]]
        goto p17
        ::p148::
        if registers[3] ~= true then
            goto p27
        end
        goto p194
        ::p172::
        tick(172)
        if not registers[14] then
            goto p230
        end
        goto p243
        ::p174::
        registers[7][registers[2]] = registers[8]
        registers[7] = upvalues[2]["wraith"]
        registers[7] = registers[7]["prev"]
        goto p184
        ::p178::
        tick(178)
        registers[13]["last_shot_time"] = registers[14]
        registers[12][registers[2]] = registers[13]
        do
            return 
        end
        ::p184::
        registers[7][registers[2]] = registers[4]
        registers[7] = upvalues[0][47]
        registers[8] = registers[2]
        registers[9] = "m_angEyeAngles"
        goto p126
        ::p190::
        registers[12] = (0)
        goto p9
        ::p194::
        registers[4] = upvalues[0][42]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        if not registers[4] then
            goto p201
        end
        goto p27
        ::p199::
        if registers[6] ~= registers[0] then
            goto p247
        end
        goto p91
        ::p201::
        registers[3] = upvalues[0][154]
        registers[4] = upvalues[0][47]
        registers[5] = registers[2]
        registers[6] = "m_flSimulationTime"
        registers[4] = registers[4](registers[5], registers[6])
        goto p241
        ::p208::
        tick(208)
        registers[7][registers[2]] = registers[8]
        registers[7] = upvalues[2]["wraith"]
        registers[7] = registers[7]["pre_prev"]
        goto p87
        ::p230::
        if registers[14] then
            goto p178
        end
        goto p275
        ::p232::
        tick(232)
        if not registers[14] then
            goto p172
        end
        goto p85
        ::p241::
        if registers[4] then
            goto p64
        end
        goto p25
        ::p243::
        registers[14] = upvalues[0][47]
        registers[15] = registers[11]
        registers[16] = "m_fLastShotTime"
        goto p68
        ::p247::
        registers[7] = upvalues[2]["wraith"]
        registers[7] = registers[7]["pre_pre_prev"]
        registers[8] = upvalues[2]["wraith"]
        registers[8] = registers[8]["pre_prev"]
        registers[8] = registers[8][registers[2]]
        goto p208
        ::p259::
        do
            return 
        end
        ::p262::
        registers[14] = (0)
        goto p269
        ::p264::
        registers[12] = registers[2];
        registers[(11)] = registers[(11)](registers[12])
        registers[12] = upvalues[2]["wraith"]
        goto p103
        ::p269::
        registers[13]["pitch"] = registers[14]
        registers[13]["yaw"] = registers[10]
        registers[13]["yaw_backwards"] = registers[9]
        registers[13]["simtime"] = registers[3]
        registers[14] = (registers[11] ~= registers[0])
        goto p232
        ::p275::
        registers[14] = nil
        goto p178
    end
end
