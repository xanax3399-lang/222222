-- Recovered function f54; author names are unavailable.
F.f54 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f54")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = (1)
        registers[4] = (0)
        goto p40
        ::p19::
        tick(19)
        registers[5] = registers[5] + registers[6]
        do
            return registers[5]
        end
        ::p21::
        tick(21)
        registers[3] = (registers[3] * 16)
        ::p40::
        if not (0 < registers[1]) then
            goto p102
        end
        goto p90
        ::p70::
        tick(70)
        registers[7] = registers[7][registers[6]]
        registers[7] = registers[7] * registers[3]
        registers[4] = registers[4] + registers[7]
        goto p97
        ::p90::
        if not (0 < registers[2]) then
            goto p102
        end
        registers[5] = registers[1] % 16
        registers[6] = registers[2] % 16
        registers[7] = upvalues[0][registers[5]]
        goto p70
        ::p97::
        registers[7] = (registers[1] - registers[5])
        registers[1] = registers[7] / 16
        registers[7] = (registers[2] - registers[6])
        registers[2] = registers[7] / 16
        goto p21
        ::p102::
        registers[5] = registers[1] * registers[3]
        a = registers
        z = 5
        q = registers
        q = q[4]
        m = registers
        x = 5
        m = m[x]
        q = q + m
        a[z] = q
        registers[6] = registers[2] * registers[3]
        goto p19
    end
end
