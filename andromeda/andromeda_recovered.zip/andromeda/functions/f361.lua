-- Recovered function f361; author names are unavailable.
F.f361 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f361")
        tick(1)
        goto p63
        ::p2::
        tick(2)
        registers[8] = environment["tostring"]
        registers[9] = registers[1]["slots"]
        registers[9] = registers[9][registers[7]]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"]
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[8] = "|"..registers[8]
        registers[3] = (registers[3]..registers[8])
        goto p96
        ::p13::
        tick(13)
        a = upvalues[1];
        registers[1] = a[2][a[1]]
        registers[2] = environment["tostring"]
        registers[3] = upvalues[4]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        registers[2] = "|Solo|"..registers[2]
        goto p107
        ::p21::
        tick(21)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = registers[3]
        do
            return registers[4]
        end
        ::p39::
        tick(39)
        registers[1] = upvalues[2]["custom"]
        registers[2] = upvalues[3];
        registers[2] = registers[2]()
        a = upvalues[1];
        registers[3] = a[2][a[1]]
        registers[4] = environment["tostring"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = environment["tostring"]
        registers[6] = registers[1]["randomize"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[5] = "|"..registers[5]
        goto p100
        ::p54::
        tick(54)
        a = upvalues[1];
        registers[1] = a[2][a[1]]
        registers[2] = environment["tostring"]
        registers[3] = upvalues[2]["double"]
        registers[3] = registers[3]["left"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"]
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        registers[3] = environment["tostring"]
        goto p139
        ::p63::
        a = upvalues[0];
        registers[1] = a[2][a[1]]
        if registers[1] ~= "Double" then
            goto p80
        end
        goto p54
        ::p80::
        a = upvalues[0];
        registers[1] = a[2][a[1]]
        if registers[1] ~= "Custom" then
            goto p13
        end
        goto p39
        ::p96::
        tick(96)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p2
        end
        goto p21
        ::p100::
        registers[4] = (registers[4]..registers[5])
        registers[4] = "|Custom|"..registers[4]
        registers[3] = (registers[3]..registers[4])
        registers[4] = (1)
        registers[5] = registers[2]
        registers[6] = (1)
        goto p122
        ::p107::
        registers[1] = (registers[1]..registers[2])
        do
            return registers[1]
        end
        ::p122::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p96
        registers[20] = 4804 + registers[20]
        registers[20] = registers[20] + -4969
        registers[13][55] = registers[20]
        registers[19][129] = 53
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        goto p54
        ::p139::
        registers[4] = upvalues[2]["double"]
        registers[4] = registers[4]["right"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        registers[4] = environment["tostring"]
        registers[5] = upvalues[2]["double"]
        registers[5] = registers[5]["randomize"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = registers[4](unpack_range(top, registers, 5))
        registers[4] = "|"..registers[4]
        registers[3] = (registers[3]..registers[4])
        registers[3] = "|"..registers[3]
        registers[2] = (registers[2]..registers[3])
        registers[2] = "|Double|"..registers[2]
        registers[1] = (registers[1]..registers[2])
        do
            return registers[1]
        end
    end
end
