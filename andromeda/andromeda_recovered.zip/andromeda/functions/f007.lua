-- Recovered function f7; author names are unavailable.
F.f7 = function(function_metadata, upvalues)
    local operand_k = function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f7")
        tick(1)
        goto p180
        ::p2::
        tick(2)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[1]
        registers[2] = upvalues[2];
        registers[2] = registers[2]()
        registers[3] = upvalues[0]
        goto p54
        ::p18::
        tick(18)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[15] = registers[5][registers[15]]
        goto p107
        ::p22::
        tick(22)
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p171
        ::p24::
        tick(24);
        registers[15] = registers[15]()
        registers[16] = upvalues[0]
        m, x = pack_returns(registers[16]())
        m = m + 16 - 1
        top = m
        z = 0
        for f = 16, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[15] = new_frame(1)
        registers[16] = upvalues[2]
        goto p163
        ::p31::
        tick(31)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[3]
        registers[15] = upvalues[2]
        goto p24
        ::p35::
        tick(35)
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        goto p131
        ::p54::
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p64::
        tick(64)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        goto p31
        ::p68::
        tick(68)
        registers[5] = {
        }
        registers[6] = (0)
        registers[7] = (255)
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p128
        ::p73::
        tick(73)
        registers[17] = upvalues[2]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        goto p109
        ::p84::
        tick(84)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p138
        end
        goto p191
        ::p88::
        tick(88)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[6] = (1)
        registers[7] = upvalues[0];
        registers[7] = registers[7]()
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p142
        registers[35] = operand_k
        registers[35][184] = 0
        registers[35][122] = 183
        registers[28] = nil
        registers[29] = nil
        registers[30] = nil
        registers[31] = nil
        registers[32] = nil
        registers[33] = nil
        registers[34] = nil
        registers[35] = nil
        goto p184
        ::p107::
        if registers[15] then
            goto p109
        end
        goto p118
        ::p109::
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        if not registers[15] then
            goto p31
        end
        goto p64
        ::p118::
        registers[15] = upvalues[1]
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        goto p73
        ::p123::
        tick(123)
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p193
        ::p128::
        tick(128)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p35
        end
        goto p88
        ::p131::
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        goto p123
        ::p138::
        registers[14] = upvalues[2];
        registers[14] = registers[14]()
        if not registers[14] then
            goto p18
        end
        goto p201
        ::p142::
        tick(142)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p197
        end
        goto p210
        ::p163::;
        registers[16] = registers[16]()
        registers[17] = upvalues[0]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(15)]
        for f = 1, top - (15) do
            q[(0) + f] = registers[(15) + f]
        end
        registers[5][registers[14]] = registers[15]
        goto p84
        ::p171::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p68
        end
        goto p2
        ::p180::
        registers[1] = (1)
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        goto p22
        ::p184::
        tick(184)
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0]
        goto p226
        ::p191::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p142
        ::p193::
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        goto p184
        ::p197::
        registers[10] = (0)
        registers[11] = (255)
        registers[12] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p84
        ::p201::
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p18
        ::p210::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p68
        ::p226::;
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p128
    end
end
