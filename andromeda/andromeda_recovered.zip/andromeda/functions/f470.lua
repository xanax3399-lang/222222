-- Recovered function f470; author names are unavailable.
F.f470 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_13, slot_14, slot_15, slot_16 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, q = andromeda_environment, nil
        local a = nil
        local tick = new_tick("f470")
        tick(1)
        goto p58
        ::p23::
        tick(23)
        slot_7 = slot_1["id"]
        if slot_7 == slot_0 then
            goto p61
        end
        goto p120
        ::p34::
        tick(34)
        slot_6 = slot_2["hitgroup"]
        goto p133
        ::p45::
        tick(45)
        q = slot_11
        q[1] = slot_12
        q[2] = slot_13
        slot_12 = new_frame(2)
        slot_13 = slot_5
        slot_14 = "miss"
        q = slot_12
        q[1] = slot_13
        q[2] = slot_14
        slot_13 = new_frame(2)
        slot_14 = " due to "
        goto p78
        ::p54::
        tick(54)
        slot_2 = upvalues[0]["shots"]
        slot_3 = slot_1["id"]
        slot_2 = slot_2[slot_3]
        goto p66
        ::p58::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p159
        end
        goto p160
        ::p61::
        tick(61)
        do
            return 
        end
        ::p62::
        tick(62)
        slot_2 = slot_1["id"]
        slot_2 = (slot_2 ~= slot_0)
        if not slot_2 then
            goto p66
        end
        goto p54
        ::p66::
        if slot_2 then
            goto p154
        end
        goto p180
        ::p74::
        tick(74)
        slot_5 = upvalues[0]["get_hitgroup"]
        slot_6 = slot_1["hitgroup"]
        if slot_6 then
            goto p133
        end
        goto p182
        ::p78::
        slot_15 = "text"
        q = slot_13
        q[1] = slot_14
        q[2] = slot_15
        slot_14 = new_frame(2)
        slot_15 = slot_6
        slot_16 = "miss"
        q = slot_14
        q[1] = slot_15
        q[2] = slot_16
        goto p99
        ::p93::
        tick(93);
        slot_5 = slot_5(slot_6)
        slot_6 = slot_1["reason"]
        slot_6 = (slot_6 == "?")
        if not slot_6 then
            goto p113
        end
        goto p172
        ::p99::
        q = slot_8
        q[1] = slot_9
        q[2] = slot_10
        q[3] = slot_11
        q[4] = slot_12
        q[5] = slot_13
        q[6] = slot_14
        slot_7(slot_8)
        if slot_2 == slot_0 then
            goto p61
        end
        goto p23
        ::p103::
        tick(103)
        slot_6 = (0)
        goto p93
        ::p105::
        tick(105)
        slot_11 = new_frame(2)
        slot_12 = " in the "
        slot_13 = "text"
        goto p45
        ::p109::
        tick(109)
        slot_6 = environment["tostring"]
        slot_7 = slot_1["reason"]
        if slot_7 then
            goto p131
        end
        goto p178
        ::p113::
        tick(113)
        if slot_6 then
            goto p124
        end
        goto p109
        ::p116::
        tick(116)
        slot_3 = slot_1["target"]
        goto p174
        ::p120::
        slot_7 = upvalues[0]["shots"]
        slot_8 = slot_1["id"]
        slot_7[slot_8] = slot_0
        goto p61
        ::p124::
        tick(124)
        slot_7 = upvalues[0]["push"]
        slot_8 = new_frame(6)
        slot_9 = new_frame(2)
        slot_10 = "Missed "
        slot_11 = "text"
        q = slot_9
        q[1] = slot_10
        q[2] = slot_11
        goto p135
        ::p131::
        tick(131);
        slot_6 = slot_6(slot_7)
        goto p124
        ::p133::
        tick(133)
        if slot_6 then
            goto p93
        end
        goto p103
        ::p135::
        slot_10 = new_frame(2)
        slot_11 = slot_4
        slot_12 = "miss"
        q = slot_10
        q[1] = slot_11
        q[2] = slot_12
        goto p105
        ::p154::
        tick(154)
        slot_3 = environment["tonumber"]
        slot_4 = slot_1["target"];
        slot_3 = slot_3(slot_4)
        if slot_3 then
            goto p174
        end
        goto p116
        ::p159::
        tick(159)
        do
            return 
        end
        ::p160::
        slot_2 = slot_1["target"]
        if slot_2 ~= slot_0 then
            goto p62
        end
        goto p159
        ::p172::
        slot_6 = "resolver"
        goto p113
        ::p174::
        slot_4 = upvalues[0]["get_player_name"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        goto p74
        ::p178::
        slot_7 = "?"
        goto p131
        ::p180::
        slot_2 = nil
        goto p154
        ::p182::
        slot_6 = (slot_2 ~= slot_0)
        if not slot_6 then
            goto p133
        end
        goto p34
    end
end
