-- Recovered function f412; author names are unavailable.
F.f412 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f412")
        tick(1)
        goto p205
        ::p13::
        tick(13)
        if not registers[11] then
            goto p166
        end
        goto p151
        ::p26::
        tick(26)
        if not registers[11] then
            goto p120
        end
        goto p32
        ::p28::
        tick(28)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p142
        end
        goto p233
        ::p30::
        tick(30)
        registers[11] = (registers[11] == "Custom")
        goto p171
        ::p32::
        registers[11] = registers[8]["type"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[11] ~= "Off")
        goto p120
        ::p42::
        tick(42)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p86
        end
        goto p100
        ::p64::
        tick(64)
        registers[11] = (registers[10] == "Jitter")
        goto p166
        ::p82::
        tick(82)
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        goto p242
        ::p86::
        registers[17] = registers[9]["slots"]
        registers[17] = registers[17][registers[16]]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["set_visible"]
        registers[19] = registers[11]
        if not registers[19] then
            goto p195
        end
        goto p215
        ::p93::
        tick(93)
        a = registers
        z = (11)
        q = registers
        q = q[7]
        q = q["state_name"]
        a[z] = q
        registers[11] = registers[2] == registers[11]
        goto p13
        ::p100::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p28
        ::p102::
        tick(102)
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        goto p218
        ::p120::
        if not registers[11] then
            goto p171
        end
        goto p229
        ::p123::
        tick(123)
        registers[13] = upvalues[3][151]
        registers[14] = (0)
        registers[15] = upvalues[3][162]
        registers[16] = (10)
        goto p179
        ::p129::
        tick(129)
        registers[13] = (1)
        registers[14] = (10)
        registers[15] = (1)
        goto p214
        ::p142::
        registers[7] = upvalues[2][registers[6]]
        registers[8] = registers[7]["delay"]
        registers[9] = registers[8]["custom"]
        registers[10] = upvalues[0]["builder"]
        registers[11] = registers[7]["state_name"]
        registers[10] = registers[10][registers[11]]
        registers[10] = registers[10]["body_yaw"]
        registers[10] = registers[10]["type"]
        goto p161
        ::p151::
        registers[11] = (registers[10] == "Off")
        if registers[11] then
            goto p166
        end
        goto p64
        ::p161::
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = registers[1]
        if not registers[11] then
            goto p13
        end
        goto p93
        ::p166::
        if not registers[11] then
            goto p26
        end
        goto p224
        ::p169::
        tick(169)
        registers[12] = (0)
        goto p123
        ::p171::
        registers[12] = registers[11]
        if not registers[12] then
            goto p218
        end
        goto p220
        ::p179::
        registers[17] = registers[12]
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[13] = registers[13](unpack_range(top, registers, 14))
        a = registers
        z = 12
        q = registers
        q = q[13]
        a[z] = q
        goto p129
        ::p186::
        tick(186)
        registers[3] = (1)
        registers[4] = upvalues[2]
        registers[4] = (#registers[4])
        registers[5] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p28
        goto p233
        ::p195::
        tick(195);
        registers[17](registers[18], registers[19])
        goto p42
        ::p205::
        registers[1] = upvalues[0]["switch"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[1] = (registers[1] == "Anti-Aim")
        if not registers[1] then
            goto p242
        end
        goto p82
        ::p214::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p42
        ::p215::
        registers[19] = (registers[16] <= registers[12])
        goto p195
        ::p218::
        if registers[12] then
            goto p123
        end
        goto p169
        ::p220::
        registers[12] = upvalues[3][154]
        registers[13] = registers[9]["count"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["get"]
        goto p102
        ::p224::
        registers[11] = registers[7]["builder_type"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[11] == "Hidden")
        goto p26
        ::p229::
        registers[11] = registers[8]["values"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        goto p30
        ::p233::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p242::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["conditions"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        goto p186
    end
end
