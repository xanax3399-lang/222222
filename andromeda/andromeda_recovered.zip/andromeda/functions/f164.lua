-- Recovered function f164; author names are unavailable.
F.f164 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local tick = new_tick("f164")
        tick(1)
        goto p54
        ::p27::
        tick(27)
        slot_2 = slot_1["hotkey"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["override"]
        slot_2(slot_3)
        goto p38
        ::p32::
        tick(32)
        do
            return 
        end
        ::p35::
        tick(35)
        slot_3 = slot_1["override"]
        if slot_3 ~= slot_0 then
            goto p47
        end
        goto p32
        ::p38::
        tick(38)
        do
            return 
        end
        ::p47::
        z = slot_1
        slot_3 = z;
        slot_2 = z["override"]
        slot_2(slot_3)
        slot_2 = slot_1["hotkey"]
        goto p80
        ::p54::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= "table" then
            goto p32
        end
        goto p35
        ::p80::
        if slot_2 == slot_0 then
            goto p38
        end
        goto p27
    end
end
