-- Recovered function f328; author names are unavailable.
F.f328 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f328")
        tick(1)
        goto p27
        ::p2::
        tick(2)
        slot_5 = (0)
        ::p10::
        tick(10)
        slot_6 = slot_2["sequence"]
        if slot_6 then
            goto p19
        end
        goto p34
        ::p19::
        tick(19)
        slot_5 = slot_5 < slot_6
        do
            return slot_5
        end
        ::p23::
        tick(23)
        slot_5 = slot_3 < slot_4
        do
            return slot_5
        end
        ::p25::
        tick(25)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p27::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_1 ~= slot_0 then
            goto p83
        end
        goto p25
        ::p30::
        tick(30)
        slot_5 = slot_1["sequence"]
        if slot_5 then
            goto p10
        end
        goto p2
        ::p34::
        slot_6 = (0)
        goto p19
        ::p37::
        tick(37)
        slot_3 = (true)
        do
            return slot_3
        end
        ::p81::
        tick(81)
        if slot_3 == slot_4 then
            goto p30
        end
        goto p23
        ::p83::
        if slot_2 ~= slot_0 then
            goto p92
        end
        goto p37
        ::p85::
        tick(85)
        slot_4 = (1000)
        goto p81
        ::p87::
        tick(87)
        slot_4 = slot_2["order"]
        if slot_4 then
            goto p81
        end
        goto p85
        ::p92::
        slot_3 = slot_1["order"]
        if slot_3 then
            goto p87
        end
        slot_3 = (1000)
        goto p87
    end
end
