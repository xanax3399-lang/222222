-- Recovered function f415; author names are unavailable.
F.f415 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f415")
        tick(1)
        goto p81
        ::p12::
        tick(12)
        registers[7] = upvalues[1]
        registers[8] = upvalues[0][46]
        registers[9] = registers[6]
        goto p107
        ::p23::
        tick(23)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = registers[2]
        registers[5] = registers[3]
        goto p119
        ::p34::
        tick(34)
        if not registers[7] then
            goto p12
        end
        goto p50
        ::p36::
        tick(36)
        registers[2] = registers[8]
        registers[3] = registers[6]
        ::p50::
        tick(50)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[5] = z;
            registers[6] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p68
        end
        goto p23
        ::p59::
        tick(59)
        registers[4] = environment["ipairs"]
        registers[5] = environment["entity"]
        a = registers
        z = (5)
        q = registers
        q = q[5]
        q = q["get_entities"]
        a[z] = q
        m, x = pack_returns(registers[5]())
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[4](unpack_range(top, registers, 5)))
        z = 0
        for f = 4, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(4)]
        n = registers[5]
        U = registers[6]
        goto p50
        ::p68::
        registers[7] = upvalues[0][42]
        registers[8] = registers[6];
        registers[(7)] = registers[(7)](registers[8])
        goto p34
        ::p81::
        registers[1] = upvalues[0][32];
        registers[1] = registers[1]()
        registers[2] = environment["math"]
        registers[2] = registers[2]["huge"]
        registers[3] = nil
        goto p59
        ::p107::
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        z = registers[7]
        registers[9] = z;
        registers[(8)] = z["dist"]
        registers[10] = upvalues[1]
        registers[11] = upvalues[0][46]
        registers[12] = registers[1]
        m, x = pack_returns(registers[11](unpack_range(12, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[10](unpack_range(top, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        if not (registers[8] < registers[2]) then
            goto p50
        end
        goto p36
        ::p119::
        do
            return unpack_range(5, registers, (4))
        end
    end
end
