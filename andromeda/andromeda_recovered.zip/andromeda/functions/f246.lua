-- Recovered function f246; author names are unavailable.
F.f246 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f246")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]["update_callbacks"]
        slot_2 = (false)
        slot_1(slot_2)
        slot_1 = upvalues[0]["reset"]
        slot_1()
        do
            return 
        end
    end
end
