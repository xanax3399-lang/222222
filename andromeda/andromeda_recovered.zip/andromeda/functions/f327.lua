-- Recovered function f327; author names are unavailable.
F.f327 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f327")
        tick(1)
        goto p59
        ::p40::
        tick(40)
        slot_5 = slot_5["antiaim"]
        slot_3 = slot_3(slot_4, slot_5)
        slot_2["antiaim"] = slot_3
        goto p70
        ::p59::
        a = {
            ...,
        }
        slot_1 = a[1]
        z = slot_1
        slot_3 = z;
        slot_2 = z["build_maps"]
        slot_2(slot_3)
        slot_2 = {
        }
        z = slot_1
        slot_4 = z;
        slot_3 = z["serialize_group"]
        slot_5 = slot_1["maps"]
        goto p40
        ::p67::
        tick(67)
        slot_3 = slot_3(slot_4, slot_5)
        slot_2["visuals"] = slot_3
        do
            return slot_2
        end
        ::p70::
        z = slot_1
        slot_4 = z;
        slot_3 = z["serialize_group"]
        slot_5 = slot_1["maps"]
        slot_5 = slot_5["visuals"]
        goto p67
    end
end
