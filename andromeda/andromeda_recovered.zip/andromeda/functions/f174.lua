-- Recovered function f174; author names are unavailable.
F.f174 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local a = nil
        local tick = new_tick("f174")
        tick(1)
        a = upvalues[0]
        a[2][a[1]] = (0)
        a = upvalues[1];
        slot_1 = a[2][a[1]]["exploits"]
        slot_1 = slot_1["defensive"]
        slot_1["left"] = 0
        a = upvalues[1];
        slot_1 = a[2][a[1]]["exploits"]
        slot_1 = slot_1["defensive"]
        slot_1["max"] = 0
        a = upvalues[1];
        slot_1 = a[2][a[1]]["exploits"]
        slot_1["charged"] = false
        do
            return 
        end
    end
end
