-- Recovered function f285; author names are unavailable.
F.f285 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f285")
        tick(1)
        goto p7
        ::p2::
        tick(2)
        do
            return 
        end
        ::p3::
        tick(3)
        slot_1 = upvalues[1]["apply"]
        slot_2 = (false)
        slot_1(slot_2)
        do
            return 
        end
        ::p7::
        slot_1 = upvalues[0]["is_quit"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p3
        end
        goto p2
    end
end
