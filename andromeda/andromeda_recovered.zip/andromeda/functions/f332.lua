-- Recovered function f332; author names are unavailable.
F.f332 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f332")
        tick(1)
        goto p49
        ::p3::
        tick(3)
        a = upvalues[2];
        slot_4 = a[2][a[1]]["exploits"]
        slot_4["charged"] = slot_3
        slot_4 = slot_1["command_number"]
        a = upvalues[3]
        a[2][a[1]] = slot_4
        goto p58
        ::p8::
        tick(8)
        slot_6 = "m_nTickBase"
        slot_4 = slot_4(slot_5, slot_6)
        slot_5 = upvalues[1]["is_double_tap"];
        slot_5 = slot_5()
        if slot_5 then
            goto p85
        end
        goto p54
        ::p49::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][32];
        slot_2 = slot_2()
        if slot_2 then
            goto p81
        end
        goto p88
        ::p54::
        slot_5 = upvalues[1]["is_on_shot_antiaim"];
        slot_5 = slot_5()
        goto p85
        ::p58::
        do
            return 
        end
        ::p60::
        tick(60)
        slot_3 = (false)
        goto p3
        ::p77::
        tick(77)
        slot_6 = upvalues[0][23];
        slot_6 = slot_6()
        slot_3 = slot_6 > slot_4
        goto p3
        ::p81::
        slot_3 = (false)
        slot_4 = upvalues[0][47]
        slot_5 = slot_2
        goto p8
        ::p85::
        if slot_5 then
            goto p77
        end
        goto p60
        ::p88::
        do
            return 
        end
    end
end
