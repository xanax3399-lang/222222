-- Recovered function f141; author names are unavailable.
F.f141 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f141")
        tick(1)
        goto p54
        ::p10::
        tick(10)
        slot_1 = slot_1["fakelag"]
        slot_1 = slot_1["variance"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        goto p19
        ::p16::
        tick(16)
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        do
            return 
        end
        ::p19::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["fakelag"]
        slot_1 = slot_1["limit"]
        goto p16
        ::p50::
        tick(50)
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        goto p10
        ::p54::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["fakelag"]
        slot_1 = slot_1["on"]
        goto p50
    end
end
