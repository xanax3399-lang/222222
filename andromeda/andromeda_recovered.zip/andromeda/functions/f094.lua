-- Recovered function f94; author names are unavailable.
F.f94 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f94")
        tick(1)
        goto p61
        ::p2::
        tick(2);
        registers[(6)] = registers[(6)](registers[7])
        registers[6] = (registers[2]..registers[6])
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p61::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]["hmac_sha256"]
        registers[5] = registers[1]
        registers[6] = upvalues[1]
        registers[7] = registers[3]
        goto p2
    end
end
