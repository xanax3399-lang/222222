-- Recovered function f468; author names are unavailable.
F.f468 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f468")
        tick(1)
        goto p29
        ::p4::
        tick(4);
        registers[2](registers[3], registers[4])
        do
            return 
        end
        ::p15::
        tick(15)
        registers[1] = upvalues[0]["fakelag_exploit_tick"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[2] = environment["type"]
        goto p34
        ::p27::
        tick(27)
        do
            return 
        end
        ::p29::
        registers[1] = upvalues[0]["fakelag_exploit_enabled"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p15
        end
        goto p27
        ::p34::
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        branch_taken = false
        if registers[2] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p84
        end
        goto p83
        ::p63::
        tick(63);
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[1]["antiaim"]
        registers[2] = registers[2]["fakelag"]
        registers[2] = registers[2]["limit"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["set"]
        a = registers
        z = 4
        q = registers
        q = q[1]
        m = 2
        q = q - m;
        a[z] = q
        goto p4
        ::p83::
        do
            return 
        end
        ::p84::
        registers[2] = upvalues[1]["misc"]
        registers[2] = registers[2]["usercmd"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["set"]
        registers[4] = registers[1]
        goto p63
    end
end
