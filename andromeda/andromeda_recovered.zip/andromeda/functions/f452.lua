-- Recovered function f452; author names are unavailable.
F.f452 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f452")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[1] * registers[2]
        registers[3] = (registers[3] * 0.01)
        registers[4] = upvalues[0]["random_float"]
        registers[5] = (registers[1] - registers[3])
        registers[6] = registers[1] + registers[3]
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
    end
end
