-- Recovered function f173; author names are unavailable.
F.f173 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f173")
        tick(1)
        slot_1 = upvalues[0]["handlers"]
        slot_1 = slot_1["save"]
        slot_1()
        do
            return 
        end
    end
end
