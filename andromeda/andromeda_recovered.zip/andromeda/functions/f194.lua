-- Recovered function f194; author names are unavailable.
F.f194 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f194")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]
        z = slot_1
        slot_2 = z;
        slot_1 = z["import_config"]
        slot_1(slot_2)
        do
            return 
        end
    end
end
