-- Recovered function f421; author names are unavailable.
F.f421 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f421")
        tick(1)
        goto p82
        ::p10::
        tick(10)
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[1]
        registers[8] = (8)
        goto p22
        ::p16::
        tick(16)
        registers[6] = registers[4]
        a = registers
        z = 7;
        a[z] = 64
        registers[5] = registers[5](registers[6], registers[7])
        registers[5] = (registers[5] * 16777216)
        goto p129
        ::p22::
        registers[6] = registers[6](registers[7], registers[8])
        registers[5] = registers[5] + registers[6]
        do
            return registers[5]
        end
        ::p75::
        tick(75)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 65536)
        a = registers
        z = 5
        q = registers
        q = q[5]
        m = registers
        x = 6
        m = m[x]
        q = q + m
        a[z] = q
        goto p89
        ::p82::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]
        registers[3] = (1)
        registers[4] = (4)
        m, x = pack_returns(registers[1](unpack_range(4, registers, 2)))
        z = 0
        for f = 1, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = upvalues[2]
        goto p16
        ::p89::
        registers[6] = upvalues[2]
        registers[7] = registers[2]
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 256)
        goto p10
        ::p129::
        registers[6] = upvalues[2]
        registers[7] = registers[3]
        registers[8] = (32)
        goto p75
    end
end
