-- Recovered function f464; author names are unavailable.
F.f464 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f464")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0];
        slot_2 = slot_2()
        goto p42
        ::p35::
        tick(35)
        z = slot_2
        slot_4 = z;
        slot_3 = z["override"]
        slot_5 = slot_1;
        slot_3(slot_4, slot_5)
        goto p45
        ::p42::
        if slot_2 == slot_0 then
            goto p45
        end
        goto p35
        ::p45::
        do
            return 
        end
    end
end
