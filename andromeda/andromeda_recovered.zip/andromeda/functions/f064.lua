-- Recovered function f64; author names are unavailable.
F.f64 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9 = nil, nil, nil, nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f64")
        tick(1)
        goto p73
        ::p2::
        tick(2)
        slot_4 = (0)
        slot_5 = (9)
        slot_6 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_6 + 0
        n = (slot_5 + 0)
        v = (slot_4 - U)
        goto p77
        goto p43
        ::p18::
        tick(18)
        slot_8 = upvalues[0];
        slot_8 = slot_8()
        slot_3 = slot_3 + slot_8
        goto p54
        ::p29::
        tick(29)
        slot_4 = upvalues[1]
        slot_5 = {
        }
        slot_6 = upvalues[2]["MAGIC_SUM_CHECK_FAILED"]
        goto p47
        ::p43::
        tick(43)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not (3 < slot_2) then
            goto p94
        end
        goto p29
        ::p47::
        slot_5["ban_num"] = slot_6
        slot_6 = "%d [MGC][0x02]"
        z = slot_6
        slot_7 = z;
        slot_6 = z["format"]
        slot_8 = slot_2
        slot_6 = slot_6(slot_7, slot_8)
        slot_5["ban_info"] = slot_6
        do
            return slot_4(slot_5)
        end
        ::p54::
        slot_9 = slot_1[slot_8]
        if not slot_9 then
            goto p79
        end
        goto p104
        ::p73::
        slot_1 = {
        }
        slot_2 = (0)
        slot_3 = (1)
        goto p2
        ::p77::
        tick(77)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_7 = v
            branch_taken = true
        end
        if branch_taken then
            goto p18
        end
        goto p43
        ::p79::
        slot_1[slot_8] = true
        goto p77
        ::p94::
        do
            return 
        end
        ::p104::
        slot_2 = slot_2 + 1
        goto p77
    end
end
