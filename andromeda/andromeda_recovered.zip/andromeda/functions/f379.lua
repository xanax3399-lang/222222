-- Recovered function f379; author names are unavailable.
F.f379 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_13, slot_14, slot_15, slot_16, slot_17, slot_18, slot_19, slot_20 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, q = andromeda_environment, nil
        local a = nil
        local tick = new_tick("f379")
        tick(1)
        goto p159
        ::p3::
        tick(3)
        q = slot_16
        q[1] = slot_17
        q[2] = slot_18
        slot_17 = new_frame(2)
        slot_18 = environment["tostring"]
        goto p97
        ::p7::
        tick(7)
        slot_8 = slot_1["damage"];
        slot_7 = slot_7(slot_8)
        if slot_7 then
            goto p65
        end
        goto p135
        ::p13::
        tick(13)
        slot_20 = "text"
        q = slot_18
        q[1] = slot_19
        q[2] = slot_20
        q = slot_9
        q[1] = slot_10
        q[2] = slot_11
        q[3] = slot_12
        q[4] = slot_13
        q[5] = slot_14
        q[6] = slot_15
        q[7] = slot_16
        q[8] = slot_17
        q[9] = slot_18
        slot_8(slot_9)
        if slot_2 == slot_0 then
            goto p63
        end
        goto p151
        ::p20::
        tick(20)
        slot_14 = "text"
        q = slot_12
        q[1] = slot_13
        q[2] = slot_14
        slot_13 = new_frame(2)
        slot_14 = slot_5
        goto p70
        ::p40::
        tick(40)
        slot_3 = slot_1["target"]
        goto p142
        ::p51::
        tick(51)
        slot_11 = new_frame(2)
        slot_12 = slot_4
        slot_13 = "hit"
        goto p147
        ::p55::
        tick(55)
        slot_2 = slot_1["id"]
        slot_2 = (slot_2 ~= slot_0)
        if not slot_2 then
            goto p87
        end
        goto p155
        ::p60::
        tick(60)
        slot_2 = slot_1["target"]
        if slot_2 ~= slot_0 then
            goto p55
        end
        goto p64
        ::p63::
        tick(63)
        do
            return 
        end
        ::p64::
        tick(64)
        do
            return 
        end
        ::p65::
        tick(65)
        slot_7 = slot_7 + 0.5;
        slot_6 = slot_6(slot_7)
        slot_7 = upvalues[0]["get_player_health"]
        slot_8 = slot_3
        goto p89
        ::p70::
        slot_15 = "hit"
        q = slot_13
        q[1] = slot_14
        q[2] = slot_15
        slot_14 = new_frame(2)
        slot_15 = " for "
        slot_16 = "text"
        q = slot_14
        q[1] = slot_15
        q[2] = slot_16
        slot_15 = new_frame(2)
        slot_16 = environment["tostring"]
        slot_17 = slot_6;
        slot_16 = slot_16(slot_17)
        slot_17 = "hit"
        goto p137
        ::p87::
        tick(87)
        if slot_2 then
            goto p130
        end
        goto p128
        ::p89::;
        slot_7 = slot_7(slot_8)
        slot_8 = upvalues[0]["push"]
        slot_9 = new_frame(9)
        slot_10 = new_frame(2)
        slot_11 = "Hit "
        slot_12 = "text"
        q = slot_10
        q[1] = slot_11
        q[2] = slot_12
        goto p51
        ::p97::
        slot_19 = slot_7;
        slot_18 = slot_18(slot_19)
        slot_19 = "hit"
        goto p112
        ::p102::
        tick(102)
        if slot_3 then
            goto p142
        end
        goto p40
        ::p112::
        q = slot_17
        q[1] = slot_18
        q[2] = slot_19
        slot_18 = new_frame(2)
        slot_19 = " health remaining)"
        goto p13
        ::p116::
        tick(116)
        slot_6 = slot_1["hitgroup"];
        slot_5 = slot_5(slot_6)
        slot_6 = upvalues[1][154]
        slot_7 = environment["tonumber"]
        goto p7
        ::p128::
        slot_2 = nil
        ::p130::
        slot_3 = environment["tonumber"]
        slot_4 = slot_1["target"];
        slot_3 = slot_3(slot_4)
        goto p102
        ::p135::
        slot_7 = (0)
        goto p65
        ::p137::
        q = slot_15
        q[1] = slot_16
        q[2] = slot_17
        slot_16 = new_frame(2)
        slot_17 = " damage ("
        slot_18 = "text"
        goto p3
        ::p142::
        slot_4 = upvalues[0]["get_player_name"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        slot_5 = upvalues[0]["get_hitgroup"]
        goto p116
        ::p147::
        q = slot_11
        q[1] = slot_12
        q[2] = slot_13
        slot_12 = new_frame(2)
        slot_13 = " in the "
        goto p20
        ::p151::
        slot_8 = slot_1["id"]
        if slot_8 == slot_0 then
            goto p63
        end
        goto p169
        ::p155::
        slot_2 = upvalues[0]["shots"]
        slot_3 = slot_1["id"]
        slot_2 = slot_2[slot_3]
        goto p87
        ::p159::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p64
        end
        goto p60
        ::p169::
        slot_8 = upvalues[0]["shots"]
        slot_9 = slot_1["id"]
        slot_8[slot_9] = slot_0
        goto p63
    end
end
