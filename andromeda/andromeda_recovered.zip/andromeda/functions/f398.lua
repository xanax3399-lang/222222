-- Recovered function f398; author names are unavailable.
F.f398 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f398")
        tick(1)
        goto p12
        ::p2::
        tick(2)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p6::
        tick(6)
        z = slot_1
        slot_4 = z;
        slot_3 = z["set"]
        slot_5 = slot_2;
        slot_3(slot_4, slot_5)
        slot_3 = (true)
        do
            return slot_3
        end
        ::p12::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        z = slot_1
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        if slot_3 == slot_2 then
            goto p2
        end
        goto p6
    end
end
