-- Recovered function f38; author names are unavailable.
F.f38 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f38")
        tick(1)
        goto p47
        ::p4::
        tick(4)
        registers[5] = "Text passed to hmac_sha256 should be a string";
        registers[3](registers[4], registers[5])
        registers[3] = (#registers[1])
        registers[4] = upvalues[0]["blocksize"]
        if not (registers[4] < registers[3]) then
            goto p52
        end
        registers[3] = upvalues[0]["sha256_binary"]
        a = registers
        z = 4
        q = registers
        q = q[1]
        a[z] = q;
        registers[(3)] = registers[(3)](registers[4])
        registers[1] = registers[3]
        goto p52
        ::p41::
        tick(41)
        registers[3] = environment["assert"]
        registers[4] = environment["type"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "string")
        goto p4
        ::p47::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = environment["assert"]
        registers[4] = environment["type"]
        goto p73
        ::p52::
        registers[3] = upvalues[1]
        a = registers
        z = 4
        q = registers
        q = q[1]
        a[z] = q
        registers[5] = (54)
        goto p108
        ::p73::
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "string")
        registers[5] = "Key passed to hmac_sha256 should be a string";
        registers[3](registers[4], registers[5])
        goto p41
        ::p80::
        tick(80)
        registers[5] = upvalues[0]["sha256"]
        registers[6] = upvalues[0]["sha256_binary"]
        registers[7] = (registers[3]..registers[2]);
        registers[(6)] = registers[(6)](registers[7])
        registers[6] = (registers[4]..registers[6])
        do
            return registers[(5)](registers[6])
        end
        ::p108::
        registers[6] = upvalues[0]["blocksize"];
        registers[3] = registers[3](unpack_range(6, registers, 4))
        registers[4] = upvalues[1]
        registers[5] = registers[1]
        registers[6] = (92)
        registers[7] = upvalues[0]["blocksize"];
        registers[4] = registers[4](unpack_range(7, registers, 5))
        goto p80
    end
end
