-- Recovered function f369; author names are unavailable.
F.f369 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f369")
        tick(1)
        goto p14
        ::p3::
        tick(3)
        registers[5] = upvalues[0]["px"]
        registers[6] = (20)
        registers[7] = registers[3]
        registers[5] = registers[5](registers[6], registers[7])
        registers[5] = registers[4] + registers[5]
        do
            return registers[5]
        end
        ::p10::
        tick(10)
        registers[6] = registers[2]
        registers[7] = registers[3];
        registers[4] = registers[4](unpack_range(7, registers, 5))
        goto p3
        ::p14::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]["measure_item"]
        registers[5] = registers[1]
        goto p10
    end
end
