-- Recovered function f256; author names are unavailable.
F.f256 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f256")
        tick(1)
        goto p110
        ::p2::
        tick(2)
        registers[15] = registers[8]
        if registers[15] then
            goto p123
        end
        goto p56
        ::p6::
        tick(6)
        registers[30] = (250)
        registers[31] = registers[12]
        registers[32] = nil
        registers[33] = registers[10]
        registers[(24)](unpack_range(33, registers, 25))
        do
            return 
        end
        ::p12::
        tick(12)
        m, x = pack_returns(registers[18](unpack_range(19, registers, 19)))
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[16] = registers[16](unpack_range(top, registers, 17))
        registers[17] = upvalues[0][151]
        goto p160
        ::p16::
        tick(16)
        registers[23] = upvalues[0][154]
        registers[24] = (registers[19] - registers[14])
        registers[24] = (registers[24] * 0.5)
        goto p220
        ::p21::
        tick(21)
        registers[31] = (140)
        registers[32] = (130)
        registers[(24)](unpack_range(32, registers, 25))
        registers[24] = upvalues[0][131]
        registers[25] = registers[22]
        goto p46
        ::p33::
        tick(33)
        registers[7] = registers[7] + 0.5
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = registers[4](unpack_range(top, registers, 5))
        registers[5] = upvalues[0][28];
        registers[5] = registers[5]()
        registers[6] = (registers[5] ~= registers[0])
        goto p91
        ::p46::
        registers[26] = registers[23]
        registers[27] = (240)
        registers[28] = (160)
        registers[29] = (180)
        goto p6
        ::p51::
        tick(51)
        registers[6] = upvalues[0][154]
        registers[7] = 1 / registers[5]
        registers[7] = registers[7] + 0.5;
        registers[(6)] = registers[(6)](registers[7])
        goto p115
        ::p56::
        registers[15] = (0)
        goto p123
        ::p73::
        tick(73)
        registers[13] = registers[6]
        registers[14] = registers[7]
        if registers[14] then
            goto p2
        end
        goto p195
        ::p77::
        tick(77)
        registers[6] = (0)
        goto p180
        ::p79::
        tick(79)
        registers[18] = registers[18] + 0.5
        m, x = pack_returns(registers[17](unpack_range(18, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        registers[16] = upvalues[0][151]
        registers[17] = (2)
        registers[18] = upvalues[0][154]
        registers[19] = 3 * registers[3]
        registers[19] = registers[19] + 0.5
        goto p12
        ::p91::
        if not registers[6] then
            goto p136
        end
        goto p213
        ::p99::
        tick(99)
        registers[20] = upvalues[3]
        registers[21] = registers[18]
        registers[22] = registers[19]
        registers[23] = registers[1]
        if registers[23] then
            goto p207
        end
        goto p121
        ::p105::
        tick(105)
        if registers[2] ~= 0 then
            goto p165
        end
        ::p108::
        tick(108)
        do
            return 
        end
        ::p110::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        if registers[2] == registers[0] then
            goto p108
        end
        goto p105
        ::p115::
        tick(115)
        if registers[6] then
            goto p180
        end
        goto p77
        ::p117::
        tick(117);
        registers[(11)] = registers[(11)](registers[12])
        registers[12] = upvalues[2]
        registers[13] = "r"
        goto p156
        ::p121::
        registers[23] = "Top Right"
        goto p207
        ::p123::
        registers[16] = registers[9]
        if registers[16] then
            goto p143
        end
        goto p224
        ::p132::
        tick(132)
        registers[16] = (4)
        registers[17] = upvalues[0][154]
        registers[18] = 6 * registers[3]
        goto p79
        ::p136::
        tick(136)
        if not registers[6] then
            goto p115
        end
        goto p51
        ::p139::
        tick(139)
        registers[15] = registers[10]
        m, x = pack_returns(registers[13](unpack_range(15, registers, 14)))
        z = 0
        for f = 13, 14 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = upvalues[0][151]
        goto p132
        ::p143::
        tick(143);
        registers[10] = registers[10](unpack_range(16, registers, 11))
        registers[11] = upvalues[2]
        registers[12] = nil
        goto p117
        ::p156::;
        registers[(12)] = registers[(12)](registers[13])
        registers[13] = upvalues[0][136]
        registers[14] = registers[11]
        goto p139
        ::p160::
        registers[18] = (14)
        registers[19] = upvalues[0][154]
        registers[20] = 20 * registers[3]
        registers[20] = registers[20] + 0.5
        goto p188
        ::p165::
        registers[3] = upvalues[1];
        registers[3] = registers[3]()
        registers[4] = upvalues[0][151]
        registers[5] = (0)
        registers[6] = upvalues[0][154]
        registers[7] = upvalues[0][67];
        registers[7] = registers[7]()
        registers[7] = (registers[7] * 1000)
        goto p33
        ::p180::
        registers[7] = upvalues[0][96]
        m, x = pack_returns(registers[7]())
        z = 0
        for f = 7, 9 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = environment["string"]
        registers[10] = registers[10]["format"]
        registers[11] = "Andromeda | rtt: %ims | rate: %i | %02d:%02d:%02d"
        registers[12] = registers[4]
        goto p73
        ::p188::
        m, x = pack_returns(registers[19](unpack_range(20, registers, 20)))
        m = m + 19 - 1
        top = m
        z = 0
        for f = 19, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[17] = registers[17](unpack_range(top, registers, 18))
        registers[18] = (registers[15] * 2)
        registers[18] = registers[13] + registers[18]
        registers[19] = upvalues[0][151]
        registers[20] = registers[17]
        goto p198
        ::p195::
        registers[14] = (0)
        goto p2
        ::p198::
        registers[21] = (registers[16] * 2)
        registers[21] = registers[14] + registers[21]
        registers[19] = registers[19](registers[20], registers[21])
        goto p99
        ::p202::
        tick(202)
        registers[27] = registers[18]
        registers[28] = registers[19]
        registers[29] = (240)
        registers[30] = (110)
        goto p21
        ::p207::
        registers[24] = registers[3]
        m, x = pack_returns(registers[20](unpack_range(24, registers, 21)))
        z = 0
        for f = 20, 21 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[22] = registers[20] + registers[18]
        registers[22] = (registers[22] - registers[15])
        goto p16
        ::p213::
        registers[6] = registers[5] > 0
        goto p136
        ::p216::
        tick(216)
        registers[24] = upvalues[0][128]
        registers[25] = registers[20]
        registers[26] = registers[21]
        goto p202
        ::p220::
        registers[24] = registers[24] + 0.5;
        registers[(23)] = registers[(23)](registers[24])
        registers[23] = registers[21] + registers[23]
        goto p216
        ::p224::
        registers[16] = (0)
        goto p143
    end
end
