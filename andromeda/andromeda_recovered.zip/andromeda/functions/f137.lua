-- Recovered function f137; author names are unavailable.
F.f137 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f137")
        tick(1)
        goto p475
        ::p10::
        tick(10)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[12] = z;
            registers[13] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p97
        end
        goto p256
        ::p13::
        tick(13)
        registers[9] = registers[7]["type"]
        branch_taken = false
        if registers[9] ~= "button" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p218
        end
        goto p173
        ::p22::
        tick(22)
        registers[8] = (false)
        goto p79
        ::p24::
        tick(24)
        registers[8] = registers[7]["type"]
        if registers[8] ~= "hotkey" then
            goto p369
        end
        goto p451
        ::p27::
        tick(27);
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "table" then
            goto p384
        end
        goto p189
        ::p32::
        tick(32)
        if registers[8] ~= "string" then
            goto p310
        end
        goto p315
        ::p34::
        tick(34)
        registers[8] = nil
        goto p252
        ::p36::
        tick(36)
        registers[11] = {
        }
        registers[9] = registers[11]
        registers[11] = (1)
        goto p464
        ::p40::
        tick(40)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[14] = v
            branch_taken = true
        end
        if branch_taken then
            goto p424
        end
        goto p187
        ::p42::
        tick(42)
        z = registers[7]
        registers[10] = z;
        registers[(9)] = z["set"]
        registers[11] = upvalues[0]
        registers[12] = registers[8]
        m, x = pack_returns(registers[11](unpack_range(12, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[9](unpack_range(top, registers, 10))
        goto p218
        ::p48::
        tick(48)
        registers[9] = environment["type"]
        registers[10] = registers[6];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "table" then
            goto p24
        end
        goto p358
        ::p53::
        tick(53)
        if registers[9] ~= "string" then
            goto p79
        end
        goto p102
        ::p55::
        tick(55)
        z = registers[7]
        registers[10] = z;
        registers[(9)] = z["set"]
        registers[11] = registers[8];
        registers[9](registers[10], registers[11])
        goto p218
        ::p60::
        tick(60)
        branch_taken = false
        if registers[9] ~= "false" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p22
        end
        if registers[9] ~= "0" then
            goto p278
        end
        goto p22
        ::p63::
        tick(63)
        z = registers[7]
        registers[10] = z;
        registers[(9)] = z["set"]
        registers[11] = registers[8];
        registers[9](registers[10], registers[11])
        goto p218
        ::p68::
        tick(68)
        registers[8] = "Always on"
        goto p457
        ::p70::
        tick(70)
        registers[9] = registers[10]
        goto p384
        ::p72::
        tick(72)
        registers[8] = registers[9]
        goto p262
        ::p74::
        tick(74)
        if registers[10] ~= "string" then
            goto p549
        end
        goto p153
        ::p76::
        tick(76)
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[11](unpack_range(top, registers, 12))
        goto p218
        ::p79::
        tick(79)
        registers[9] = environment["type"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        goto p248
        ::p83::
        tick(83)
        registers[8] = registers[7]["type"]
        branch_taken = false
        if registers[8] ~= "label" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p218
        end
        goto p13
        ::p87::
        tick(87)
        registers[11] = environment["pairs"]
        registers[12] = registers[6]
        m, x = pack_returns(registers[11](unpack_range(12, registers, 12)))
        z = 0
        for f = 11, 13 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(11)]
        n = registers[12]
        U = registers[13]
        goto p10
        ::p91::
        tick(91)
        z = registers[7]
        registers[13] = z;
        registers[(12)] = z["set"]
        registers[14] = registers[11];
        registers[12](registers[13], registers[14])
        goto p218
        ::p95::
        tick(95)
        registers[8] = (registers[8] ~= 0)
        goto p79
        ::p97::
        if registers[13] ~= true then
            goto p10
        end
        goto p145
        ::p99::
        tick(99)
        registers[8] = registers[7]["type"]
        if registers[8] ~= "checkbox" then
            goto p438
        end
        goto p389
        ::p102::
        z = registers[8]
        registers[10] = z;
        registers[(9)] = z["lower"];
        registers[(9)] = registers[(9)](registers[10])
        branch_taken = false
        if registers[9] ~= "true" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p250
        end
        goto p441
        ::p106::
        tick(106)
        z = registers[7]
        registers[12] = z;
        registers[(11)] = z["set"]
        registers[13] = environment["tostring"]
        registers[14] = registers[6]
        goto p76
        ::p110::
        tick(110)
        registers[8] = registers[6]
        registers[9] = environment["type"]
        registers[10] = registers[8]
        goto p421
        ::p114::
        tick(114)
        registers[10] = environment["tonumber"]
        registers[11] = registers[8];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] == registers[0] then
            goto p510
        end
        goto p228
        ::p143::
        tick(143)
        branch_taken = false
        if registers[4] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p178
        end
        goto p240
        ::p145::
        registers[14] = registers[10]
        registers[15] = registers[12]
        registers[(14)](registers[15])
        goto p10
        ::p149::
        tick(149)
        z = registers[7]
        registers[12] = z;
        registers[(11)] = z["set"]
        registers[13] = registers[6];
        registers[11](registers[12], registers[13])
        goto p218
        ::p153::
        registers[11] = environment["tonumber"]
        registers[12] = registers[6];
        registers[(11)] = registers[(11)](registers[12])
        goto p449
        ::p157::
        tick(157)
        registers[8] = registers[8][1]
        goto p42
        ::p159::
        tick(159)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p237
        ::p162::
        tick(162)
        registers[10] = environment["type"]
        registers[11] = registers[8];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "string" then
            goto p510
        end
        goto p114
        ::p167::
        tick(167)
        if registers[9] ~= "number" then
            goto p549
        end
        goto p74
        ::p169::
        tick(169)
        registers[10] = environment["type"]
        registers[11] = registers[8];
        registers[(10)] = registers[(10)](registers[11])
        goto p486
        ::p173::
        registers[8] = registers[7]["type"]
        if registers[8] ~= "multiselect" then
            goto p350
        end
        goto p395
        ::p176::
        tick(176)
        if registers[9] ~= "boolean" then
            goto p218
        end
        goto p319
        ::p178::
        registers[4] = environment["pairs"]
        registers[5] = registers[3]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        z = 0
        for f = 4, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(4)]
        n = registers[5]
        U = registers[6]
        goto p218
        goto p399
        ::p183::
        tick(183)
        registers[10] = environment["type"]
        registers[11] = registers[6];
        registers[(10)] = registers[(10)](registers[11])
        goto p267
        ::p187::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p523
        ::p189::
        registers[8] = registers[6][1]
        registers[10] = registers[6][2]
        if registers[10] then
            goto p70
        end
        goto p292
        ::p201::
        tick(201)
        z = registers[6]
        registers[12] = z;
        registers[(11)] = z["lower"];
        registers[(11)] = registers[(11)](registers[12])
        branch_taken = false
        if registers[11] ~= "true" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p334
        end
        goto p503
        ::p207::
        tick(207)
        if registers[9] ~= "boolean" then
            goto p218
        end
        goto p323
        ::p211::
        tick(211)
        registers[7] = registers[2][registers[5]]
        if registers[7] == registers[0] then
            goto p218
        end
        goto p83
        ::p214::
        tick(214)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p216::
        tick(216)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[14] = v
            branch_taken = true
        end
        if branch_taken then
            goto p470
        end
        goto p159
        ::p218::
        tick(218)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[5] = z;
            registers[6] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p211
        end
        goto p214
        ::p221::
        tick(221)
        registers[10] = (0)
        goto p321
        ::p223::
        tick(223)
        branch_taken = false
        if registers[10] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p176
        end
        goto p106
        ::p225::
        tick(225)
        z = registers[7]
        registers[12] = z;
        registers[(11)] = z["set"]
        registers[(11)](registers[12])
        goto p235
        ::p228::
        registers[8] = registers[10]
        goto p510
        ::p230::
        tick(230)
        registers[10] = environment["type"]
        registers[11] = registers[8];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "string" then
            goto p218
        end
        goto p374
        ::p235::
        tick(235)
        do
            local f = (8)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        goto p218
        ::p237::
        tick(237)
        registers[11] = (#registers[8])
        if not (0 < registers[11]) then
            goto p225
        end
        goto p516
        ::p240::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p248::
        if registers[9] ~= "boolean" then
            goto p218
        end
        goto p55
        ::p250::
        tick(250)
        registers[8] = (true)
        goto p79
        ::p252::
        tick(252)
        registers[9] = (0)
        registers[10] = environment["type"]
        registers[11] = registers[6]
        goto p27
        ::p256::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p237
        ::p258::
        tick(258)
        registers[10] = environment["tonumber"]
        registers[11] = registers[9];
        registers[(10)] = registers[(10)](registers[11])
        goto p447
        ::p262::
        tick(262)
        registers[9] = environment["type"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "number" then
            goto p218
        end
        goto p499
        ::p267::
        if registers[9] ~= registers[10] then
            goto p167
        end
        goto p149
        ::p278::
        registers[8] = registers[0]
        goto p79
        ::p280::
        tick(280)
        z = registers[7]
        registers[13] = z;
        registers[(12)] = z["set"]
        registers[14] = (false);
        registers[12](registers[13], registers[14])
        goto p218
        ::p292::
        registers[10] = (0)
        goto p70
        ::p303::
        tick(303)
        registers[8] = registers[7]["type"]
        if registers[8] ~= "textbox" then
            goto p543
        end
        goto p399
        ::p307::
        tick(307)
        branch_taken = false
        if registers[11] ~= "false" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p280
        end
        goto p379
        ::p310::
        registers[8] = environment["type"]
        registers[9] = registers[6];
        registers[(8)] = registers[(8)](registers[9])
        branch_taken = false
        if registers[8] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p323
        end
        goto p354
        ::p315::
        z = registers[7]
        registers[9] = z;
        registers[(8)] = z["set"]
        registers[10] = registers[6];
        registers[8](registers[9], registers[10])
        goto p218
        ::p319::
        if registers[10] ~= "number" then
            goto p407
        end
        goto p558
        ::p321::
        tick(321)
        registers[9] = registers[10]
        goto p162
        ::p323::
        z = registers[7]
        registers[9] = z;
        registers[(8)] = z["set"]
        registers[10] = environment["tostring"]
        registers[11] = registers[6]
        m, x = pack_returns(registers[10](unpack_range(11, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[8](unpack_range(top, registers, 9))
        goto p218
        ::p329::
        tick(329)
        registers[8] = upvalues[2]
        registers[9] = registers[7]
        registers[10] = registers[6]
        goto p417
        ::p334::
        tick(334)
        z = registers[7]
        registers[13] = z;
        registers[(12)] = z["set"]
        registers[14] = (true);
        registers[12](registers[13], registers[14])
        goto p218
        ::p344::
        tick(344)
        registers[9] = environment["tonumber"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        goto p72
        ::p350::
        tick(350)
        registers[8] = registers[7]["type"]
        if registers[8] ~= "color_picker" then
            goto p24
        end
        goto p48
        ::p354::
        registers[9] = environment["type"]
        registers[10] = registers[6];
        registers[(9)] = registers[(9)](registers[10])
        goto p207
        ::p358::
        registers[8] = registers[6]
        registers[9] = environment["type"]
        registers[10] = registers[8][1];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "table" then
            goto p42
        end
        goto p157
        ::p364::
        tick(364)
        registers[8] = {
        }
        registers[9] = nil
        registers[10] = registers[7]["get_list"]
        if registers[10] == registers[0] then
            goto p523
        end
        goto p492
        ::p369::
        tick(369)
        registers[8] = registers[7]["type"]
        branch_taken = false
        if registers[8] ~= "slider" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p110
        end
        goto p443
        ::p372::
        tick(372)
        registers[8] = upvalues[1][registers[8]]
        goto p230
        ::p374::
        z = registers[7]
        registers[11] = z;
        registers[(10)] = z["set"]
        registers[12] = registers[8]
        registers[13] = registers[9]
        registers[(10)](unpack_range(13, registers, 11))
        goto p218
        ::p379::
        if registers[11] ~= "0" then
            goto p218
        end
        goto p280
        ::p381::
        tick(381)
        if registers[15] ~= "string" then
            goto p40
        end
        goto p434
        ::p384::
        registers[10] = environment["type"]
        registers[11] = registers[9];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "string" then
            goto p162
        end
        goto p258
        ::p389::
        registers[8] = registers[6]
        registers[9] = environment["type"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "number" then
            goto p409
        end
        goto p95
        ::p395::
        registers[9] = environment["type"]
        registers[10] = registers[6];
        registers[(9)] = registers[(9)](registers[10])
        goto p541
        ::p399::
        registers[8] = environment["type"]
        registers[9] = registers[6];
        registers[(8)] = registers[(8)](registers[9])
        goto p32
        ::p403::
        tick(403)
        registers[11] = (1)
        registers[12] = (#registers[6])
        registers[13] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[13] + 0
        n = (registers[12] + 0)
        v = (registers[11] - U)
        goto p216
        ::p407::
        if registers[10] ~= "string" then
            goto p218
        end
        goto p201
        ::p409::
        registers[9] = environment["type"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        goto p53
        ::p417::
        registers[11] = registers[5];
        registers[8] = registers[8](unpack_range(11, registers, 9))
        if registers[8] == registers[0] then
            goto p218
        end
        goto p63
        ::p421::;
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "string" then
            goto p262
        end
        goto p344
        ::p424::
        registers[15] = environment["type"]
        registers[16] = registers[10][registers[14]];
        registers[(15)] = registers[(15)](registers[16])
        goto p381
        ::p434::
        registers[15] = registers[10][registers[14]]
        registers[9][registers[15]] = true
        goto p40
        ::p438::
        registers[8] = registers[7]["type"]
        if registers[8] ~= "combobox" then
            goto p303
        end
        goto p329
        ::p441::
        if registers[9] ~= "1" then
            goto p60
        end
        goto p250
        ::p443::
        registers[9] = registers[7]["type"]
        if registers[9] ~= "listbox" then
            goto p99
        end
        goto p110
        ::p447::
        if registers[10] then
            goto p321
        end
        goto p221
        ::p449::
        if registers[11] == registers[0] then
            goto p218
        end
        goto p91
        ::p451::
        registers[9] = environment["type"]
        registers[10] = registers[6];
        registers[(9)] = registers[(9)](registers[10])
        branch_taken = false
        if registers[9] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p512
        end
        goto p459
        ::p457::
        tick(457)
        if registers[8] then
            goto p252
        end
        goto p34
        ::p459::
        registers[10] = environment["type"]
        registers[11] = registers[6];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "boolean" then
            goto p369
        end
        goto p512
        ::p464::
        registers[12] = (#registers[10])
        registers[13] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[13] + 0
        n = (registers[12] + 0)
        v = (registers[11] - U)
        goto p40
        goto p149
        ::p470::
        registers[15] = registers[10]
        registers[16] = registers[6][registers[14]]
        registers[(15)](registers[16])
        goto p216
        ::p475::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = environment["type"]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p143
        ::p486::
        if registers[10] ~= "number" then
            goto p230
        end
        goto p372
        ::p492::
        z = registers[7]
        registers[11] = z;
        registers[(10)] = z["get_list"];
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = environment["type"]
        registers[12] = registers[10];
        registers[(11)] = registers[(11)](registers[12])
        if registers[11] ~= "table" then
            goto p523
        end
        goto p36
        ::p499::
        z = registers[7]
        registers[10] = z;
        registers[(9)] = z["set"]
        registers[11] = registers[8];
        registers[9](registers[10], registers[11])
        goto p218
        ::p503::
        if registers[11] ~= "1" then
            goto p307
        end
        goto p334
        ::p510::
        if registers[8] == registers[0] then
            goto p218
        end
        goto p169
        ::p512::
        registers[8] = (registers[6] == true)
        if not registers[8] then
            goto p457
        end
        goto p68
        ::p516::
        z = registers[7]
        registers[12] = z;
        registers[(11)] = z["set"]
        registers[13] = upvalues[0]
        registers[14] = registers[8]
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[11](unpack_range(top, registers, 12))
        goto p235
        ::p523::
        a = D.f138
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[11] = (#registers[6])
        if not (0 < registers[11]) then
            goto p87
        end
        goto p403
        ::p541::
        if registers[9] ~= "table" then
            goto p350
        end
        goto p364
        ::p543::
        z = registers[7]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = environment["type"]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        goto p183
        ::p549::
        if registers[9] ~= "string" then
            goto p176
        end
        goto p223
        ::p558::
        z = registers[7]
        registers[12] = z;
        registers[(11)] = z["set"]
        registers[13] = (registers[6] ~= 0);
        registers[11](registers[12], registers[13])
        goto p218
    end
end
