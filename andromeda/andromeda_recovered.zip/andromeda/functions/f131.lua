-- Recovered function f131; author names are unavailable.
F.f131 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local tick = new_tick("f131")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][154]
        slot_3 = upvalues[1]
        slot_3 = slot_1 * slot_3
        slot_3 = slot_3 + 0.5
        do
            return slot_2(slot_3)
        end
    end
end
