-- Recovered function f489; author names are unavailable.
F.f489 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f489")
        tick(1)
        tick(3)
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["viewmodel_offset_y"];
        slot_1 = slot_1(slot_2)
        goto p45
        ::p40::
        tick(40)
        slot_1 = upvalues[2]
        slot_1()
        do
            return 
        end
        ::p43::
        tick(43)
        do
            return 
        end
        ::p45::
        if not slot_1 then
            goto p40
        end
        goto p43
    end
end
