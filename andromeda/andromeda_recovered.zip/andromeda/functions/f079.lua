-- Recovered function f79; author names are unavailable.
F.f79 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local tick = new_tick("f79")
        tick(1)
        goto p13
        ::p2::
        tick(2)
        slot_3 = "count";
        slot_2 = slot_2(slot_3)
        if slot_1 ~= slot_2 then
            goto p22
        end
        slot_3 = environment["collectgarbage"]
        slot_4 = "collect"
        slot_3(slot_4)
        slot_3 = environment["collectgarbage"]
        slot_4 = "count";
        slot_3 = slot_3(slot_4)
        goto p19
        ::p13::
        slot_1 = environment["collectgarbage"]
        slot_2 = "count";
        slot_1 = slot_1(slot_2)
        slot_2 = environment["collectgarbage"]
        goto p2
        ::p19::
        slot_3 = slot_3 < slot_2
        slot_3 = not slot_3
        do
            return slot_3
        end
        ::p22::
        slot_3 = (true)
        do
            return slot_3
        end
    end
end
