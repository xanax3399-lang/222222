-- Recovered function f152; author names are unavailable.
F.f152 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f152")
        tick(1)
        goto p3
        ::p2::
        tick(2)
        do
            return 
        end
        ::p3::
        slot_1 = upvalues[0]["is_quit"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p62
        end
        goto p2
        ::p62::
        slot_1 = upvalues[1]
        slot_1()
        do
            return 
        end
    end
end
