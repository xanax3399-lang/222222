-- Recovered function f97; author names are unavailable.
F.f97 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local tick = new_tick("f97")
        tick(1)
        do
            return 
        end
    end
end
