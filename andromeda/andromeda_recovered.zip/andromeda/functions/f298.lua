-- Recovered function f298; author names are unavailable.
F.f298 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local environment, n, v, R = andromeda_environment, nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f298")
        tick(1)
        goto p38
        ::p2::
        tick(2)
        slot_2 = (false)
        do
            return slot_2
        end
        ::p18::
        tick(18)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_2 = (false)
        do
            return slot_2
        end
        ::p26::
        tick(26)
        slot_6 = (true)
        do
            return slot_6
        end
        ::p30::
        tick(30)
        slot_2 = (1)
        slot_3 = upvalues[0]
        slot_3 = (#slot_3)
        slot_4 = (1)
        goto p45
        ::p35::
        tick(35)
        slot_6 = upvalues[0][slot_5]
        if slot_6 ~= slot_1 then
            goto p60
        end
        goto p26
        ::p38::
        tick(38)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        branch_taken = false
        if slot_2 ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p30
        end
        goto p2
        ::p45::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_4 + 0
        n = (slot_3 + 0)
        v = (slot_2 - U)
        goto p60
        goto p38
        ::p60::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_5 = v
            branch_taken = true
        end
        if branch_taken then
            goto p35
        end
        goto p18
    end
end
