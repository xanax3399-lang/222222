-- Recovered function f358; author names are unavailable.
F.f358 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f358")
        tick(1)
        goto p140
        ::p2::
        tick(2)
        registers[9] = registers[6]
        registers[10] = registers[7]
        registers[8] = registers[8](registers[9], registers[10])
        registers[4] = registers[8]
        goto p82
        ::p15::
        tick(15)
        registers[6] = upvalues[1][151]
        registers[7] = (1)
        registers[8] = (registers[4] - registers[5])
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[1][162]
        registers[8] = (16)
        registers[9] = registers[4] + registers[5]
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[0]["random_int"]
        goto p2
        ::p26::
        tick(26)
        if registers[5] ~= "Smart" then
            goto p158
        end
        goto p117
        ::p44::
        tick(44)
        registers[6] = upvalues[2];
        registers[6] = registers[6]()
        goto p128
        ::p47::
        tick(47)
        a = upvalues[3];
        registers[5] = a[2][a[1]]
        if registers[5] ~= "Random" then
            goto p82
        end
        goto p102
        ::p50::
        tick(50)
        registers[7] = (0)
        ::p51::
        tick(51);
        registers[(6)] = registers[(6)](registers[7])
        registers[6] = registers[6] % 4
        if registers[6] ~= 0 then
            goto p136
        end
        goto p125
        ::p82::
        tick(82)
        registers[5] = upvalues[0]["clamp"]
        registers[6] = upvalues[1][154]
        registers[7] = registers[4];
        registers[(6)] = registers[(6)](registers[7])
        goto p94
        ::p88::
        tick(88)
        registers[8] = (45);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1][154]
        registers[7] = registers[3]
        if registers[7] then
            goto p51
        end
        goto p50
        ::p94::
        registers[7] = (1)
        registers[8] = (16)
        do
            return registers[(5)](unpack_range(8, registers, 6))
        end
        ::p102::
        registers[5] = upvalues[5]
        registers[6] = registers[4]
        registers[7] = registers[2]
        registers[8] = (100);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        goto p15
        ::p117::
        registers[5] = upvalues[4];
        registers[5] = registers[5]()
        registers[4] = registers[4] + registers[5]
        goto p82
        ::p121::
        tick(121)
        registers[5] = upvalues[5]
        registers[6] = registers[4]
        registers[7] = registers[2]
        goto p88
        ::p125::
        registers[4] = (registers[4] - registers[5])
        goto p82
        ::p128::
        tick(128);
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = (1)
        registers[7] = (16);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        a = upvalues[3];
        registers[5] = a[2][a[1]]
        goto p26
        ::p136::
        if registers[6] ~= 2 then
            goto p82
        end
        registers[4] = registers[4] + registers[5]
        goto p82
        ::p140::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]["clamp"]
        registers[5] = upvalues[1][154]
        registers[6] = registers[1]
        if registers[6] then
            goto p128
        end
        goto p44
        ::p158::
        a = upvalues[3];
        registers[5] = a[2][a[1]]
        if registers[5] ~= "Fluctuate" then
            goto p47
        end
        goto p121
    end
end
