-- Recovered function f149; author names are unavailable.
F.f149 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f149")
        tick(1)
        goto p99
        ::p4::
        tick(4)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p56
        ::p15::
        tick(15)
        registers[4] = (1)
        a = registers
        z = 5
        q = registers
        q = q[2]
        a[z] = q
        registers[6] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p73
        goto p99
        ::p47::
        tick(47)
        registers[8] = upvalues[0][45]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        goto p75
        ::p51::
        tick(51)
        registers[8] = (#registers[3])
        registers[8] = registers[8] + 1
        registers[3][registers[8]] = registers[7]
        goto p73
        ::p56::
        tick(56)
        registers[4] = registers[3]
        do
            return registers[4]
        end
        ::p71::
        tick(71)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p166
        end
        goto p4
        ::p73::
        tick(73)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p47
        end
        goto p171
        ::p75::
        if registers[8] ~= "CCSPlayer" then
            goto p73
        end
        goto p92
        ::p85::
        tick(85)
        registers[8] = upvalues[0][33]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] then
            goto p158
        end
        goto p71
        ::p92::
        registers[9] = upvalues[0][33]
        a = registers
        z = 10
        q = registers
        q = q[7]
        a[z] = q;
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] then
            goto p51
        end
        goto p73
        ::p99::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][31];
        registers[2] = registers[2]()
        if registers[2] then
            goto p104
        end
        goto p136
        ::p104::
        tick(104)
        registers[3] = {
        }
        if not registers[1] then
            goto p114
        end
        goto p15
        ::p114::
        registers[4] = (1)
        registers[5] = registers[2]
        registers[6] = (1)
        goto p139
        ::p129::
        tick(129)
        registers[8] = upvalues[0][50]
        a = registers
        z = 9
        q = registers
        q = q[7]
        a[z] = q;
        registers[(8)] = registers[(8)](registers[9])
        if not registers[8] then
            goto p71
        end
        goto p85
        ::p136::
        registers[2] = (64)
        goto p104
        ::p139::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p71
        goto p15
        ::p158::
        registers[8] = (#registers[3])
        a = registers
        z = (8)
        q = registers
        m = 8
        q = q[m]
        m = 1
        q = (q + m);
        a[z] = q
        registers[3][registers[8]] = registers[7]
        goto p71
        ::p166::
        registers[8] = upvalues[0][45]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        branch_taken = false
        if registers[8] ~= "CCSPlayer" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p129
        end
        goto p71
        ::p171::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p56
    end
end
