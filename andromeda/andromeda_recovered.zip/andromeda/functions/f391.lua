-- Recovered function f391; author names are unavailable.
F.f391 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f391")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = environment["tostring"]
        registers[4] = registers[1]
        if registers[4] then
            goto p110
        end
        goto p100
        ::p42::
        tick(42);
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[0][151]
        registers[7] = (1)
        registers[8] = (registers[3] - registers[5])
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[0][162]
        goto p86
        ::p67::
        tick(67)
        registers[8] = (0)
        registers[9] = (1);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        registers[6] = registers[4] * registers[6]
        registers[6] = registers[6] + 0.5
        goto p42
        ::p73::
        tick(73)
        z = registers[1]
        registers[9] = z;
        registers[(8)] = z["sub"]
        registers[10] = registers[6]
        registers[11] = registers[7]
        do
            return registers[(8)](unpack_range(11, registers, 9))
        end
        ::p77::
        tick(77)
        registers[7] = (0)
        goto p67
        ::p79::
        tick(79);
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = upvalues[0][154]
        registers[5] = (#registers[1])
        registers[5] = (registers[5] * 0.5)
        registers[5] = registers[5] + 0.5
        goto p104
        ::p86::
        registers[8] = (#registers[1])
        registers[9] = registers[3] + registers[5]
        registers[7] = registers[7](registers[8], registers[9])
        goto p73
        ::p100::
        registers[4] = ""
        goto p110
        ::p104::;
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = upvalues[0][154]
        registers[6] = upvalues[1]["clamp"]
        registers[7] = registers[2]
        if registers[7] then
            goto p67
        end
        goto p77
        ::p110::;
        registers[(3)] = registers[(3)](registers[4])
        registers[1] = registers[3]
        registers[3] = upvalues[0][154]
        registers[4] = (#registers[1])
        registers[4] = (registers[4] * 0.5)
        registers[4] = registers[4] + 0.5
        goto p79
    end
end
