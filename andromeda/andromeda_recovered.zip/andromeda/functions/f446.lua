-- Recovered function f446; author names are unavailable.
F.f446 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f446")
        tick(1)
        goto p35
        ::p2::
        tick(2)
        slot_3 = slot_2
        do
            return slot_3
        end
        ::p35::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["builder"]
        slot_2 = slot_2[slot_1]
        if slot_2 then
            goto p2
        end
        slot_3 = upvalues[0]["builder"]
        slot_4 = upvalues[1][1]
        slot_3 = slot_3[slot_4]
        do
            return slot_3
        end
    end
end
