-- Recovered function f353; author names are unavailable.
F.f353 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f353")
        tick(1)
        goto p78
        ::p3::
        tick(3)
        registers[9] = (29)
        goto p85
        ::p14::
        tick(14)
        registers[6] = registers[2]
        registers[2] = registers[1]
        registers[1] = registers[6]
        goto p76
        ::p27::
        tick(27)
        if registers[9] then
            goto p85
        end
        goto p3
        ::p37::
        tick(37)
        registers[19] = registers[1]
        registers[20] = registers[2]
        m, x = pack_returns(registers[17](unpack_range(20, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[16](unpack_range(top, registers, 17))
        end
        ::p41::
        tick(41)
        registers[6] = registers[1]
        do
            return registers[6]
        end
        ::p44::
        tick(44);
        registers[(6)] = registers[(6)](registers[7])
        registers[1] = registers[6]
        registers[6] = upvalues[0][154]
        registers[7] = registers[2]
        if registers[7] then
            goto p148
        end
        goto p177
        ::p50::
        tick(50)
        registers[9] = (17)
        goto p27
        ::p52::
        tick(52)
        registers[13] = registers[4]
        if not registers[13] then
            goto p63
        end
        goto p153
        ::p61::
        tick(61)
        registers[7] = (0)
        goto p44
        ::p63::
        tick(63)
        if registers[13] then
            goto p126
        end
        goto p83
        ::p76::
        tick(76)
        if registers[1] ~= registers[2] then
            goto p113
        end
        goto p41
        ::p78::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = upvalues[0][154]
        registers[7] = registers[1]
        if registers[7] then
            goto p44
        end
        goto p61
        ::p83::
        registers[13] = (1.9)
        goto p126
        ::p85::
        registers[10] = upvalues[0][154]
        a = upvalues[1];
        registers[11] = a[2][a[1]]["packets"];
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = (registers[10] * 97)
        registers[12] = (registers[8] * 13)
        goto p161
        ::p94::
        tick(94);
        registers[(14)] = registers[(14)](registers[15])
        registers[14] = (registers[14] * 2)
        registers[14] = (registers[14] - 1)
        registers[15] = (registers[13] * 0.3)
        goto p166
        ::p100::
        tick(100)
        registers[12] = (0)
        goto p120
        ::p102::
        tick(102)
        registers[9] = registers[4]
        if not registers[9] then
            goto p27
        end
        goto p50
        ::p109::
        tick(109);
        registers[(13)] = registers[(13)](registers[14])
        registers[14] = upvalues[2]
        registers[15] = registers[11]
        goto p94
        ::p113::
        registers[6] = registers[1] + registers[2]
        registers[6] = (registers[6] * 0.5)
        registers[7] = (registers[2] - registers[1])
        registers[7] = (registers[7] * 0.5)
        registers[8] = registers[3]
        if registers[8] then
            goto p102
        end
        goto p175
        ::p120::
        tick(120)
        registers[11] = registers[11] + registers[12]
        a = upvalues[1];
        registers[12] = a[2][a[1]]["packets"]
        registers[12] = (registers[12] * 0.15)
        registers[13] = (registers[8] * 0.37)
        registers[12] = registers[12] + registers[13]
        goto p52
        ::p126::
        registers[12] = registers[12] + registers[13]
        registers[13] = upvalues[0][163]
        registers[14] = registers[12]
        goto p109
        ::p148::
        tick(148);
        registers[(6)] = registers[(6)](registers[7])
        registers[2] = registers[6]
        if not (registers[2] < registers[1]) then
            goto p76
        end
        goto p14
        ::p153::
        registers[13] = (0)
        goto p63
        ::p161::
        registers[11] = registers[11] + registers[12]
        registers[11] = registers[11] + registers[9]
        registers[12] = registers[5]
        if registers[12] then
            goto p120
        end
        goto p100
        ::p166::
        registers[16] = (registers[14] * 0.7)
        registers[15] = registers[15] + registers[16]
        registers[16] = upvalues[3]["round"]
        registers[17] = upvalues[3]["clamp"]
        registers[18] = registers[15] * registers[7]
        registers[18] = registers[6] + registers[18]
        goto p37
        ::p175::
        registers[8] = (1)
        goto p102
        ::p177::
        registers[7] = (0)
        goto p148
    end
end
