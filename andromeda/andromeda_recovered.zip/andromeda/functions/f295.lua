-- Recovered function f295; author names are unavailable.
F.f295 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f295")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["sim_store"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["ent_store"]
        goto p25
        ::p10::
        tick(10)
        slot_2 = slot_2["miss_side"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        goto p93
        ::p14::
        tick(14)
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["last_value"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        goto p10
        ::p25::
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["resolved"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["records"]
        goto p73
        ::p57::
        tick(57)
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["prev"]
        slot_2[slot_1] = slot_0
        goto p112
        ::p61::
        tick(61)
        slot_2 = upvalues[1]
        slot_3 = slot_1
        slot_2(slot_3)
        goto p122
        ::p73::
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["miss_counter"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["correction_until"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["cur"]
        slot_2[slot_1] = slot_0
        goto p57
        ::p93::
        slot_2 = slot_2["miss_until"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["misses"]
        slot_2[slot_1] = slot_0
        goto p61
        ::p112::
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["pre_prev"]
        slot_2[slot_1] = slot_0
        tick(116)
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["pre_pre_prev"]
        slot_2[slot_1] = slot_0
        slot_2 = upvalues[0]["wraith"]
        slot_2 = slot_2["flags"]
        goto p14
        ::p122::
        do
            return 
        end
    end
end
