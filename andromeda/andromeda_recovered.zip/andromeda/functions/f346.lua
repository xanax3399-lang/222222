-- Recovered function f346; author names are unavailable.
F.f346 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f346")
        tick(1)
        goto p44
        ::p4::
        tick(4)
        slot_1 = slot_1[2]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        goto p82
        ::p26::
        tick(26)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["freestanding"]
        slot_1 = slot_1["hotkey"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["edge_yaw"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["roll"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        do
            return 
        end
        ::p44::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["enabled"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        goto p100
        ::p52::
        tick(52)
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["yaw_base"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        goto p169
        ::p59::
        tick(59)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["body_yaw"]
        goto p107
        ::p69::
        tick(69)
        slot_1 = slot_1[2]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        goto p159
        ::p77::
        tick(77)
        slot_1 = slot_1["body_yaw"]
        slot_1 = slot_1[2]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        goto p164
        ::p82::
        slot_1 = slot_1["yaw_jitter"]
        slot_1 = slot_1[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["yaw_jitter"]
        slot_1 = slot_1[2]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        goto p59
        ::p100::
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["pitch"]
        slot_1 = slot_1[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        goto p148
        ::p107::
        slot_1 = slot_1[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        goto p77
        ::p148::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["pitch"]
        goto p69
        ::p152::
        tick(152)
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["freestanding"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        slot_1(slot_2)
        goto p26
        ::p159::
        slot_1 = slot_1["yaw"]
        slot_1 = slot_1[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        goto p52
        ::p164::
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["freestanding_body_yaw"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["override"]
        goto p152
        ::p169::
        slot_1(slot_2)
        slot_1 = upvalues[0]["antiaim"]
        slot_1 = slot_1["angles"]
        slot_1 = slot_1["yaw"]
        goto p4
    end
end
