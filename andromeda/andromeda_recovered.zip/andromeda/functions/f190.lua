-- Recovered function f190; author names are unavailable.
F.f190 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f190")
        tick(1)
        goto p47
        ::p2::
        tick(2)
        if registers[1] == registers[4] then
            goto p156
        end
        goto p35
        ::p12::
        tick(12)
        registers[5] = upvalues[1]["config"]
        registers[5] = registers[5]["name"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set"]
        goto p24
        ::p16::
        tick(16)
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["update_list"]
        registers[(6)](registers[7])
        registers[6] = environment["type"]
        registers[7] = registers[5];
        registers[(6)] = registers[(6)](registers[7])
        goto p120
        ::p24::
        registers[7] = "";
        registers[5](registers[6], registers[7])
        goto p149
        ::p35::
        registers[5] = upvalues[3]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["create_config"]
        registers[7] = registers[1]
        registers[5] = registers[5](registers[6], registers[7])
        registers[6] = upvalues[3]
        goto p16
        ::p44::
        tick(44)
        if registers[4] then
            goto p65
        end
        goto p118
        ::p47::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]["config"]
        registers[2] = registers[2]["name"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        m = m + 2 - 1
        top = m
        z = 0
        for f = 2, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[1] = registers[1](unpack_range(top, registers, 2))
        registers[2] = upvalues[2]
        goto p158
        ::p65::
        tick(65)
        branch_taken = false
        if registers[1] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p156
        end
        goto p2
        ::p95::
        tick(95)
        registers[6] = upvalues[1]["config"]
        registers[6] = registers[6]["list"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["set"]
        goto p102
        ::p99::
        tick(99)
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["update_list"]
        registers[(5)](registers[6])
        do
            return 
        end
        ::p102::
        registers[8] = (registers[5] - 1);
        registers[6](registers[7], registers[8])
        goto p137
        ::p118::
        registers[4] = nil
        goto p65
        ::p120::
        if registers[6] ~= "number" then
            goto p137
        end
        goto p95
        ::p125::
        tick(125)
        registers[4] = registers[3][1]
        goto p44
        ::p137::
        registers[6] = upvalues[1]["config"]
        registers[6] = registers[6]["name"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["set"]
        registers[8] = "";
        registers[6](registers[7], registers[8])
        goto p149
        ::p143::
        tick(143);
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "table")
        if not registers[4] then
            goto p44
        end
        goto p125
        ::p149::
        tick(149)
        registers[5] = upvalues[3]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["save_config"]
        registers[7] = upvalues[2]
        m, x = pack_returns(registers[7]())
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[5](unpack_range(top, registers, 6))
        registers[5] = upvalues[3]
        goto p99
        ::p156::
        branch_taken = false
        if registers[1] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p149
        end
        goto p12
        ::p158::;
        registers[2] = registers[2]()
        registers[3] = upvalues[3]["configs_db"]
        registers[3] = registers[3]["cfg_list"]
        registers[3] = registers[3][registers[2]]
        registers[4] = environment["type"]
        registers[5] = registers[3]
        goto p143
    end
end
