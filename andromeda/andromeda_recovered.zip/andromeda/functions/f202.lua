-- Recovered function f202; author names are unavailable.
F.f202 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f202")
        tick(1)
        goto p10
        ::p2::
        tick(2)
        z = slot_1
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        slot_3 = slot_2
        if slot_3 then
            goto p31
        end
        goto p13
        ::p10::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 ~= slot_0 then
            goto p2
        end
        goto p29
        ::p13::
        slot_3 = (false)
        goto p31
        ::p29::
        slot_2 = (false)
        do
            return slot_2
        end
        ::p31::
        do
            return slot_3
        end
    end
end
