-- Recovered function f291; author names are unavailable.
F.f291 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f291")
        tick(1)
        goto p137
        ::p9::
        tick(9);
        registers[4](registers[5], registers[6])
        registers[4] = registers[2]["stop_to_full_running_fraction"]
        if registers[4] then
            goto p27
        end
        registers[4] = (0)
        goto p27
        ::p17::
        tick(17)
        registers[4] = upvalues[1][151]
        registers[5] = (1)
        registers[6] = registers[2]["feet_speed_unknown_forwards_or_sideways"]
        if registers[6] then
            goto p9
        end
        goto p62
        ::p22::
        tick(22)
        registers[5] = upvalues[1][161]
        registers[6] = registers[2]["max_yaw"]
        if registers[6] then
            goto p77
        end
        goto p70
        ::p27::
        registers[4] = (registers[4] * -0.30000001)
        registers[4] = (registers[4] - 0.19999999)
        registers[4] = registers[4] * registers[3]
        registers[4] = registers[4] + 1
        goto p22
        ::p44::
        tick(44)
        registers[4] = (0)
        goto p133
        ::p62::
        registers[6] = (1)
        goto p9
        ::p66::
        tick(66)
        registers[3] = upvalues[0]["clamp"]
        registers[4] = registers[2]["feet_speed_forwards_or_sideways"]
        if registers[4] then
            goto p133
        end
        goto p44
        ::p70::
        registers[6] = (58)
        ::p77::;
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = registers[5] * registers[4]
        registers[7] = upvalues[0]["clamp"]
        registers[8] = registers[6]
        goto p112
        ::p82::
        tick(82)
        registers[3] = (58)
        do
            return registers[3]
        end
        ::p94::
        tick(94)
        registers[12] = (58)
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[7](unpack_range(top, registers, 8))
        end
        ::p112::
        registers[9] = (27)
        registers[10] = upvalues[1][162]
        registers[11] = registers[5]
        goto p94
        ::p133::
        registers[5] = (0)
        registers[6] = (1);
        registers[3] = registers[3](unpack_range(6, registers, 4))
        goto p17
        ::p137::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[2] ~= registers[0] then
            goto p66
        end
        goto p82
    end
end
