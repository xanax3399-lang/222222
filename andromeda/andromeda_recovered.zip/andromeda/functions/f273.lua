-- Recovered function f273; author names are unavailable.
F.f273 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f273")
        tick(1)
        slot_1 = upvalues[0][86]
        slot_2 = "play ui/armsrace_level_up.wav"
        slot_1(slot_2)
        slot_1 = upvalues[0][86]
        slot_2 = "sv_cheats 1;mp_roundtime_defuse 99999;mp_warmup_end;mp_buytime 99999999;mp_buy_anywhere 1;sv_infinite_ammo 1;impulse 101;sv_airaccelerate 100;sv_regeneration_force_on 1;mp_respawn_on_death_ct 1;mp_respawn_on_death_t 1;bot_stop 1;mp_roundtime_hostage 10000"
        slot_1(slot_2)
        do
            return 
        end
    end
end
