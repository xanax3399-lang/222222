-- Recovered function f253; author names are unavailable.
F.f253 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f253")
        tick(1)
        goto p8
        ::p2::
        tick(2)
        registers[3] = (1)
        ::p5::
        tick(5)
        registers[4] = (0.5)
        registers[5] = (2)
        do
            return registers[(2)](unpack_range(5, registers, 3))
        end
        ::p8::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["clamp"]
        registers[3] = registers[1]
        if registers[3] then
            goto p5
        end
        goto p2
    end
end
