-- Recovered function f451; author names are unavailable.
F.f451 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f451")
        tick(1)
        goto p9
        ::p3::
        tick(3)
        registers[6] = registers[6] * registers[7];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[0][163]
        goto p42
        ::p7::
        tick(7)
        registers[9] = (0)
        goto p146
        ::p9::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = upvalues[0][163]
        registers[6] = upvalues[0][30];
        registers[6] = registers[6]()
        registers[7] = registers[3]
        if registers[7] then
            goto p3
        end
        goto p129
        ::p22::
        tick(22)
        registers[10] = registers[6]
        do
            return registers[(7)](unpack_range(10, registers, 8))
        end
        ::p26::
        tick(26)
        registers[7] = registers[1]
        if registers[7] then
            goto p73
        end
        goto p68
        ::p29::
        tick(29)
        registers[9] = registers[1]
        if registers[9] then
            goto p146
        end
        goto p7
        ::p42::
        registers[7] = upvalues[0][30];
        registers[7] = registers[7]()
        registers[8] = registers[3]
        if registers[8] then
            goto p61
        end
        goto p70
        ::p61::
        tick(61)
        registers[7] = registers[7] * registers[8];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = registers[5] + 1
        registers[5] = registers[7] / 2
        if registers[4] ~= "Lerp" then
            goto p26
        end
        goto p135
        ::p68::
        registers[7] = (0)
        goto p73
        ::p70::
        registers[8] = (0)
        goto p61
        ::p73::
        registers[8] = registers[2]
        if registers[8] then
            goto p29
        end
        registers[8] = (0)
        goto p29
        ::p129::
        registers[7] = (0)
        goto p3
        ::p132::
        tick(132)
        registers[9] = (0)
        goto p22
        ::p134::
        tick(134)
        do
            return registers[7]
        end
        ::p135::
        registers[7] = upvalues[1]["lerp"]
        registers[8] = registers[1]
        if registers[8] then
            goto p155
        end
        goto p154
        ::p146::
        registers[8] = (registers[8] - registers[9])
        registers[8] = registers[8] * registers[5]
        registers[7] = registers[7] + registers[8]
        goto p134
        ::p154::
        registers[8] = (0)
        ::p155::
        registers[9] = registers[2]
        if registers[9] then
            goto p22
        end
        goto p132
    end
end
