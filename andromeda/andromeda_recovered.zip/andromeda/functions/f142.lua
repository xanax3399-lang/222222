-- Recovered function f142; author names are unavailable.
F.f142 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f142")
        tick(1)
        goto p65
        ::p33::
        tick(33)
        registers[2] = upvalues[1]
        registers[3] = upvalues[0][47]
        registers[4] = registers[1]
        registers[5] = "m_vecVelocity"
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        registers[3] = upvalues[0][47]
        registers[4] = registers[1]
        registers[5] = "m_fFlags"
        goto p52
        ::p50::
        tick(50)
        registers[3] = (0)
        goto p83
        ::p52::
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] then
            goto p83
        end
        goto p50
        ::p55::
        tick(55)
        registers[6] = (1)
        registers[4] = registers[4](registers[5], registers[6])
        registers[4] = (registers[4] == 1)
        z = registers[2]
        registers[6] = z;
        registers[(5)] = z["length2d"];
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] < 2)
        if not registers[5] then
            goto p82
        end
        goto p103
        ::p65::
        registers[1] = upvalues[0][32];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p105
        end
        registers[2] = upvalues[0][50]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] then
            goto p33
        end
        goto p105
        ::p82::
        tick(82)
        do
            return registers[5]
        end
        ::p83::
        registers[4] = environment["bit"]
        registers[4] = registers[4]["band"]
        registers[5] = registers[3]
        goto p55
        ::p103::
        registers[5] = registers[4]
        goto p82
        ::p105::
        registers[2] = (false)
        do
            return registers[2]
        end
    end
end
