-- Recovered function f44; author names are unavailable.
F.f44 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, _, z, a = 0, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f44")
        tick(1)
        goto p11
        ::p3::
        tick(3)
        registers[5] = (#registers[2])
        registers[6] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p6
        ::p6::
        tick(6)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p19
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = registers[3]
        do
            return registers[4]
        end
        ::p11::
        _, Q = pack_returns(...)
        registers[2] = {
        }
        z = (_ - T - 1)
        if z < 0 then
            z = -1
        end
        q = 0
        for T = 3, 3 + z, 1 do
            registers[T] = Q[W + q]
            q = q + 1
        end
        top = (3 + z)
        q = registers[(2)]
        for f = 1, top - (2) do
            q[(0) + f] = registers[(2) + f]
        end
        registers[3] = ""
        registers[4] = (1)
        goto p3
        ::p19::
        registers[8] = registers[2][registers[7]]
        registers[8] = upvalues[0][registers[8]]
        registers[3] = (registers[3]..registers[8])
        goto p6
    end
end
