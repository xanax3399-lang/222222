-- Recovered function f397; author names are unavailable.
F.f397 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f397")
        tick(1)
        goto p225
        ::p2::
        tick(2)
        registers[16] = upvalues[1]["render_items"]
        registers[16] = registers[16][registers[13]]
        registers[17] = upvalues[1]["draw_bomb_group"]
        goto p344
        ::p6::
        tick(6)
        registers[7] = registers[4]
        if registers[7] then
            goto p78
        end
        goto p330
        ::p9::
        tick(9)
        if not registers[16] then
            goto p23
        end
        goto p26
        ::p11::
        tick(11)
        upvalues[1]["render_count"] = 0
        upvalues[1]["published_frame"] = -1
        upvalues[1]["published_count"] = 0
        registers[2] = upvalues[1]["update_planting_state"]
        registers[3] = (false)
        registers[(2)](registers[3])
        registers[2] = upvalues[1]["clear_table"]
        goto p213
        ::p19::
        tick(19)
        registers[2] = upvalues[1]["render_count"]
        if not (registers[2] <= 0) then
            goto p136
        end
        goto p350
        ::p23::
        tick(23)
        if registers[15] == registers[0] then
            goto p140
        end
        goto p143
        ::p26::
        registers[16] = upvalues[1]["find_bomb_subitem_index"]
        registers[17] = registers[11];
        registers[(16)] = registers[(16)](registers[17])
        goto p134
        ::p36::
        tick(36)
        if not registers[16] then
            goto p85
        end
        goto p269
        ::p46::
        tick(46)
        registers[6] = upvalues[1]["px"]
        registers[7] = (28)
        registers[8] = registers[2]
        registers[6] = registers[6](registers[7], registers[8])
        goto p6
        ::p54::
        tick(54)
        registers[2] = environment["type"]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        branch_taken = false
        if registers[2] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p19
        end
        goto p90
        ::p59::
        tick(59)
        m, x = pack_returns(registers[7]())
        z = 0
        for f = 7, 8 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = upvalues[1]["px"]
        registers[10] = (14)
        registers[11] = registers[2]
        goto p74
        ::p64::
        tick(64)
        registers[20] = upvalues[1]["measure_item"]
        registers[21] = registers[15]
        registers[22] = "+bd"
        goto p174
        ::p69::
        tick(69)
        registers[11] = registers[11] + 0.5;
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = (1)
        registers[12] = registers[10]
        goto p211
        ::p74::
        registers[9] = registers[9](registers[10], registers[11])
        registers[10] = upvalues[2][154]
        registers[11] = (registers[8] * 0.6)
        goto p69
        ::p78::
        tick(78)
        registers[8] = upvalues[1]["px"]
        registers[9] = (4)
        registers[10] = registers[2]
        goto p253
        ::p82::
        tick(82)
        if not (0.15 < registers[3]) then
            goto p19
        end
        goto p11
        ::p85::
        tick(85)
        registers[16] = upvalues[1]["draw_item"]
        registers[17] = registers[15]
        registers[18] = registers[9]
        registers[19] = registers[12]
        goto p64
        ::p90::
        registers[3] = upvalues[2][30];
        registers[3] = registers[3]()
        registers[4] = upvalues[1]["last_capture_time"]
        registers[3] = (registers[3] - registers[4])
        goto p82
        ::p101::
        tick(101)
        registers[1] = upvalues[2][29];
        registers[1] = registers[1]()
        registers[2] = environment["type"]
        goto p245
        ::p105::
        tick(105)
        registers[22] = registers[2]
        registers[23] = "+bd"
        registers[(16)](unpack_range(23, registers, 17))
        goto p128
        ::p110::
        tick(110)
        registers[14] = upvalues[1]["render_count"]
        branch_taken = false
        if not (not (registers[11] <= registers[14])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p148
        end
        goto p150
        ::p115::
        tick(115)
        registers[18] = registers[18](registers[19], registers[20])
        registers[17] = registers[17] + registers[18]
        registers[12] = registers[17] + registers[6]
        registers[11] = registers[11] + 1
        goto p110
        ::p128::
        registers[16] = registers[12] + registers[5]
        registers[12] = registers[16] + registers[6]
        registers[11] = registers[11] + 1
        goto p110
        ::p132::
        tick(132)
        if registers[15] == registers[0] then
            goto p23
        end
        goto p197
        ::p134::
        registers[13] = registers[16]
        goto p23
        ::p136::
        registers[2] = upvalues[1]["get_dpi_scale"];
        registers[2] = registers[2]()
        registers[3] = upvalues[2][136]
        goto p339
        ::p140::
        tick(140)
        if registers[15] == registers[0] then
            goto p85
        end
        goto p207
        ::p143::
        registers[16] = registers[15]["kind"]
        if registers[16] ~= "bomb_planting" then
            goto p140
        end
        goto p266
        ::p148::
        do
            return 
        end
        ::p150::
        registers[15] = upvalues[1]["render_items"]
        registers[15] = registers[15][registers[11]]
        if registers[11] ~= registers[13] then
            goto p132
        end
        goto p172
        ::p167::
        tick(167)
        registers[25] = "+bd"
        registers[(17)](unpack_range(25, registers, 18))
        registers[17] = (registers[5] * 2)
        registers[17] = registers[12] + registers[17]
        goto p352
        ::p172::
        registers[11] = registers[11] + 1
        goto p110
        ::p174::
        registers[23] = registers[2];
        registers[20] = registers[20](unpack_range(23, registers, 21))
        registers[21] = registers[5]
        goto p105
        ::p178::
        tick(178)
        registers[8] = registers[2]
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[2][57]
        goto p59
        ::p182::
        tick(182)
        do
            return 
        end
        ::p183::
        tick(183)
        registers[23] = registers[15]
        registers[24] = registers[16]
        registers[25] = "+bd"
        registers[26] = registers[2];
        registers[22] = registers[22](unpack_range(26, registers, 23))
        registers[23] = registers[5]
        registers[24] = registers[2]
        goto p167
        ::p191::
        tick(191)
        registers[3] = upvalues[1]["capture_frame"]
        registers[3] = (registers[1] - registers[3])
        if not (1 < registers[3]) then
            goto p54
        end
        goto p249
        ::p197::
        registers[16] = upvalues[1]["is_bomb_main_kind"]
        registers[17] = registers[15]["kind"];
        registers[(16)] = registers[(16)](registers[17])
        goto p9
        ::p207::
        registers[16] = upvalues[1]["is_bomb_main_kind"]
        registers[17] = registers[15]["kind"];
        registers[(16)] = registers[(16)](registers[17])
        goto p36
        ::p211::
        registers[13] = nil
        goto p110
        ::p213::
        registers[3] = upvalues[1]["visible_keys"]
        registers[(2)](registers[3])
        goto p19
        ::p225::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p234
        end
        goto p182
        ::p229::
        tick(229)
        registers[11] = registers[11] + 1
        goto p110
        ::p231::
        tick(231)
        do
            return 
        end
        ::p234::
        registers[1] = upvalues[1]["active"]
        if registers[1] then
            goto p101
        end
        goto p231
        ::p245::
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= "number" then
            goto p54
        end
        goto p191
        ::p249::
        upvalues[1]["render_count"] = 0
        upvalues[1]["published_frame"] = -1
        upvalues[1]["published_count"] = 0
        goto p324
        ::p253::
        registers[8] = registers[8](registers[9], registers[10])
        registers[7] = registers[7] + registers[8]
        registers[5] = registers[5](registers[6], registers[7])
        registers[6] = upvalues[1]["px"]
        registers[7] = (8)
        goto p178
        ::p266::
        if registers[13] ~= registers[0] then
            goto p140
        end
        goto p297
        ::p269::
        if registers[13] == registers[0] then
            goto p85
        end
        goto p2
        ::p275::
        tick(275)
        registers[22] = registers[2]
        registers[23] = "+bd"
        registers[(16)](unpack_range(23, registers, 17))
        registers[16] = registers[12] + registers[5]
        registers[12] = registers[16] + registers[6]
        goto p229
        ::p281::
        tick(281)
        registers[19] = registers[12]
        registers[20] = upvalues[1]["measure_planting_item"]
        registers[21] = registers[15]
        registers[22] = "+bd"
        registers[23] = registers[2];
        registers[20] = registers[20](unpack_range(23, registers, 21))
        registers[21] = registers[5]
        goto p275
        ::p297::
        registers[16] = upvalues[1]["draw_planting_item"]
        registers[17] = registers[15]
        registers[18] = registers[9]
        goto p281
        ::p324::
        registers[2] = upvalues[1]["update_planting_state"]
        registers[3] = (false)
        registers[(2)](registers[3])
        registers[2] = upvalues[1]["clear_table"]
        goto p376
        ::p330::
        registers[7] = (20)
        goto p78
        ::p339::
        registers[4] = "+bd"
        registers[5] = "A"
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        z = 0
        for f = 3, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = upvalues[2][151]
        goto p46
        ::p344::
        registers[18] = registers[15]
        registers[19] = registers[16]
        registers[20] = registers[9]
        registers[21] = registers[12]
        registers[22] = upvalues[1]["measure_bomb_group"]
        goto p183
        ::p350::
        do
            return 
        end
        ::p352::
        registers[18] = upvalues[1]["px"]
        registers[19] = (1)
        registers[20] = registers[2]
        goto p115
        ::p376::
        registers[3] = upvalues[1]["visible_keys"]
        registers[(2)](registers[3])
        goto p19
    end
end
