-- Recovered function f290; author names are unavailable.
F.f290 = function(function_metadata, upvalues)
    local operand_i, code_metadata, operand_k = function_metadata[2], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_22, slot_23, slot_24, slot_25, slot_26, slot_27, slot_28, slot_29 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f290")
        tick(1)
        goto p72
        ::p12::
        tick(12)
        slot_3 = slot_1[1]
        slot_4 = upvalues[0][161]
        slot_5 = slot_1[1]
        goto p52
        ::p16::
        tick(16)
        slot_3 = (#slot_1)
        if slot_3 ~= 0 then
            goto p12
        end
        goto p98
        ::p28::
        tick(28)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_8 = v
            branch_taken = true
        end
        if branch_taken then
            goto p30
        end
        goto p56
        ::p30::
        slot_9 = upvalues[0][161]
        slot_10 = slot_1[slot_8]
        slot_10 = (slot_2 - slot_10);
        slot_9 = slot_9(slot_10)
        goto p78
        ::p52::
        slot_5 = (slot_2 - slot_5);
        slot_4 = slot_4(slot_5)
        slot_5 = (2)
        goto p80
        ::p56::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_5 = slot_3
        do
            return slot_5
        end
        ::p59::
        tick(59)
        slot_3 = slot_1[slot_8]
        slot_4 = slot_9
        goto p28
        ::p72::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_1 == slot_0 then
            goto p98
        end
        goto p16
        ::p78::
        if not (slot_9 < slot_4) then
            goto p28
        end
        goto p59
        ::p80::
        slot_6 = (#slot_1)
        slot_7 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_7 + 0
        n = (slot_6 + 0)
        v = (slot_5 - U)
        goto p28
        slot_29 = operand_k
        slot_23 = code_metadata
        slot_28 = operand_i
        slot_28[56] = 0
        slot_23[56] = 177
        slot_29[56] = 0
        slot_29[19] = 27
        slot_22 = nil
        slot_23 = nil
        slot_24 = nil
        slot_25 = nil
        slot_26 = nil
        slot_27 = nil
        slot_28 = nil
        slot_29 = nil
        goto p28
        ::p98::
        slot_3 = nil
        do
            return slot_3
        end
    end
end
