-- Recovered function f339; author names are unavailable.
F.f339 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f339")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]["unset_hitchance"]
        slot_1()
        upvalues[0]["active"] = false
        do
            return 
        end
    end
end
