-- Recovered function f472; author names are unavailable.
F.f472 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f472")
        tick(1)
        goto p48
        ::p10::
        tick(10)
        do
            return 
        end
        ::p16::
        tick(16)
        do
            return 
        end
        ::p28::
        tick(28)
        registers[4] = upvalues[2]["setup_command"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        goto p10
        ::p35::
        tick(35)
        a = upvalues[0]
        a[2][a[1]] = registers[1]
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "setup_command"
        goto p28
        ::p48::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[1] = (registers[1] == true)
        a = upvalues[0];
        registers[2] = a[2][a[1]]
        if registers[2] ~= registers[1] then
            goto p35
        end
        goto p16
    end
end
