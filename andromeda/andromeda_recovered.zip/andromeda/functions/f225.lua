-- Recovered function f225; author names are unavailable.
F.f225 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f225")
        tick(1)
        goto p76
        ::p11::
        tick(11)
        registers[2] = upvalues[1]["clear"]
        registers[(2)]()
        ::p26::
        tick(26)
        do
            return 
        end
        ::p28::
        tick(28)
        do
            return 
        end
        ::p29::
        tick(29)
        upvalues[1]["active"] = registers[1]
        registers[2] = upvalues[2]["set_callback"]
        registers[3] = "aim_fire"
        registers[4] = upvalues[1]["aim_fire"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[2]["set_callback"]
        goto p80
        ::p57::
        tick(57)
        registers[1] = upvalues[1]["is_enabled"];
        registers[1] = registers[1]()
        registers[2] = upvalues[1]["active"]
        if registers[2] ~= registers[1] then
            goto p29
        end
        goto p28
        ::p62::
        tick(62)
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[2]["set_callback"]
        goto p115
        ::p76::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p57
        end
        goto p110
        ::p80::
        registers[3] = "aim_hit"
        registers[4] = upvalues[1]["aim_hit"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        goto p111
        ::p94::
        tick(94)
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[2]["set_callback"]
        registers[3] = "player_hurt"
        registers[4] = upvalues[1]["player_hurt"]
        goto p62
        ::p110::
        do
            return 
        end
        ::p111::
        registers[2] = upvalues[2]["set_callback"]
        registers[3] = "aim_miss"
        registers[4] = upvalues[1]["aim_miss"]
        goto p94
        ::p115::
        registers[3] = "paint"
        registers[4] = upvalues[1]["paint"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        if registers[1] then
            goto p26
        end
        goto p11
    end
end
