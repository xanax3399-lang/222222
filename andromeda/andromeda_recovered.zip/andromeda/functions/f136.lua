-- Recovered function f136; author names are unavailable.
F.f136 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f136")
        tick(1)
        goto p32
        ::p15::
        tick(15)
        if not slot_3 then
            goto p36
        end
        goto p26
        ::p25::
        tick(25)
        do
            return slot_3
        end
        ::p26::
        slot_3 = slot_1["options"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"]
        slot_5 = slot_2
        slot_3 = slot_3(slot_4, slot_5)
        slot_3 = (slot_3 == true)
        goto p36
        ::p32::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (slot_1 ~= slot_0)
        if not slot_3 then
            goto p15
        end
        goto p58
        ::p36::
        if not slot_3 then
            goto p51
        end
        goto p53
        ::p51::
        tick(51)
        if not slot_3 then
            goto p25
        end
        goto p61
        ::p53::
        slot_3 = slot_1[slot_2]
        slot_3 = (slot_3 ~= slot_0)
        goto p51
        ::p58::
        slot_3 = slot_1["options"]
        slot_3 = (slot_3 ~= slot_0)
        goto p15
        ::p61::
        slot_3 = slot_1[slot_2]
        slot_3 = slot_3["value"]
        slot_3 = (slot_3 ~= slot_0)
        goto p25
    end
end
