-- Recovered function f440; author names are unavailable.
F.f440 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f440")
        tick(1)
        goto p39
        ::p11::
        tick(11)
        slot_2 = (slot_1 ~= slot_0)
        if not slot_2 then
            goto p55
        end
        goto p42
        ::p38::
        tick(38)
        do
            return slot_2
        end
        ::p39::
        slot_1 = upvalues[0]["visuals"]
        if not slot_1 then
            goto p11
        end
        goto p52
        ::p42::
        slot_2 = slot_1["aimbot_logs"]
        slot_2 = (slot_2 ~= slot_0)
        goto p55
        ::p46::
        tick(46)
        slot_2 = slot_1["aimbot_logs"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == true)
        goto p38
        ::p52::
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["stubs"]
        goto p11
        ::p55::
        if not slot_2 then
            goto p38
        end
        goto p46
    end
end
