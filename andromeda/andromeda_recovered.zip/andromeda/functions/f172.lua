-- Recovered function f172; author names are unavailable.
F.f172 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f172")
        tick(1)
        goto p208
        ::p45::
        tick(45)
        if registers[3] then
            goto p172
        end
        goto p75
        ::p47::
        tick(47)
        registers[3] = registers[1]
        goto p108
        ::p57::
        tick(57)
        registers[14] = registers[14]["stubs"]
        registers[14] = registers[14]["damage_indicator"]
        if registers[14] == registers[0] then
            goto p96
        end
        goto p116
        ::p61::
        tick(61)
        registers[13] = registers[17]
        registers[12] = registers[16]
        registers[11] = registers[15]
        goto p96
        ::p71::
        tick(71)
        registers[8] = "b"
        registers[9] = registers[6]
        registers[7] = registers[7](registers[8], registers[9])
        goto p199
        ::p75::
        registers[3] = registers[1]
        goto p172
        ::p77::
        tick(77)
        registers[7] = registers[3];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = upvalues[2][136]
        goto p71
        ::p81::
        tick(81)
        registers[2] = registers[2]["minimum_damage_override"]
        registers[2] = registers[2][2]
        registers[3] = (registers[2] ~= registers[0])
        goto p181
        ::p96::
        tick(96)
        registers[15] = 255 * registers[5]
        registers[16] = upvalues[2][131]
        registers[17] = registers[9]
        registers[18] = registers[10]
        registers[19] = registers[11]
        goto p165
        ::p102::
        tick(102)
        registers[10] = (registers[7] * 0.5)
        registers[9] = (registers[9] - registers[10])
        registers[9] = registers[9] + 10
        goto p195
        ::p108::
        tick(108)
        registers[4] = upvalues[0]["is_minimum_damage"];
        registers[4] = registers[4]()
        registers[5] = upvalues[1]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = environment["tostring"]
        goto p77
        ::p116::
        registers[15] = registers[14]["get_color"]
        if registers[15] == registers[0] then
            goto p96
        end
        z = registers[14]
        registers[16] = z;
        registers[(15)] = z["get_color"]
        m, x = pack_returns(registers[15](unpack_range(16, registers, 16)))
        z = 0
        for f = 15, 17 do
            z = (z + 1);
            registers[f] = x[z]
        end
        if registers[15] == registers[0] then
            goto p96
        end
        goto p61
        ::p145::
        tick(145)
        registers[11] = (255)
        registers[12] = (255)
        registers[13] = (255)
        registers[14] = upvalues[4]["visuals"]
        goto p57
        ::p150::
        tick(150)
        m, x = pack_returns(registers[25](unpack_range(26, registers, 26)))
        m = m + 25 - 1
        top = m
        z = 0
        for f = 25, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[16](unpack_range(top, registers, 17))
        do
            return 
        end
        ::p165::
        registers[20] = registers[12]
        registers[21] = registers[13]
        registers[22] = registers[15]
        goto p183
        ::p172::
        registers[4] = environment["type"]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        branch_taken = false
        if registers[4] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p108
        end
        goto p47
        ::p178::
        tick(178)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        goto p45
        ::p181::
        if not registers[3] then
            goto p45
        end
        goto p178
        ::p183::
        registers[23] = ""
        registers[24] = (0)
        registers[25] = environment["tostring"]
        registers[26] = registers[3]
        goto p150
        ::p195::
        registers[10] = registers[8]["y"]
        registers[10] = (registers[10] * 0.5)
        registers[10] = (registers[10] - 20)
        goto p145
        ::p199::
        registers[8] = upvalues[3]
        registers[9] = upvalues[2][57]
        m, x = pack_returns(registers[9]())
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = registers[8]["x"]
        registers[9] = (registers[9] * 0.5)
        goto p102
        ::p208::
        registers[1] = upvalues[0]["ragebot"]
        registers[1] = registers[1]["minimum_damage"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[2] = upvalues[0]["ragebot"]
        goto p81
    end
end
