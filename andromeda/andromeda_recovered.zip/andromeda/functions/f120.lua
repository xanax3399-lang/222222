-- Recovered function f120; author names are unavailable.
F.f120 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f120")
        tick(1)
        goto p117
        ::p3::
        tick(3)
        registers[7] = (registers[6] * 0)
        registers[7] = registers[7] / 0
        goto p133
        ::p6::
        tick(6)
        registers[7] = (registers[5] - 1023)
        registers[7] = 2 ^ registers[7]
        registers[7] = registers[6] * registers[7]
        registers[8] = registers[4] / 4503599627370496
        registers[8] = registers[3] + registers[8]
        registers[7] = registers[7] * registers[8]
        goto p134
        ::p13::
        tick(13)
        if registers[4] ~= 0 then
            goto p24
        end
        goto p70
        ::p24::
        registers[5] = (1)
        registers[3] = (0)
        goto p6
        ::p37::
        tick(37);
        registers[2] = registers[2]()
        registers[3] = (1)
        registers[4] = upvalues[1]
        registers[5] = registers[2]
        registers[6] = (1)
        registers[7] = (20)
        goto p75
        ::p68::
        tick(68)
        if registers[5] ~= 2047 then
            goto p6
        end
        goto p72
        ::p70::
        registers[7] = (registers[6] * 0)
        do
            return registers[7]
        end
        ::p72::
        registers[7] = (registers[4] == 0)
        if not registers[7] then
            goto p94
        end
        goto p83
        ::p75::;
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[4] = (registers[4] * 4294967296)
        a = registers
        z = 4
        q = registers
        q = q[4]
        m = registers
        x = 1
        m = m[x]
        q = q + m
        a[z] = q
        registers[5] = upvalues[1]
        goto p105
        ::p83::
        registers[7] = (registers[6] * 1)
        registers[7] = registers[7] / 0
        ::p94::
        if registers[7] then
            goto p133
        end
        goto p3
        ::p105::
        registers[6] = registers[2]
        registers[7] = (21)
        registers[8] = (31);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1]
        registers[7] = registers[2]
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = 1 ^ registers[6]
        registers[6] = -registers[6]
        if registers[5] ~= 0 then
            goto p68
        end
        goto p13
        ::p117::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        a = registers
        z = 2
        q = upvalues
        q = q[0]
        a[z] = q
        goto p37
        ::p133::
        do
            return registers[7]
        end
        ::p134::
        do
            return registers[7]
        end
    end
end
