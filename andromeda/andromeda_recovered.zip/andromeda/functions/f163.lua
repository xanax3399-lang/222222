-- Recovered function f163; author names are unavailable.
F.f163 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local tick = new_tick("f163")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= "table" then
            goto p78
        end
        goto p54
        ::p25::
        tick(25)
        do
            return 
        end
        ::p26::
        tick(26)
        z = slot_1
        slot_3 = z;
        slot_2 = z["override"]
        slot_2(slot_3)
        slot_2 = slot_1["hotkey"]
        if slot_2 == slot_0 then
            goto p25
        end
        goto p74
        ::p54::
        slot_3 = slot_1["override"]
        if slot_3 ~= slot_0 then
            goto p26
        end
        goto p78
        ::p74::
        slot_2 = slot_1["hotkey"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["override"]
        slot_2(slot_3)
        goto p25
        ::p78::
        do
            return 
        end
    end
end
