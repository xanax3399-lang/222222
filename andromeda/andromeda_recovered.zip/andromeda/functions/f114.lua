-- Recovered function f114; author names are unavailable.
F.f114 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f114")
        tick(1)
        goto p66
        ::p3::
        tick(3)
        do
            return registers[5]
        end
        ::p6::
        tick(6)
        registers[8] = (8)
        registers[6] = registers[6](registers[7], registers[8])
        registers[5] = registers[5] + registers[6]
        goto p3
        ::p20::
        tick(20)
        registers[4] = (4)
        m, x = pack_returns(registers[1](unpack_range(4, registers, 2)))
        z = 0
        for f = 1, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = upvalues[2]
        registers[6] = registers[4]
        registers[7] = (64)
        registers[5] = registers[5](registers[6], registers[7])
        goto p83
        ::p38::
        tick(38)
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 256)
        a = registers
        z = 5
        q = registers
        q = q[5]
        m = registers
        x = 6
        m = m[x]
        q = q + m
        a[z] = q
        registers[6] = upvalues[2]
        registers[7] = registers[1]
        goto p6
        ::p66::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]
        registers[3] = (1)
        goto p20
        ::p83::
        registers[5] = (registers[5] * 16777216)
        registers[6] = upvalues[2]
        registers[7] = registers[3]
        a = registers
        z = 8;
        a[z] = 32
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 65536)
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[2]
        goto p38
    end
end
