-- Recovered function f200; author names are unavailable.
F.f200 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f200")
        tick(1)
        goto p78
        ::p9::
        tick(9)
        if not (0 < registers[3]) then
            goto p88
        end
        goto p43
        ::p11::
        tick(11)
        if not (10 < registers[2]) then
            goto p73
        end
        goto p83
        ::p13::
        tick(13)
        registers[3] = environment["tonumber"]
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["match"]
        registers[6] = "(%d+%.?%d*)"
        m, x = pack_returns(registers[4](unpack_range(6, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] == registers[0] then
            goto p88
        end
        goto p9
        ::p43::
        registers[4] = upvalues[1]["clamp"]
        registers[5] = (registers[3] * 0.01)
        registers[6] = (0.5)
        registers[7] = (2)
        do
            return registers[(4)](unpack_range(7, registers, 5))
        end
        ::p56::
        tick(56)
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = environment["type"]
        goto p66
        ::p61::
        tick(61)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["dpi"]
        ::p63::
        tick(63)
        if registers[1] ~= registers[0] then
            goto p56
        end
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p66::
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "number" then
            goto p90
        end
        goto p11
        ::p73::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = registers[2]
        registers[5] = (0.5)
        registers[6] = (2)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p78::
        registers[1] = upvalues[0]["visuals"]
        if not registers[1] then
            goto p63
        end
        goto p61
        ::p83::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = (registers[2] * 0.01)
        registers[5] = (0.5)
        registers[6] = (2)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p88::
        tick(88)
        registers[3] = (1)
        do
            return registers[3]
        end
        ::p90::
        registers[3] = environment["type"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "string" then
            goto p88
        end
        goto p13
    end
end
