-- Recovered function f323; author names are unavailable.
F.f323 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f323")
        tick(1)
        goto p39
        ::p2::
        tick(2);
        slot_2 = slot_2(slot_3)
        if slot_2 then
            goto p35
        end
        goto p22
        ::p9::
        tick(9)
        z = slot_2
        slot_5 = z;
        slot_4 = z["get_sequence_activity"]
        slot_6 = slot_3["sequence"]
        slot_4 = slot_4(slot_5, slot_6)
        goto p68
        ::p22::
        tick(22)
        slot_3 = -1
        do
            return slot_3
        end
        ::p35::
        z = slot_2
        slot_4 = z;
        slot_3 = z["get_anim_overlay"]
        slot_5 = (1)
        slot_3 = slot_3(slot_4, slot_5)
        goto p71
        ::p39::
        tick(39)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1
        goto p2
        ::p57::
        tick(57)
        slot_5 = -1
        do
            return slot_5
        end
        ::p60::
        tick(60)
        slot_5 = slot_3["cycle"]
        do
            return slot_5
        end
        ::p62::
        tick(62)
        slot_5 = slot_3["weight"]
        branch_taken = false
        if slot_5 ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p57
        end
        goto p60
        ::p65::
        tick(65)
        slot_4 = -1
        do
            return slot_4
        end
        ::p68::
        if slot_4 ~= 967 then
            goto p57
        end
        goto p62
        ::p71::
        if slot_3 then
            goto p9
        end
        goto p65
    end
end
