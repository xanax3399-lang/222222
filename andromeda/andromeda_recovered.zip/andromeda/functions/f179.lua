-- Recovered function f179; author names are unavailable.
F.f179 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local tick = new_tick("f179")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = (slot_1 >= 0)
        if not slot_2 then
            goto p7
        end
        goto p14
        ::p7::
        tick(7)
        if slot_2 then
            goto p18
        end
        slot_2 = upvalues[0][144]
        slot_3 = (slot_1 - 0.5);
        slot_2 = slot_2(slot_3)
        goto p18
        ::p14::
        slot_2 = upvalues[0][154]
        slot_3 = slot_1 + 0.5;
        slot_2 = slot_2(slot_3)
        goto p7
        ::p18::
        do
            return slot_2
        end
    end
end
