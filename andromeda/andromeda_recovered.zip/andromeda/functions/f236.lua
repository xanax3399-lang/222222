-- Recovered function f236; author names are unavailable.
F.f236 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2 = nil, nil, nil
        local z = nil
        local tick = new_tick("f236")
        tick(1)
        goto p76
        ::p16::
        tick(16)
        if not slot_1 then
            goto p46
        end
        goto p64
        ::p34::
        tick(34)
        slot_1 = (slot_1 ~= slot_0)
        goto p46
        ::p37::
        tick(37);
        slot_1 = slot_1(slot_2)
        slot_1 = (slot_1 == true)
        goto p75
        ::p46::
        if not slot_1 then
            goto p75
        end
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["hitchance"]
        slot_1 = slot_1["enabled"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"]
        goto p37
        ::p64::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["hitchance"]
        slot_1 = slot_1["enabled"]
        goto p34
        ::p70::
        tick(70)
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["hitchance"]
        slot_1 = (slot_1 ~= slot_0)
        goto p16
        ::p75::
        do
            return slot_1
        end
        ::p76::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p16
        end
        goto p70
    end
end
