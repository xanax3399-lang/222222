-- Recovered function f185; author names are unavailable.
F.f185 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f185")
        tick(1)
        goto p81
        ::p2::
        tick(2)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[4] = z;
            registers[5] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p4
        end
        goto p84
        ::p4::
        registers[6] = upvalues[3][110]
        registers[7] = upvalues[1]
        registers[8] = registers[5]["type"];
        registers[6](registers[7], registers[8])
        registers[6] = upvalues[3][110]
        registers[7] = upvalues[0]
        registers[8] = environment["unpack"]
        registers[9] = registers[5]["value"]
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[6](unpack_range(top, registers, 7))
        registers[1][registers[4]] = registers[0]
        goto p2
        ::p16::
        tick(16)
        registers[1] = upvalues[0]
        registers[1] = upvalues[2][registers[1]]
        if registers[1] ~= registers[0] then
            goto p20
        end
        goto p27
        ::p20::
        registers[2] = upvalues[3][120]
        registers[3] = upvalues[1];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = environment["pairs"]
        registers[4] = registers[1]
        goto p76
        ::p27::
        do
            return 
        end
        ::p28::
        tick(28)
        do
            return 
        end
        ::p76::
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        z = 0
        for f = 3, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(3)]
        n = registers[4]
        U = registers[5]
        goto p2
        ::p78::
        tick(78)
        registers[2] = upvalues[1]
        if registers[2] ~= registers[0] then
            goto p16
        end
        goto p28
        ::p81::
        registers[1] = upvalues[0]
        if registers[1] == registers[0] then
            goto p28
        end
        goto p78
        ::p84::
        tick(84)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[3] = upvalues[3][110]
        registers[4] = upvalues[1]
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        registers[3] = upvalues[0]
        upvalues[2][registers[3]] = registers[0]
        do
            return 
        end
    end
end
