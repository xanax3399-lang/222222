-- Recovered function f343; author names are unavailable.
F.f343 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f343")
        tick(1)
        goto p99
        ::p2::
        tick(2)
        registers[8] = registers[6]["builder_type"]
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        registers[8] = (registers[8] == "Hidden")
        goto p16
        ::p7::
        tick(7)
        registers[5] = (0)
        registers[6] = registers[2]["yaw"]
        registers[7] = registers[6]
        if not registers[7] then
            goto p201
        end
        goto p171
        ::p12::
        tick(12)
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        z = registers[1]
        registers[13] = z;
        registers[(12)] = z["is_left_side"]
        goto p222
        ::p16::
        tick(16)
        if not registers[8] then
            goto p207
        end
        goto p161
        ::p18::
        tick(18)
        registers[4] = registers[3]["left"]
        registers[4] = registers[4] > 0
        goto p84
        ::p21::
        tick(21)
        if not registers[4] then
            goto p23
        end
        goto p173
        ::p23::
        tick(23)
        if not registers[4] then
            goto p84
        end
        goto p18
        ::p63::
        tick(63)
        a = upvalues[4];
        registers[17] = a[2][a[1]]["current"]
        registers[17] = upvalues[3][registers[17]]
        registers[18] = registers[12]
        goto p102
        ::p68::
        tick(68)
        do
            return 
        end
        ::p69::
        tick(69)
        registers[10] = registers[9]["builder_type"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        registers[10] = (registers[10] == "Hidden")
        goto p86
        ::p82::
        tick(82)
        if registers[8] then
            goto p136
        end
        goto p134
        ::p84::
        if registers[4] then
            goto p7
        end
        goto p182
        ::p86::
        tick(86)
        if not registers[10] then
            goto p116
        end
        goto p108
        ::p88::
        tick(88)
        registers[9] = registers[7]["type"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] ~= "Static" then
            goto p118
        end
        goto p144
        ::p99::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[2] ~= registers[0] then
            goto p105
        end
        goto p181
        ::p102::;
        registers[13] = registers[13](unpack_range(18, registers, 14))
        registers[5] = registers[5] + registers[13]
        goto p207
        ::p105::
        registers[3] = upvalues[0]["switch_type"]
        if registers[3] == registers[0] then
            goto p155
        end
        goto p176
        ::p108::
        z = registers[1]
        registers[12] = z;
        registers[(11)] = z["get_yaw_modifier_add"]
        registers[13] = registers[9]["hidden"]
        registers[11] = registers[11](registers[12], registers[13])
        registers[5] = registers[5] + registers[11]
        goto p116
        ::p113::
        tick(113)
        if registers[13] then
            goto p204
        end
        goto p159
        ::p116::
        if registers[5] ~= 0 then
            goto p136
        end
        goto p82
        ::p118::
        registers[10] = registers[7]["left"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = registers[7]["right"]
        goto p12
        ::p125::
        tick(125);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[11]["add"] = registers[12]
        do
            return 
        end
        ::p134::
        do
            return 
        end
        ::p136::
        registers[11] = registers[1]["pitch"]
        registers[11]["type"] = "Custom"
        registers[11] = registers[1]["pitch"]
        registers[11]["value"] = 89
        registers[11] = registers[1]["yaw"]
        registers[12] = upvalues[5]["normalize"]
        registers[13] = registers[1]["yaw"]
        goto p213
        ::p144::
        registers[10] = registers[7]["static"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        registers[5] = registers[10]
        goto p207
        ::p149::
        tick(149)
        registers[13] = upvalues[2]
        registers[14] = registers[10]
        registers[15] = registers[11]
        registers[16] = (13)
        goto p63
        ::p155::
        tick(155)
        a = upvalues[1];
        registers[3] = a[2][a[1]]["exploits"]
        registers[3] = registers[3]["defensive"]
        registers[4] = registers[1]["force_defensive_active"]
        goto p21
        ::p159::
        registers[13] = registers[11]
        goto p204
        ::p161::
        if registers[7] == registers[0] then
            goto p207
        end
        goto p88
        ::p171::
        registers[7] = registers[6]["hidden"]
        goto p201
        ::p173::
        tick(173)
        registers[4] = (registers[3] ~= registers[0])
        goto p23
        ::p176::
        registers[4] = upvalues[0]["switch_type"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= "Defensive" then
            goto p155
        end
        goto p68
        ::p181::
        do
            return 
        end
        ::p182::
        do
            return 
        end
        ::p201::
        registers[8] = (registers[6] ~= registers[0])
        if not registers[8] then
            goto p16
        end
        goto p2
        ::p204::
        registers[5] = registers[13]
        if registers[9] ~= "Side Reworked" then
            goto p207
        end
        goto p149
        ::p207::
        registers[9] = registers[2]["yaw_modifiers"]
        registers[10] = (registers[9] ~= registers[0])
        if not registers[10] then
            goto p86
        end
        goto p69
        ::p211::
        tick(211)
        registers[13] = registers[10]
        goto p113
        ::p213::
        registers[13] = registers[13]["add"]
        registers[13] = registers[13] + registers[5]
        registers[14] = -180
        registers[15] = (180)
        goto p125
        ::p222::;
        registers[(12)] = registers[(12)](registers[13])
        registers[13] = registers[12]
        if not registers[13] then
            goto p113
        end
        goto p211
    end
end
