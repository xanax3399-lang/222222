-- Recovered function f347; author names are unavailable.
F.f347 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f347")
        tick(1)
        slot_1 = upvalues[0]["quit_requested"]
        slot_1 = (slot_1 == true)
        do
            return slot_1
        end
    end
end
