-- Recovered function f153; author names are unavailable.
F.f153 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f153")
        tick(1)
        goto p85
        ::p2::
        tick(2)
        registers[9] = registers[1]
        registers[10] = registers[2]
        registers[11] = registers[4]
        registers[12] = registers[5]
        goto p132
        ::p7::
        tick(7)
        registers[(8)](unpack_range(17, registers, 9))
        registers[8] = upvalues[0][130]
        registers[9] = registers[1]
        registers[10] = registers[2]
        goto p158
        ::p20::
        tick(20)
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        registers[15] = (registers[7] * 0.065)
        goto p66
        ::p39::
        tick(39)
        registers[15] = (registers[7] * 0.105)
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        goto p163
        ::p43::
        tick(43)
        registers[(8)](unpack_range(17, registers, 9))
        do
            return 
        end
        ::p54::
        tick(54)
        registers[8] = upvalues[0][130]
        registers[9] = registers[1]
        registers[10] = registers[2]
        registers[11] = registers[4]
        registers[12] = registers[5]
        goto p109
        ::p66::
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        registers[15] = (10)
        registers[16] = (0)
        registers[17] = (1)
        goto p7
        ::p81::
        tick(81)
        registers[9] = registers[1]
        registers[10] = registers[2]
        registers[11] = registers[4]
        goto p20
        ::p85::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = registers[3][1]
        registers[5] = registers[3][2]
        registers[6] = registers[3][3]
        registers[7] = registers[3][4]
        registers[8] = upvalues[0][130]
        registers[9] = registers[1]
        registers[10] = registers[2]
        registers[11] = registers[4]
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        goto p138
        ::p98::
        tick(98);
        registers[(14)] = registers[(14)](registers[15])
        registers[15] = (3)
        registers[16] = (0)
        registers[17] = (1)
        goto p43
        ::p109::
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        registers[15] = (registers[7] * 0.04)
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        registers[15] = (13)
        registers[16] = (0)
        registers[17] = (1)
        registers[(8)](unpack_range(17, registers, 9))
        registers[8] = upvalues[0][130]
        goto p81
        ::p120::
        tick(120)
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        registers[15] = (registers[7] * 0.175)
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        registers[15] = (5)
        registers[16] = (0)
        registers[17] = (1)
        registers[(8)](unpack_range(17, registers, 9))
        registers[8] = upvalues[0][130]
        goto p2
        ::p132::
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        registers[15] = (registers[7] * 0.28)
        registers[15] = registers[15] + 0.5
        goto p98
        ::p138::
        registers[15] = (registers[7] * 0.024)
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        goto p177
        ::p142::
        tick(142)
        registers[(8)](unpack_range(17, registers, 9))
        registers[8] = upvalues[0][130]
        registers[9] = registers[1]
        registers[10] = registers[2]
        registers[11] = registers[4]
        goto p120
        ::p158::
        registers[11] = registers[4]
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[14] = upvalues[0][154]
        goto p39
        ::p163::
        registers[15] = (7)
        registers[16] = (0)
        registers[17] = (1)
        goto p142
        ::p177::
        registers[15] = (16)
        registers[16] = (0)
        registers[17] = (1)
        registers[(8)](unpack_range(17, registers, 9))
        goto p54
    end
end
