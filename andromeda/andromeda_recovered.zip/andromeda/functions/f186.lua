-- Recovered function f186; author names are unavailable.
F.f186 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1 = nil, nil
        local tick = new_tick("f186")
        tick(1)
        slot_1 = upvalues[0]["unset_hitchance"]
        slot_1()
        upvalues[0]["active"] = false
        upvalues[0]["hotkey_active"] = false
        upvalues[0]["updated_this_tick"] = false
        upvalues[0]["indicator_value"] = slot_0
        do
            return 
        end
    end
end
