-- Recovered function f178; author names are unavailable.
F.f178 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f178")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0][151]
        registers[5] = registers[2]
        registers[6] = upvalues[0][162]
        registers[7] = registers[1]
        registers[8] = registers[3]
        m, x = pack_returns(registers[6](unpack_range(8, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[4](unpack_range(top, registers, 5))
        end
    end
end
