-- Recovered function f420; author names are unavailable.
F.f420 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f420")
        tick(1)
        goto p83
        ::p2::
        tick(2)
        do
            return registers[5]
        end
        ::p4::
        tick(4)
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        a = registers
        z = 5
        q = registers
        q = q[4]
        m = registers
        x = 4
        m = m[x]
        q = q + m
        a[z] = q
        registers[5] = registers[1] % registers[5]
        registers[5] = (registers[5] >= registers[4])
        goto p37
        ::p13::
        tick(13)
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        registers[4] = (registers[1] / registers[4])
        a = registers
        z = 5
        q = registers
        q = q[3]
        m = 1
        q = q - m;
        a[z] = q
        registers[6] = (registers[2] - 1)
        registers[5] = (registers[5] - registers[6])
        registers[5] = registers[5] + 1
        registers[5] = 2 ^ registers[5]
        goto p40
        ::p34::
        tick(34)
        registers[5] = (0)
        goto p89
        ::p37::
        if not registers[5] then
            goto p90
        end
        goto p86
        ::p40::
        registers[4] = registers[4] % registers[5]
        registers[5] = registers[4] % 1
        registers[5] = (registers[4] - registers[5])
        goto p2
        ::p83::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if not registers[3] then
            goto p4
        end
        goto p13
        ::p86::
        a = registers
        z = 5;
        a[z] = 1
        goto p90
        ::p89::
        tick(89)
        do
            return registers[5]
        end
        ::p90::
        if registers[5] then
            goto p89
        end
        goto p34
    end
end
