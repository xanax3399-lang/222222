-- Recovered function f432; author names are unavailable.
F.f432 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local tick = new_tick("f432")
        tick(1)
        registers[1] = {
        }
        registers[2] = {
        }
        registers[3] = upvalues[0]["get"];
        registers[3] = registers[3]()
        registers[4] = upvalues[1]
        registers[5] = registers[1]
        registers[6] = registers[2]
        registers[7] = registers[3]
        registers[(4)](unpack_range(7, registers, 5))
        registers[4] = environment["table"]
        goto p71
        ::p59::
        tick(59);
        registers[4](registers[5], registers[6])
        registers[4] = registers[1]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[4]
        end
        ::p71::
        registers[4] = registers[4]["sort"]
        registers[5] = registers[1]
        a = D.f433
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p59
    end
end
