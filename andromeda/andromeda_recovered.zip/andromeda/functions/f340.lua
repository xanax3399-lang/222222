-- Recovered function f340; author names are unavailable.
F.f340 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f340")
        tick(1)
        goto p50
        ::p16::
        tick(16)
        slot_4 = slot_3 == slot_0
        goto p102
        ::p31::
        tick(31)
        slot_4 = upvalues[0][95]
        goto p74
        ::p50::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = slot_3
        if slot_4 then
            goto p102
        end
        goto p16
        ::p56::
        tick(56)
        if slot_4 then
            goto p74
        end
        goto p31
        ::p74::
        slot_5 = slot_4
        slot_6 = slot_1
        slot_7 = slot_2;
        slot_5(slot_6, slot_7)
        do
            return 
        end
        ::p100::
        tick(100)
        slot_4 = upvalues[0][56]
        goto p56
        ::p102::
        if not slot_4 then
            goto p56
        end
        goto p100
    end
end
