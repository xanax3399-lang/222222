-- Recovered function f211; author names are unavailable.
F.f211 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local tick = new_tick("f211")
        tick(1)
        goto p56
        ::p3::
        tick(3)
        slot_2 = upvalues[2][30];
        slot_2 = slot_2()
        a = upvalues[1];
        slot_3 = a[2][a[1]]
        slot_2 = slot_2 < slot_3
        goto p51
        ::p11::
        tick(11)
        slot_2 = upvalues[2][30];
        slot_2 = slot_2()
        slot_2 = slot_2 + 0.12
        a = upvalues[1]
        a[2][a[1]] = slot_2
        slot_2 = (true)
        goto p52
        ::p51::
        do
            return slot_2
        end
        ::p52::
        do
            return slot_2
        end
        ::p53::
        tick(53);
        slot_2 = slot_2(slot_3)
        if not slot_2 then
            goto p3
        end
        goto p11
        ::p56::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1
        goto p53
    end
end
