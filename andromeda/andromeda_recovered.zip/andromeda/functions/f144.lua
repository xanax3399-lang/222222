-- Recovered function f144; author names are unavailable.
F.f144 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local z = nil
        local tick = new_tick("f144")
        tick(1)
        goto p3
        ::p2::
        tick(2)
        do
            return 
        end
        ::p3::
        slot_1 = upvalues[0]["update_callbacks"]
        slot_2 = upvalues[1]["ragebot"]
        slot_2 = slot_2["enemy_resolver"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == true)
        slot_1(slot_2)
        goto p2
    end
end
