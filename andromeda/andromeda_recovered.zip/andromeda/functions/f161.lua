-- Recovered function f161; author names are unavailable.
F.f161 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f161")
        tick(1)
        goto p35
        ::p3::
        tick(3)
        do
            return registers[1]
        end
        ::p13::
        tick(13)
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        goto p3
        ::p19::
        tick(19)
        registers[1] = upvalues[0]["ragebot"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q["quickpeek"]
        a[z] = q
        registers[1] = registers[1][1]
        registers[1] = registers[1]["hotkey"]
        goto p13
        ::p35::
        registers[1] = upvalues[0]["ragebot"]
        registers[1] = registers[1]["quickpeek"]
        registers[1] = registers[1][1]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if not registers[1] then
            goto p3
        end
        goto p19
    end
end
