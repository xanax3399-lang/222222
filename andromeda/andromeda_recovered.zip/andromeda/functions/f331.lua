-- Recovered function f331; author names are unavailable.
F.f331 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f331")
        tick(1)
        registers[1] = upvalues[0]["update_callbacks"]
        registers[2] = upvalues[1]
        m, x = pack_returns(registers[2]())
        m = m + 2 - 1
        top = m
        z = 0
        for f = 2, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p14
        end
        registers[1] = upvalues[0]["reset"]
        registers[(1)]()
        ::p14::
        do
            return 
        end
    end
end
