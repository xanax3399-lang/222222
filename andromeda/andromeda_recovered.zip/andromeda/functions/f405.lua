-- Recovered function f405; author names are unavailable.
F.f405 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f405")
        tick(1)
        goto p72
        ::p2::
        tick(2)
        if registers[2] then
            goto p10
        end
        goto p69
        ::p10::
        tick(10)
        if registers[2] ~= registers[0] then
            goto p59
        end
        goto p34
        ::p23::
        tick(23)
        registers[1] = nil
        goto p63
        ::p26::
        tick(26)
        registers[5] = (110)
        goto p47
        ::p34::
        registers[3] = (110)
        do
            return registers[3]
        end
        ::p39::
        tick(39);
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p47
        end
        goto p26
        ::p42::
        tick(42)
        registers[6] = (255)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p47::
        registers[5] = registers[5] + 0.5;
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = (0)
        goto p42
        ::p59::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = upvalues[2][154]
        z = registers[2]
        registers[6] = z;
        registers[(5)] = z["get"]
        goto p39
        ::p63::
        tick(63)
        registers[2] = (registers[1] ~= registers[0])
        if not registers[2] then
            goto p2
        end
        goto p116
        ::p66::
        tick(66)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["stubs"]
        goto p88
        ::p69::
        registers[2] = nil
        goto p10
        ::p72::
        registers[1] = upvalues[0]["visuals"]
        registers[1] = (registers[1] ~= registers[0])
        if not registers[1] then
            goto p88
        end
        goto p66
        ::p88::
        if registers[1] then
            goto p63
        end
        goto p23
        ::p116::
        registers[2] = registers[1]["native_indicators_gradient"]
        goto p2
    end
end
