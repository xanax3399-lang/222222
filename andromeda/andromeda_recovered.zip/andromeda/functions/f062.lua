-- Recovered function f62; author names are unavailable.
F.f62 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local tick = new_tick("f62")
        tick(1)
        goto p21
        ::p7::
        tick(7)
        registers[3] = registers[1]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[3]
        end
        ::p9::
        tick(9)
        a = D.f63
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[(3)](registers[4])
        if registers[2] then
            goto p7
        end
        registers[3] = upvalues[1]
        registers[4] = {
        }
        registers[5] = upvalues[2]["MAGIC_SUM_CHECK_FAILED"]
        registers[4]["ban_num"] = registers[5]
        registers[4]["ban_info"] = "[MGC][0x01]"
        goto p83
        ::p21::
        tick(21)
        registers[1] = (1)
        registers[2] = (false)
        registers[3] = environment["pcall"]
        goto p9
        ::p83::
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[(3)](registers[4])
        end
    end
end
