-- Recovered function f261; author names are unavailable.
F.f261 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local z = nil
        local tick = new_tick("f261")
        tick(1)
        goto p35
        ::p10::
        tick(10)
        slot_2 = (slot_1 == "Defensive")
        do
            return slot_2
        end
        ::p35::
        slot_1 = upvalues[0]["switch_type"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= "number" then
            goto p10
        end
        slot_2 = (slot_1 == 2)
        do
            return slot_2
        end
    end
end
