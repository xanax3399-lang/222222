-- Recovered function f154; author names are unavailable.
F.f154 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f154")
        tick(1)
        goto p38
        ::p2::
        tick(2)
        registers[8] = registers[6]
        do
            return unpack_range(8, registers, (7))
        end
        ::p4::
        tick(4);
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = environment["tostring"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = ":"..registers[4]
        goto p33
        ::p30::
        tick(30)
        registers[5] = registers[4][1]
        registers[6] = registers[4][2]
        do
            return unpack_range(6, registers, (5))
        end
        ::p33::
        registers[3] = (registers[3]..registers[4])
        registers[4] = upvalues[0][registers[3]]
        if registers[4] == registers[0] then
            goto p72
        end
        goto p30
        ::p38::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = environment["tostring"]
        registers[4] = registers[1]
        goto p4
        ::p72::
        registers[5] = upvalues[1][136]
        registers[6] = registers[1]
        registers[7] = registers[2]
        m, x = pack_returns(registers[5](unpack_range(7, registers, 6)))
        z = 0
        for f = 5, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = new_frame(2)
        registers[8] = registers[5]
        registers[9] = registers[6]
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        upvalues[0][registers[3]] = registers[7]
        registers[7] = registers[5]
        goto p2
    end
end
