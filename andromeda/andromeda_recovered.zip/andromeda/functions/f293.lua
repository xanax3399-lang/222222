-- Recovered function f293; author names are unavailable.
F.f293 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f293")
        tick(1)
        goto p73
        ::p8::
        tick(8)
        do
            return 
        end
        ::p9::
        tick(9)
        registers[2] = upvalues[1][141]
        registers[3] = registers[1]
        registers[4] = "Override prefer body aim"
        goto p24
        ::p13::
        tick(13)
        registers[2] = upvalues[1][141]
        registers[3] = registers[1]
        registers[4] = "Force body yaw"
        registers[5] = (false)
        registers[(2)](unpack_range(5, registers, 3))
        goto p39
        ::p24::
        registers[5] = "-"
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[0]["applied_body"]
        registers[2][registers[1]] = registers[0]
        goto p8
        ::p39::
        registers[2] = upvalues[1][141]
        registers[3] = registers[1]
        registers[4] = "Force body yaw value"
        registers[5] = (0)
        goto p77
        ::p61::
        tick(61)
        if not registers[2] then
            goto p103
        end
        goto p13
        ::p73::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["applied"]
        registers[2] = registers[2][registers[1]]
        goto p61
        ::p77::
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[0]["applied"]
        registers[2][registers[1]] = registers[0]
        ::p103::
        registers[2] = upvalues[0]["applied_body"]
        registers[2] = registers[2][registers[1]]
        if not registers[2] then
            goto p8
        end
        goto p9
    end
end
