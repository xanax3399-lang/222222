-- Recovered function f92; author names are unavailable.
F.f92 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f92")
        tick(1)
        slot_1 = upvalues[0]
        do
            return slot_1()
        end
    end
end
