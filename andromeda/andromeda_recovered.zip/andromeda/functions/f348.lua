-- Recovered function f348; author names are unavailable.
F.f348 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2 = nil, nil, nil
        local z = nil
        local tick = new_tick("f348")
        tick(1)
        goto p8
        ::p3::
        tick(3)
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["fast_ladder"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        goto p32
        ::p8::
        slot_1 = upvalues[0]["visuals"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p34
        end
        goto p48
        ::p32::
        tick(32)
        do
            return slot_1
        end
        ::p34::
        tick(34)
        if not slot_1 then
            goto p32
        end
        goto p3
        ::p48::
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["fast_ladder"]
        slot_1 = (slot_1 ~= slot_0)
        goto p34
    end
end
