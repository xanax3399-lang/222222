-- Recovered function f46; author names are unavailable.
F.f46 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f46")
        tick(1)
        goto p74
        ::p18::
        tick(18)
        registers[5] = registers[1]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        a = registers
        z = (1)
        a = a[z]
        z = "signature"
        q = registers
        m = 2
        q = q[m]
        a[z] = q
        goto p57
        ::p42::
        tick(42)
        registers[1]["info"] = registers[2]
        registers[2] = upvalues[1]["hmac_sha256"]
        registers[3] = upvalues[2]
        registers[4] = environment["json"]
        registers[4] = registers[4]["stringify"]
        goto p18
        ::p57::
        registers[2] = environment["database"]
        a = registers
        z = (2)
        q = registers
        q = q[2]
        q = q["write"]
        a[z] = q
        registers[3] = "grenade_helper_store_v1"
        registers[4] = registers[1];
        registers[2](registers[3], registers[4])
        do
            return 
        end
        ::p74::
        registers[1] = {
        }
        registers[2] = environment["client"]
        registers[2] = registers[2]["unix_time"];
        registers[2] = registers[2]()
        registers[1]["timestamp"] = registers[2]
        registers[1]["script"] = "Andromeda Exclusive"
        a = registers
        z = 2
        q = upvalues
        q = q[0]
        a[z] = q
        goto p42
    end
end
