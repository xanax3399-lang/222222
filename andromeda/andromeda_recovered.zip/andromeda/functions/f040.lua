-- Recovered function f40; author names are unavailable.
F.f40 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f40")
        tick(1)
        goto p99
        ::p11::
        tick(11)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        a = registers
        z = (5)
        q = environment
        q = q["table"]
        a[z] = q
        registers[5] = registers[5]["concat"]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = environment["string"]
        registers[6] = registers[6]["rep"]
        goto p51
        ::p21::
        tick(21)
        registers[23] = constant_cache[7]
        registers[24] = "\2467";
        registers[(23)] = registers[(23)](registers[24])
        ::p25::
        tick(25)
        registers[23] = registers[23] + 506
        registers[23] = 7910 + registers[23]
        registers[23] = registers[23] + -8526
        registers[20][88] = registers[23]
        registers[22][2] = 104
        a = (15)
        z = 26
        for f = a, z do
            q = registers
            m = f
            f = nil;
            q[m] = f
        end
        goto p105
        ::p45::
        tick(45)
        registers[6] = registers[6](registers[7], registers[8])
        registers[5] = (registers[5]..registers[6])
        do
            return registers[5]
        end
        ::p51::
        registers[7] = upvalues[0][registers[2]]
        registers[8] = (#registers[1])
        registers[8] = (registers[3] - registers[8])
        goto p45
        ::p55::
        tick(55)
        registers[7] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p105
        if registers[23] then
            goto p25
        end
        goto p21
        ::p76::
        tick(76)
        registers[9] = environment["bit"]
        registers[9] = registers[9]["bxor"]
        registers[10] = registers[2]
        registers[11] = upvalues[1]
        registers[12] = registers[1]
        registers[13] = registers[8]
        registers[14] = registers[8]
        m, x = pack_returns(registers[11](unpack_range(14, registers, 12)))
        m = m + 11 - 1
        top = m
        z = 0
        for f = 11, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[9] = registers[9](unpack_range(top, registers, 10))
        a = registers
        z = 9
        q = upvalues
        m = (0)
        q = q[m]
        m = registers
        m = m[9]
        q = q[m]
        a[z] = q
        registers[4][registers[8]] = registers[9]
        goto p105
        ::p99::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = {
        }
        registers[5] = (1)
        registers[6] = (#registers[1])
        goto p55
        ::p105::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p76
        end
        goto p11
    end
end
