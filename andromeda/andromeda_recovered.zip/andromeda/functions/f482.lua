-- Recovered function f482; author names are unavailable.
F.f482 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f482")
        tick(1)
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p18
        end
        goto p29
        ::p18::
        tick(18)
        if slot_1 then
            goto p60
        end
        goto p33
        ::p29::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["hold_aim_ticks"]
        goto p18
        ::p33::
        slot_1 = nil
        ::p60::
        slot_2 = upvalues[1]["apply"]
        slot_3 = (slot_1 ~= slot_0)
        if not slot_3 then
            goto p78
        end
        goto p85
        ::p78::
        tick(78)
        slot_2(slot_3)
        do
            return 
        end
        ::p85::
        z = slot_1
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        slot_3 = (slot_3 == true)
        goto p78
    end
end
