-- Recovered function f367; author names are unavailable.
F.f367 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f367")
        tick(1)
        goto p45
        ::p19::
        tick(19)
        registers[5] = registers[2]["slots"]
        registers[5] = registers[5][registers[4]]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        goto p92
        ::p24::
        tick(24)
        registers[2] = upvalues[0]["custom"]
        registers[3] = upvalues[1][151]
        registers[4] = (2)
        registers[5] = upvalues[1][162]
        registers[6] = (10)
        registers[7] = upvalues[1][154]
        registers[8] = registers[2]["count"]
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"]
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[7](unpack_range(top, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[5](unpack_range(top, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        registers[4] = upvalues[2]["inverts"]
        registers[4] = registers[4] % registers[3]
        registers[4] = registers[4] + 1
        goto p19
        ::p40::
        tick(40)
        registers[2] = upvalues[0]["left"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        goto p50
        ::p45::
        registers[1] = upvalues[0]["values"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] ~= "Double" then
            goto p83
        end
        goto p40
        ::p50::
        registers[3] = upvalues[0]["right"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = (2)
        goto p58
        ::p55::
        tick(55)
        do
            return unpack_range(8, registers, (6))
        end
        ::p56::
        tick(56)
        registers[5] = (1)
        do
            return unpack_range(5, registers, (3))
        end
        ::p58::
        do
            return unpack_range(4, registers, (2))
        end
        ::p83::
        if registers[1] ~= "Custom" then
            goto p86
        end
        goto p24
        ::p86::
        registers[2] = upvalues[0]["offset"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = registers[2]
        registers[4] = registers[2]
        goto p56
        ::p92::
        registers[6] = registers[5]
        registers[7] = registers[5]
        registers[8] = registers[4]
        goto p55
    end
end
