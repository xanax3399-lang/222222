-- Recovered function f138; author names are unavailable.
F.f138 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f138")
        tick(1)
        goto p56
        ::p3::
        tick(3)
        a = upvalues[0];
        slot_2 = a[2][a[1]]
        if slot_2 == slot_0 then
            goto p25
        end
        a = upvalues[0]
        slot_3 = a[2][a[1]][slot_1]
        if slot_3 then
            goto p25
        end
        do
            return 
        end
        ::p25::
        slot_2 = upvalues[1]
        slot_2 = (#slot_2)
        slot_2 = slot_2 + 1
        goto p62
        ::p56::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        branch_taken = false
        if slot_2 ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p3
        end
        goto p64
        ::p62::
        upvalues[1][slot_2] = slot_1
        do
            return 
        end
        ::p64::
        do
            return 
        end
    end
end
