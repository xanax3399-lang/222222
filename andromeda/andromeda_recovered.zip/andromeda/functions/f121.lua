-- Recovered function f121; author names are unavailable.
F.f121 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f121")
        tick(1)
        goto p98
        ::p2::
        tick(2)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p134
        end
        goto p63
        ::p4::
        tick(4)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        ::p7::
        tick(7)
        registers[5] = {
        }
        registers[6] = (0)
        registers[7] = (255)
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p16
        ::p12::
        tick(12)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[1]
        registers[2] = upvalues[2]
        goto p182
        ::p16::
        tick(16)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p110
        end
        goto p53
        ::p19::
        tick(19)
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        goto p102
        ::p24::
        tick(24)
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        registers[17] = upvalues[0]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(15)]
        for f = 1, top - (15) do
            q[(0) + f] = registers[(15) + f]
        end
        registers[5][registers[14]] = registers[15]
        goto p2
        ::p32::
        tick(32)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p7
        end
        goto p12
        ::p46::
        tick(46)
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        a = registers
        z = 11
        q = upvalues
        q = q[1]
        a[z] = q
        goto p203
        ::p53::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[6] = (1)
        registers[7] = upvalues[0];
        registers[7] = registers[7]()
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p107
        ::p59::
        tick(59)
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        goto p46
        ::p63::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p107
        ::p65::
        tick(65)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[3]
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[16] = upvalues[0]
        m, x = pack_returns(registers[16]())
        m = m + 16 - 1
        top = m
        z = 0
        for f = 16, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[15] = new_frame(1)
        goto p24
        ::p74::
        tick(74)
        registers[15] = upvalues[1]
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        registers[17] = upvalues[2]
        goto p19
        ::p82::
        tick(82)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        if not registers[15] then
            goto p65
        end
        goto p140
        ::p93::
        tick(93)
        registers[10] = (0)
        a = registers
        z = 11;
        a[z] = 255
        registers[12] = (1)
        goto p158
        ::p98::
        tick(98)
        registers[1] = (1)
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        goto p126
        ::p102::
        tick(102)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p82
        ::p107::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p93
        end
        goto p4
        ::p110::
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        registers[10] = upvalues[1]
        goto p59
        ::p126::
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p32
        registers[29] = code_metadata
        registers[35] = operand_k
        registers[29][32] = 183
        registers[35][81] = 97
        registers[28] = nil
        registers[29] = nil
        registers[30] = nil
        registers[31] = nil
        registers[32] = nil
        registers[33] = nil
        registers[34] = nil
        registers[35] = nil
        goto p98
        ::p134::
        registers[14] = upvalues[2];
        registers[14] = registers[14]()
        if not registers[14] then
            goto p186
        end
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p186
        ::p140::
        a = registers
        z = 15
        q = upvalues
        q = q[2]
        a[z] = q;
        registers[15] = registers[15]()
        goto p65
        ::p158::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p2
        goto p7
        ::p182::;
        registers[2] = registers[2]()
        registers[3] = upvalues[0]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p186::
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[15] = registers[5][registers[15]]
        if registers[15] then
            goto p102
        end
        goto p74
        ::p203::
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p16
    end
end
