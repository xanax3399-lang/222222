-- Recovered function f433; author names are unavailable.
F.f433 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f433")
        tick(1)
        goto p5
        ::p2::
        tick(2)
        slot_3 = slot_3 > slot_4
        do
            return slot_3
        end
        ::p5::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (#slot_1)
        slot_4 = (#slot_2)
        goto p2
    end
end
