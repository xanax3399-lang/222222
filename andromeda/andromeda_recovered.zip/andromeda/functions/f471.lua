-- Recovered function f471; author names are unavailable.
F.f471 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f471")
        tick(1)
        goto p263
        ::p8::
        tick(8)
        registers[4] = registers[1]["attacker"]
        if registers[4] ~= registers[0] then
            goto p43
        end
        goto p236
        ::p18::
        tick(18)
        do
            return 
        end
        ::p19::
        tick(19)
        if registers[4] ~= registers[2] then
            goto p66
        end
        goto p98
        ::p43::
        registers[3] = upvalues[0][54]
        registers[4] = environment["tonumber"]
        registers[5] = registers[1]["userid"];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p88
        end
        goto p164
        ::p49::
        tick(49)
        if registers[9] then
            goto p258
        end
        goto p142
        ::p66::
        registers[5] = upvalues[0][154]
        registers[6] = environment["tonumber"]
        registers[7] = registers[1]["dmg_health"];
        registers[(6)] = registers[(6)](registers[7])
        goto p200
        ::p78::
        tick(78)
        registers[5] = registers[1]["attacker"]
        ::p79::
        tick(79);
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] == registers[0] then
            goto p98
        end
        goto p211
        ::p88::
        tick(88);
        registers[(3)] = registers[(3)](registers[4])
        if registers[2] == registers[0] then
            goto p155
        end
        goto p224
        ::p98::
        tick(98)
        do
            return 
        end
        ::p99::
        tick(99)
        q = registers[(11)]
        q[1] = registers[12]
        q[2] = registers[13]
        registers[12] = new_frame(2)
        registers[13] = registers[8]
        registers[14] = "got"
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        registers[13] = new_frame(2)
        goto p136
        ::p106::
        tick(106)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        registers[(9)](registers[10])
        do
            return 
        end
        ::p115::
        tick(115)
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        registers[3] = registers[1]["userid"]
        if registers[3] == registers[0] then
            goto p236
        end
        goto p8
        ::p120::
        tick(120)
        registers[16] = new_frame(2)
        registers[17] = environment["tostring"]
        registers[18] = registers[5];
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = "got"
        q = registers[(16)]
        q[1] = registers[17]
        q[2] = registers[18]
        registers[17] = new_frame(2)
        goto p146
        ::p128::
        tick(128)
        registers[16] = "got"
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        registers[15] = new_frame(2)
        registers[16] = " for "
        registers[17] = "text"
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        goto p120
        ::p136::
        registers[14] = " in the "
        registers[15] = "text"
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        registers[14] = new_frame(2)
        registers[15] = registers[7]
        goto p128
        ::p142::
        registers[9] = upvalues[1]["get_player_health"]
        registers[10] = registers[2];
        registers[(9)] = registers[(9)](registers[10])
        goto p258
        ::p146::
        registers[18] = " damage ("
        registers[19] = "text"
        q = registers[(17)]
        q[1] = registers[18]
        q[2] = registers[19]
        registers[18] = new_frame(2)
        registers[19] = environment["tostring"]
        registers[20] = registers[6];
        registers[(19)] = registers[(19)](registers[20])
        goto p166
        ::p155::
        tick(155)
        do
            return 
        end
        ::p164::
        registers[4] = registers[1]["userid"]
        goto p88
        ::p166::
        registers[20] = "got"
        q = registers[(18)]
        q[1] = registers[19]
        q[2] = registers[20]
        registers[19] = new_frame(2)
        goto p219
        ::p178::
        tick(178)
        registers[9] = upvalues[1]["push"]
        registers[10] = new_frame(9)
        registers[11] = new_frame(2)
        registers[12] = "Got Hit by "
        registers[13] = "text"
        goto p99
        ::p184::
        tick(184)
        registers[8] = registers[1]["hitgroup"];
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = upvalues[1]["get_player_name"]
        registers[9] = registers[4];
        registers[(8)] = registers[(8)](registers[9])
        goto p178
        ::p200::
        if registers[6] then
            goto p227
        end
        goto p232
        ::p211::
        branch_taken = false
        if registers[4] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p98
        end
        goto p19
        ::p213::
        tick(213)
        registers[4] = upvalues[0][54]
        registers[5] = environment["tonumber"]
        registers[6] = registers[1]["attacker"];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p79
        end
        goto p78
        ::p219::
        registers[20] = " health remaining)"
        registers[21] = "text"
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        goto p106
        ::p224::
        if registers[3] == registers[2] then
            goto p213
        end
        goto p155
        ::p227::
        tick(227)
        registers[6] = registers[6] + 0.5;
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[0][151]
        registers[7] = (0)
        goto p238
        ::p232::
        registers[6] = (0)
        goto p227
        ::p236::
        do
            return 
        end
        ::p238::
        registers[8] = upvalues[0][154]
        registers[9] = environment["tonumber"]
        registers[10] = registers[1]["health"];
        registers[(9)] = registers[(9)](registers[10])
        goto p49
        ::p258::
        registers[9] = registers[9] + 0.5
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[1]["get_hitgroup"]
        goto p184
        ::p263::
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] ~= registers[0] then
            goto p115
        end
        goto p18
    end
end
