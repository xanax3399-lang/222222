-- Recovered function f243; author names are unavailable.
F.f243 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f243")
        tick(1)
        goto p46
        ::p2::
        tick(2)
        slot_2 = (slot_1 ~= slot_0)
        if not slot_2 then
            goto p15
        end
        goto p6
        ::p5::
        tick(5)
        do
            return 
        end
        ::p6::
        slot_2 = slot_1["fakelag_exploit_tick"]
        goto p15
        ::p9::
        tick(9)
        slot_2 = nil
        goto p93
        ::p15::
        if slot_2 then
            goto p93
        end
        goto p9
        ::p19::
        tick(19)
        slot_1 = nil
        goto p2
        ::p21::
        tick(21)
        do
            return 
        end
        ::p24::
        tick(24)
        do
            return 
        end
        ::p30::
        tick(30)
        slot_1 = upvalues[1]["antiaim"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p52
        end
        goto p61
        ::p35::
        tick(35)
        slot_6 = slot_3;
        slot_4(slot_5, slot_6)
        do
            return 
        end
        ::p46::
        slot_1 = upvalues[0]["is_enabled"];
        slot_1 = slot_1()
        if slot_1 then
            goto p30
        end
        goto p24
        ::p52::
        tick(52)
        if slot_1 then
            goto p2
        end
        goto p19
        ::p61::
        slot_1 = upvalues[1]["antiaim"]
        slot_1 = slot_1["features"]
        goto p52
        ::p79::
        tick(79)
        z = slot_2
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        slot_4 = environment["type"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        branch_taken = false
        if slot_4 ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p98
        end
        goto p5
        ::p93::
        if slot_2 ~= slot_0 then
            goto p79
        end
        goto p21
        ::p98::
        slot_4 = upvalues[2]["misc"]
        slot_4 = slot_4["usercmd"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["set"]
        goto p35
    end
end
