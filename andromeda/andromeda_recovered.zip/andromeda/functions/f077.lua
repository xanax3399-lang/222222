-- Recovered function f77; author names are unavailable.
F.f77 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local tick = new_tick("f77")
        tick(1)
        goto p24
        ::p3::
        tick(3)
        slot_2["ban_info"] = slot_3
        slot_1(slot_2)
        do
            return 
        end
        ::p7::
        tick(7)
        slot_3 = upvalues[2]["lua_str"]
        slot_4 = upvalues[3]
        slot_3 = slot_3[slot_4]
        slot_3 = slot_3.." [MT][0x01]"
        goto p3
        ::p24::
        slot_1 = upvalues[0]
        slot_2 = {
        }
        slot_3 = upvalues[1]["CHECK_12_FAILED"]
        slot_2["ban_num"] = slot_3
        goto p7
    end
end
