-- Recovered function f29; author names are unavailable.
F.f29 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, S, z, a = 0, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f29")
        tick(1)
        ::p18::
        tick(18)
        registers[1] = {
        }
        registers[2] = (0)
        registers[3] = (255)
        registers[4] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[4] + 0
        n = (registers[3] + 0)
        v = (registers[2] - U)
        goto p150
        ::p24::
        tick(24)
        registers[65] = (1747873779)
        registers[66] = (1955562222)
        registers[67] = (2024104815)
        goto p200
        ::p29::
        tick(29)
        registers[73] = (3329325298)
        q = registers[(9)]
        for f = 1, 64, 1 do
            q[0 + f] = registers[(9) + f]
        end
        registers[10] = {
        }
        goto p63
        ::p51::
        tick(51)
        registers[17] = (2870763221)
        a = registers
        z = 18;
        a[z] = 3624381080
        registers[19] = (310598401)
        registers[20] = (607225278)
        goto p134
        ::p57::
        tick(57)
        registers[27] = (4022224774)
        registers[28] = (264347078)
        registers[29] = (604807628)
        goto p85
        ::p62::
        tick(62)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[12]
        end
        ::p63::
        registers[10]["blocksize"] = 64
        registers[11] = "preproc"
        a = D.f30
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p95
        ::p68::
        tick(68)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p90
        end
        goto p219
        ::p80::
        tick(80)
        registers[33] = (1996064986)
        a = registers
        z = 34;
        a[z] = 2554220882
        registers[35] = (2821834349)
        goto p101
        ::p85::
        registers[30] = (770255983)
        a = registers
        z = 31;
        a[z] = 1249150122
        registers[32] = (1555081692)
        goto p80
        ::p90::
        registers[8] = registers[2]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        registers[3][registers[8]] = registers[7]
        goto p68
        ::p95::
        registers[10][registers[11]] = registers[12]
        registers[11] = "initH256"
        a = D.f31
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        registers[11] = "digestblock"
        goto p233
        ::p101::
        registers[36] = (2952996808)
        registers[37] = (3210313671)
        registers[38] = (3336571891)
        registers[39] = (3584528711)
        registers[40] = (113926993)
        registers[41] = (338241895)
        registers[42] = (666307205)
        registers[43] = (773529912)
        goto p225
        ::p116::
        tick(116)
        registers[6] = environment["string"]
        registers[6] = registers[6]["char"]
        registers[7] = registers[5];
        registers[(6)] = registers[(6)](registers[7])
        registers[1][registers[5]] = registers[6]
        goto p150
        ::p122::
        tick(122)
        a = D.f32
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f34
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[7] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f35
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[8] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[9] = new_frame(64)
        registers[10] = (1116352408)
        registers[11] = (1899447441)
        registers[12] = (3049323471)
        registers[13] = (3921009573)
        registers[14] = (961987163)
        registers[15] = (1508970993)
        registers[16] = (2453635748)
        goto p51
        ::p134::
        registers[21] = (1426881987)
        registers[22] = (1925078388)
        registers[23] = (2162078206)
        goto p196
        ::p138::
        tick(138)
        registers[59] = (506948616)
        registers[60] = (659060556)
        registers[61] = (883997877)
        goto p155
        ::p150::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[5] = v
            branch_taken = true
        end
        if branch_taken then
            goto p116
        end
        goto p237
        ::p155::
        registers[62] = (958139571)
        registers[63] = (1322822218)
        registers[64] = (1537002063)
        goto p24
        ::p173::
        tick(173)
        registers[47] = (1986661051)
        registers[48] = (2177026350)
        registers[49] = (2456956037)
        registers[50] = (2730485921)
        registers[51] = (2820302411)
        registers[52] = (3259730800)
        registers[53] = (3345764771)
        registers[54] = (3516065817)
        registers[55] = (3600352804)
        registers[56] = (4094571909)
        registers[57] = (275423344)
        registers[58] = (430227734)
        goto p138
        ::p196::
        registers[24] = (2614888103)
        registers[25] = (3248222580)
        registers[26] = (3835390401)
        goto p57
        ::p200::
        registers[68] = (2227730452)
        a = registers
        z = 69;
        a[z] = 2361852424
        registers[70] = (2428436474)
        registers[71] = (2756734187)
        registers[72] = (3204031479)
        goto p29
        ::p207::
        tick(207)
        registers[12] = "sha256"
        a = D.f36
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[12]] = registers[13]
        registers[12] = "sha256_binary"
        a = D.f37
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[12]] = registers[13]
        registers[12] = "hmac_sha256"
        a = D.f38
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[13] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[12]] = registers[13]
        registers[12] = registers[10]
        goto p62
        ::p219::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        a = D.f39
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f40
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[5] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p122
        ::p225::
        registers[44] = (1294757372)
        registers[45] = (1396182291)
        registers[46] = (1695183700)
        goto p173
        ::p231::
        tick(231)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p68
        goto p18
        ::p233::
        a = D.f41
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[10][registers[11]] = registers[12]
        a = D.f42
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p207
        ::p237::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        a = D.f44
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[2] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[3] = {
        }
        registers[4] = (0)
        registers[5] = (255)
        registers[6] = (1)
        goto p231
    end
end
