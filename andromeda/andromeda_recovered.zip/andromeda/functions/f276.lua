-- Recovered function f276; author names are unavailable.
F.f276 = function(function_metadata, upvalues)
    local operand_i, code_metadata, operand_k = function_metadata[2], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, _, S, z, a = 0, nil, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f276")
        tick(1)
        goto p152
        ::p2::
        tick(2)
        registers[20] = (3)
        registers[21] = (2)
        registers[22] = (1)
        registers[23] = (0)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (13)
        goto p129
        ::p10::
        tick(10)
        registers[24] = registers[24] + 1
        registers[24] = registers[12][registers[24]]
        registers[23] = registers[23] + registers[24]
        registers[18] = registers[23] % 256
        registers[23] = registers[17][registers[18]]
        registers[25] = registers[17][registers[22]]
        goto p435
        ::p17::
        tick(17)
        registers[13] = registers[6]
        registers[14] = registers[12]
        registers[15] = nil;
        registers[13](registers[14], registers[15])
        goto p112
        ::p22::
        tick(22)
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        registers[20] = (11)
        goto p452
        ::p28::
        tick(28)
        if registers[13] ~= registers[18] then
            goto p350
        end
        goto p413
        ::p30::
        tick(30)
        registers[32] = (7)
        registers[33] = (4)
        registers[34] = (5)
        registers[35] = (2)
        registers[36] = (3)
        goto p177
        ::p36::
        tick(36)
        registers[25] = (0)
        registers[26] = (1)
        registers[27] = (2)
        registers[28] = (3)
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        goto p389
        ::p45::
        tick(45)
        registers[22] = registers[14] * registers[13]
        registers[22] = registers[22] + registers[15]
        registers[13] = registers[22] % 256
        goto p315
        ::p49::
        tick(49)
        registers[20] = (3)
        registers[21] = (12)
        registers[22] = (13)
        registers[23] = (14)
        goto p650
        ::p54::
        tick(54)
        registers[18] = registers[1]
        registers[19] = (1)
        registers[20] = (4)
        m, x = pack_returns(registers[17](unpack_range(20, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[13] = (1)
        registers[14] = (4)
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p648
        ::p63::
        tick(63)
        registers[28] = (11)
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        goto p698
        ::p68::
        tick(68)
        registers[23][0] = 14
        registers[24] = (15)
        registers[25] = (12)
        goto p772
        ::p74::
        tick(74)
        registers[16] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[16]()
        end
        ::p76::
        tick(76)
        registers[14] = registers[7]
        registers[15] = registers[12];
        registers[(14)] = registers[(14)](registers[15])
        goto p224
        ::p90::
        tick(90)
        registers[12] = (3)
        registers[13] = (2)
        registers[14] = (5)
        registers[15] = (4)
        goto p609
        ::p96::
        tick(96)
        registers[6] = nil;
        registers[3] = registers[3](unpack_range(6, registers, 4))
        registers[2] = registers[2] == registers[3]
        if not registers[2] then
            goto p150
        end
        goto p226
        ::p101::
        tick(101)
        registers[29] = (8)
        registers[30] = (9)
        registers[31] = (6)
        goto p30
        ::p112::
        registers[13] = {
        }
        registers[14] = {
        }
        registers[15] = (false)
        registers[16] = registers[8]
        registers[17] = registers[12]
        registers[18] = nil
        goto p243
        ::p119::
        tick(119)
        registers[39] = (0)
        q = registers[(24)]
        q[1] = registers[25]
        q[2] = registers[26]
        q[3] = registers[27]
        q[4] = registers[28]
        q[5] = registers[29]
        q[6] = registers[30]
        q[7] = registers[31]
        q[8] = registers[32]
        q[9] = registers[33]
        q[10] = registers[34]
        q[11] = registers[35]
        q[12] = registers[36]
        q[13] = registers[37]
        q[14] = registers[38]
        q[15] = registers[39]
        q = registers[(9)]
        q[1] = registers[10]
        q[2] = registers[11]
        q[3] = registers[12]
        q[4] = registers[13]
        q[5] = registers[14]
        q[6] = registers[15]
        q[7] = registers[16]
        q[8] = registers[17]
        q[9] = registers[18]
        q[10] = registers[19]
        q[11] = registers[20]
        q[12] = registers[21]
        q[13] = registers[22]
        q[14] = registers[23]
        q[15] = registers[24]
        goto p757
        ::p125::
        tick(125)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (13)
        goto p265
        ::p129::
        registers[27] = (12)
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (9)
        goto p317
        ::p134::
        tick(134)
        registers[19] = ""..registers[14]
        registers[(16)](unpack_range(19, registers, 17))
        registers[14][registers[14]] = registers[14]
        goto p565
        ::p150::
        tick(150)
        if registers[2] then
            goto p641
        end
        goto p531
        ::p152::
        _, Q = pack_returns(...)
        registers[1] = Q[W]
        registers[2] = environment["string"]
        registers[2] = registers[2]["len"]
        goto p632
        ::p157::
        tick(157)
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (8)
        goto p212
        ::p161::
        tick(161)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (255)
        registers[21] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[21] + 0
        n = (registers[20] + 0)
        v = (registers[19] - U)
        goto p181
        registers[61] = operand_k
        registers[55] = code_metadata
        registers[60] = operand_i
        registers[55][31] = 212
        registers[61][31] = 33
        registers[60][31] = 0
        registers[61][95] = 29
        registers[54] = nil
        registers[55] = nil
        registers[56] = nil
        registers[57] = nil
        registers[58] = nil
        registers[59] = nil
        registers[60] = nil
        registers[61] = nil
        goto p30
        ::p177::
        registers[37] = (0)
        registers[38] = (1)
        q = registers[(23)]
        q[1] = registers[24]
        q[2] = registers[25]
        q[3] = registers[26]
        q[4] = registers[27]
        q[5] = registers[28]
        q[6] = registers[29]
        q[7] = registers[30]
        q[8] = registers[31]
        q[9] = registers[32]
        q[10] = registers[33]
        q[11] = registers[34]
        q[12] = registers[35]
        q[13] = registers[36]
        q[14] = registers[37]
        q[15] = registers[38]
        goto p306
        ::p181::
        tick(181)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[22] = v
            branch_taken = true
        end
        if branch_taken then
            goto p311
        end
        goto p550
        ::p183::
        tick(183);
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[14]
        m, x = pack_returns(registers[20]())
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[16](unpack_range(top, registers, 17))
        registers[16] = registers[14]
        registers[17] = (registers[14]..registers[14])
        registers[18] = registers[14]..""
        goto p134
        ::p204::
        tick(204)
        registers[33] = (6)
        registers[34] = (1)
        registers[35] = (0)
        registers[36] = (3)
        registers[37] = (2)
        q = registers[(22)]
        q[1] = registers[23]
        q[2] = registers[24]
        q[3] = registers[25]
        q[4] = registers[26]
        q[5] = registers[27]
        q[6] = registers[28]
        q[7] = registers[29]
        q[8] = registers[30]
        q[9] = registers[31]
        q[10] = registers[32]
        q[11] = registers[33]
        q[12] = registers[34]
        q[13] = registers[35]
        q[14] = registers[36]
        q[15] = registers[37]
        registers[23] = new_frame(15)
        goto p68
        ::p212::
        registers[22] = (9)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        goto p383
        ::p218::
        tick(218)
        registers[15] = (5)
        registers[16] = (6)
        registers[17] = (7)
        registers[18] = (8)
        registers[19] = (9)
        goto p456
        ::p224::
        if registers[14] == registers[0] then
            goto p17
        end
        goto p393
        ::p226::
        registers[2] = (163)
        goto p150
        ::p228::
        tick(228)
        registers[17] = registers[2] % 256
        registers[12][registers[16]] = registers[17]
        registers[2] = registers[2] / 256
        goto p748
        ::p232::
        tick(232)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        q[5] = registers[18]
        q[6] = registers[19]
        q[7] = registers[20]
        q[8] = registers[21]
        q[9] = registers[22]
        q[10] = registers[23]
        q[11] = registers[24]
        q[12] = registers[25]
        q[13] = registers[26]
        q[14] = registers[27]
        q[15] = registers[28]
        registers[14] = new_frame(15)
        registers[14][0] = 5
        registers[15] = (4)
        registers[16] = (7)
        registers[17] = (6)
        goto p744
        ::p239::
        tick(239)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        goto p533
        ::p243::
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(16)]
        n = registers[17]
        U = registers[18]
        goto p350
        ::p244::
        tick(244)
        registers[22] = (5)
        registers[23] = (#registers[1])
        registers[24] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[24] + 0
        n = (registers[23] + 0)
        v = (registers[22] - U)
        goto p584
        ::p248::
        tick(248)
        registers[27] = (12)
        registers[28] = (11)
        registers[29] = (10)
        goto p703
        ::p252::
        tick(252)
        registers[13][0] = 4
        registers[14] = (5)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (0)
        registers[18] = (1)
        registers[19] = (2)
        goto p49
        ::p260::
        tick(260)
        registers[21] = (2)
        registers[22] = (13)
        registers[23] = (12)
        goto p544
        ::p265::
        registers[27] = (12)
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        q[3] = registers[15]
        q[4] = registers[16]
        q[5] = registers[17]
        q[6] = registers[18]
        q[7] = registers[19]
        q[8] = registers[20]
        q[9] = registers[21]
        q[10] = registers[22]
        q[11] = registers[23]
        q[12] = registers[24]
        q[13] = registers[25]
        q[14] = registers[26]
        q[15] = registers[27]
        registers[13] = new_frame(15)
        goto p252
        ::p269::
        tick(269)
        registers[36] = (3)
        q = registers[(21)]
        q[1] = registers[22]
        q[2] = registers[23]
        q[3] = registers[24]
        q[4] = registers[25]
        q[5] = registers[26]
        q[6] = registers[27]
        q[7] = registers[28]
        q[8] = registers[29]
        q[9] = registers[30]
        q[10] = registers[31]
        q[11] = registers[32]
        q[12] = registers[33]
        q[13] = registers[34]
        q[14] = registers[35]
        q[15] = registers[36]
        registers[22] = new_frame(15)
        registers[22][0] = 13
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        registers[28] = (11)
        registers[29] = (10)
        goto p628
        ::p295::
        tick(295)
        registers[28] = registers[17][registers[28]]
        registers[26] = registers[26](registers[27], registers[28])
        registers[26] = registers[16][registers[26]]
        registers[21] = (registers[21]..registers[26])
        goto p584
        ::p302::
        tick(302)
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        goto p2
        ::p306::
        registers[24] = new_frame(15)
        registers[24][0] = 15
        registers[25] = (14)
        registers[26] = (13)
        goto p248
        ::p311::
        registers[23] = registers[17][registers[22]]
        registers[23] = registers[18] + registers[23]
        registers[24] = registers[22] % 8
        goto p10
        ::p315::
        tick(315)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[21] = v
            branch_taken = true
        end
        if branch_taken then
            goto p666
        end
        goto p161
        ::p317::
        registers[31] = (8)
        q = registers[(16)]
        q[1] = registers[17]
        q[2] = registers[18]
        q[3] = registers[19]
        q[4] = registers[20]
        q[5] = registers[21]
        q[6] = registers[22]
        q[7] = registers[23]
        q[8] = registers[24]
        q[9] = registers[25]
        q[10] = registers[26]
        q[11] = registers[27]
        q[12] = registers[28]
        q[13] = registers[29]
        q[14] = registers[30]
        q[15] = registers[31]
        registers[17] = new_frame(15)
        registers[17][0] = 8
        registers[18] = (9)
        goto p346
        ::p324::
        tick(324)
        registers[25] = (14)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        registers[11] = new_frame(15)
        registers[11][0] = 2
        registers[12] = (3)
        registers[13] = (0)
        registers[14] = (1)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        goto p157
        ::p337::
        tick(337)
        registers[15] = registers[15] % 128
        registers[15] = 2 * registers[15]
        registers[15] = (registers[15] - 1)
        registers[16] = {
        }
        registers[17] = {
        }
        registers[18] = (0)
        registers[19] = (255)
        registers[20] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[20] + 0
        n = (registers[19] + 0)
        v = (registers[18] - U)
        goto p315
        ::p346::
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (12)
        goto p662
        ::p350::
        tick(350)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[17] = z;
            registers[18] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p28
        end
        goto p791
        ::p352::
        tick(352)
        registers[21][0] = 12
        registers[22] = (13)
        registers[23] = (14)
        goto p504
        ::p356::
        tick(356)
        registers[16] = registers[13]
        registers[14] = registers[14](registers[15], registers[16])
        registers[15] = registers[14]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        m, x = pack_returns(registers[18]())
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        a = D.f277
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[16] = registers[16](registers[17], registers[18])
        if not registers[16] then
            goto p809
        end
        goto p502
        ::p376::
        tick(376)
        registers[18] = (5)
        registers[19] = (2)
        registers[20] = (3)
        registers[21] = (0)
        registers[22] = (1)
        registers[23] = (14)
        goto p462
        ::p383::
        q = registers[(11)]
        q[1] = registers[12]
        q[2] = registers[13]
        q[3] = registers[14]
        q[4] = registers[15]
        q[5] = registers[16]
        q[6] = registers[17]
        q[7] = registers[18]
        q[8] = registers[19]
        q[9] = registers[20]
        q[10] = registers[21]
        q[11] = registers[22]
        q[12] = registers[23]
        q[13] = registers[24]
        q[14] = registers[25]
        q[15] = registers[26]
        registers[12] = new_frame(15)
        registers[12][0] = 3
        registers[13] = (2)
        goto p719
        ::p389::
        registers[32] = (7)
        q = registers[(17)]
        q[1] = registers[18]
        q[2] = registers[19]
        q[3] = registers[20]
        q[4] = registers[21]
        q[5] = registers[22]
        q[6] = registers[23]
        q[7] = registers[24]
        q[8] = registers[25]
        q[9] = registers[26]
        q[10] = registers[27]
        q[11] = registers[28]
        q[12] = registers[29]
        q[13] = registers[30]
        q[14] = registers[31]
        q[15] = registers[32]
        registers[18] = new_frame(15)
        goto p657
        ::p393::
        tick(393)
        registers[13] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[13]()
        end
        ::p409::
        tick(409)
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        goto p592
        ::p413::
        registers[15] = (true)
        registers[12][registers[17]] = registers[14]
        goto p350
        ::p416::
        tick(416)
        registers[24] = (14)
        registers[25] = (15)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        registers[9][0] = registers[10]
        goto p573
        ::p422::
        tick(422)
        registers[16] = (registers[14] >= registers[14])
        goto p479
        ::p428::
        tick(428)
        registers[23] = (8)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (3)
        goto p765
        ::p435::
        registers[17][registers[18]] = registers[25]
        registers[17][registers[22]] = registers[23]
        goto p181
        ::p438::
        tick(438)
        if not registers[12] then
            goto p393
        end
        registers[13] = environment["type"]
        registers[14] = registers[12];
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "table" then
            goto p393
        end
        goto p76
        ::p452::
        registers[21] = (10)
        registers[22] = (9)
        registers[23] = (8)
        goto p125
        ::p456::
        registers[20] = (10)
        registers[21] = (11)
        registers[22] = (12)
        registers[23] = (13)
        goto p416
        ::p462::
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        goto p794
        ::p468::
        tick(468)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[22] = registers[21]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[22]
        end
        ::p471::
        tick(471)
        registers[9] = new_frame(15)
        registers[10] = new_frame(15)
        registers[10][0] = 0
        registers[11] = (1)
        registers[12] = (2)
        registers[13] = (3)
        registers[14] = (4)
        goto p218
        ::p479::
        tick(479)
        registers[15] = registers[16]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[19] = registers[14]
        registers[20] = registers[14]
        goto p183
        ::p486::
        tick(486)
        registers[29] = (0)
        registers[30] = (1)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (4)
        goto p802
        ::p492::
        tick(492)
        registers[13]["__lt"] = registers[12]
        registers[13]["__le"] = registers[12]
        registers[13]["__concat"] = registers[12]
        goto p811
        ::p502::
        registers[16] = registers[14]
        goto p809
        ::p504::
        registers[24] = (15)
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        goto p63
        ::p509::
        tick(509)
        registers[35] = (4)
        q = registers[(20)]
        q[1] = registers[21]
        q[2] = registers[22]
        q[3] = registers[23]
        q[4] = registers[24]
        q[5] = registers[25]
        q[6] = registers[26]
        q[7] = registers[27]
        q[8] = registers[28]
        q[9] = registers[29]
        q[10] = registers[30]
        q[11] = registers[31]
        q[12] = registers[32]
        q[13] = registers[33]
        q[14] = registers[34]
        q[15] = registers[35]
        registers[21] = new_frame(15)
        goto p352
        ::p514::
        tick(514)
        registers[29] = registers[17][registers[20]]
        registers[28] = registers[28] + registers[29]
        registers[28] = registers[28] % 256
        goto p295
        ::p518::
        tick(518)
        registers[16] = registers[14] > registers[14]
        goto p524
        ::p520::
        tick(520)
        registers[13]["__sub"] = registers[12]
        registers[13]["__mul"] = registers[12]
        registers[13]["__div"] = registers[12]
        goto p690
        ::p524::
        tick(524)
        registers[15] = registers[16]
        registers[16] = (registers[14] <= registers[14])
        if not registers[16] then
            goto p479
        end
        goto p422
        ::p529::
        tick(529)
        if registers[13] == registers[14] then
            goto p694
        end
        goto p74
        ::p531::
        registers[2] = (156)
        goto p641
        ::p533::
        registers[26] = (13)
        registers[27] = (2)
        registers[28] = (3)
        goto p486
        ::p537::
        tick(537)
        registers[31] = (4)
        registers[32] = (7)
        registers[33] = (6)
        q = registers[(18)]
        q[1] = registers[19]
        q[2] = registers[20]
        q[3] = registers[21]
        q[4] = registers[22]
        q[5] = registers[23]
        q[6] = registers[24]
        q[7] = registers[25]
        q[8] = registers[26]
        q[9] = registers[27]
        q[10] = registers[28]
        q[11] = registers[29]
        q[12] = registers[30]
        q[13] = registers[31]
        q[14] = registers[32]
        q[15] = registers[33]
        registers[19] = new_frame(15)
        registers[19][0] = 10
        goto p637
        ::p544::
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        goto p711
        ::p550::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = ""
        goto p244
        ::p556::
        tick(556)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = registers[12][3]
        registers[14] = registers[12][1]
        registers[14] = registers[14] % 64
        goto p599
        ::p561::
        tick(561)
        registers[15] = registers[16]
        registers[16] = registers[14] < registers[14]
        if not registers[16] then
            goto p524
        end
        goto p518
        ::p565::
        registers[16] = registers[14][registers[14]]
        registers[14][registers[14]] = registers[16]
        registers[12] = registers[3]
        goto p438
        ::p569::
        tick(569)
        registers[16] = registers[14]
        goto p616
        ::p573::
        registers[10] = new_frame(15)
        registers[10][0] = 1
        registers[11] = (0)
        goto p90
        ::p584::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[25] = v
            branch_taken = true
        end
        if branch_taken then
            goto p682
        end
        goto p468
        ::p586::
        tick(586)
        if not registers[16] then
            goto p561
        end
        goto p742
        ::p588::
        tick(588)
        registers[3] = registers[3]["byte"]
        registers[4] = "\239\128\186"
        registers[5] = (1)
        goto p96
        ::p592::
        registers[25] = (14)
        registers[26] = (1)
        registers[27] = (0)
        registers[28] = (3)
        registers[29] = (2)
        registers[30] = (5)
        goto p537
        ::p599::
        registers[14] = 4 * registers[14]
        registers[14] = registers[14] + 1
        registers[15] = registers[12][2]
        goto p337
        ::p609::
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (9)
        registers[19] = (8)
        registers[20] = (11)
        goto p723
        ::p616::
        tick(616)
        registers[15] = registers[16]
        registers[16] = registers[14] + registers[14]
        registers[17] = registers[14] * registers[14]
        registers[17] = (registers[17] / registers[14])
        goto p672
        ::p621::
        tick(621)
        registers[5] = environment["string"]
        registers[5] = registers[5]["byte"]
        registers[6] = environment["setmetatable"]
        registers[7] = environment["getmetatable"]
        registers[8] = environment["next"]
        goto p471
        ::p628::
        registers[30] = (5)
        registers[31] = (4)
        registers[32] = (7)
        goto p204
        ::p632::
        registers[3] = "\224\199";
        registers[(2)] = registers[(2)](registers[3])
        registers[2] = 496 - registers[2]
        registers[3] = environment["string"]
        goto p588
        ::p637::
        registers[20] = (11)
        registers[21] = (8)
        registers[22] = (9)
        goto p239
        ::p641::
        registers[2] = (registers[2] - 304)
        registers[2] = (registers[2] - 278)
        registers[2] = -1322376851 + registers[2]
        registers[3] = registers
        registers[4] = environment["string"]
        registers[4] = registers[4]["char"]
        goto p621
        ::p648::
        tick(648)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p228
        end
        goto p556
        ::p650::
        registers[24] = (15)
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        registers[28] = (11)
        goto p232
        ::p657::
        registers[18][0] = 9
        registers[19] = (8)
        registers[20] = (11)
        registers[21] = (10)
        goto p409
        ::p662::
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        goto p36
        ::p666::
        registers[22] = registers[4]
        registers[23] = registers[13];
        registers[(22)] = registers[(22)](registers[23])
        registers[16][registers[13]] = registers[22]
        registers[17][registers[13]] = registers[13]
        goto p45
        ::p672::
        registers[18] = (registers[14] ^ registers[14])
        registers[17] = registers[17] % registers[18]
        registers[15] = (registers[16] - registers[17])
        registers[16] = registers[14] == registers[14]
        goto p586
        ::p677::
        tick(677)
        registers[17][registers[20]] = registers[28]
        registers[17][registers[19]] = registers[26]
        registers[26] = registers[10]
        goto p751
        ::p682::
        registers[26] = registers[19] + 1
        registers[19] = registers[26] % 256
        registers[26] = registers[17][registers[19]]
        registers[26] = registers[20] + registers[26]
        registers[20] = registers[26] % 256
        registers[26] = registers[17][registers[20]]
        registers[28] = registers[17][registers[19]]
        goto p677
        ::p690::
        registers[13]["__mod"] = registers[12]
        registers[13]["__pow"] = registers[12]
        registers[13]["__eq"] = registers[12]
        goto p492
        ::p694::
        registers[12] = new_frame(4)
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = registers[5]
        goto p54
        ::p698::
        registers[32] = (7)
        registers[33] = (0)
        registers[34] = (1)
        registers[35] = (2)
        goto p269
        ::p703::
        registers[30] = (9)
        registers[31] = (8)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (5)
        goto p730
        ::p711::
        registers[28] = (11)
        registers[29] = (10)
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        q[5] = registers[19]
        q[6] = registers[20]
        q[7] = registers[21]
        q[8] = registers[22]
        q[9] = registers[23]
        q[10] = registers[24]
        q[11] = registers[25]
        q[12] = registers[26]
        q[13] = registers[27]
        q[14] = registers[28]
        q[15] = registers[29]
        registers[15] = new_frame(15)
        registers[15][0] = 6
        registers[16] = (7)
        registers[17] = (4)
        goto p376
        ::p719::
        registers[14] = (1)
        registers[15] = (0)
        registers[16] = (7)
        goto p22
        ::p723::
        registers[21] = (10)
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        goto p324
        ::p730::
        registers[35] = (4)
        registers[36] = (3)
        registers[37] = (2)
        registers[38] = (1)
        goto p119
        ::p742::
        registers[16] = (registers[14] ~= registers[14])
        goto p561
        ::p744::
        registers[18] = (1)
        registers[19] = (0)
        registers[20] = (3)
        goto p260
        ::p748::
        registers[17] = registers[2] % 1
        registers[2] = (registers[2] - registers[17])
        goto p648
        ::p751::
        registers[27] = registers[5]
        registers[28] = registers[1]
        registers[29] = registers[25]
        registers[27] = registers[27](registers[28], registers[29])
        registers[28] = registers[17][registers[19]]
        goto p514
        ::p757::
        a = D.f278
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f279
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f281
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[13] = {
        }
        registers[13]["__tostring"] = registers[11]
        registers[13]["__call"] = registers[12]
        registers[13]["__add"] = registers[12]
        goto p520
        ::p765::
        registers[29] = (2)
        registers[30] = (1)
        registers[31] = (0)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (5)
        goto p509
        ::p772::
        registers[26] = (13)
        registers[27] = (10)
        registers[28] = (11)
        goto p101
        ::p791::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not registers[15] then
            goto p74
        end
        goto p529
        ::p794::
        registers[27] = (10)
        registers[28] = (11)
        registers[29] = (8)
        registers[30] = (9)
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        q[3] = registers[18]
        q[4] = registers[19]
        q[5] = registers[20]
        q[6] = registers[21]
        q[7] = registers[22]
        q[8] = registers[23]
        q[9] = registers[24]
        q[10] = registers[25]
        q[11] = registers[26]
        q[12] = registers[27]
        q[13] = registers[28]
        q[14] = registers[29]
        q[15] = registers[30]
        registers[16] = new_frame(15)
        registers[16][0] = 7
        goto p302
        ::p802::
        registers[34] = (5)
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        q[3] = registers[22]
        q[4] = registers[23]
        q[5] = registers[24]
        q[6] = registers[25]
        q[7] = registers[26]
        q[8] = registers[27]
        q[9] = registers[28]
        q[10] = registers[29]
        q[11] = registers[30]
        q[12] = registers[31]
        q[13] = registers[32]
        q[14] = registers[33]
        q[15] = registers[34]
        registers[20] = new_frame(15)
        registers[20][0] = 11
        registers[21] = (10)
        registers[22] = (9)
        goto p428
        ::p809::
        if registers[16] then
            goto p616
        end
        goto p569
        ::p811::
        registers[13]["__index"] = registers[12]
        registers[13]["__newindex"] = registers[12]
        registers[13]["__metatable"] = false
        registers[14] = registers[6]
        registers[15] = {
        }
        goto p356
    end
end
