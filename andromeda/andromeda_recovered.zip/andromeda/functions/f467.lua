-- Recovered function f467; author names are unavailable.
F.f467 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f467")
        tick(1)
        goto p39
        ::p11::
        tick(11)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = registers[3]
        do
            return registers[4]
        end
        ::p14::
        tick(14)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p34
        end
        goto p11
        ::p16::
        tick(16)
        registers[6] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p14
        registers[21] = operand_k
        registers[15] = code_metadata
        registers[22] = 44
        registers[23] = constant_cache[10]
        registers[24] = "j#\226"
        registers[25] = (3)
        registers[26] = (3);
        registers[23] = registers[23](unpack_range(26, registers, 24))
        registers[22] = registers[22] + registers[23]
        registers[22] = 25341 + registers[22]
        registers[22] = registers[22] + -25526
        registers[15][48] = registers[22]
        registers[21][33] = 43
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        goto p44
        ::p34::
        registers[8] = upvalues[1][151]
        registers[9] = registers[3]
        registers[10] = upvalues[0]["measure_item"]
        registers[11] = upvalues[0]["render_items"]
        goto p44
        ::p39::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = (0)
        registers[4] = (1)
        registers[5] = upvalues[0]["render_count"]
        goto p16
        ::p44::
        registers[11] = registers[11][registers[7]]
        registers[12] = registers[1]
        registers[13] = registers[2]
        m, x = pack_returns(registers[10](unpack_range(13, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[3] = registers[8]
        goto p14
    end
end
