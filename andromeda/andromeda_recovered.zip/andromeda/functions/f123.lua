-- Recovered function f123; author names are unavailable.
F.f123 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f123")
        tick(1)
        goto p197
        ::p2::
        tick(2)
        registers[5]["fps_optimization_options"] = registers[6]
        registers[6] = registers[1]["maps"]
        registers[6] = registers[6]["visuals"]
        registers[(2)](unpack_range(6, registers, 3))
        goto p49
        ::p7::
        tick(7)
        registers[5]["watermark_color"] = registers[6]
        registers[6] = registers[1]["maps"]
        registers[6] = registers[6]["visuals"]
        goto p62
        ::p11::
        tick(11)
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        if not registers[6] then
            goto p183
        end
        goto p115
        ::p15::
        tick(15)
        registers[6] = nil
        goto p210
        ::p17::
        tick(17)
        registers[6] = upvalues[0]["ragebot"]
        registers[5]["ragebot"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[5]["stubs"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["widgets"]
        registers[5]["widgets"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["animations"]
        goto p217
        ::p28::
        tick(28)
        registers[6] = nil
        goto p134
        ::p47::
        tick(47)
        if registers[6] then
            goto p7
        end
        goto p144
        ::p49::
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["add_handles"]
        registers[4] = "visuals.native_indicators"
        registers[5] = {
        }
        goto p11
        ::p62::
        registers[(2)](unpack_range(6, registers, 3))
        do
            return 
        end
        ::p64::
        tick(64)
        registers[5]["enabled"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        if not registers[6] then
            goto p235
        end
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[6] = registers[6]["native_indicators_gradient"]
        goto p235
        ::p93::
        tick(93)
        registers[2]["visuals"] = registers[3]
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["add_handles"]
        registers[4] = "antiaim"
        registers[5] = {
        }
        registers[6] = upvalues[0]["antiaim"]
        registers[6] = registers[6]["conditions"]
        registers[5]["conditions"] = registers[6]
        registers[6] = upvalues[0]["antiaim"]
        registers[6] = registers[6]["features"]
        registers[5]["features"] = registers[6]
        registers[6] = upvalues[0]["antiaim"]
        registers[6] = registers[6]["gamesense"]
        goto p121
        ::p115::
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[6] = registers[6]["native_indicators"]
        goto p183
        ::p119::
        tick(119)
        registers[6] = nil
        goto p64
        ::p121::
        registers[5]["gamesense"] = registers[6]
        registers[6] = upvalues[0]["builder"]
        registers[5]["builder"] = registers[6]
        registers[6] = upvalues[0]["defensive"]
        registers[5]["defensive"] = registers[6]
        registers[6] = registers[1]["maps"]
        registers[6] = registers[6]["antiaim"]
        registers[(2)](unpack_range(6, registers, 3))
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["add_handles"]
        registers[4] = "visuals"
        registers[5] = {
        }
        goto p17
        ::p134::
        tick(134)
        registers[5]["watermark_gradient"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        if not registers[6] then
            goto p228
        end
        goto p185
        ::p139::
        tick(139)
        registers[5]["gradient"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        if not registers[6] then
            goto p208
        end
        goto p230
        ::p144::
        registers[6] = nil
        goto p7
        ::p158::
        tick(158)
        if not registers[6] then
            goto p47
        end
        goto p204
        ::p183::
        if registers[6] then
            goto p64
        end
        goto p119
        ::p185::
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[6] = registers[6]["watermark_position"]
        goto p228
        ::p197::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = registers[1]["maps"]
        registers[3] = {
        }
        registers[2]["antiaim"] = registers[3]
        registers[2] = registers[1]["maps"]
        registers[3] = {
        }
        goto p93
        ::p204::
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[6] = registers[6]["watermark_accent_color"]
        goto p47
        ::p208::
        tick(208)
        if registers[6] then
            goto p134
        end
        goto p28
        ::p210::
        tick(210)
        registers[5]["watermark_position"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        goto p158
        ::p214::
        tick(214)
        registers[6] = nil
        goto p139
        ::p217::
        registers[5]["animations"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["fast_ladder"]
        registers[5]["fast_ladder"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["fps_optimization"]
        registers[5]["fps_optimization"] = registers[6]
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["fps_optimization_options"]
        goto p2
        ::p228::
        if registers[6] then
            goto p210
        end
        goto p15
        ::p230::
        registers[6] = upvalues[0]["visuals"]
        registers[6] = registers[6]["stubs"]
        registers[6] = registers[6]["watermark_cs2_gradient"]
        goto p208
        ::p235::
        if registers[6] then
            goto p139
        end
        goto p214
    end
end
