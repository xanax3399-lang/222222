-- Recovered function f66; author names are unavailable.
F.f66 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, _, S, z, a = 0, nil, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f66")
        tick(1)
        goto p508
        ::p2::
        tick(2)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[18] = (0)
        registers[19] = (0)
        goto p526
        ::p7::
        tick(7)
        registers[14] = (5)
        registers[15] = (4)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (9)
        registers[19] = (8)
        registers[20] = (11)
        registers[21] = (10)
        goto p660
        ::p16::
        tick(16)
        registers[16] = registers[14] > registers[14]
        goto p761
        ::p18::
        tick(18)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not registers[15] then
            goto p118
        end
        goto p120
        ::p21::
        tick(21)
        registers[6] = environment["setmetatable"]
        registers[7] = environment["getmetatable"]
        registers[8] = environment["next"]
        registers[9] = new_frame(15)
        registers[10] = new_frame(15)
        registers[10][0] = 0
        registers[11] = (1)
        registers[12] = (2)
        goto p106
        ::p30::
        tick(30)
        registers[13][0] = 4
        registers[14] = (5)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (0)
        registers[18] = (1)
        registers[19] = (2)
        goto p366
        ::p38::
        tick(38)
        registers[13] = registers[6]
        registers[14] = registers[12]
        registers[15] = nil;
        registers[13](registers[14], registers[15])
        goto p272
        ::p43::
        tick(43)
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        registers[19] = (2)
        goto p377
        ::p48::
        tick(48)
        registers[26] = (9)
        registers[27] = (10)
        registers[28] = (11)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        q[5] = registers[18]
        q[6] = registers[19]
        q[7] = registers[20]
        q[8] = registers[21]
        q[9] = registers[22]
        q[10] = registers[23]
        q[11] = registers[24]
        q[12] = registers[25]
        q[13] = registers[26]
        q[14] = registers[27]
        q[15] = registers[28]
        goto p643
        ::p53::
        tick(53)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[22] = registers[21]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[22]
        end
        ::p56::
        tick(56)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (10)
        goto p433
        ::p60::
        tick(60)
        registers[26] = (13)
        registers[27] = (12)
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        q[3] = registers[15]
        q[4] = registers[16]
        q[5] = registers[17]
        q[6] = registers[18]
        q[7] = registers[19]
        q[8] = registers[20]
        q[9] = registers[21]
        q[10] = registers[22]
        q[11] = registers[23]
        q[12] = registers[24]
        q[13] = registers[25]
        q[14] = registers[26]
        q[15] = registers[27]
        registers[13] = new_frame(15)
        goto p30
        ::p65::
        tick(65)
        registers[15] = registers[16]
        registers[16] = registers[14] + registers[14]
        registers[17] = registers[14] * registers[14]
        registers[17] = (registers[17] / registers[14])
        goto p112
        ::p70::
        tick(70)
        registers[26] = (13)
        registers[27] = (2)
        registers[28] = (3)
        goto p185
        ::p74::
        tick(74)
        registers[27] = registers[5]
        registers[28] = registers[1]
        registers[29] = registers[25]
        goto p650
        ::p78::
        tick(78)
        registers[28] = (3)
        registers[29] = (4)
        registers[30] = (5)
        goto p233
        ::p82::
        tick(82)
        registers[13]["__call"] = registers[12]
        registers[13]["__add"] = registers[12]
        registers[13]["__sub"] = registers[12]
        goto p148
        ::p86::
        tick(86)
        registers[27] = (12)
        registers[28] = (11)
        registers[29] = (10)
        goto p454
        ::p90::
        tick(90)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        registers[28] = (11)
        goto p215
        ::p98::
        tick(98)
        registers[14][registers[14]] = registers[16]
        registers[12] = registers[3]
        if not registers[12] then
            goto p175
        end
        goto p626
        ::p102::
        tick(102)
        registers[23] = (8)
        registers[24] = (15)
        registers[25] = (14)
        goto p60
        ::p106::
        registers[13] = (3)
        registers[14] = (4)
        registers[15] = (5)
        goto p208
        ::p110::
        tick(110)
        registers[16] = registers[14]
        goto p65
        ::p112::
        registers[18] = (registers[14] ^ registers[14])
        registers[17] = registers[17] % registers[18]
        registers[15] = (registers[16] - registers[17])
        registers[16] = registers[14] == registers[14]
        if not registers[16] then
            goto p390
        end
        goto p146
        ::p118::
        tick(118)
        registers[16] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[16]()
        end
        ::p120::
        if registers[13] == registers[14] then
            goto p179
        end
        goto p118
        ::p122::
        tick(122)
        registers[22] = (5)
        registers[23] = (#registers[1])
        registers[24] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[24] + 0
        n = (registers[23] + 0)
        v = (registers[22] - U)
        goto p383
        ::p126::
        tick(126)
        registers[19] = (1)
        registers[20.0] = (4)
        m, x = pack_returns(registers[17](unpack_range(20, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[13] = (1)
        registers[14] = (4)
        goto p529
        ::p133::
        tick(133)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[21] = v
            branch_taken = true
        end
        if branch_taken then
            goto p560
        end
        goto p2
        ::p136::
        tick(136)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (8)
        goto p48
        ::p140::
        tick(140)
        registers[2] = registers[2]["len"]
        registers[3] = "(\186\248";
        registers[(2)] = registers[(2)](registers[3])
        registers[2] = (registers[2] - 252)
        registers[2] = (registers[2] - 352)
        goto p297
        ::p146::
        registers[16] = (registers[14] ~= registers[14])
        goto p390
        ::p148::
        registers[13]["__mul"] = registers[12]
        registers[13]["__div"] = registers[12]
        registers[13]["__mod"] = registers[12]
        registers[13]["__pow"] = registers[12]
        registers[13]["__eq"] = registers[12]
        registers[13]["__lt"] = registers[12]
        registers[13]["__le"] = registers[12]
        registers[13]["__concat"] = registers[12]
        registers[13]["__index"] = registers[12]
        registers[13]["__newindex"] = registers[12]
        registers[13]["__metatable"] = false
        registers[14] = registers[6]
        registers[15] = {
        }
        goto p444
        ::p171::
        tick(171)
        registers[12] = (3)
        registers[13] = (0)
        registers[14] = (1)
        goto p486
        ::p175::
        tick(175)
        registers[13] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[13]()
        end
        ::p177::
        tick(177)
        if registers[16] then
            goto p65
        end
        goto p110
        ::p179::
        registers[12] = new_frame(4)
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = registers[5]
        registers[18] = registers[1]
        goto p126
        ::p185::
        registers[29] = (0)
        registers[30] = (1)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (4)
        goto p600
        ::p191::
        tick(191)
        registers[14] = registers[7]
        registers[15] = registers[12];
        registers[(14)] = registers[(14)](registers[15])
        if registers[14] == registers[0] then
            goto p38
        end
        goto p175
        ::p197::
        tick(197)
        registers[21] = (11)
        registers[22] = (12)
        registers[23] = (13)
        registers[24] = (14)
        registers[25] = (15)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        registers[9][0] = registers[10]
        registers[10] = new_frame(15)
        goto p316
        ::p206::
        tick(206)
        registers[13] = registers[22] % 256
        goto p133
        ::p208::
        registers[16] = (6)
        registers[17] = (7)
        registers[18] = (8)
        registers[19] = (9)
        registers[20] = (10)
        goto p197
        ::p215::
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (0)
        goto p261
        ::p221::
        tick(221)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[17] = z;
            registers[18] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p512
        end
        goto p18
        ::p223::
        tick(223)
        registers[17] = registers[2] % 256
        registers[12][registers[16]] = registers[17]
        registers[2] = registers[2] / 256
        goto p568
        ::p227::
        tick(227)
        registers[19] = (4)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (9)
        goto p102
        ::p233::
        registers[31] = (6)
        registers[32] = (7)
        q = registers[(17)]
        q[1] = registers[18]
        q[2] = registers[19]
        q[3] = registers[20]
        q[4] = registers[21]
        q[5] = registers[22]
        q[6] = registers[23]
        q[7] = registers[24]
        q[8] = registers[25]
        q[9] = registers[26]
        q[10] = registers[27]
        q[11] = registers[28]
        q[12] = registers[29]
        q[13] = registers[30]
        q[14] = registers[31]
        q[15] = registers[32]
        registers[18] = new_frame(15)
        registers[18][0] = 9
        goto p665
        ::p239::
        tick(239)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (10)
        registers[28] = (11)
        registers[29] = (8)
        registers[30] = (9)
        goto p752
        ::p247::
        tick(247)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        goto p70
        ::p252::
        tick(252)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        goto p712
        ::p256::
        tick(256)
        registers[19] = ""..registers[14]
        registers[(16)](unpack_range(19, registers, 17))
        registers[14][registers[14]] = registers[14]
        registers[16] = registers[14][registers[14]]
        goto p98
        ::p261::
        registers[34] = (1)
        registers[35] = (2)
        registers[36] = (3)
        q = registers[(21)]
        q[1] = registers[22]
        q[2] = registers[23]
        q[3] = registers[24]
        q[4] = registers[25]
        q[5] = registers[26]
        q[6] = registers[27]
        q[7] = registers[28]
        q[8] = registers[29]
        q[9] = registers[30]
        q[10] = registers[31]
        q[11] = registers[32]
        q[12] = registers[33]
        q[13] = registers[34]
        q[14] = registers[35]
        q[15] = registers[36]
        registers[22] = new_frame(15)
        registers[22][0] = 13
        registers[23] = (12)
        goto p400
        ::p270::
        tick(270)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[22] = v
            branch_taken = true
        end
        if branch_taken then
            goto p678
        end
        goto p590
        ::p272::
        registers[13] = {
        }
        registers[14] = {
        }
        registers[15] = (false)
        goto p670
        ::p276::
        tick(276)
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        goto p386
        ::p280::
        tick(280)
        a = D.f67
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[13] = {
        }
        registers[13]["__tostring"] = registers[11]
        goto p82
        ::p284::
        tick(284)
        registers[20][0] = 11
        registers[21] = (10)
        registers[22] = (9)
        registers[23] = (8)
        registers[24] = (15)
        registers[25] = (14)
        goto p595
        ::p291::
        tick(291)
        registers[17] = new_frame(15)
        registers[17][0] = 8
        registers[18] = (9)
        registers[19] = (10)
        registers[20] = (11)
        goto p423
        ::p297::
        registers[2] = (registers[2] - 0)
        registers[2] = (registers[2] - 442)
        registers[2] = registers[2] + 212
        goto p479
        ::p316::
        registers[10][0] = 1
        registers[11] = (0)
        registers[12] = (3)
        registers[13] = (2)
        goto p7
        ::p321::
        tick(321)
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[16] = registers[16](registers[17], registers[18])
        if not registers[16] then
            goto p177
        end
        registers[16] = registers[14]
        goto p177
        ::p328::
        tick(328)
        registers[27] = (0)
        registers[28] = (3)
        registers[29] = (2)
        registers[30] = (5)
        goto p636
        ::p333::
        tick(333)
        registers[31] = (4)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (1)
        registers[35] = (0)
        registers[36] = (3)
        registers[37] = (2)
        goto p732
        ::p341::
        tick(341)
        registers[15] = registers[16]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[19] = registers[14]
        registers[20] = registers[14];
        registers[(19)] = registers[(19)](registers[20])
        goto p613
        ::p355::
        tick(355)
        registers[30] = (1)
        registers[31] = (0)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (5)
        registers[35] = (4)
        q = registers[(20)]
        q[1] = registers[21]
        q[2] = registers[22]
        q[3] = registers[23]
        q[4] = registers[24]
        q[5] = registers[25]
        q[6] = registers[26]
        q[7] = registers[27]
        q[8] = registers[28]
        q[9] = registers[29]
        q[10] = registers[30]
        q[11] = registers[31]
        q[12] = registers[32]
        q[13] = registers[33]
        q[14] = registers[34]
        q[15] = registers[35]
        registers[21] = new_frame(15)
        registers[21][0] = 12
        registers[22] = (13)
        goto p90
        ::p366::
        registers[20] = (3)
        registers[21] = (12)
        registers[22] = (13)
        goto p136
        ::p377::
        registers[20] = (3)
        registers[21] = (0)
        registers[22] = (1)
        registers[23] = (14)
        goto p239
        ::p383::
        tick(383)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[25] = v
            branch_taken = true
        end
        if branch_taken then
            goto p519
        end
        goto p53
        ::p386::
        m, x = pack_returns(registers[18]())
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        a = D.f68
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p321
        ::p390::
        registers[15] = registers[16]
        registers[16] = registers[14] < registers[14]
        if not registers[16] then
            goto p761
        end
        goto p16
        ::p400::
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (9)
        goto p631
        ::p419::
        tick(419)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        registers[11] = new_frame(15)
        registers[11][0] = 2
        goto p171
        ::p423::
        registers[21] = (12)
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (0)
        registers[26] = (1)
        registers[27] = (2)
        goto p78
        ::p431::
        tick(431)
        registers[17][registers[22]] = registers[23]
        goto p270
        ::p433::
        registers[28] = (11)
        registers[29] = (8)
        registers[30] = (9)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (4)
        registers[34] = (5)
        registers[35] = (2)
        registers[36] = (3)
        registers[37] = (0)
        goto p620
        ::p444::
        registers[16] = registers[13]
        registers[14] = registers[14](registers[15], registers[16])
        registers[15] = registers[14]
        goto p276
        ::p448::
        tick(448)
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (8)
        registers[22] = (9)
        registers[23] = (14)
        goto p252
        ::p454::
        registers[30] = (9)
        registers[31] = (8)
        q = registers[(16)]
        q[1] = registers[17]
        q[2] = registers[18]
        q[3] = registers[19]
        q[4] = registers[20]
        q[5] = registers[21]
        q[6] = registers[22]
        q[7] = registers[23]
        q[8] = registers[24]
        q[9] = registers[25]
        q[10] = registers[26]
        q[11] = registers[27]
        q[12] = registers[28]
        q[13] = registers[29]
        q[14] = registers[30]
        q[15] = registers[31]
        goto p291
        ::p470::
        tick(470)
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        registers[28] = (11)
        registers[29] = (10)
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        q[5] = registers[19]
        q[6] = registers[20]
        q[7] = registers[21]
        q[8] = registers[22]
        q[9] = registers[23]
        q[10] = registers[24]
        q[11] = registers[25]
        q[12] = registers[26]
        q[13] = registers[27]
        q[14] = registers[28]
        q[15] = registers[29]
        registers[15] = new_frame(15)
        registers[15][0] = 6
        goto p43
        ::p479::
        registers[2] = 1156302040 + registers[2]
        registers[3] = registers
        registers[4] = environment["string"]
        registers[4] = registers[4]["char"]
        registers[5] = environment["string"]
        registers[5] = registers[5]["byte"]
        goto p21
        ::p486::
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        goto p448
        ::p491::
        tick(491)
        registers[16] = (registers[14] >= registers[14])
        goto p341
        ::p493::
        tick(493)
        registers[14] = 4 * registers[14]
        registers[14] = registers[14] + 1
        registers[15] = registers[12][2]
        registers[15] = registers[15] % 128
        registers[15] = 2 * registers[15]
        registers[15] = (registers[15] - 1)
        registers[16] = {
        }
        registers[17] = {
        }
        goto p515
        ::p502::
        tick(502)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (9)
        goto p746
        ::p508::
        _, Q = pack_returns(...)
        registers[1] = Q[W]
        registers[2] = environment["string"]
        goto p140
        ::p512::
        if registers[13] ~= registers[18] then
            goto p221
        end
        goto p610
        ::p515::
        registers[18] = (0)
        registers[19] = (255)
        registers[20] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[20] + 0
        n = (registers[19] + 0)
        v = (registers[18] - U)
        goto p133
        ::p519::
        registers[26] = registers[19] + 1
        registers[19] = registers[26] % 256
        registers[26] = registers[17][registers[19]]
        registers[26] = registers[20] + registers[26]
        registers[20] = registers[26] % 256
        registers[26] = registers[17][registers[20]]
        goto p727
        ::p526::
        registers[20] = (255)
        registers[21] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[21] + 0
        n = (registers[20] + 0)
        v = (registers[19] - U)
        goto p270
        ::p529::
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p689
        ::p531::
        tick(531)
        registers[23] = (0)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (13)
        goto p86
        ::p536::
        tick(536)
        q = registers[(9)]
        q[1] = registers[10]
        q[2] = registers[11]
        q[3] = registers[12]
        q[4] = registers[13]
        q[5] = registers[14]
        q[6] = registers[15]
        q[7] = registers[16]
        q[8] = registers[17]
        q[9] = registers[18]
        q[10] = registers[19]
        q[11] = registers[20]
        q[12] = registers[21]
        q[13] = registers[22]
        q[14] = registers[23]
        q[15] = registers[24]
        a = D.f69
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f70
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p280
        ::p541::
        tick(541)
        registers[19] = (0)
        registers[20] = (3)
        registers[21] = (2)
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        goto p470
        ::p560::
        registers[22] = registers[4]
        registers[23] = registers[13];
        registers[(22)] = registers[(22)](registers[23])
        registers[16][registers[13]] = registers[22]
        registers[17][registers[13]] = registers[13]
        registers[22] = registers[14] * registers[13]
        registers[22] = registers[22] + registers[15]
        goto p206
        ::p568::
        registers[17] = registers[2] % 1
        registers[2] = (registers[2] - registers[17])
        goto p689
        ::p584::
        tick(584)
        registers[21] = (registers[21]..registers[26])
        goto p383
        ::p586::
        tick(586)
        registers[20] = (11)
        registers[21] = (8)
        registers[22] = (9)
        goto p247
        ::p590::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = ""
        goto p122
        ::p595::
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (3)
        registers[29] = (2)
        goto p355
        ::p600::
        registers[34] = (5)
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        q[3] = registers[22]
        q[4] = registers[23]
        q[5] = registers[24]
        q[6] = registers[25]
        q[7] = registers[26]
        q[8] = registers[27]
        q[9] = registers[28]
        q[10] = registers[29]
        q[11] = registers[30]
        q[12] = registers[31]
        q[13] = registers[32]
        q[14] = registers[33]
        q[15] = registers[34]
        registers[20] = new_frame(15)
        goto p284
        ::p604::
        tick(604)
        registers[36] = (3)
        registers[37] = (2)
        registers[38] = (1)
        registers[39] = (0)
        q = registers[(24)]
        q[1] = registers[25]
        q[2] = registers[26]
        q[3] = registers[27]
        q[4] = registers[28]
        q[5] = registers[29]
        q[6] = registers[30]
        q[7] = registers[31]
        q[8] = registers[32]
        q[9] = registers[33]
        q[10] = registers[34]
        q[11] = registers[35]
        q[12] = registers[36]
        q[13] = registers[37]
        q[14] = registers[38]
        q[15] = registers[39]
        goto p536
        ::p610::
        registers[15] = (true)
        registers[12][registers[17]] = registers[14]
        goto p221
        ::p613::
        registers[20] = registers[14]
        m, x = pack_returns(registers[20]())
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[16](unpack_range(top, registers, 17))
        registers[16] = registers[14]
        registers[17] = (registers[14]..registers[14])
        registers[18] = registers[14]..""
        goto p256
        ::p620::
        registers[38] = (1)
        q = registers[(23)]
        q[1] = registers[24]
        q[2] = registers[25]
        q[3] = registers[26]
        q[4] = registers[27]
        q[5] = registers[28]
        q[6] = registers[29]
        q[7] = registers[30]
        q[8] = registers[31]
        q[9] = registers[32]
        q[10] = registers[33]
        q[11] = registers[34]
        q[12] = registers[35]
        q[13] = registers[36]
        q[14] = registers[37]
        q[15] = registers[38]
        registers[24] = new_frame(15)
        registers[24][0] = 15
        registers[25] = (14)
        goto p502
        ::p626::
        registers[13] = environment["type"]
        registers[14] = registers[12];
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "table" then
            goto p175
        end
        goto p191
        ::p631::
        registers[27] = (8)
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (5)
        goto p333
        ::p636::
        registers[31] = (4)
        registers[32] = (7)
        registers[33] = (6)
        q = registers[(18)]
        q[1] = registers[19]
        q[2] = registers[20]
        q[3] = registers[21]
        q[4] = registers[22]
        q[5] = registers[23]
        q[6] = registers[24]
        q[7] = registers[25]
        q[8] = registers[26]
        q[9] = registers[27]
        q[10] = registers[28]
        q[11] = registers[29]
        q[12] = registers[30]
        q[13] = registers[31]
        q[14] = registers[32]
        q[15] = registers[33]
        registers[19] = new_frame(15)
        registers[19][0] = 10
        goto p586
        ::p643::
        registers[14] = new_frame(15)
        registers[14][0] = 5
        registers[15] = (4)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (1)
        goto p541
        ::p650::
        registers[27] = registers[27](registers[28], registers[29])
        registers[28] = registers[17][registers[19]]
        registers[29] = registers[17][registers[20]]
        registers[28] = registers[28] + registers[29]
        registers[28] = registers[28] % 256
        registers[28] = registers[17][registers[28]]
        registers[26] = registers[26](registers[27], registers[28])
        registers[26] = registers[16][registers[26]]
        goto p584
        ::p660::
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        goto p419
        ::p665::
        registers[19] = (8)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (13)
        goto p756
        ::p670::
        registers[16] = registers[8]
        registers[17] = registers[12]
        registers[18] = nil
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(16)]
        n = registers[17]
        U = registers[18]
        goto p221
        ::p674::
        tick(674)
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        goto p738
        ::p678::
        registers[23] = registers[17][registers[22]]
        registers[23] = registers[18] + registers[23]
        registers[24] = registers[22] % 8
        registers[24] = registers[24] + 1
        registers[24] = registers[12][registers[24]]
        registers[23] = registers[23] + registers[24]
        registers[18] = registers[23] % 256
        registers[23] = registers[17][registers[18]]
        registers[25] = registers[17][registers[22]]
        registers[17][registers[18]] = registers[25]
        goto p431
        ::p689::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p223
        end
        goto p722
        ::p712::
        q = registers[(11)]
        q[1] = registers[12]
        q[2] = registers[13]
        q[3] = registers[14]
        q[4] = registers[15]
        q[5] = registers[16]
        q[6] = registers[17]
        q[7] = registers[18]
        q[8] = registers[19]
        q[9] = registers[20]
        q[10] = registers[21]
        q[11] = registers[22]
        q[12] = registers[23]
        q[13] = registers[24]
        q[14] = registers[25]
        q[15] = registers[26]
        registers[12] = new_frame(15)
        registers[12][0] = 3
        registers[13] = (2)
        registers[14] = (1)
        registers[15] = (0)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (5)
        goto p227
        ::p722::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = registers[12][3]
        registers[14] = registers[12][1]
        registers[14] = registers[14] % 64
        goto p493
        ::p727::
        registers[28] = registers[17][registers[19]]
        registers[17][registers[20]] = registers[28]
        registers[17][registers[19]] = registers[26]
        registers[26] = registers[10]
        goto p74
        ::p732::
        q = registers[(22)]
        q[1] = registers[23]
        q[2] = registers[24]
        q[3] = registers[25]
        q[4] = registers[26]
        q[5] = registers[27]
        q[6] = registers[28]
        q[7] = registers[29]
        q[8] = registers[30]
        q[9] = registers[31]
        q[10] = registers[32]
        q[11] = registers[33]
        q[12] = registers[34]
        q[13] = registers[35]
        q[14] = registers[36]
        q[15] = registers[37]
        registers[23] = new_frame(15)
        registers[23][0] = 14
        registers[24] = (15)
        goto p56
        ::p738::
        registers[20] = (3)
        registers[21] = (2)
        registers[22] = (1)
        goto p531
        ::p746::
        registers[31] = (8)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (5)
        registers[35] = (4)
        goto p604
        ::p752::
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        q[3] = registers[18]
        q[4] = registers[19]
        q[5] = registers[20]
        q[6] = registers[21]
        q[7] = registers[22]
        q[8] = registers[23]
        q[9] = registers[24]
        q[10] = registers[25]
        q[11] = registers[26]
        q[12] = registers[27]
        q[13] = registers[28]
        q[14] = registers[29]
        q[15] = registers[30]
        registers[16] = new_frame(15)
        registers[16][0] = 7
        goto p674
        ::p756::
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (1)
        goto p328
        ::p761::
        registers[15] = registers[16]
        registers[16] = (registers[14] <= registers[14])
        if not registers[16] then
            goto p341
        end
        goto p491
    end
end
