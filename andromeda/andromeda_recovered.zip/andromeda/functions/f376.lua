-- Recovered function f376; author names are unavailable.
F.f376 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f376")
        tick(1)
        goto p13
        ::p2::
        tick(2)
        slot_1 = upvalues[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["reset_disable_fakelag"]
        slot_1(slot_2)
        slot_1 = upvalues[2]
        slot_1()
        goto p10
        ::p8::
        tick(8)
        do
            return 
        end
        ::p10::
        slot_1 = upvalues[3]
        slot_1()
        do
            return 
        end
        ::p13::
        slot_1 = upvalues[0]["is_quit"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p2
        end
        goto p8
    end
end
