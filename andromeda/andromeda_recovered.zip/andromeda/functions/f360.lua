-- Recovered function f360; author names are unavailable.
F.f360 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f360")
        tick(1)
        goto p72
        ::p2::
        tick(2)
        a = upvalues[0];
        registers[4] = a[2][a[1]]
        if registers[4] ~= "Timing" then
            goto p21
        end
        goto p121
        ::p6::
        tick(6)
        a = upvalues[0];
        registers[2] = a[2][a[1]]
        if registers[2] ~= "Timing" then
            goto p51
        end
        goto p253
        ::p9::
        tick(9)
        registers[5] = registers[2]
        goto p70
        ::p13::
        tick(13);
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = registers[4] % 2
        registers[4] = registers[4] + 1
        registers[5] = (registers[4] == 1)
        if not registers[5] then
            goto p70
        end
        goto p9
        ::p21::
        registers[4] = upvalues[3][154]
        registers[5] = registers[1]
        if registers[5] then
            goto p13
        end
        goto p96
        ::p26::
        tick(26)
        registers[5] = registers[3]
        goto p262
        ::p51::
        registers[2] = upvalues[5]
        registers[3] = upvalues[7];
        registers[3] = registers[3]()
        goto p118
        ::p70::
        if registers[5] then
            goto p262
        end
        goto p26
        ::p72::
        a = {
            ...,
        }
        registers[1] = a[1]
        a = upvalues[0];
        registers[2] = a[2][a[1]]
        if registers[2] ~= "Off" then
            goto p237
        end
        goto p207
        ::p76::
        tick(76)
        registers[8] = registers[8]["randomize"]
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = registers[1]
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p81::
        tick(81)
        registers[4] = registers[3]
        registers[3] = registers[2]
        registers[2] = registers[4]
        goto p133
        ::p93::
        tick(93)
        a = upvalues[1];
        registers[2] = a[2][a[1]]
        if registers[2] ~= "Custom" then
            goto p6
        end
        goto p105
        ::p96::
        registers[5] = (0)
        goto p13
        ::p98::
        tick(98)
        registers[6] = upvalues[2]["clamp"]
        registers[7] = upvalues[3][154]
        z = registers[5]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] then
            goto p137
        end
        goto p226
        ::p105::
        registers[2] = upvalues[4]["custom"]
        registers[3] = upvalues[6];
        registers[3] = registers[3]()
        registers[4] = upvalues[3][154]
        registers[5] = registers[1]
        if registers[5] then
            goto p151
        end
        goto p123
        ::p113::
        tick(113)
        registers[4] = registers[4]["left"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] then
            goto p128
        end
        goto p251
        ::p118::
        registers[4] = (50)
        registers[5] = registers[1]
        do
            return registers[(2)](unpack_range(5, registers, 3))
        end
        ::p121::
        if not (registers[3] < registers[2]) then
            goto p133
        end
        goto p81
        ::p123::
        registers[5] = (0)
        goto p151
        ::p125::
        tick(125)
        a = upvalues[0];
        registers[6] = a[2][a[1]]
        if registers[6] ~= "Timing" then
            goto p228
        end
        goto p98
        ::p128::
        tick(128);
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = (1)
        registers[5] = (16);
        registers[2] = registers[2](unpack_range(5, registers, 3))
        goto p199
        ::p133::
        registers[4] = upvalues[2]["random_int"]
        registers[5] = registers[2]
        registers[6] = registers[3]
        goto p141
        ::p137::
        tick(137);
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = (1)
        registers[9] = (16)
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p141::
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p151::;
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = registers[4] % registers[3]
        registers[4] = registers[4] + 1
        registers[5] = registers[2]["slots"]
        registers[5] = registers[5][registers[4]]
        if registers[5] then
            goto p125
        end
        tick(158)
        registers[5] = registers[2]["slots"]
        registers[5] = registers[5][1]
        goto p125
        ::p186::
        tick(186)
        registers[2] = upvalues[2]["clamp"]
        registers[3] = upvalues[3][154]
        registers[4] = upvalues[4]["double"]
        goto p113
        ::p190::
        tick(190)
        registers[5] = (1)
        goto p240
        ::p199::
        registers[3] = upvalues[2]["clamp"]
        registers[4] = upvalues[3][154]
        registers[5] = upvalues[4]["double"]
        registers[5] = registers[5]["right"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p240
        end
        goto p190
        ::p207::
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p226::
        registers[8] = (1)
        goto p137
        ::p228::
        registers[6] = upvalues[5]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["get"];
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = registers[2]["randomize"]
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = registers[1]
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p237::
        a = upvalues[1];
        registers[2] = a[2][a[1]]
        if registers[2] ~= "Double" then
            goto p93
        end
        goto p186
        ::p240::;
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = (1)
        registers[6] = (16);
        registers[3] = registers[3](unpack_range(6, registers, 4))
        goto p2
        ::p251::
        registers[4] = (1)
        goto p128
        ::p253::
        registers[2] = upvalues[7]
        do
            return registers[2]()
        end
        ::p262::
        registers[6] = upvalues[5]
        registers[7] = registers[5]
        registers[8] = upvalues[4]["double"]
        goto p76
    end
end
