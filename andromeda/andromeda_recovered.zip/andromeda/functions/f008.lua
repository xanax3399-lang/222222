-- Recovered function f8; author names are unavailable.
F.f8 = function(function_metadata, upvalues)
    local operand_i, operand_k = function_metadata[2], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, _, S, z, a = 0, nil, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f8")
        tick(1)
        _, Q = pack_returns(...)
        registers[1] = Q[W]
        registers[2] = environment["string"]
        registers[2] = registers[2]["byte"]
        goto p407
        ::p15::
        tick(15)
        registers[21][0] = 12
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        goto p483
        ::p20::
        tick(20)
        registers[26] = (13)
        registers[27] = (10)
        registers[28] = (11)
        goto p75
        ::p24::
        tick(24)
        registers[20] = (255)
        registers[21] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[21] + 0
        n = (registers[20] + 0)
        v = (registers[19] - U)
        goto p756
        ::p27::
        tick(27)
        registers[18] = (1)
        registers[19] = (0)
        registers[20] = (3)
        registers[21] = (2)
        registers[22] = (13)
        goto p703
        ::p33::
        tick(33)
        registers[16][registers[13]] = registers[22]
        registers[17][registers[13]] = registers[13]
        registers[22] = registers[14] * registers[13]
        registers[22] = registers[22] + registers[15]
        registers[13] = registers[22] % 256
        goto p561
        ::p39::
        tick(39)
        registers[21] = (10)
        registers[22] = (13)
        registers[23] = (12)
        goto p51
        ::p43::
        tick(43)
        registers[17] = (registers[17] / registers[14])
        registers[18] = (registers[14] ^ registers[14])
        registers[17] = registers[17] % registers[18]
        goto p128
        ::p47::
        tick(47)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        q[5] = registers[18]
        q[6] = registers[19]
        q[7] = registers[20]
        q[8] = registers[21]
        q[9] = registers[22]
        q[10] = registers[23]
        q[11] = registers[24]
        q[12] = registers[25]
        q[13] = registers[26]
        q[14] = registers[27]
        q[15] = registers[28]
        registers[14] = new_frame(15)
        registers[14][0] = 5
        goto p71
        ::p51::
        registers[24] = (15)
        registers[25] = (14)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        goto p190
        ::p55::
        tick(55)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (10)
        goto p465
        ::p62::
        tick(62)
        registers[18] = (8)
        registers[19] = (9)
        registers[20] = (10)
        registers[21] = (11)
        goto p258
        ::p67::
        tick(67)
        registers[15] = registers[16]
        registers[16] = (registers[14] <= registers[14])
        if not registers[16] then
            goto p420
        end
        goto p312
        ::p71::
        registers[15] = (4)
        registers[16] = (7)
        registers[17] = (6)
        goto p27
        ::p75::
        registers[29] = (8)
        registers[30] = (9)
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        q[3] = registers[18]
        q[4] = registers[19]
        q[5] = registers[20]
        q[6] = registers[21]
        q[7] = registers[22]
        q[8] = registers[23]
        q[9] = registers[24]
        q[10] = registers[25]
        q[11] = registers[26]
        q[12] = registers[27]
        q[13] = registers[28]
        q[14] = registers[29]
        q[15] = registers[30]
        registers[16] = new_frame(15)
        registers[16][0] = 7
        goto p811
        ::p81::
        tick(81)
        registers[2] = environment["math"]
        registers[2] = registers[2]["floor"]
        registers[3] = environment["math"]
        registers[3] = registers[3]["pi"];
        registers[(2)] = registers[(2)](registers[3])
        goto p293
        ::p87::
        tick(87)
        registers[22] = (5)
        registers[23] = (#registers[1])
        registers[24] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[24] + 0
        n = (registers[23] + 0)
        v = (registers[22] - U)
        goto p519
        ::p91::
        tick(91)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (4)
        goto p439
        ::p95::
        tick(95)
        if not registers[16] then
            goto p340
        end
        goto p364
        ::p97::
        tick(97)
        registers[17] = registers[12]
        registers[18] = nil
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(16)]
        n = registers[17]
        U = registers[18]
        goto p671
        ::p100::
        tick(100)
        registers[15] = (true)
        registers[12][registers[17]] = registers[14]
        goto p671
        ::p103::
        tick(103)
        registers[14] = registers[14] + 1
        registers[15] = registers[12][2]
        registers[15] = registers[15] % 128
        goto p212
        ::p107::
        tick(107)
        registers[31] = (8)
        q = registers[(16)]
        q[1] = registers[17]
        q[2] = registers[18]
        q[3] = registers[19]
        q[4] = registers[20]
        q[5] = registers[21]
        q[6] = registers[22]
        q[7] = registers[23]
        q[8] = registers[24]
        q[9] = registers[25]
        q[10] = registers[26]
        q[11] = registers[27]
        q[12] = registers[28]
        q[13] = registers[29]
        q[14] = registers[30]
        q[15] = registers[31]
        registers[17] = new_frame(15)
        registers[17][0] = 8
        registers[18] = (9)
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (12)
        goto p348
        ::p116::
        tick(116);
        registers[2] = registers[2](unpack_range(5, registers, 3))
        registers[2] = registers[2] + 192
        registers[2] = (registers[2] ~= 324)
        if not registers[2] then
            goto p293
        end
        goto p81
        ::p123::
        tick(123)
        registers[33] = (6)
        registers[34] = (5)
        registers[35] = (4)
        registers[36] = (3)
        goto p366
        ::p128::
        registers[15] = (registers[16] - registers[17])
        registers[16] = registers[14] == registers[14]
        if not registers[16] then
            goto p557
        end
        goto p344
        ::p132::
        tick(132)
        registers[13] = registers[6]
        registers[14] = registers[12]
        registers[15] = nil;
        registers[13](registers[14], registers[15])
        registers[13] = {
        }
        goto p320
        ::p138::
        tick(138)
        registers[26] = (9)
        registers[27] = (10)
        registers[28] = (11)
        goto p47
        ::p143::
        tick(143)
        q = registers[(22)]
        q[1] = registers[23]
        q[2] = registers[24]
        q[3] = registers[25]
        q[4] = registers[26]
        q[5] = registers[27]
        q[6] = registers[28]
        q[7] = registers[29]
        q[8] = registers[30]
        q[9] = registers[31]
        q[10] = registers[32]
        q[11] = registers[33]
        q[12] = registers[34]
        q[13] = registers[35]
        q[14] = registers[36]
        q[15] = registers[37]
        registers[23] = new_frame(15)
        registers[23][0] = 14
        goto p55
        ::p147::
        tick(147)
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (1)
        registers[27] = (0)
        registers[28] = (3)
        registers[29] = (2)
        goto p638
        ::p171::
        tick(171)
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[16] = registers[16](registers[17], registers[18])
        goto p95
        ::p182::
        tick(182)
        registers[8] = environment["next"]
        registers[9] = new_frame(15)
        registers[10] = new_frame(15)
        registers[10][0] = 0
        registers[11] = (1)
        registers[12] = (2)
        registers[13] = (3)
        goto p601
        ::p190::
        registers[11] = new_frame(15)
        registers[11][0] = 2
        registers[12] = (3)
        goto p356
        ::p199::
        tick(199)
        registers[2] = (301)
        goto p738
        ::p201::
        tick(201)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[20] + 0
        n = (registers[19] + 0)
        v = (registers[18] - U)
        goto p561
        registers[47] = operand_i
        registers[48] = operand_k
        registers[49] = -61
        registers[49] = (registers[49] - 341)
        registers[49] = 23389 + registers[49]
        registers[49] = registers[49] + -22971
        registers[47][173] = registers[49]
        registers[48][194] = 741
        registers[41] = nil
        registers[42] = nil
        registers[43] = nil
        registers[44] = nil
        registers[45] = nil
        registers[46] = nil
        registers[47] = nil
        registers[48] = nil
        registers[49] = nil
        registers[50] = nil
        registers[51] = nil
        registers[52] = nil
        goto p742
        ::p212::
        registers[15] = 2 * registers[15]
        registers[15] = (registers[15] - 1)
        registers[16] = {
        }
        goto p695
        ::p216::
        tick(216)
        registers[2] = environment["string"]
        registers[2] = registers[2]["byte"]
        registers[3] = "\238o\026D\198"
        registers[4] = (5)
        goto p493
        ::p232::
        tick(232)
        registers[17] = (registers[14]..registers[14])
        registers[18] = registers[14]..""
        registers[19] = ""..registers[14]
        registers[(16)](unpack_range(19, registers, 17))
        registers[14][registers[14]] = registers[14]
        registers[16] = registers[14][registers[14]]
        registers[14][registers[14]] = registers[16]
        registers[12] = registers[3]
        if not registers[12] then
            goto p700
        end
        goto p335
        ::p251::
        tick(251)
        registers[2] = environment["string"]
        registers[2] = registers[2]["len"]
        registers[3] = "b\150";
        registers[(2)] = registers[(2)](registers[3])
        goto p754
        ::p256::
        tick(256)
        registers[2] = (440)
        goto p766
        ::p258::
        registers[22] = (12)
        registers[23] = (13)
        registers[24] = (14)
        registers[25] = (15)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        registers[9][0] = registers[10]
        registers[10] = new_frame(15)
        registers[10][0] = 1
        goto p748
        ::p267::
        tick(267)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (1)
        goto p621
        ::p271::
        tick(271)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = ""
        goto p87
        ::p284::
        tick(284)
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (3)
        registers[29] = (2)
        registers[30] = (1)
        registers[31] = (0)
        registers[32] = (7)
        goto p302
        ::p293::
        if registers[2] then
            goto p646
        end
        goto p673
        ::p295::
        tick(295)
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (9)
        goto p107
        ::p302::
        registers[33] = (6)
        registers[34] = (5)
        registers[35] = (4)
        q = registers[(20)]
        q[1] = registers[21]
        q[2] = registers[22]
        q[3] = registers[23]
        q[4] = registers[24]
        q[5] = registers[25]
        q[6] = registers[26]
        q[7] = registers[27]
        q[8] = registers[28]
        q[9] = registers[29]
        q[10] = registers[30]
        q[11] = registers[31]
        q[12] = registers[32]
        q[13] = registers[33]
        q[14] = registers[34]
        q[15] = registers[35]
        registers[21] = new_frame(15)
        goto p15
        ::p308::
        tick(308)
        registers[34] = (5)
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        q[3] = registers[22]
        q[4] = registers[23]
        q[5] = registers[24]
        q[6] = registers[25]
        q[7] = registers[26]
        q[8] = registers[27]
        q[9] = registers[28]
        q[10] = registers[29]
        q[11] = registers[30]
        q[12] = registers[31]
        q[13] = registers[32]
        q[14] = registers[33]
        q[15] = registers[34]
        registers[20] = new_frame(15)
        goto p443
        ::p312::
        registers[16] = (registers[14] >= registers[14])
        goto p420
        ::p317::
        tick(317)
        registers[2] = (registers[2] ~= 425)
        if not registers[2] then
            goto p738
        end
        goto p199
        ::p320::
        registers[14] = {
        }
        registers[15] = (false)
        registers[16] = registers[8]
        goto p97
        ::p324::
        tick(324)
        registers[13]["__mod"] = registers[12]
        registers[13]["__pow"] = registers[12]
        registers[13]["__eq"] = registers[12]
        registers[13]["__lt"] = registers[12]
        registers[13]["__le"] = registers[12]
        goto p594
        ::p330::
        tick(330)
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        q[5] = registers[19]
        q[6] = registers[20]
        q[7] = registers[21]
        q[8] = registers[22]
        q[9] = registers[23]
        q[10] = registers[24]
        q[11] = registers[25]
        q[12] = registers[26]
        q[13] = registers[27]
        q[14] = registers[28]
        q[15] = registers[29]
        registers[15] = new_frame(15)
        registers[15][0] = 6
        registers[16] = (7)
        goto p712
        ::p335::
        registers[13] = environment["type"]
        registers[14] = registers[12];
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "table" then
            goto p700
        end
        goto p707
        ::p340::
        tick(340)
        if registers[16] then
            goto p515
        end
        goto p642
        ::p344::
        registers[16] = (registers[14] ~= registers[14])
        goto p557
        ::p348::
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (0)
        registers[26] = (1)
        registers[27] = (2)
        registers[28] = (3)
        goto p613
        ::p356::
        registers[13] = (0)
        registers[14] = (1)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        goto p565
        ::p364::
        registers[16] = registers[14]
        goto p340
        ::p366::
        registers[37] = (2)
        registers[38] = (1)
        registers[39] = (0)
        q = registers[(24)]
        q[1] = registers[25]
        q[2] = registers[26]
        q[3] = registers[27]
        q[4] = registers[28]
        q[5] = registers[29]
        q[6] = registers[30]
        q[7] = registers[31]
        q[8] = registers[32]
        q[9] = registers[33]
        q[10] = registers[34]
        q[11] = registers[35]
        q[12] = registers[36]
        q[13] = registers[37]
        q[14] = registers[38]
        q[15] = registers[39]
        q = registers[(9)]
        q[1] = registers[10]
        q[2] = registers[11]
        q[3] = registers[12]
        q[4] = registers[13]
        q[5] = registers[14]
        q[6] = registers[15]
        q[7] = registers[16]
        q[8] = registers[17]
        q[9] = registers[18]
        q[10] = registers[19]
        q[11] = registers[20]
        q[12] = registers[21]
        q[13] = registers[22]
        q[14] = registers[23]
        q[15] = registers[24]
        a = D.f9
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f10
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p785
        ::p376::
        tick(376)
        registers[26] = (13)
        registers[27] = (12)
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        q[3] = registers[15]
        q[4] = registers[16]
        q[5] = registers[17]
        q[6] = registers[18]
        q[7] = registers[19]
        q[8] = registers[20]
        q[9] = registers[21]
        q[10] = registers[22]
        q[11] = registers[23]
        q[12] = registers[24]
        q[13] = registers[25]
        q[14] = registers[26]
        q[15] = registers[27]
        goto p826
        ::p380::
        tick(380)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        q = registers[(11)]
        q[1] = registers[12]
        q[2] = registers[13]
        q[3] = registers[14]
        q[4] = registers[15]
        q[5] = registers[16]
        q[6] = registers[17]
        q[7] = registers[18]
        q[8] = registers[19]
        q[9] = registers[20]
        q[10] = registers[21]
        q[11] = registers[22]
        q[12] = registers[23]
        q[13] = registers[24]
        q[14] = registers[25]
        q[15] = registers[26]
        registers[12] = new_frame(15)
        registers[12][0] = 3
        registers[13] = (2)
        registers[14] = (1)
        registers[15] = (0)
        registers[16] = (7)
        goto p835
        ::p392::
        tick(392)
        registers[26] = registers[10]
        registers[27] = registers[5]
        registers[28] = registers[1]
        registers[29] = registers[25]
        registers[27] = registers[27](registers[28], registers[29])
        registers[28] = registers[17][registers[19]]
        registers[29] = registers[17][registers[20]]
        goto p489
        ::p400::
        tick(400)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (9)
        registers[23] = (8)
        registers[24] = (15)
        registers[25] = (14)
        goto p376
        ::p407::
        registers[3] = ",b"
        registers[4] = (1)
        registers[5] = (1)
        goto p116
        ::p416::
        tick(416)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (13)
        goto p147
        ::p420::
        registers[15] = registers[16]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        goto p500
        ::p425::
        tick(425)
        registers[26] = (9)
        registers[27] = (8)
        registers[28] = (11)
        registers[29] = (10)
        goto p330
        ::p430::
        tick(430)
        registers[20] = registers[26] % 256
        registers[26] = registers[17][registers[20]]
        registers[28] = registers[17][registers[19]]
        registers[17][registers[20]] = registers[28]
        registers[17][registers[19]] = registers[26]
        goto p392
        ::p436::
        tick(436)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[22] = registers[21]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[22]
        end
        ::p439::
        registers[34] = (5)
        registers[35] = (2)
        registers[36] = (3)
        goto p802
        ::p443::
        registers[20][0] = 11
        registers[21] = (10)
        registers[22] = (9)
        registers[23] = (8)
        registers[24] = (15)
        goto p284
        ::p450::
        tick(450)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p691
        end
        goto p526
        ::p452::
        tick(452)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[18] = (0)
        registers[19] = (0)
        goto p24
        ::p462::
        tick(462)
        registers[14] = (4)
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p450
        ::p465::
        registers[28] = (11)
        registers[29] = (8)
        registers[30] = (9)
        goto p91
        ::p483::
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        registers[28] = (11)
        registers[29] = (4)
        goto p816
        ::p489::
        registers[28] = registers[28] + registers[29]
        registers[28] = registers[28] % 256
        registers[28] = registers[17][registers[28]]
        goto p667
        ::p493::
        registers[5] = (5);
        registers[2] = registers[2](unpack_range(5, registers, 3))
        goto p317
        ::p496::
        tick(496)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not registers[15] then
            goto p740
        end
        goto p736
        ::p500::
        registers[19] = registers[14]
        registers[20] = registers[14];
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[14]
        m, x = pack_returns(registers[20]())
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[16](unpack_range(top, registers, 17))
        registers[16] = registers[14]
        goto p232
        ::p515::
        tick(515)
        registers[15] = registers[16]
        registers[16] = registers[14] + registers[14]
        registers[17] = registers[14] * registers[14]
        goto p43
        ::p519::
        tick(519)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[25] = v
            branch_taken = true
        end
        if branch_taken then
            goto p839
        end
        goto p436
        ::p526::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = registers[12][3]
        registers[14] = registers[12][1]
        registers[14] = registers[14] % 64
        registers[14] = 4 * registers[14]
        goto p103
        ::p532::
        tick(532)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        goto p20
        ::p536::
        tick(536)
        registers[21] = (2)
        registers[22] = (1)
        registers[23] = (0)
        registers[24] = (15)
        goto p295
        ::p541::
        tick(541)
        registers[29] = (10)
        registers[30] = (5)
        registers[31] = (4)
        goto p267
        ::p545::
        tick(545)
        q = registers[(17)]
        q[1] = registers[18]
        q[2] = registers[19]
        q[3] = registers[20]
        q[4] = registers[21]
        q[5] = registers[22]
        q[6] = registers[23]
        q[7] = registers[24]
        q[8] = registers[25]
        q[9] = registers[26]
        q[10] = registers[27]
        q[11] = registers[28]
        q[12] = registers[29]
        q[13] = registers[30]
        q[14] = registers[31]
        q[15] = registers[32]
        registers[18] = new_frame(15)
        registers[18][0] = 9
        registers[19] = (8)
        goto p416
        ::p550::
        tick(550)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (0)
        registers[18] = (1)
        registers[19] = (2)
        registers[20] = (3)
        goto p719
        ::p557::
        registers[15] = registers[16]
        registers[16] = registers[14] < registers[14]
        if not registers[16] then
            goto p67
        end
        goto p629
        ::p561::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[21] = v
            branch_taken = true
        end
        if branch_taken then
            goto p649
        end
        goto p452
        ::p565::
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (8)
        registers[22] = (9)
        goto p380
        ::p583::
        tick(583)
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (9)
        registers[31] = (8)
        registers[32] = (7)
        goto p123
        ::p590::
        tick(590)
        registers[17] = registers[2] % 1
        registers[2] = (registers[2] - registers[17])
        goto p450
        ::p594::
        registers[13]["__concat"] = registers[12]
        registers[13]["__index"] = registers[12]
        registers[13]["__newindex"] = registers[12]
        registers[13]["__metatable"] = false
        goto p742
        ::p601::
        registers[14] = (4)
        registers[15] = (5)
        registers[16] = (6)
        registers[17] = (7)
        goto p62
        ::p606::
        tick(606)
        q = registers[(21)]
        q[1] = registers[22]
        q[2] = registers[23]
        q[3] = registers[24]
        q[4] = registers[25]
        q[5] = registers[26]
        q[6] = registers[27]
        q[7] = registers[28]
        q[8] = registers[29]
        q[9] = registers[30]
        q[10] = registers[31]
        q[11] = registers[32]
        q[12] = registers[33]
        q[13] = registers[34]
        q[14] = registers[35]
        q[15] = registers[36]
        registers[22] = new_frame(15)
        registers[22][0] = 13
        registers[23] = (12)
        registers[24] = (15)
        goto p830
        ::p613::
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        registers[32] = (7)
        goto p545
        ::p618::
        tick(618)
        registers[17][registers[18]] = registers[25]
        registers[17][registers[22]] = registers[23]
        goto p756
        ::p621::
        registers[35] = (0)
        registers[36] = (3)
        registers[37] = (2)
        goto p143
        ::p625::
        tick(625)
        registers[27] = (2)
        registers[28] = (3)
        registers[29] = (0)
        goto p780
        ::p629::
        registers[16] = registers[14] > registers[14]
        goto p67
        ::p631::
        tick(631)
        registers[18] = registers[1]
        registers[19] = (1)
        registers[20] = (4)
        m, x = pack_returns(registers[17](unpack_range(20, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[13] = (1)
        goto p462
        ::p638::
        registers[30] = (5)
        registers[31] = (4)
        registers[32] = (7)
        goto p675
        ::p642::
        registers[16] = registers[14]
        goto p515
        ::p644::
        tick(644)
        if registers[13] ~= registers[18] then
            goto p671
        end
        goto p100
        ::p646::
        tick(646)
        registers[2] = (registers[2] >= 461)
        if not registers[2] then
            goto p754
        end
        goto p251
        ::p649::
        registers[22] = registers[4]
        registers[23] = registers[13];
        registers[(22)] = registers[(22)](registers[23])
        goto p33
        ::p653::
        tick(653)
        registers[22] = (9)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        goto p625
        ::p661::
        tick(661)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (9)
        registers[19] = (8)
        registers[20] = (11)
        goto p39
        ::p667::
        registers[26] = registers[26](registers[27], registers[28])
        registers[26] = registers[16][registers[26]]
        registers[21] = (registers[21]..registers[26])
        goto p519
        ::p671::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[17] = z;
            registers[18] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p644
        end
        goto p496
        ::p673::
        registers[2] = (352)
        goto p646
        ::p675::
        registers[33] = (6)
        q = registers[(18)]
        q[1] = registers[19]
        q[2] = registers[20]
        q[3] = registers[21]
        q[4] = registers[22]
        q[5] = registers[23]
        q[6] = registers[24]
        q[7] = registers[25]
        q[8] = registers[26]
        q[9] = registers[27]
        q[10] = registers[28]
        q[11] = registers[29]
        q[12] = registers[30]
        q[13] = registers[31]
        q[14] = registers[32]
        q[15] = registers[33]
        registers[19] = new_frame(15)
        registers[19][0] = 10
        registers[20] = (11)
        registers[21] = (8)
        goto p653
        ::p682::
        tick(682)
        registers[12] = new_frame(4)
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = registers[5]
        goto p631
        ::p686::
        tick(686)
        registers[5] = environment["string"]
        registers[5] = registers[5]["byte"]
        registers[6] = environment["setmetatable"]
        registers[7] = environment["getmetatable"]
        goto p182
        ::p691::
        registers[17] = registers[2] % 256
        registers[12][registers[16]] = registers[17]
        registers[2] = registers[2] / 256
        goto p590
        ::p695::
        registers[17] = {
        }
        registers[18] = (0)
        registers[19] = (255)
        registers[20] = (1)
        goto p201
        ::p700::
        tick(700)
        registers[13] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[13]()
        end
        ::p703::
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        goto p425
        ::p707::
        registers[14] = registers[7]
        registers[15] = registers[12];
        registers[(14)] = registers[(14)](registers[15])
        if registers[14] == registers[0] then
            goto p132
        end
        goto p700
        ::p712::
        registers[17] = (4)
        registers[18] = (5)
        registers[19] = (2)
        registers[20] = (3)
        registers[21] = (0)
        registers[22] = (1)
        goto p532
        ::p719::
        registers[21] = (12)
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (8)
        goto p138
        ::p725::
        tick(725)
        registers[24] = registers[24] + 1
        registers[24] = registers[12][registers[24]]
        registers[23] = registers[23] + registers[24]
        registers[18] = registers[23] % 256
        registers[23] = registers[17][registers[18]]
        registers[25] = registers[17][registers[22]]
        goto p618
        ::p732::
        tick(732)
        registers[23] = registers[17][registers[22]]
        registers[23] = registers[18] + registers[23]
        registers[24] = registers[22] % 8
        goto p725
        ::p736::
        if registers[13] == registers[14] then
            goto p682
        end
        goto p740
        ::p738::
        if registers[2] then
            goto p766
        end
        goto p256
        ::p740::
        registers[16] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[16]()
        end
        ::p742::
        registers[14] = registers[6]
        registers[15] = {
        }
        registers[16] = registers[13]
        registers[14] = registers[14](registers[15], registers[16])
        goto p772
        ::p748::
        registers[11] = (0)
        registers[12] = (3)
        registers[13] = (2)
        registers[14] = (5)
        registers[15] = (4)
        goto p661
        ::p754::
        if registers[2] then
            goto p317
        end
        goto p216
        ::p756::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[22] = v
            branch_taken = true
        end
        if branch_taken then
            goto p732
        end
        goto p271
        ::p766::
        registers[2] = registers[2] + 385
        registers[2] = -621382508 + registers[2]
        registers[3] = registers
        registers[4] = environment["string"]
        registers[4] = registers[4]["char"]
        goto p686
        ::p772::
        registers[15] = registers[14]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        m, x = pack_returns(registers[18]())
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        a = D.f12
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p171
        ::p780::
        registers[30] = (1)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (4)
        goto p308
        ::p785::
        a = D.f13
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[13] = {
        }
        registers[13]["__tostring"] = registers[11]
        registers[13]["__call"] = registers[12]
        registers[13]["__add"] = registers[12]
        registers[13]["__sub"] = registers[12]
        registers[13]["__mul"] = registers[12]
        registers[13]["__div"] = registers[12]
        goto p324
        ::p802::
        registers[37] = (0)
        registers[38] = (1)
        q = registers[(23)]
        q[1] = registers[24]
        q[2] = registers[25]
        q[3] = registers[26]
        q[4] = registers[27]
        q[5] = registers[28]
        q[6] = registers[29]
        q[7] = registers[30]
        q[8] = registers[31]
        q[9] = registers[32]
        q[10] = registers[33]
        q[11] = registers[34]
        q[12] = registers[35]
        q[13] = registers[36]
        q[14] = registers[37]
        q[15] = registers[38]
        registers[24] = new_frame(15)
        registers[24][0] = 15
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        goto p583
        ::p811::
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        registers[20] = (3)
        goto p536
        ::p816::
        registers[30] = (5)
        registers[31] = (6)
        registers[32] = (7)
        registers[33] = (0)
        registers[34] = (1)
        registers[35] = (2)
        registers[36] = (3)
        goto p606
        ::p826::
        registers[13] = new_frame(15)
        registers[13][0] = 4
        registers[14] = (5)
        goto p550
        ::p830::
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        registers[28] = (11)
        goto p541
        ::p835::
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        goto p400
        ::p839::
        registers[26] = registers[19] + 1
        registers[19] = registers[26] % 256
        registers[26] = registers[17][registers[19]]
        registers[26] = registers[20] + registers[26]
        goto p430
    end
end
