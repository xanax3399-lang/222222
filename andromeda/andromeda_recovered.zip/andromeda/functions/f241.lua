-- Recovered function f241; author names are unavailable.
F.f241 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f241")
        tick(1)
        goto p26
        ::p9::
        tick(9)
        do
            return 
        end
        ::p23::
        tick(23)
        registers[(6)](unpack_range(9, registers, 7))
        goto p54
        ::p26::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        z = registers[1]
        registers[4] = z;
        registers[(3)] = z["build_maps"]
        registers[(3)](registers[4])
        goto p144
        ::p30::
        tick(30)
        registers[6] = registers[5]["Visuals"]
        if not registers[6] then
            goto p54
        end
        goto p76
        ::p35::
        tick(35)
        z = registers[1]
        registers[7] = z;
        registers[(6)] = z["apply_group"]
        registers[8] = registers[1]["maps"]
        registers[8] = registers[8]["antiaim"]
        goto p159
        ::p50::
        tick(50)
        registers[5] = upvalues[0][86]
        registers[6] = "play resource/warning.wav"
        registers[(5)](registers[6])
        goto p9
        ::p54::
        registers[6] = upvalues[0][86]
        registers[7] = "play ui\\beepclear"
        registers[(6)](registers[7])
        do
            return 
        end
        ::p66::
        tick(66)
        do
            return 
        end
        ::p76::
        z = registers[1]
        registers[7] = z;
        registers[(6)] = z["apply_group"]
        registers[8] = registers[1]["maps"]
        registers[8] = registers[8]["visuals"]
        registers[9] = registers[4]["visuals"]
        goto p23
        ::p81::
        tick(81)
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if registers[5] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p127
        end
        goto p50
        ::p96::
        tick(96)
        registers[5] = registers[3][2]
        if registers[5] ~= "" then
            goto p162
        end
        goto p112
        ::p100::
        tick(100)
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["decode"]
        registers[6] = registers[3][2]
        registers[4] = registers[4](registers[5], registers[6])
        registers[5] = environment["type"]
        goto p81
        ::p112::
        tick(112)
        registers[4] = upvalues[0][86]
        registers[5] = "play resource/warning.wav"
        registers[(4)](registers[5])
        goto p66
        ::p123::
        tick(123)
        registers[4] = registers[3][2]
        if registers[4] == registers[0] then
            goto p112
        end
        goto p96
        ::p127::
        z = registers[1]
        registers[6] = z;
        registers[(5)] = z["get_selected_groups"];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = registers[5]["Antiaim"]
        goto p149
        ::p131::
        tick(131)
        do
            return 
        end
        ::p140::
        tick(140)
        registers[4] = upvalues[0][86]
        registers[5] = "play resource/warning.wav"
        registers[(4)](registers[5])
        goto p131
        ::p144::
        registers[3] = registers[1]["configs_db"]
        registers[3] = registers[3]["cfg_list"]
        registers[3] = registers[3][registers[2]]
        if not registers[3] then
            goto p112
        end
        goto p123
        ::p149::
        if not registers[6] then
            goto p30
        end
        goto p35
        ::p159::
        registers[9] = registers[4]["antiaim"]
        registers[(6)](unpack_range(9, registers, 7))
        goto p30
        ::p162::
        registers[4] = registers[1]["configs_db"]
        registers[4] = registers[4]["cfg_list"]
        registers[4] = (#registers[4])
        if not (registers[4] < registers[2]) then
            goto p100
        end
        goto p140
    end
end
