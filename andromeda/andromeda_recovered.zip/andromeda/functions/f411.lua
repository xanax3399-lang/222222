-- Recovered function f411; author names are unavailable.
F.f411 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f411")
        tick(1)
        goto p73
        ::p2::
        tick(2)
        registers[16] = (10)
        registers[17] = registers[12]
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[13] = registers[13](unpack_range(top, registers, 14))
        registers[12] = registers[13]
        registers[13] = (1)
        registers[14] = (10)
        goto p52
        ::p13::
        tick(13)
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        goto p21
        ::p17::
        tick(17)
        registers[11] = (registers[10] == "Jitter")
        goto p135
        ::p21::
        tick(21)
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["conditions"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"]
        goto p196
        ::p27::
        tick(27)
        if registers[12] then
            goto p29
        end
        goto p137
        ::p29::
        tick(29)
        registers[13] = upvalues[3][151]
        a = registers
        z = 14;
        a[z] = 0
        registers[15] = upvalues[3][162]
        goto p2
        ::p35::
        tick(35)
        registers[11] = (registers[11] == "Custom")
        goto p129
        ::p37::
        tick(37)
        registers[17] = registers[9]["slots"]
        registers[17] = registers[17][registers[16]]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["set_visible"]
        registers[19] = registers[11]
        if not registers[19] then
            goto p155
        end
        goto p54
        ::p43::
        tick(43)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p127
        ::p52::
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p148
        ::p54::
        registers[19] = (registers[16] <= registers[12])
        goto p155
        ::p56::
        tick(56)
        registers[12] = upvalues[3][154]
        registers[13] = registers[9]["count"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["get"]
        goto p164
        ::p63::
        tick(63)
        registers[11] = registers[8]["values"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        goto p35
        ::p73::
        tick(73)
        registers[1] = upvalues[0]["switch"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        goto p214
        ::p101::
        tick(101)
        registers[11] = registers[7]["state_name"]
        registers[11] = registers[2] == registers[11]
        goto p152
        ::p127::
        tick(127)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p217
        end
        goto p246
        ::p129::
        tick(129)
        registers[12] = registers[11]
        if not registers[12] then
            goto p27
        end
        goto p56
        ::p135::
        tick(135)
        if not registers[11] then
            goto p231
        end
        goto p180
        ::p137::
        registers[12] = (0)
        goto p29
        ::p139::
        tick(139)
        registers[11] = registers[8]["type"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[11] ~= "Off")
        goto p209
        ::p148::
        tick(148)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p37
        end
        goto p43
        ::p150::
        tick(150)
        registers[11] = (registers[11] == "Default")
        goto p231
        ::p152::
        tick(152)
        if not registers[11] then
            goto p135
        end
        goto p211
        ::p155::;
        registers[17](registers[18], registers[19])
        goto p148
        ::p164::
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        goto p27
        ::p180::
        a = registers
        z = (11)
        q = registers
        q = q[7]
        q = q["builder_type"]
        a[z] = q
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        goto p150
        ::p196::;
        registers[(2)] = registers[(2)](registers[3])
        a = registers
        z = 3;
        a[z] = 1
        registers[4] = upvalues[2]
        registers[4] = (#registers[4])
        registers[5] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p127
        registers[34] = code_metadata
        registers[40] = operand_k
        registers[34][73] = 111
        registers[40][61] = 244
        registers[33] = nil
        registers[34] = nil
        registers[35] = nil
        registers[36] = nil
        registers[37] = nil
        registers[38] = nil
        registers[39] = nil
        registers[40] = nil
        goto p73
        ::p209::
        tick(209)
        if not registers[11] then
            goto p129
        end
        goto p63
        ::p211::
        registers[11] = (registers[10] == "Off")
        if registers[11] then
            goto p135
        end
        goto p17
        ::p214::
        registers[1] = (registers[1] == "Anti-Aim")
        if not registers[1] then
            goto p21
        end
        goto p13
        ::p217::
        registers[7] = upvalues[2][registers[6]]
        a = registers
        z = (8)
        q = registers
        q = q[7]
        q = q["delay"]
        a[z] = q
        registers[9] = registers[8]["custom"]
        registers[10] = upvalues[0]["builder"]
        registers[11] = registers[7]["state_name"]
        registers[10] = registers[10][registers[11]]
        registers[10] = registers[10]["body_yaw"]
        registers[10] = registers[10]["type"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        goto p233
        ::p231::
        if not registers[11] then
            goto p209
        end
        goto p139
        ::p233::
        registers[11] = registers[1]
        if not registers[11] then
            goto p152
        end
        goto p101
        ::p246::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
    end
end
