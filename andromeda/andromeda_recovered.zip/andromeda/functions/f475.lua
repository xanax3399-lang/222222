-- Recovered function f475; author names are unavailable.
F.f475 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f475")
        tick(1)
        goto p12
        ::p2::
        tick(2)
        slot_3 = slot_2 > 0.5
        do
            return slot_3
        end
        ::p6::
        tick(6)
        slot_2 = (0)
        goto p2
        ::p8::
        tick(8)
        slot_4 = "m_flDuckAmount"
        slot_2 = slot_2(slot_3, slot_4)
        if slot_2 then
            goto p2
        end
        goto p6
        ::p12::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][47]
        slot_3 = slot_1
        goto p8
    end
end
