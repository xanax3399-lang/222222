-- Recovered function f338; author names are unavailable.
F.f338 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f338")
        tick(1)
        tick(2)
        upvalues[0]["hotkey_active"] = false
        upvalues[0]["updated_this_tick"] = false
        slot_1 = upvalues[0]["update_hitchance"]
        slot_1()
        do
            return 
        end
    end
end
