-- Recovered function f72; author names are unavailable.
F.f72 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local tick = new_tick("f72")
        tick(1)
        tick(2)
        do
            return 
        end
    end
end
