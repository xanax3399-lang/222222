-- Recovered function f419; author names are unavailable.
F.f419 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f419")
        tick(1)
        goto p7
        ::p2::
        tick(2)
        if not (0 < slot_2) then
            goto p79
        end
        goto p11
        ::p5::
        tick(5)
        if not (0 < slot_1) then
            goto p79
        end
        goto p2
        ::p7::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p5
        ::p11::
        slot_5 = slot_1 % 2
        slot_6 = slot_2 % 2
        if slot_5 == slot_6 then
            goto p17
        end
        goto p77
        ::p15::
        tick(15)
        slot_4 = slot_4 + slot_3
        goto p72
        ::p17::
        tick(17)
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 2
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 2
        slot_3 = (slot_3 * 2)
        goto p5
        ::p33::
        tick(33)
        slot_1 = slot_2
        goto p70
        ::p64::
        tick(64)
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p67::
        tick(67)
        slot_5 = slot_1 % 2
        if not (0 < slot_5) then
            goto p72
        end
        goto p15
        ::p70::
        tick(70)
        if not (0 < slot_1) then
            goto p64
        end
        goto p67
        ::p72::
        slot_6 = (slot_1 - slot_5)
        slot_1 = slot_6 / 2
        slot_3 = (slot_3 * 2)
        goto p70
        ::p77::
        slot_4 = slot_4 + slot_3
        goto p17
        ::p79::
        if not (slot_1 < slot_2) then
            goto p70
        end
        goto p33
    end
end
