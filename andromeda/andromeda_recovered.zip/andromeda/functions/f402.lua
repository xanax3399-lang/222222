-- Recovered function f402; author names are unavailable.
F.f402 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f402")
        tick(1)
        goto p61
        ::p2::
        tick(2)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "BODY"
        registers[6] = (1)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p312
        end
        goto p268
        ::p14::
        tick(14)
        registers[4] = ""
        goto p340
        ::p21::
        tick(21)
        branch_taken = false
        if registers[2] ~= "FS" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p203
        end
        goto p143
        ::p25::
        tick(25)
        if registers[2] ~= "DMG" then
            goto p83
        end
        goto p85
        ::p29::
        tick(29);
        registers[5] = registers[5](unpack_range(9, registers, 6))
        if registers[5] == registers[0] then
            goto p38
        end
        goto p361
        ::p32::
        tick(32)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p201
        end
        goto p168
        ::p38::
        branch_taken = false
        if registers[2] ~= "HC" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p136
        end
        goto p270
        ::p40::
        tick(40)
        registers[8] = (true);
        registers[4] = registers[4](unpack_range(8, registers, 5))
        if registers[4] ~= registers[0] then
            goto p361
        end
        goto p116
        ::p59::
        tick(59)
        branch_taken = false
        if registers[2] ~= "DUCK" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p128
        end
        goto p138
        ::p61::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["string"]
        registers[2] = registers[2]["upper"]
        registers[3] = environment["tostring"]
        goto p363
        ::p74::
        tick(74)
        registers[3] = "bomb_planting"
        do
            return registers[3]
        end
        ::p76::
        tick(76)
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["find"]
        registers[6] = "SHOT"
        registers[7] = (1)
        registers[8] = (true)
        goto p367
        ::p81::
        tick(81)
        registers[3] = "safe"
        do
            return registers[3]
        end
        ::p83::
        branch_taken = false
        if registers[2] ~= "OSAA" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p126
        end
        goto p314
        ::p85::
        tick(85)
        registers[3] = "damage"
        do
            return registers[3]
        end
        ::p87::
        tick(87)
        branch_taken = false
        if registers[2] ~= "DA" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p149
        end
        goto p304
        ::p90::
        tick(90)
        branch_taken = false
        if registers[2] ~= "MD" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p85
        end
        goto p318
        ::p92::
        tick(92)
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["find"]
        registers[6] = "PLANTED"
        registers[7] = (1)
        registers[8] = (true)
        goto p327
        ::p116::
        z = registers[2]
        registers[6] = z;
        registers[(5)] = z["find"]
        registers[7] = "C4"
        registers[8] = (1)
        registers[9] = (true)
        goto p29
        ::p122::
        tick(122)
        registers[3] = "fatal"
        do
            return registers[3]
        end
        ::p126::
        tick(126)
        registers[3] = "osaa"
        do
            return registers[3]
        end
        ::p128::
        tick(128)
        registers[3] = "duck"
        do
            return registers[3]
        end
        ::p130::
        tick(130)
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["find"]
        registers[6] = "DAMAGE"
        registers[7] = (1)
        registers[8] = (true);
        registers[4] = registers[4](unpack_range(8, registers, 5))
        goto p213
        ::p136::
        tick(136)
        registers[3] = "hc"
        do
            return registers[3]
        end
        ::p138::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "FD"
        registers[6] = (1)
        registers[7] = (true)
        goto p324
        ::p143::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "FREESTAND"
        registers[6] = (1)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        goto p155
        ::p149::
        tick(149)
        registers[3] = "dormant"
        do
            return registers[3]
        end
        ::p151::
        tick(151)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p90
        end
        goto p136
        ::p155::
        if registers[3] == registers[0] then
            goto p349
        end
        goto p203
        ::p157::
        tick(157)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "SAFE"
        registers[6] = (1)
        registers[7] = (true)
        goto p190
        ::p163::
        tick(163)
        branch_taken = false
        if registers[2] ~= "BODY" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p268
        end
        goto p2
        ::p166::
        tick(166)
        registers[3] = nil
        do
            return registers[3]
        end
        ::p168::
        tick(168)
        registers[3] = "ping"
        do
            return registers[3]
        end
        ::p170::
        tick(170)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "FATAL"
        registers[6] = (1)
        registers[7] = (true)
        goto p351
        ::p184::
        tick(184)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "DOUBLE"
        registers[6] = (1)
        goto p262
        ::p190::;
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p163
        end
        goto p81
        ::p201::
        branch_taken = false
        if registers[2] ~= "SAFE" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p81
        end
        goto p157
        ::p203::
        registers[3] = "fs"
        do
            return registers[3]
        end
        ::p213::
        if registers[4] ~= registers[0] then
            goto p85
        end
        goto p25
        ::p216::
        tick(216)
        if registers[2] ~= "B" then
            goto p281
        end
        goto p332
        ::p233::
        tick(233)
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["find"]
        registers[6] = "BOMB"
        registers[7] = (1)
        goto p40
        ::p247::
        tick(247)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "B%s*%-"
        registers[6] = (1)
        registers[7] = (false);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] ~= registers[0] then
            goto p361
        end
        goto p233
        ::p262::
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p322
        end
        ::p266::
        tick(266)
        registers[3] = "dt"
        do
            return registers[3]
        end
        ::p268::
        registers[3] = "body"
        do
            return registers[3]
        end
        ::p270::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "HC "
        registers[6] = (1)
        goto p151
        ::p281::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "PLANTING"
        registers[6] = (1)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p370
        end
        goto p74
        ::p288::
        tick(288)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] ~= registers[0] then
            goto p85
        end
        goto p130
        ::p298::
        tick(298)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p59
        end
        goto p149
        ::p304::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "DORMANT"
        registers[6] = (1)
        goto p298
        ::p308::
        tick(308)
        registers[7] = (true);
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] ~= registers[0] then
            goto p126
        end
        goto p76
        ::p312::
        branch_taken = false
        if registers[2] ~= "FATAL" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p122
        end
        goto p170
        ::p314::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "HIDE"
        registers[6] = (1)
        goto p308
        ::p318::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "MD "
        registers[6] = (1)
        goto p288
        ::p322::
        branch_taken = false
        if registers[2] ~= "PING" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p168
        end
        goto p375
        ::p324::;
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p21
        end
        goto p128
        ::p327::;
        registers[4] = registers[4](unpack_range(8, registers, 5))
        if registers[4] == registers[0] then
            goto p354
        end
        goto p347
        ::p332::
        tick(332)
        registers[3] = "bomb_planting"
        do
            return registers[3]
        end
        ::p340::
        tick(340)
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        branch_taken = false
        if registers[2] ~= "A" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p332
        end
        goto p216
        ::p345::
        tick(345)
        registers[3] = "bomb_hp"
        do
            return registers[3]
        end
        ::p347::
        tick(347)
        registers[3] = "planted_bomb"
        do
            return registers[3]
        end
        ::p349::
        branch_taken = false
        if registers[2] ~= "DT" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p266
        end
        goto p184
        ::p351::;
        registers[3] = registers[3](unpack_range(7, registers, 4))
        if registers[3] == registers[0] then
            goto p166
        end
        goto p122
        ::p354::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["match"]
        registers[5] = "^%-?%d+%s*HP$"
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] == registers[0] then
            goto p247
        end
        goto p345
        ::p361::
        registers[3] = "bomb"
        do
            return registers[3]
        end
        ::p363::
        registers[4] = registers[1]
        if registers[4] then
            goto p340
        end
        goto p14
        ::p367::;
        registers[4] = registers[4](unpack_range(8, registers, 5))
        if registers[4] == registers[0] then
            goto p87
        end
        goto p126
        ::p370::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["match"]
        registers[5] = "^[AB]%s*%-%s*[%d%.]+S"
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] ~= registers[0] then
            goto p347
        end
        goto p92
        ::p375::
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["find"]
        registers[5] = "PING"
        registers[6] = (1)
        goto p32
    end
end
