-- Recovered function f329; author names are unavailable.
F.f329 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f329")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_1 == slot_0 then
            goto p45
        end
        goto p40
        ::p12::
        tick(12)
        slot_4 = ""
        goto p43
        ::p40::
        slot_3 = environment["tostring"]
        slot_4 = slot_1
        do
            return slot_3(slot_4)
        end
        ::p43::
        tick(43)
        do
            return slot_3(slot_4)
        end
        ::p45::
        slot_3 = environment["tostring"]
        slot_4 = slot_2
        if slot_4 then
            goto p43
        end
        goto p12
    end
end
