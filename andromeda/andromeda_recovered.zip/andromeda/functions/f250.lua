-- Recovered function f250; author names are unavailable.
F.f250 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f250")
        tick(1)
        goto p43
        ::p2::
        tick(2)
        registers[2] = upvalues[0][40];
        registers[2] = registers[2]()
        if registers[2] ~= registers[0] then
            goto p46
        end
        goto p30
        ::p18::
        tick(18)
        registers[5] = registers[3]
        do
            return registers[5]
        end
        ::p30::
        registers[3] = nil
        do
            return registers[3]
        end
        ::p41::
        tick(41)
        registers[5] = (registers[3] / registers[4])
        do
            return registers[5]
        end
        ::p43::
        tick(43)
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] ~= registers[0] then
            goto p2
        end
        goto p64
        ::p46::
        registers[3] = upvalues[0][47]
        registers[4] = registers[2]
        registers[5] = "m_iKills"
        registers[6] = registers[1];
        registers[3] = registers[3](unpack_range(6, registers, 4))
        if registers[3] then
            goto p53
        end
        goto p62
        ::p53::
        tick(53)
        registers[4] = upvalues[0][47]
        registers[5] = registers[2]
        registers[6] = "m_iDeaths"
        registers[7] = registers[1];
        registers[4] = registers[4](unpack_range(7, registers, 5))
        if registers[4] then
            goto p76
        end
        registers[4] = (0)
        goto p76
        ::p62::
        registers[3] = (0)
        goto p53
        ::p64::
        registers[2] = nil
        do
            return registers[2]
        end
        ::p76::
        if not (0 < registers[4]) then
            goto p18
        end
        goto p41
    end
end
