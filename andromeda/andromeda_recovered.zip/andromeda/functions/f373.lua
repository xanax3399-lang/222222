-- Recovered function f373; author names are unavailable.
F.f373 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f373")
        tick(1)
        goto p16
        ::p2::
        tick(2)
        slot_3 = (0)
        ::p5::
        tick(5)
        slot_3 = slot_3 + 1
        slot_2 = slot_2[slot_3]
        if slot_2 then
            goto p43
        end
        goto p40
        ::p16::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["hitgroups"]
        slot_3 = environment["tonumber"]
        goto p44
        ::p40::
        slot_2 = "?"
        ::p43::
        do
            return slot_2
        end
        ::p44::
        slot_4 = slot_1;
        slot_3 = slot_3(slot_4)
        if slot_3 then
            goto p5
        end
        goto p2
    end
end
