-- Recovered function f146; author names are unavailable.
F.f146 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f146")
        tick(1)
        goto p57
        ::p2::
        tick(2)
        if registers[4] then
            goto p89
        end
        goto p158
        ::p4::
        tick(4)
        registers[6] = upvalues[1]["is_double_tap"];
        registers[6] = registers[6]()
        if not registers[6] then
            goto p29
        end
        goto p160
        ::p22::
        tick(22)
        registers[1]["force_defensive_active"] = true
        registers[2]["force_defensive"] = true
        do
            return 
        end
        ::p26::
        tick(26)
        if registers[4] ~= registers[0] then
            goto p140
        end
        goto p146
        ::p29::
        tick(29)
        do
            return 
        end
        ::p36::
        tick(36)
        registers[6] = upvalues[1]["is_on_shot_antiaim"];
        registers[6] = registers[6]()
        if not registers[6] then
            goto p26
        end
        goto p151
        ::p43::
        tick(43)
        registers[6] = upvalues[1]["is_on_shot_antiaim"];
        registers[6] = registers[6]()
        if not registers[6] then
            goto p110
        end
        goto p22
        ::p57::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[1]["force_defensive_active"] = false
        registers[2]["force_defensive"] = false
        registers[4] = registers[3]
        if not registers[4] then
            goto p2
        end
        goto p107
        ::p89::
        tick(89)
        z = registers[1]
        registers[6] = z;
        registers[(5)] = z["is_hidden_enabled"]
        registers[7] = registers[3]
        registers[5] = registers[5](registers[6], registers[7])
        a = upvalues[0];
        registers[6] = a[2][a[1]]["exploits"]
        goto p127
        ::p99::
        tick(99)
        registers[6] = upvalues[1]["is_double_tap"];
        registers[6] = registers[6]()
        if registers[6] then
            goto p151
        end
        goto p36
        ::p103::
        tick(103)
        registers[6] = registers[2]["command_number"]
        registers[6] = registers[6] % 7
        registers[6] = (registers[6] == 0)
        goto p118
        ::p107::
        registers[4] = registers[3]["force_defensive"]
        goto p2
        ::p110::
        tick(110)
        z = registers[4]
        registers[7] = z;
        registers[(6)] = z["get"]
        registers[8] = "Double tap"
        registers[6] = registers[6](registers[7], registers[8])
        if not registers[6] then
            goto p29
        end
        goto p4
        ::p116::
        tick(116)
        if not registers[5] then
            goto p26
        end
        goto p99
        ::p118::
        tick(118)
        registers[2]["force_defensive"] = registers[6]
        do
            return 
        end
        ::p127::
        registers[6] = registers[6]["charged"]
        if registers[6] then
            goto p171
        end
        registers[1]["backtrack_cleaner_timer"] = 0
        do
            return 
        end
        ::p140::
        z = registers[4]
        registers[7] = z;
        registers[(6)] = z["get"]
        registers[8] = "On shot anti-aim"
        registers[6] = registers[6](registers[7], registers[8])
        if not registers[6] then
            goto p110
        end
        goto p43
        ::p146::
        do
            return 
        end
        ::p151::
        registers[1]["force_defensive_active"] = true
        registers[6] = environment["type"]
        registers[7] = registers[2]["command_number"];
        registers[(6)] = registers[(6)](registers[7])
        registers[6] = (registers[6] ~= "number")
        if registers[6] then
            goto p118
        end
        goto p103
        ::p158::
        registers[4] = nil
        goto p89
        ::p160::
        registers[1]["force_defensive_active"] = true
        registers[2]["force_defensive"] = true
        do
            return 
        end
        ::p171::
        z = registers[1]
        registers[7] = z;
        registers[(6)] = z["update_invalid_tick_cleaner"]
        registers[8] = registers[2]
        registers[9] = registers[3]
        registers[(6)](unpack_range(9, registers, 7))
        goto p116
    end
end
