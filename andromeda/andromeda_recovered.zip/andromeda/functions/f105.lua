-- Recovered function f105; author names are unavailable.
F.f105 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f105")
        tick(1)
        goto p43
        ::p3::
        tick(3);
        registers[(2)] = registers[(2)](registers[3])
        branch_taken = false
        if registers[2] ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p13
        end
        goto p17
        ::p13::
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["gsub"]
        registers[4] = "%z"
        registers[5] = ""
        goto p75
        ::p17::
        tick(17)
        registers[2] = nil
        do
            return registers[2]
        end
        ::p41::
        tick(41)
        if registers[2] then
            goto p66
        end
        goto p67
        ::p43::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["type"]
        registers[3] = registers[1]
        goto p3
        ::p66::
        tick(66)
        do
            return registers[2]
        end
        ::p67::
        registers[2] = nil
        goto p66
        ::p69::
        tick(69)
        registers[5] = "";
        registers[2] = registers[2](unpack_range(5, registers, 3))
        registers[1] = registers[2]
        registers[2] = (registers[1] ~= "")
        if not registers[2] then
            goto p41
        end
        goto p80
        ::p75::;
        registers[2] = registers[2](unpack_range(5, registers, 3))
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["gsub"]
        registers[4] = "%s+"
        goto p69
        ::p80::
        registers[2] = registers[1]
        goto p41
    end
end
