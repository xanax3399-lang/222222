-- Recovered function f213; author names are unavailable.
F.f213 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f213")
        tick(1)
        goto p51
        ::p2::
        tick(2)
        slot_4 = (1)
        goto p55
        ::p20::
        tick(20)
        if slot_4 then
            goto p55
        end
        goto p2
        ::p51::
        tick(51)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0][154]
        slot_4 = slot_2
        goto p20
        ::p55::
        slot_4 = slot_1 * slot_4
        slot_4 = slot_4 + 0.5
        do
            return slot_3(slot_4)
        end
    end
end
