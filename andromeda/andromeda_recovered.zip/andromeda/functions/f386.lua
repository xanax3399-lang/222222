-- Recovered function f386; author names are unavailable.
F.f386 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f386")
        tick(1)
        goto p16
        ::p2::
        tick(2)
        do
            return 
        end
        ::p14::
        tick(14)
        if slot_3 then
            goto p98
        end
        goto p45
        ::p16::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p73
        end
        goto p84
        ::p20::
        tick(20)
        slot_2 = upvalues[0]["player_state"]
        slot_3 = environment["tonumber"]
        slot_4 = slot_1["target"];
        slot_3 = slot_3(slot_4)
        goto p14
        ::p34::
        tick(34)
        slot_4 = (0)
        goto p74
        ::p36::
        tick(36)
        if slot_4 then
            goto p74
        end
        goto p34
        ::p38::
        tick(38)
        slot_2["stable_ticks"] = slot_3
        goto p2
        ::p40::
        tick(40)
        slot_4 = slot_4 + 2
        slot_5 = (12)
        slot_3 = slot_3(slot_4, slot_5)
        goto p38
        ::p45::
        slot_3 = slot_1["target"]
        goto p98
        ::p47::
        tick(47)
        slot_2["penalty_until"] = 0
        slot_3 = upvalues[1][23];
        slot_3 = slot_3()
        slot_3 = slot_3 + 24
        slot_2["boost_until"] = slot_3
        slot_3 = upvalues[1][162]
        slot_4 = slot_2["hit_streak"]
        goto p36
        ::p71::
        tick(71)
        slot_4 = (0)
        goto p40
        ::p73::
        tick(73)
        do
            return 
        end
        ::p74::
        slot_4 = slot_4 + 1
        slot_5 = (4)
        slot_3 = slot_3(slot_4, slot_5)
        slot_2["hit_streak"] = slot_3
        slot_2["miss_streak"] = 0
        slot_3 = upvalues[1][162]
        slot_4 = slot_2["stable_ticks"]
        if slot_4 then
            goto p40
        end
        goto p71
        ::p84::
        slot_2 = slot_1["target"]
        if slot_2 ~= slot_0 then
            goto p20
        end
        goto p73
        ::p98::
        slot_2 = slot_2[slot_3]
        if slot_2 == slot_0 then
            goto p2
        end
        goto p47
    end
end
