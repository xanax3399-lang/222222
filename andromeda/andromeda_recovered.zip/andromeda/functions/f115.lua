-- Recovered function f115; author names are unavailable.
F.f115 = function(function_metadata, upvalues)
    return function()

    end
end
