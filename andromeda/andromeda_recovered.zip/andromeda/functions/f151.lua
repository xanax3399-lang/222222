-- Recovered function f151; author names are unavailable.
F.f151 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f151")
        tick(1)
        goto p31
        ::p10::
        tick(10)
        slot_5["type"] = "180"
        slot_5 = upvalues[0]["yaw"]
        slot_5["body"] = 0
        goto p40
        ::p21::
        tick(21)
        if slot_6 then
            goto p104
        end
        goto p70
        ::p31::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = a[4]
        slot_5 = upvalues[0]["pitch"]
        slot_5["type"] = "Custom"
        slot_5 = upvalues[0]["pitch"]
        goto p108
        ::p36::
        tick(36)
        upvalues[0]["freestanding"] = false
        upvalues[0]["edge_yaw"] = false
        upvalues[0]["safehead_active"] = true
        do
            return 
        end
        ::p40::
        slot_5 = upvalues[0]["yaw"]
        slot_6 = slot_2
        if slot_6 then
            goto p56
        end
        slot_6 = (0)
        goto p56
        ::p48::
        tick(48)
        slot_5["value"] = slot_6
        slot_5 = upvalues[0]["body_yaw"]
        slot_5["freestanding"] = false
        slot_5 = upvalues[0]["yaw"]
        slot_5["base"] = "At targets"
        slot_5 = upvalues[0]["yaw"]
        goto p10
        ::p56::
        slot_5["add"] = slot_6
        slot_5 = upvalues[0]["yaw"]
        slot_5["value"] = 0
        goto p36
        ::p70::
        slot_6 = "Opposite"
        goto p104
        ::p73::
        tick(73)
        slot_6 = (0)
        goto p48
        ::p102::
        tick(102)
        if slot_6 then
            goto p48
        end
        goto p73
        ::p104::
        slot_5["type"] = slot_6
        slot_5 = upvalues[0]["body_yaw"]
        slot_6 = slot_4
        goto p102
        ::p108::
        slot_5["value"] = 89
        slot_5 = upvalues[0]["body_yaw"]
        slot_6 = slot_3
        goto p21
    end
end
