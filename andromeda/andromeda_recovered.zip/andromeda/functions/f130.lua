-- Recovered function f130; author names are unavailable.
F.f130 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f130")
        tick(1)
        goto p82
        ::p12::
        tick(12)
        slot_5 = upvalues[2]
        slot_6 = (11);
        slot_5 = slot_5(slot_6)
        slot_4["gap"] = slot_5
        slot_4["flags"] = "-"
        upvalues[0][slot_3] = slot_4
        do
            return 
        end
        ::p34::
        tick(34)
        slot_5 = environment["tostring"]
        slot_6 = slot_1;
        slot_5 = slot_5(slot_6)
        slot_4["text"] = slot_5
        a = upvalues[1];
        slot_5 = a[2][a[1]]
        slot_4["color"] = slot_5
        slot_5 = upvalues[2]
        slot_6 = (4);
        slot_5 = slot_5(slot_6)
        goto p89
        ::p82::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = upvalues[0]
        slot_3 = (#slot_3)
        slot_3 = slot_3 + 1
        slot_4 = {
        }
        goto p34
        ::p89::
        slot_4["gap"] = slot_5
        upvalues[0][slot_3] = slot_4
        slot_3 = upvalues[0]
        slot_3 = (#slot_3)
        slot_3 = slot_3 + 1
        slot_4 = {
        }
        slot_4["text"] = slot_2
        slot_5 = upvalues[3]
        slot_4["color"] = slot_5
        goto p12
    end
end
