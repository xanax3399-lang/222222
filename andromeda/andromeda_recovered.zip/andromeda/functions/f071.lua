-- Recovered function f71; author names are unavailable.
F.f71 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f71")
        tick(1)
        tick(22)
        slot_1 = (0)
        do
            return slot_1
        end
    end
end
