-- Recovered function f180; author names are unavailable.
F.f180 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1 = nil, nil
        local tick = new_tick("f180")
        tick(1)
        goto p15
        ::p2::
        tick(2)
        do
            return 
        end
        ::p15::
        slot_1 = {
        }
        upvalues[0]["delay_states"] = slot_1
        upvalues[0]["delay_next_switch_packet"] = 1
        upvalues[0]["delay_switch_count"] = 0
        upvalues[0]["delay_signature"] = slot_0
        slot_1 = {
        }
        upvalues[0]["defensive_yaw_double_states"] = slot_1
        slot_1 = {
        }
        goto p47
        ::p26::
        tick(26)
        upvalues[0]["last_exploit_charged"] = slot_0
        upvalues[0]["defensive_pitch_delay_side"] = false
        slot_1 = upvalues[2]
        slot_1()
        goto p2
        ::p47::
        upvalues[0]["hidden_modifier_meta_states"] = slot_1
        slot_1 = upvalues[1]
        slot_1()
        upvalues[0]["last_exploit_key_active"] = slot_0
        goto p26
    end
end
