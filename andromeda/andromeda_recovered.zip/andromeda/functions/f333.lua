-- Recovered function f333; author names are unavailable.
F.f333 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f333")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] then
            goto p70
        end
        goto p117
        ::p36::
        tick(36)
        registers[2] = upvalues[0][47]
        a = registers
        z = 3
        q = registers
        q = q[1]
        a[z] = q
        registers[4] = "m_flSimulationTime"
        registers[2] = registers[2](registers[3], registers[4])
        registers[3] = environment["type"]
        registers[4] = registers[2]
        goto p51
        ::p47::
        tick(47)
        upvalues[1][registers[1]] = registers[0]
        registers[3] = (0)
        registers[4] = (0)
        do
            return unpack_range(4, registers, (3))
        end
        ::p51::;
        registers[(3)] = registers[(3)](registers[4])
        branch_taken = false
        if registers[3] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p73
        end
        goto p47
        ::p58::
        tick(58)
        registers[3] = registers[2]
        goto p113
        ::p70::
        tick(70)
        if registers[1] ~= registers[0] then
            goto p36
        end
        goto p123
        ::p73::
        tick(73)
        registers[3] = upvalues[1][registers[1]]
        if registers[3] then
            goto p113
        end
        goto p58
        ::p111::
        tick(111)
        do
            return unpack_range(5, registers, (4))
        end
        ::p113::
        tick(113)
        upvalues[1][registers[1]] = registers[2]
        registers[4] = registers[2]
        registers[5] = registers[3]
        goto p111
        ::p117::
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        a = registers
        z = 1
        q = registers
        q = q[2]
        a[z] = q
        goto p70
        ::p123::
        registers[2] = (0)
        a = registers
        z = 3;
        a[z] = 0
        do
            return unpack_range(3, registers, (2))
        end
    end
end
