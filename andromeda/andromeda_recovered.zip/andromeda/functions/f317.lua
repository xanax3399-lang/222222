-- Recovered function f317; author names are unavailable.
F.f317 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f317")
        tick(1)
        goto p8
        ::p2::
        tick(2)
        registers[3] = upvalues[0]["shots"]
        registers[3][registers[2]] = registers[0]
        goto p12
        ::p5::
        tick(5)
        m, x = pack_returns(registers[1](unpack_range(2, registers, 2)))
        z = 0
        for f = 1, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(1)]
        n = registers[2]
        U = registers[3]
        goto p12
        goto p20
        ::p8::
        registers[1] = upvalues[0]["items"]
        registers[1] = (#registers[1])
        registers[2] = (1)
        goto p26
        ::p12::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[2] = z;
            registers[3] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p2
        end
        goto p17
        ::p14::
        tick(14)
        registers[5] = upvalues[0]["items"]
        registers[5][registers[4]] = registers[0]
        goto p24
        ::p17::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p20::
        tick(20)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = environment["pairs"]
        registers[2] = upvalues[0]["shots"]
        goto p5
        ::p24::
        tick(24)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p14
        end
        goto p20
        ::p26::
        registers[3] = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p24
        error("ANDROMEDA_INVALID_FALLTHROUGH: f317 pc=27", 0)
    end
end
