-- Recovered function f263; author names are unavailable.
F.f263 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f263")
        tick(1)
        goto p22
        ::p2::
        tick(2)
        z = registers[3]
        registers[7] = z;
        registers[(6)] = z["set"]
        registers[8] = registers[5][registers[2]];
        registers[6](registers[7], registers[8])
        goto p44
        ::p6::
        tick(6)
        a = registers
        z = 5
        q = upvalues
        m = (5)
        q = q[m]
        m = registers
        m = m[1]
        q = q[m]
        a[z] = q
        if registers[5] then
            goto p130
        end
        goto p192
        ::p13::
        tick(13)
        if not registers[4] then
            goto p62
        end
        goto p159
        ::p22::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[3] ~= registers[0] then
            goto p34
        end
        goto p52
        ::p27::
        tick(27)
        z = registers[3]
        registers[6] = z;
        registers[(5)] = z["set_visible"]
        registers[7] = (false);
        registers[5](registers[6], registers[7])
        goto p51
        ::p31::
        tick(31)
        registers[4] = upvalues[3];
        registers[4] = registers[4]()
        goto p62
        ::p34::
        registers[4] = upvalues[0]
        registers[4] = registers[1] == registers[4]
        if not registers[4] then
            goto p13
        end
        goto p138
        ::p39::
        tick(39)
        z = registers[3]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if registers[5] ~= "Default" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p152
        end
        goto p112
        ::p44::
        tick(44)
        registers[5][registers[2]] = registers[0]
        registers[6] = environment["next"]
        a = registers
        z = 7
        q = registers
        q = q[5]
        a[z] = q;
        registers[(6)] = registers[(6)](registers[7])
        goto p200
        ::p51::
        tick(51)
        do
            return 
        end
        ::p52::
        do
            return 
        end
        ::p53::
        tick(53)
        registers[5] = upvalues[5][registers[1]]
        z = registers[3]
        registers[7] = z;
        registers[(6)] = z["get"];
        registers[(6)] = registers[(6)](registers[7])
        a = registers
        z = 5
        a = a[z]
        z = registers
        q = (2)
        z = z[q]
        q = registers
        m = 6
        q = q[m]
        a[z] = q
        goto p39
        ::p62::
        tick(62)
        registers[5] = upvalues[4]
        if not registers[5] then
            goto p134
        end
        goto p6
        ::p102::
        tick(102)
        registers[6] = registers[5][registers[2]]
        if registers[6] == registers[0] then
            goto p109
        end
        goto p145
        ::p105::
        tick(105)
        if registers[5] ~= registers[0] then
            goto p39
        end
        goto p53
        ::p107::
        tick(107)
        if not registers[4] then
            goto p51
        end
        goto p149
        ::p109::
        tick(109)
        registers[6] = upvalues[6]
        if not registers[6] then
            goto p155
        end
        goto p167
        ::p112::
        z = registers[3]
        registers[6] = z;
        registers[(5)] = z["set"]
        registers[7] = "Default";
        registers[5](registers[6], registers[7])
        goto p152
        ::p130::
        tick(130)
        upvalues[5][registers[1]] = registers[5]
        registers[5] = upvalues[5][registers[1]]
        registers[5] = registers[5][registers[2]]
        goto p105
        ::p134::
        registers[5] = upvalues[5][registers[1]]
        if registers[5] == registers[0] then
            goto p109
        end
        goto p102
        ::p138::
        registers[4] = upvalues[1]["switch"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        registers[4] = (registers[4] == "Anti-Aim")
        goto p13
        ::p145::
        z = registers[3]
        registers[7] = z;
        registers[(6)] = z["get"];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = registers[5][registers[2]]
        goto p175
        ::p149::
        registers[5] = registers[3]["set_visible"]
        if registers[5] == registers[0] then
            goto p51
        end
        goto p27
        ::p152::
        registers[5] = upvalues[6]
        if not registers[5] then
            goto p51
        end
        goto p107
        ::p155::
        tick(155)
        do
            return 
        end
        ::p159::
        registers[4] = upvalues[2];
        registers[4] = registers[4]()
        if registers[4] then
            goto p62
        end
        goto p31
        ::p165::
        tick(165)
        upvalues[5][registers[1]] = registers[0]
        goto p109
        ::p167::
        if not registers[4] then
            goto p155
        end
        goto p196
        ::p169::
        tick(169)
        z = registers[3]
        registers[7] = z;
        registers[(6)] = z["set_visible"]
        registers[8] = (true);
        registers[6](registers[7], registers[8])
        goto p155
        ::p175::
        if registers[6] == registers[7] then
            goto p44
        end
        goto p2
        ::p192::
        registers[5] = {
        }
        goto p130
        ::p196::
        registers[6] = registers[3]["set_visible"]
        if registers[6] == registers[0] then
            goto p155
        end
        goto p169
        ::p200::
        if registers[6] ~= registers[0] then
            goto p109
        end
        goto p165
    end
end
