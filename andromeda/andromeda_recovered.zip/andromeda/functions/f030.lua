-- Recovered function f30; author names are unavailable.
F.f30 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f30")
        tick(1)
        goto p21
        ::p2::
        tick(2)
        registers[6] = (8)
        registers[4] = registers[4](registers[5], registers[6])
        registers[2] = registers[4]
        registers[4] = environment["string"]
        a = registers
        z = (4)
        q = registers
        q = q[4]
        q = q["rep"]
        a[z] = q
        registers[5] = "\000"
        registers[6] = registers[3]
        goto p72
        ::p21::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[2] + 9
        registers[3] = registers[3] % 64
        registers[3] = 64 - registers[3]
        registers[4] = upvalues[0]
        registers[5] = 8 * registers[2]
        goto p2
        ::p36::
        tick(36)
        registers[1] = (registers[1]..registers[4])
        a = registers
        z = (4)
        q = environment
        q = q["assert"]
        a[z] = q
        registers[5] = (#registers[1])
        registers[5] = registers[5] % 64
        registers[5] = (registers[5] == 0)
        registers[(4)](registers[5])
        a = registers
        z = 4
        q = registers
        q = q[1]
        a[z] = q
        do
            return registers[4]
        end
        ::p72::
        registers[4] = registers[4](registers[5], registers[6])
        registers[4] = (registers[4]..registers[2])
        registers[4] = "\128"..registers[4]
        goto p36
    end
end
