-- Recovered function f441; author names are unavailable.
F.f441 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f441")
        tick(1)
        goto p61
        ::p2::
        tick(2)
        registers[2] = (registers[1] ~= registers[0])
        if not registers[2] then
            goto p104
        end
        goto p75
        ::p6::
        tick(6)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["stubs"]
        goto p2
        ::p9::
        tick(9)
        registers[5] = registers[5] + 0.5;
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = (0)
        registers[6] = (255)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p24::
        tick(24)
        registers[5] = (95)
        goto p9
        ::p30::
        tick(30)
        registers[3] = (95)
        do
            return registers[3]
        end
        ::p34::
        tick(34)
        if registers[2] ~= registers[0] then
            goto p55
        end
        goto p30
        ::p55::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = upvalues[2][154]
        z = registers[2]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] then
            goto p9
        end
        goto p24
        ::p61::
        registers[1] = upvalues[0]["visuals"]
        if not registers[1] then
            goto p2
        end
        goto p6
        ::p65::
        tick(65)
        registers[2] = nil
        goto p34
        ::p75::
        registers[2] = registers[1]["aimbot_logs_gradient"]
        ::p104::
        if registers[2] then
            goto p34
        end
        goto p65
    end
end
