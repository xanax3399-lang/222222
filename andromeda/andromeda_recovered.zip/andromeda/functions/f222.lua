-- Recovered function f222; author names are unavailable.
F.f222 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f222")
        tick(1)
        slot_1 = upvalues[0]["handlers"]
        slot_1 = slot_1["import"]
        slot_1()
        do
            return 
        end
    end
end
