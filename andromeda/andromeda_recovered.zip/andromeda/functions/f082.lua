-- Recovered function f82; author names are unavailable.
F.f82 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local tick = new_tick("f82")
        tick(1)
        slot_1 = environment["getfenv"]
        slot_2 = environment["tostring"];
        slot_1 = slot_1(slot_2)
        slot_2 = environment["getfenv"]
        slot_3 = (0);
        slot_2 = slot_2(slot_3)
        if slot_1 == slot_2 then
            goto p22
        end
        goto p50
        ::p21::
        tick(21)
        slot_1(slot_2)
        ::p22::
        do
            return 
        end
        ::p50::
        slot_1 = upvalues[0]
        slot_2 = {
        }
        slot_3 = upvalues[1]["CHECK_15_FAILED"]
        slot_2["ban_num"] = slot_3
        slot_2["ban_info"] = "external [CALL][0x01]"
        goto p21
    end
end
