-- Recovered function f170; author names are unavailable.
F.f170 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f170")
        tick(1)
        goto p124
        ::p2::
        tick(2)
        if registers[1] then
            goto p60
        end
        goto p107
        ::p4::
        tick(4)
        registers[5] = registers[3]
        goto p57
        ::p9::
        tick(9)
        if registers[4] then
            goto p54
        end
        goto p40
        ::p27::
        tick(27)
        m, x = pack_returns(registers[4](unpack_range(6, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] == registers[0] then
            goto p42
        end
        goto p35
        ::p31::
        tick(31)
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "number" then
            goto p102
        end
        goto p72
        ::p35::
        registers[4] = upvalues[1]["clamp"]
        registers[5] = registers[3] > 10
        if not registers[5] then
            goto p128
        end
        goto p139
        ::p40::
        tick(40)
        registers[4] = registers[2]
        goto p54
        ::p42::
        tick(42)
        registers[3] = (1)
        do
            return registers[3]
        end
        ::p45::
        tick(45)
        registers[4] = (registers[2] * 0.01)
        goto p9
        ::p54::
        registers[5] = (0.5)
        registers[6] = (2)
        do
            return registers[(3)](unpack_range(6, registers, 4))
        end
        ::p57::
        tick(57)
        registers[6] = (0.5)
        registers[7] = (2)
        do
            return registers[(4)](unpack_range(7, registers, 5))
        end
        ::p60::
        tick(60)
        if registers[1] ~= registers[0] then
            goto p154
        end
        goto p81
        ::p72::
        registers[3] = upvalues[1]["clamp"]
        registers[4] = registers[2] > 10
        if not registers[4] then
            goto p9
        end
        goto p45
        ::p81::
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p98::
        tick(98)
        registers[3] = environment["tonumber"]
        z = registers[2]
        registers[5] = z;
        registers[(4)] = z["match"]
        registers[6] = "(%d+%.?%d*)"
        goto p27
        ::p102::
        registers[3] = environment["type"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "string" then
            goto p42
        end
        goto p98
        ::p107::
        registers[1] = nil
        goto p60
        ::p109::
        tick(109)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["dpi"]
        goto p2
        ::p124::
        registers[1] = upvalues[0]["visuals"]
        registers[1] = (registers[1] ~= registers[0])
        if not registers[1] then
            goto p2
        end
        goto p109
        ::p128::
        tick(128)
        if registers[5] then
            goto p57
        end
        goto p4
        ::p139::
        registers[5] = (registers[3] * 0.01)
        goto p128
        ::p154::
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = environment["type"]
        goto p31
    end
end
