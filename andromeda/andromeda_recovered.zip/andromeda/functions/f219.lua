-- Recovered function f219; author names are unavailable.
F.f219 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f219")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["visuals"]
        if slot_2 == slot_0 then
            goto p10
        end
        slot_3 = upvalues[0]["visuals"]
        slot_3 = slot_3["fps_optimization_options"]
        if slot_3 ~= slot_0 then
            goto p12
        end
        ::p10::
        slot_2 = (false)
        do
            return slot_2
        end
        ::p12::
        slot_2 = upvalues[0]["visuals"]
        slot_2 = slot_2["fps_optimization_options"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"]
        slot_4 = slot_1
        slot_2 = slot_2(slot_3, slot_4)
        slot_2 = (slot_2 == true)
        do
            return slot_2
        end
    end
end
