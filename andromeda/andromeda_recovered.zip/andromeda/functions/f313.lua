-- Recovered function f313; author names are unavailable.
F.f313 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f313")
        tick(1)
        goto p17
        ::p2::
        tick(2)
        slot_3 = upvalues[0]["round"]
        slot_4 = slot_2 / 10;
        slot_3 = slot_3(slot_4)
        slot_3 = (slot_3 * 10)
        do
            return slot_3
        end
        ::p10::
        tick(10)
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        branch_taken = false
        if slot_3 ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p2
        end
        slot_3 = (0)
        do
            return slot_3
        end
        ::p17::
        a = {
            ...,
        }
        slot_1 = a[1]
        z = slot_1
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        slot_3 = environment["type"]
        goto p10
    end
end
