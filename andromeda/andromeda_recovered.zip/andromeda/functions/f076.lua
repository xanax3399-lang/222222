-- Recovered function f76; author names are unavailable.
F.f76 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f76")
        tick(1)
        goto p37
        ::p7::
        tick(7)
        registers[4] = upvalues[3]
        registers[3] = registers[3][registers[4]]
        registers[4] = environment["setmetatable"]
        goto p83
        ::p37::
        registers[1] = {
        }
        registers[2] = {
        }
        registers[3] = "__tostring"
        goto p89
        ::p83::
        registers[5] = registers[1]
        registers[6] = registers[2]
        m, x = pack_returns(registers[4](unpack_range(6, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[3](unpack_range(top, registers, 4))
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p89::
        a = D.f77
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[2][registers[3]] = registers[4]
        registers[3] = upvalues[2]["lua"]
        goto p7
    end
end
