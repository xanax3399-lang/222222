-- Recovered function f316; author names are unavailable.
F.f316 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f316")
        tick(1)
        slot_1 = upvalues[0]["handlers"]
        slot_1 = slot_1["load"]
        slot_1()
        do
            return 
        end
    end
end
