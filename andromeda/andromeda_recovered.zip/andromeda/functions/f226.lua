-- Recovered function f226; author names are unavailable.
F.f226 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f226")
        tick(1)
        goto p42
        ::p29::
        tick(29)
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[0]["set_callback"]
        registers[2] = "aim_hit"
        registers[3] = upvalues[1]["aim_hit"]
        goto p56
        ::p35::
        tick(35)
        upvalues[1]["active"] = false
        registers[1] = upvalues[1]["clear"]
        registers[(1)]()
        goto p77
        ::p42::
        registers[1] = upvalues[0]["set_callback"]
        registers[2] = "aim_fire"
        registers[3] = upvalues[1]["aim_fire"]
        goto p29
        ::p46::
        tick(46)
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[0]["set_callback"]
        goto p70
        ::p50::
        tick(50)
        registers[3] = upvalues[1]["paint"]
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        goto p35
        ::p56::
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[0]["set_callback"]
        registers[2] = "aim_miss"
        registers[3] = upvalues[1]["aim_miss"]
        goto p46
        ::p70::
        registers[2] = "player_hurt"
        registers[3] = upvalues[1]["player_hurt"]
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        registers[1] = upvalues[0]["set_callback"]
        registers[2] = "paint"
        goto p50
        ::p77::
        do
            return 
        end
    end
end
