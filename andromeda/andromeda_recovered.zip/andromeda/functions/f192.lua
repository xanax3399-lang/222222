-- Recovered function f192; author names are unavailable.
F.f192 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f192")
        tick(1)
        registers[1] = upvalues[0]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["remove_config"]
        registers[3] = upvalues[1]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        registers[1] = upvalues[0]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["update_list"]
        registers[(1)](registers[2])
        do
            return 
        end
    end
end
