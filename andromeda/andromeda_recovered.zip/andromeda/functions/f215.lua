-- Recovered function f215; author names are unavailable.
F.f215 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f215")
        tick(1)
        goto p60
        ::p10::
        tick(10)
        registers[3] = nil
        do
            return registers[3]
        end
        ::p13::
        tick(13)
        registers[5] = upvalues[0][46]
        registers[6] = registers[2]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = registers[4](unpack_range(top, registers, 5))
        registers[5] = (registers[4] - registers[3])
        z = registers[5]
        registers[7] = z;
        registers[(6)] = z["angles"]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        z = 0
        for f = 6, 7 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = (registers[7] - 180)
        do
            return registers[8]
        end
        ::p41::
        tick(41)
        registers[3] = upvalues[1]
        registers[4] = upvalues[0][46]
        registers[5] = registers[1]
        goto p85
        ::p60::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][52];
        registers[2] = registers[2]()
        if registers[2] ~= registers[0] then
            goto p41
        end
        goto p10
        ::p85::
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        registers[4] = upvalues[1]
        goto p13
    end
end
