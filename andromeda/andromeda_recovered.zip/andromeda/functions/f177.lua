-- Recovered function f177; author names are unavailable.
F.f177 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f177")
        tick(1)
        goto p397
        ::p3::
        tick(3)
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        registers[9] = (1)
        registers[10] = (2);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        goto p323
        ::p17::
        tick(17)
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        registers[9] = (1)
        registers[10] = (2);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        goto p387
        ::p24::
        tick(24)
        registers[5] = environment["type"]
        registers[6] = registers[1];
        registers[(5)] = registers[(5)](registers[6])
        goto p264
        ::p28::
        tick(28)
        registers[5] = environment["tonumber"]
        registers[6] = registers[1][1];
        registers[(5)] = registers[(5)](registers[6])
        registers[7] = environment["tonumber"]
        registers[8] = registers[1][2]
        goto p71
        ::p35::
        tick(35)
        registers[7] = registers[3] == registers[0]
        goto p90
        ::p37::
        tick(37)
        registers[5] = new_frame(4)
        registers[6] = registers[1]
        registers[7] = registers[2]
        registers[8] = registers[3]
        goto p232
        ::p56::
        tick(56)
        registers[7] = registers[3] == registers[0]
        goto p210
        ::p71::;
        registers[(7)] = registers[(7)](registers[8])
        registers[2] = registers[7]
        registers[7] = environment["tonumber"]
        goto p273
        ::p75::
        tick(75)
        registers[2] = registers[6]
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        registers[9] = (5)
        registers[10] = (6);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        goto p405
        ::p84::
        tick(84);
        registers[(7)] = registers[(7)](registers[8])
        a = registers
        z = 2
        q = registers
        q = q[7]
        a[z] = q
        registers[7] = environment["tonumber"]
        goto p154
        ::p90::
        tick(90)
        if not registers[7] then
            goto p306
        end
        goto p277
        ::p92::
        tick(92);
        registers[6](registers[7], registers[8])
        registers[6] = registers[5]
        do
            return registers[6]
        end
        ::p95::
        tick(95)
        registers[5]["g"] = registers[6]
        registers[6] = upvalues[0]["clamp"]
        a = registers
        z = (7)
        q = environment
        q = q["tonumber"]
        a[z] = q
        registers[8] = registers[3];
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] then
            goto p297
        end
        registers[7] = (registers[2] ~= registers[0])
        if not registers[7] then
            goto p297
        end
        goto p185
        ::p106::
        tick(106)
        registers[5] = environment["error"]
        registers[6] = "Table convert color error, report this and wait fix!"
        registers[7] = (2);
        registers[5](registers[6], registers[7])
        goto p37
        ::p118::
        tick(118)
        registers[7] = (registers[2] ~= registers[0])
        if not registers[7] then
            goto p210
        end
        goto p56
        ::p137::
        tick(137)
        registers[6] = registers[6](registers[7], registers[8])
        registers[3] = registers[6]
        registers[4] = (255)
        goto p37
        ::p152::
        tick(152)
        registers[7] = (255)
        goto p227
        ::p154::
        registers[8] = registers[1][3];
        registers[(7)] = registers[(7)](registers[8])
        registers[3] = registers[7]
        registers[7] = environment["tonumber"]
        goto p364
        ::p159::
        tick(159)
        if registers[7] then
            goto p181
        end
        goto p253
        ::p161::
        tick(161)
        registers[8] = (0)
        registers[9] = (255);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        goto p349
        ::p181::
        tick(181)
        registers[8] = (0)
        registers[9] = (255);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        goto p95
        ::p185::
        registers[7] = registers[5]["r"]
        goto p297
        ::p188::
        tick(188)
        registers[5] = environment["tonumber"]
        registers[6] = registers[1][1];
        registers[(5)] = registers[(5)](registers[6])
        registers[7] = environment["tonumber"]
        registers[8] = registers[1][2]
        goto p84
        ::p210::
        if not registers[7] then
            goto p159
        end
        goto p418
        ::p213::
        tick(213)
        registers[7] = (255)
        goto p161
        ::p215::
        tick(215)
        if registers[7] then
            goto p159
        end
        goto p118
        ::p217::
        tick(217);
        registers[6](registers[7], registers[8])
        goto p37
        ::p227::
        tick(227)
        registers[8] = (0)
        registers[9] = (255);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        registers[5]["a"] = registers[6]
        goto p300
        ::p232::
        registers[9] = registers[4]
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        registers[6] = upvalues[0]["clamp"]
        registers[7] = environment["tonumber"]
        goto p282
        ::p237::
        tick(237)
        registers[4] = (255)
        registers[1] = registers[5]
        goto p37
        ::p247::
        tick(247)
        registers[7] = environment["tonumber"]
        registers[8] = registers[2];
        registers[(7)] = registers[(7)](registers[8])
        goto p215
        ::p253::
        registers[7] = (255)
        goto p181
        ::p264::
        if registers[5] ~= "table" then
            goto p37
        end
        goto p409
        ::p266::
        tick(266);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = (#registers[5])
        if registers[6] ~= 6 then
            goto p375
        end
        goto p3
        ::p270::
        tick(270)
        registers[5] = (#registers[1])
        if registers[5] ~= 4 then
            goto p106
        end
        goto p188
        ::p273::
        registers[8] = registers[1][3];
        registers[(7)] = registers[(7)](registers[8])
        registers[3] = registers[7]
        goto p237
        ::p277::
        registers[7] = registers[2]
        goto p306
        ::p282::
        registers[8] = registers[1];
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] then
            goto p161
        end
        goto p213
        ::p286::
        tick(286);
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] then
            goto p306
        end
        goto p420
        ::p289::
        tick(289)
        registers[6] = environment["error"]
        registers[7] = "HEX error, report this and wait fix!"
        registers[8] = (2)
        goto p217
        ::p293::
        tick(293);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        goto p75
        ::p297::
        if registers[7] then
            goto p356
        end
        goto p308
        ::p300::
        registers[6] = environment["setmetatable"]
        registers[7] = registers[5]
        registers[8] = {
        }
        registers[9] = upvalues[1]
        registers[8]["__index"] = registers[9]
        goto p92
        ::p306::
        if registers[7] then
            goto p227
        end
        goto p152
        ::p308::
        registers[7] = (255)
        goto p356
        ::p316::
        tick(316)
        registers[9] = (7)
        registers[10] = (8);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        goto p354
        ::p323::
        registers[6] = registers[6](registers[7], registers[8])
        registers[1] = registers[6]
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        registers[9] = (3)
        goto p401
        ::p331::
        tick(331)
        registers[9] = (5)
        registers[10] = (6);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        goto p137
        ::p336::
        tick(336);
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] ~= "string" then
            goto p24
        end
        goto p412
        ::p339::
        tick(339)
        registers[6] = registers[6](registers[7], registers[8])
        a = registers
        z = 2
        q = registers
        q = q[6]
        a[z] = q
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        goto p331
        ::p347::
        tick(347)
        registers[7] = registers[5]["r"]
        goto p416
        ::p349::
        registers[5]["r"] = registers[6]
        registers[6] = upvalues[0]["clamp"]
        registers[7] = registers[3] == registers[0]
        if not registers[7] then
            goto p416
        end
        goto p347
        ::p354::
        registers[4] = registers[6]
        goto p37
        ::p356::
        registers[8] = (0)
        registers[9] = (255);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        registers[5]["b"] = registers[6]
        registers[6] = upvalues[0]["clamp"]
        registers[7] = environment["tonumber"]
        registers[8] = registers[4]
        goto p286
        ::p364::
        registers[8] = registers[1][4];
        registers[(7)] = registers[(7)](registers[8])
        registers[4] = registers[7]
        registers[1] = registers[5]
        goto p37
        ::p375::
        registers[6] = (#registers[5])
        if registers[6] ~= 8 then
            goto p289
        end
        goto p17
        ::p381::
        tick(381)
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        a = registers
        z = 9;
        a[z] = 3
        registers[10] = (4)
        goto p293
        ::p387::
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        registers[1] = registers[6]
        goto p381
        ::p397::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = environment["type"]
        registers[6] = registers[1]
        goto p336
        ::p401::
        registers[10] = (4);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = (16)
        goto p339
        ::p405::
        registers[3] = registers[6]
        registers[6] = environment["tonumber"]
        z = registers[5]
        registers[8] = z;
        registers[(7)] = z["sub"]
        goto p316
        ::p409::
        registers[5] = (#registers[1])
        if registers[5] ~= 3 then
            goto p270
        end
        goto p28
        ::p412::
        z = registers[1]
        registers[6] = z;
        registers[(5)] = z["gsub"]
        registers[7] = "#"
        registers[8] = ""
        goto p266
        ::p416::
        if registers[7] then
            goto p215
        end
        goto p247
        ::p418::
        registers[7] = registers[5]["r"]
        goto p159
        ::p420::
        registers[7] = (registers[2] ~= registers[0])
        if not registers[7] then
            goto p90
        end
        goto p35
    end
end
