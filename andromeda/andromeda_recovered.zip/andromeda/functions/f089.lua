-- Recovered function f89; author names are unavailable.
F.f89 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f89")
        tick(1)
        goto p57
        ::p11::
        tick(11)
        slot_5 = slot_5 * slot_6;
        slot_4 = slot_4(slot_5)
        slot_4 = slot_2 + slot_4
        do
            return slot_4
        end
        ::p53::
        tick(53)
        slot_5 = (slot_3 - slot_2)
        slot_5 = slot_5 + 1
        slot_6 = slot_1 / 2147483648
        goto p11
        ::p57::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = 1103515245 * slot_1
        slot_4 = slot_4 + 12345
        slot_1 = slot_4 % 2147483648
        slot_4 = upvalues[0]
        goto p53
    end
end
