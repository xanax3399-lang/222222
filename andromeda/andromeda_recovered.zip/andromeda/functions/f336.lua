-- Recovered function f336; author names are unavailable.
F.f336 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f336")
        tick(1)
        goto p156
        ::p10::
        tick(10)
        registers[4] = registers[4](registers[5], registers[6])
        if not registers[4] then
            goto p47
        end
        goto p85
        ::p13::
        tick(13)
        registers[4] = upvalues[0]["is_on_ground"]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        goto p175
        ::p30::
        tick(30)
        registers[5] = upvalues[1]["ragebot"]
        registers[5] = registers[5]["hitchance"]
        registers[5] = registers[5]["hotkey"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] ~= true then
            goto p162
        end
        goto p208
        ::p47::
        tick(47)
        registers[4] = upvalues[0]["option_enabled"]
        registers[5] = registers[3]
        registers[6] = "In Air"
        registers[4] = registers[4](registers[5], registers[6])
        if not registers[4] then
            goto p94
        end
        goto p119
        ::p56::
        tick(56)
        registers[6] = upvalues[0]["get_option_value"]
        registers[7] = registers[3]
        registers[8] = "No Scope"
        goto p186
        ::p60::
        tick(60)
        registers[4] = upvalues[1]["ragebot"]
        registers[4] = registers[4]["hitchance"]
        registers[4] = registers[4]["hotkey"]
        if registers[4] == registers[0] then
            goto p162
        end
        goto p30
        ::p78::
        tick(78)
        registers[4] = upvalues[2]["is_fake_duck"];
        registers[4] = registers[4]()
        if registers[4] then
            goto p213
        end
        goto p189
        ::p85::
        registers[4] = registers[3]["No Scope"]
        registers[5] = registers[4]["distance"]
        registers[5] = (registers[5] ~= registers[0])
        if not registers[5] then
            goto p123
        end
        goto p144
        ::p90::
        tick(90)
        registers[4] = upvalues[2]["is_quick_peek"];
        registers[4] = registers[4]()
        if not registers[4] then
            goto p182
        end
        goto p168
        ::p94::
        tick(94)
        registers[4] = nil
        do
            return registers[4]
        end
        ::p104::
        tick(104)
        registers[6] = upvalues[0]["get_distance"]
        registers[7] = registers[1]
        registers[8] = upvalues[3][52]
        m, x = pack_returns(registers[8]())
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        if registers[6] == registers[0] then
            goto p47
        end
        goto p150
        ::p111::
        tick(111)
        registers[7] = upvalues[0]["get_option_value"]
        registers[8] = registers[3]
        registers[9] = "No Scope"
        do
            return registers[(7)](unpack_range(9, registers, 8))
        end
        ::p115::
        tick(115)
        registers[6] = "Hotkey"
        registers[4] = registers[4](registers[5], registers[6])
        if not registers[4] then
            goto p162
        end
        goto p60
        ::p119::
        registers[4] = upvalues[0]["is_on_ground"]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        goto p153
        ::p123::
        tick(123)
        if registers[5] then
            goto p148
        end
        goto p173
        ::p144::
        registers[5] = registers[4]["distance"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        goto p123
        ::p148::
        tick(148)
        if registers[5] ~= 101 then
            goto p104
        end
        goto p56
        ::p150::
        registers[7] = (registers[6] * 0.083333336)
        branch_taken = false
        if not (not (registers[7] <= registers[5])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p47
        end
        goto p111
        ::p153::
        if registers[4] then
            goto p94
        end
        goto p195
        ::p156::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        upvalues[0]["hotkey_active"] = false
        registers[4] = upvalues[0]["option_enabled"]
        registers[5] = registers[3]
        goto p115
        ::p162::
        registers[4] = upvalues[0]["option_enabled"]
        registers[5] = registers[3]
        registers[6] = "Crouch"
        registers[4] = registers[4](registers[5], registers[6])
        if not registers[4] then
            goto p213
        end
        goto p13
        ::p168::
        registers[4] = upvalues[0]["get_option_value"]
        registers[5] = registers[3]
        registers[6] = "Peek Assist"
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p173::
        registers[5] = (101)
        goto p148
        ::p175::
        if not registers[4] then
            goto p213
        end
        registers[4] = upvalues[0]["is_crouched"]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        if not registers[4] then
            goto p213
        end
        goto p78
        ::p182::
        tick(182)
        registers[4] = upvalues[0]["option_enabled"]
        registers[5] = registers[3]
        registers[6] = "No Scope"
        goto p10
        ::p186::
        do
            return registers[(6)](unpack_range(8, registers, 7))
        end
        ::p189::
        registers[4] = upvalues[0]["get_option_value"]
        registers[5] = registers[3]
        registers[6] = "Crouch"
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p195::
        registers[4] = upvalues[0]["get_option_value"]
        registers[5] = registers[3]
        registers[6] = "In Air"
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p208::
        upvalues[0]["hotkey_active"] = true
        registers[4] = upvalues[0]["get_option_value"]
        registers[5] = registers[3]
        registers[6] = "Hotkey"
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p213::
        registers[4] = upvalues[0]["option_enabled"]
        registers[5] = registers[3]
        registers[6] = "Peek Assist"
        registers[4] = registers[4](registers[5], registers[6])
        if not registers[4] then
            goto p182
        end
        goto p90
    end
end
