-- Recovered function f166; author names are unavailable.
F.f166 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f166")
        tick(1)
        goto p85
        ::p2::
        tick(2)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p4::
        tick(4);
        slot_3 = slot_3(slot_4)
        slot_3 = (slot_3 == "Hidden")
        goto p62
        ::p7::
        tick(7)
        slot_3 = slot_2["yaw"]
        slot_3 = (slot_3 ~= slot_0)
        if not slot_3 then
            goto p73
        end
        slot_3 = slot_2["yaw"]
        slot_3 = slot_3["builder_type"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        slot_3 = (slot_3 == "Hidden")
        goto p73
        ::p35::
        tick(35)
        slot_3 = (slot_3 == "Hidden")
        goto p76
        ::p37::
        tick(37)
        if slot_4 ~= "Defensive" then
            goto p7
        end
        goto p71
        ::p49::
        tick(49)
        slot_3 = slot_2["yaw_modifiers"]
        slot_3 = slot_3["builder_type"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"]
        goto p4
        ::p55::
        tick(55)
        slot_3 = slot_2["yaw_modifiers"]
        slot_3 = (slot_3 ~= slot_0)
        if not slot_3 then
            goto p62
        end
        goto p49
        ::p59::
        tick(59)
        slot_3 = upvalues[0]["switch_type"]
        if slot_3 == slot_0 then
            goto p7
        end
        goto p102
        ::p62::
        tick(62)
        if slot_3 then
            goto p76
        end
        goto p114
        ::p71::
        slot_3 = (false)
        do
            return slot_3
        end
        ::p73::
        if slot_3 then
            goto p62
        end
        goto p55
        ::p76::
        tick(76)
        do
            return slot_3
        end
        ::p85::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_2 ~= slot_0 then
            goto p59
        end
        goto p2
        ::p90::
        tick(90)
        slot_3 = slot_2["delay"]
        slot_3 = slot_3["builder_type"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        goto p35
        ::p102::
        slot_4 = upvalues[0]["switch_type"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["get"];
        slot_4 = slot_4(slot_5)
        goto p37
        ::p114::
        slot_3 = slot_2["delay"]
        slot_3 = (slot_3 ~= slot_0)
        if not slot_3 then
            goto p76
        end
        goto p90
    end
end
