-- Recovered function f447; author names are unavailable.
F.f447 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f447")
        tick(1)
        goto p4
        ::p2::
        tick(2)
        slot_2 = "Manual"
        do
            return slot_2
        end
        ::p4::
        a = upvalues[0];
        slot_1 = a[2][a[1]]["current"]
        if slot_1 then
            goto p7
        end
        goto p10
        ::p7::
        tick(7)
        a = upvalues[0];
        slot_2 = a[2][a[1]]["freestanding"]
        if not slot_2 then
            goto p18
        end
        goto p14
        ::p10::
        slot_1 = upvalues[1][1]
        goto p7
        ::p14::
        slot_2 = "Freestanding"
        do
            return slot_2
        end
        ::p16::
        tick(16)
        slot_2 = slot_1
        do
            return slot_2
        end
        ::p18::
        a = upvalues[0];
        slot_2 = a[2][a[1]]["manual"]
        if not slot_2 then
            goto p16
        end
        goto p2
    end
end
