-- Recovered function f410; author names are unavailable.
F.f410 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f410")
        tick(1)
        goto p43
        ::p2::
        tick(2)
        registers[1] = upvalues[1]["updated_this_tick"]
        if not registers[1] then
            goto p76
        end
        goto p25
        ::p14::
        tick(14)
        registers[(1)](unpack_range(6, registers, 2))
        do
            return 
        end
        ::p25::
        registers[1] = upvalues[1]["hotkey_active"]
        if registers[1] then
            goto p28
        end
        goto p76
        ::p28::
        registers[1] = upvalues[2][138]
        registers[2] = (255)
        registers[3] = (255)
        goto p39
        ::p32::
        tick(32)
        do
            return 
        end
        ::p39::
        registers[4] = (255)
        registers[5] = (200)
        registers[6] = "HC"
        goto p14
        ::p43::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p2
        end
        goto p32
        ::p76::
        do
            return 
        end
    end
end
