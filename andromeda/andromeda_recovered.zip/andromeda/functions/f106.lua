-- Recovered function f106; author names are unavailable.
F.f106 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f106")
        tick(1)
        goto p36
        ::p9::
        tick(9)
        registers[3] = environment["writefile"]
        registers[4] = registers[1]
        registers[5] = registers[2];
        registers[3](registers[4], registers[5])
        registers[3] = registers[2]
        goto p103
        ::p15::
        tick(15)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[2] = upvalues[0]["icon_assets"]
        registers[2] = registers[2][registers[1]]
        goto p119
        ::p21::
        tick(21)
        branch_taken = false
        if registers[7] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p96
        end
        goto p78
        ::p23::
        tick(23)
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] ~= "string" then
            goto p92
        end
        goto p68
        ::p36::
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] ~= registers[0] then
            goto p113
        end
        goto p88
        ::p58::
        tick(58)
        branch_taken = false
        if registers[2] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p70
        end
        goto p9
        ::p68::
        branch_taken = false
        if registers[7] ~= "" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p92
        end
        goto p129
        ::p70::
        tick(70)
        registers[3] = nil
        do
            return registers[3]
        end
        ::p78::
        tick(78)
        registers[8] = registers[7]
        do
            return registers[8]
        end
        ::p81::
        tick(81)
        registers[6] = upvalues[0]["icon_path_prefixes"]
        registers[6] = registers[6][registers[5]]
        registers[7] = environment["readfile"]
        registers[8] = (registers[6]..registers[1]);
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = environment["type"]
        goto p23
        ::p88::
        registers[2] = nil
        do
            return registers[2]
        end
        ::p92::
        registers[8] = environment["readfile"]
        z = registers[1]
        registers[10] = z;
        registers[(9)] = z["gsub"]
        registers[11] = "/"
        goto p133
        ::p96::
        tick(96)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[5] = v
            branch_taken = true
        end
        if branch_taken then
            goto p81
        end
        goto p15
        ::p103::
        do
            return registers[3]
        end
        ::p113::
        registers[2] = (1)
        registers[3] = upvalues[0]["icon_path_prefixes"]
        registers[3] = (#registers[3])
        registers[4] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[4] + 0
        n = (registers[3] + 0)
        v = (registers[2] - U)
        goto p96
        goto p78
        ::p119::
        registers[3] = environment["type"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= "string" then
            goto p70
        end
        goto p58
        ::p129::
        registers[8] = registers[7]
        do
            return registers[8]
        end
        ::p133::
        registers[12] = "\\";
        registers[9] = registers[9](unpack_range(12, registers, 10))
        registers[9] = (registers[6]..registers[9]);
        registers[(8)] = registers[(8)](registers[9])
        registers[7] = registers[8]
        registers[8] = environment["type"]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] ~= "string" then
            goto p96
        end
        goto p21
    end
end
