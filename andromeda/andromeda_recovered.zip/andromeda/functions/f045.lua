-- Recovered function f45; author names are unavailable.
F.f45 = function(function_metadata, upvalues)
    local code_metadata = function_metadata[8]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f45")
        tick(1)
        if type(code_metadata[1]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=1", 0)
        end
        goto p41
        error("ANDROMEDA_INVALID_FALLTHROUGH: f45 pc=1", 0)
        ::p3::
        tick(3)
        if type(code_metadata[3]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=3", 0)
        end
        goto p3
        ::p4::
        tick(4)
        if type(code_metadata[4]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=4", 0)
        end
        goto p32
        error("ANDROMEDA_INVALID_FALLTHROUGH: f45 pc=4", 0)
        ::p22::
        tick(22)
        branch_taken = false
        if type(code_metadata[22]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=22", 0)
        end
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[5] = v
            branch_taken = true
        end
        if branch_taken then
            goto p31
        end
        if type(code_metadata[23]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=23", 0)
        end
        goto p3
        error("ANDROMEDA_INVALID_FALLTHROUGH: f45 pc=23", 0)
        ::p31::
        if type(code_metadata[31]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=31", 0)
        end
        goto p68
        ::p32::
        if type(code_metadata[32]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=32", 0)
        end;
        registers[(2)] = registers[(2)](registers[3])
        if type(code_metadata[33]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=33", 0)
        end
        registers[3] = environment["pcall"]
        if type(code_metadata[34]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=34", 0)
        end
        a = D.f46
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[4] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        if type(code_metadata[35]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=35", 0)
        end
        registers[(3)](registers[4])
        if type(code_metadata[36]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=36", 0)
        end
        a = D.f47
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[3] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        if type(code_metadata[37]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=37", 0)
        end
        registers[(3)]()
        if type(code_metadata[38]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=38", 0)
        end
        a = (4)
        z = 6
        if type(code_metadata[39]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=39", 0)
        end
        for f = a, z do
            q = registers
            m = f
            f = nil;
            q[m] = f
        end
        if type(code_metadata[40]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=40", 0)
        end
        goto p56
        ::p41::
        if type(code_metadata[41]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=41", 0)
        end
        goto p67
        ::p42::
        tick(42)
        if type(code_metadata[42]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=42", 0)
        end
        a = {
            ...,
        }
        registers[1] = a[1]
        if type(code_metadata[43]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=43", 0)
        end
        a = D.f53
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[2] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        if type(code_metadata[44]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=44", 0)
        end
        registers[3] = "\162L\154\023\026\134\173%\180gB\024Y\009\244\144\014\009I=\179\\\169B\255S\031<\1928*\020\177\194]\179"
        if type(code_metadata[45]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=45", 0)
        end
        goto p4
        error("ANDROMEDA_INVALID_FALLTHROUGH: f45 pc=45", 0)
        ::p56::
        if type(code_metadata[56]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=56", 0)
        end
        registers[2] = nil
        registers[3] = nil
        registers[4] = nil
        if type(code_metadata[57]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=57", 0)
        end
        registers[0] = nil
        registers[1] = nil
        registers[2] = nil
        if type(code_metadata[58]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=58", 0)
        end
        registers[0] = function_metadata
        if type(code_metadata[59]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=59", 0)
        end
        registers[1] = (8)
        if type(code_metadata[60]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=60", 0)
        end
        registers[0] = registers[0][registers[1]]
        if type(code_metadata[61]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=61", 0)
        end
        registers[1] = {
        }
        if type(code_metadata[62]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=62", 0)
        end
        registers[2] = (1)
        if type(code_metadata[63]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=63", 0)
        end
        registers[3] = (#registers[0])
        if type(code_metadata[64]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=64", 0)
        end
        a = registers
        z = 4
        if type(code_metadata[65]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=65", 0)
        end;
        a[z] = 1
        if type(code_metadata[66]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=66", 0)
        end
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[4] + 0
        n = (registers[3] + 0)
        v = (registers[2] - U)
        goto p22
        ::p67::
        if type(code_metadata[67]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=67", 0)
        end
        goto p42
        ::p68::
        if type(code_metadata[68]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=68", 0)
        end
        registers[0][registers[5]] = registers[1]
        if type(code_metadata[69]) == "table" then
            error("ANDROMEDA_DESTROYED_INSTRUCTION: f45 pc=69", 0)
        end
        goto p22
        error("ANDROMEDA_INVALID_FALLTHROUGH: f45 pc=69", 0)
    end
end
