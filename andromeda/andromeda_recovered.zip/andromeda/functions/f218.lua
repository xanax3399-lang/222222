-- Recovered function f218; author names are unavailable.
F.f218 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f218")
        tick(1)
        goto p84
        ::p9::
        tick(9)
        do
            return 
        end
        ::p10::
        tick(10)
        slot_2 = upvalues[0][54]
        slot_3 = slot_1["userid"];
        slot_2 = slot_2(slot_3)
        slot_3 = upvalues[0][32]
        goto p87
        ::p84::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p9
        end
        goto p10
        ::p87::;
        slot_3 = slot_3()
        if slot_2 ~= slot_3 then
            goto p9
        end
        slot_2 = upvalues[1]["reset"]
        slot_2()
        goto p9
    end
end
