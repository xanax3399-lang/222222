-- Recovered function f39; author names are unavailable.
F.f39 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f39")
        tick(1)
        goto p20
        ::p2::
        tick(2)
        registers[5] = (#registers[1])
        goto p14
        ::p12::
        tick(12)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p41
        goto p20
        ::p14::
        tick(14)
        registers[3] = registers[5]
        registers[5] = registers[2]
        registers[6] = registers[3]
        registers[7] = (1)
        goto p12
        ::p20::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = {
        }
        registers[5] = registers[2]
        if registers[5] then
            goto p53
        end
        goto p50
        ::p26::
        tick(26)
        registers[11] = upvalues[0][registers[9]]
        a = registers
        z = 4
        a = a[z]
        z = registers
        q = (10)
        z = z[q]
        q = registers
        m = 11
        q = q[m]
        a[z] = q
        goto p41
        ::p34::
        tick(34)
        z = registers[1]
        registers[10] = z;
        registers[(9)] = z["sub"]
        registers[11] = registers[8]
        registers[12] = registers[8];
        registers[9] = registers[9](unpack_range(12, registers, 10))
        registers[10] = (#registers[4])
        registers[10] = registers[10] + 1
        goto p26
        ::p41::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p34
        end
        goto p88
        ::p50::
        registers[5] = (1)
        goto p53
        ::p52::
        tick(52)
        do
            return registers[(5)](registers[6])
        end
        ::p53::
        registers[2] = registers[5]
        registers[5] = registers[3]
        if registers[5] then
            goto p14
        end
        goto p2
        ::p88::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[5] = environment["unpack"]
        registers[6] = registers[4]
        goto p52
    end
end
