-- Recovered function f265; author names are unavailable.
F.f265 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z = nil
        local tick = new_tick("f265")
        tick(1)
        goto p104
        ::p2::
        tick(2)
        slot_1 = slot_2
        goto p46
        ::p16::
        tick(16)
        if slot_2 ~= "number" then
            goto p46
        end
        goto p98
        ::p18::
        tick(18)
        slot_2 = upvalues[2]["antiaim"]
        slot_2 = slot_2["fakelag"]
        slot_2 = slot_2["limit"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["set"]
        slot_4 = slot_1;
        slot_2(slot_3, slot_4)
        upvalues[0]["saved_limit"] = slot_0
        goto p103
        ::p33::
        tick(33)
        slot_1 = upvalues[0]["saved_limit"]
        slot_2 = environment["type"]
        slot_3 = slot_1
        goto p89
        ::p46::
        slot_2 = upvalues[2]["misc"]
        slot_2 = slot_2["usercmd"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["set"]
        slot_4 = slot_1;
        slot_2(slot_3, slot_4)
        upvalues[0]["saved_usercmd"] = slot_0
        goto p109
        ::p58::
        tick(58)
        slot_2 = upvalues[1][162]
        slot_3 = slot_1
        slot_4 = (14)
        slot_2 = slot_2(slot_3, slot_4)
        slot_1 = slot_2
        goto p18
        ::p64::
        tick(64)
        slot_1 = upvalues[0]["saved_usercmd"]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        goto p16
        ::p89::;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= "number" then
            goto p18
        end
        goto p58
        ::p98::
        slot_2 = upvalues[1][162]
        slot_3 = slot_1
        slot_4 = (16)
        slot_2 = slot_2(slot_3, slot_4)
        goto p2
        ::p103::
        tick(103)
        do
            return 
        end
        ::p104::
        slot_1 = upvalues[0]["saved_usercmd"]
        if slot_1 == slot_0 then
            goto p109
        end
        goto p64
        ::p109::
        slot_1 = upvalues[0]["saved_limit"]
        if slot_1 == slot_0 then
            goto p103
        end
        goto p33
    end
end
