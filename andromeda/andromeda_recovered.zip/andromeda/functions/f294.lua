-- Recovered function f294; author names are unavailable.
F.f294 = function(function_metadata, upvalues)
    local operand_i, operand_g, operand_k = function_metadata[2], function_metadata[6], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f294")
        tick(1)
        goto p82
        ::p8::
        tick(8)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p143
        registers[26] = operand_i
        registers[25] = operand_g
        registers[27] = operand_k
        registers[25][50] = 2
        registers[26][50] = 1
        registers[27][100] = 70
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        goto p71
        ::p17::
        tick(17)
        upvalues[1]["applied_body"] = registers[1]
        registers[1] = {
        }
        upvalues[1]["correction_until"] = registers[1]
        registers[1] = {
        }
        registers[2] = {
        }
        registers[1]["cur"] = registers[2]
        goto p145
        ::p46::
        tick(46)
        registers[5] = upvalues[0][141]
        registers[6] = registers[4]
        registers[7] = "Force body yaw value"
        goto p136
        ::p50::
        tick(50)
        registers[1]["miss_until"] = registers[2]
        registers[2] = {
        }
        registers[1]["misses"] = registers[2]
        upvalues[1]["wraith"] = registers[1]
        do
            return 
        end
        ::p63::
        tick(63)
        registers[5] = upvalues[0][141]
        registers[6] = registers[4]
        registers[7] = "Force body yaw"
        registers[8] = (false)
        registers[(5)](unpack_range(8, registers, 6))
        goto p46
        ::p71::
        tick(71)
        registers[1]["last_value"] = registers[2]
        registers[2] = {
        }
        registers[1]["miss_side"] = registers[2]
        registers[2] = {
        }
        goto p50
        ::p82::
        registers[1] = (1)
        registers[2] = (64)
        registers[3] = (1)
        goto p8
        ::p86::
        tick(86)
        registers[2] = {
        }
        registers[1]["flags"] = registers[2]
        registers[2] = {
        }
        goto p71
        ::p98::
        tick(98)
        registers[(5)](unpack_range(8, registers, 6))
        goto p143
        ::p102::
        tick(102)
        registers[1]["pre_prev"] = registers[2]
        registers[2] = {
        }
        registers[1]["pre_pre_prev"] = registers[2]
        goto p86
        ::p128::
        tick(128)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = {
        }
        upvalues[1]["applied"] = registers[1]
        registers[1] = {
        }
        goto p17
        ::p136::
        registers[8] = (0)
        registers[(5)](unpack_range(8, registers, 6))
        registers[5] = upvalues[0][141]
        registers[6] = registers[4]
        registers[7] = "Override prefer body aim"
        registers[8] = "-"
        goto p98
        ::p143::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p63
        end
        goto p128
        ::p145::
        registers[2] = {
        }
        registers[1]["prev"] = registers[2]
        registers[2] = {
        }
        goto p102
    end
end
