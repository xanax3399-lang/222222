-- Recovered function f251; author names are unavailable.
F.f251 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f251")
        tick(1)
        goto p52
        ::p21::
        tick(21)
        registers[2] = registers[1].."d"
        do
            return registers[2]
        end
        ::p27::
        tick(27)
        registers[2] = environment["string"]
        registers[2] = registers[2]["find"]
        registers[3] = registers[1]
        registers[4] = "d"
        registers[5] = (1)
        registers[6] = (true);
        registers[2] = registers[2](unpack_range(6, registers, 3))
        if registers[2] == registers[0] then
            goto p21
        end
        registers[2] = registers[1]
        do
            return registers[2]
        end
        ::p50::
        tick(50)
        if registers[1] ~= "" then
            goto p27
        end
        goto p66
        ::p52::
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] == registers[0] then
            goto p66
        end
        goto p50
        ::p66::
        registers[2] = "d"
        do
            return registers[2]
        end
    end
end
