-- Recovered function f400; author names are unavailable.
F.f400 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f400")
        tick(1)
        goto p64
        ::p2::
        tick(2)
        slot_2 = slot_1["raw"]
        slot_2["hide_view_model_zoomed"] = false
        slot_2 = upvalues[0]
        slot_2 = (#slot_2)
        slot_2 = slot_2 + 1
        slot_3 = slot_1["idx"]
        goto p52
        ::p36::
        tick(36)
        do
            return 
        end
        ::p52::
        upvalues[0][slot_2] = slot_3
        do
            return 
        end
        ::p55::
        tick(55)
        slot_2 = slot_1["raw"]
        slot_2 = slot_2["hide_view_model_zoomed"]
        if slot_2 then
            goto p2
        end
        goto p36
        ::p61::
        tick(61)
        slot_2 = slot_1["raw"]
        if slot_2 ~= slot_0 then
            goto p55
        end
        goto p67
        ::p64::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p67
        end
        goto p61
        ::p67::
        do
            return 
        end
    end
end
