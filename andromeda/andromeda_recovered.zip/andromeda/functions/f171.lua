-- Recovered function f171; author names are unavailable.
F.f171 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f171")
        tick(1)
        goto p38
        ::p2::
        tick(2)
        registers[4] = (1)
        goto p18
        ::p4::
        tick(4)
        a = upvalues[0];
        registers[3] = a[2][a[1]]
        if registers[3] ~= registers[2] then
            goto p110
        end
        goto p86
        ::p16::
        tick(16)
        if registers[2] then
            goto p4
        end
        goto p108
        ::p18::
        tick(18)
        if registers[4] then
            goto p89
        end
        goto p56
        ::p26::
        tick(26)
        m, x = pack_returns(registers[9](unpack_range(11, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        a = upvalues[0]
        a[2][a[1]] = registers[6]
        a = upvalues[0];
        registers[6] = a[2][a[1]]
        do
            return registers[6]
        end
        ::p31::
        tick(31)
        registers[5] = registers[5] * registers[4]
        registers[5] = registers[3] + registers[5]
        registers[6] = upvalues[2]["clamp"]
        registers[7] = registers[5]
        goto p93
        ::p36::
        tick(36)
        registers[2] = (1)
        goto p16
        ::p38::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = registers[1]
        if not registers[2] then
            goto p16
        end
        goto p36
        ::p56::
        registers[4] = -1
        goto p89
        ::p86::
        registers[3] = registers[2]
        do
            return registers[3]
        end
        ::p89::
        registers[5] = upvalues[1][19];
        registers[5] = registers[5]()
        registers[5] = (registers[5] * 12)
        goto p31
        ::p93::
        registers[8] = upvalues[1][162]
        registers[9] = registers[3]
        registers[10] = registers[2]
        registers[8] = registers[8](registers[9], registers[10])
        registers[9] = upvalues[1][151]
        registers[10] = registers[3]
        registers[11] = registers[2]
        goto p26
        ::p108::
        registers[2] = (0)
        goto p4
        ::p110::
        a = upvalues[0];
        registers[3] = a[2][a[1]]
        registers[4] = registers[2] > registers[3]
        if not registers[4] then
            goto p18
        end
        goto p2
    end
end
