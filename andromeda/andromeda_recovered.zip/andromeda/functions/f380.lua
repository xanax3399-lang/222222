-- Recovered function f380; author names are unavailable.
F.f380 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f380")
        tick(1)
        goto p7
        ::p3::
        tick(3)
        registers[4] = registers[1]["g"]
        registers[5] = registers[1]["b"]
        registers[6] = registers[1]["a"]
        goto p32
        ::p7::
        tick(7)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["new"]
        registers[3] = registers[1]["r"]
        goto p3
        ::p32::
        do
            return registers[(2)](unpack_range(6, registers, 3))
        end
    end
end
