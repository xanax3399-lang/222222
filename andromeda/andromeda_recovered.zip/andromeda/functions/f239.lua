-- Recovered function f239; author names are unavailable.
F.f239 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f239")
        tick(1)
        goto p47
        ::p4::
        tick(4)
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["minimum_damage_override"]
        slot_1 = slot_1[1]
        slot_1 = slot_1["hotkey"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        ::p42::
        tick(42)
        do
            return slot_1
        end
        ::p47::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["minimum_damage_override"]
        slot_1 = slot_1[1]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        if not slot_1 then
            goto p42
        end
        goto p4
    end
end
