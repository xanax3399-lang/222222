-- Recovered function f155; author names are unavailable.
F.f155 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f155")
        tick(1)
        goto p129
        ::p2::
        tick(2)
        registers[13] = (registers[7] == "Right")
        if not registers[13] then
            goto p276
        end
        goto p229
        ::p5::
        tick(5)
        registers[14] = "\226\174\156"
        registers[15] = "\226\174\158"
        if registers[8] ~= "Second" then
            goto p349
        end
        goto p573
        ::p9::
        tick(9)
        registers[13] = (registers[7] == "Forward")
        goto p585
        ::p12::
        tick(12)
        registers[28] = registers[6] + 9
        registers[29] = registers[18][1]
        registers[30] = registers[18][2]
        registers[31] = registers[18][3]
        goto p595
        ::p22::
        tick(22)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        registers[11] = registers[11](registers[12], registers[13])
        registers[12] = upvalues[6]
        goto p69
        ::p26::
        tick(26)
        registers[12] = registers[12](registers[13], registers[14])
        registers[13] = new_frame(4)
        registers[14] = (35)
        registers[15] = (35)
        goto p77
        ::p31::
        tick(31)
        registers[20] = registers[12]
        goto p317
        ::p34::
        tick(34)
        registers[21] = registers[15][1]
        registers[22] = registers[15][2]
        registers[23] = registers[15][3]
        registers[24] = registers[15][4]
        registers[25] = "+c"
        registers[26] = (0)
        goto p180
        ::p41::
        tick(41)
        registers[16] = (registers[16] - registers[14])
        registers[17] = (registers[7] == "Right")
        if not registers[17] then
            goto p489
        end
        goto p324
        ::p45::
        tick(45)
        registers[12] = upvalues[7]
        registers[13] = (registers[5] - registers[9])
        registers[14] = registers[6]
        registers[15] = registers[11]
        registers[(12)](unpack_range(15, registers, 13))
        goto p61
        ::p51::
        tick(51)
        registers[19] = upvalues[9]["body_yaw"]
        registers[19] = (registers[19] ~= registers[0])
        goto p227
        ::p54::
        tick(54)
        if registers[21] then
            goto p116
        end
        goto p518
        ::p56::
        tick(56)
        if registers[1] == registers[0] then
            goto p138
        end
        goto p147
        ::p58::
        tick(58)
        registers[16] = (registers[7] == "Right")
        if not registers[16] then
            goto p295
        end
        goto p198
        ::p61::
        tick(61)
        do
            return 
        end
        ::p63::
        tick(63)
        registers[25] = (registers[15] - 13)
        registers[26] = (registers[6] - 9)
        registers[27] = (registers[15] - 13)
        registers[28] = registers[6] + 9
        registers[29] = registers[17][1]
        goto p353
        ::p69::
        registers[13] = registers[1]["manual_arrows_ts_cl2"]
        registers[14] = new_frame(4)
        registers[15] = (0)
        registers[16] = (200)
        registers[17] = (255)
        registers[18] = (255)
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        goto p26
        ::p77::
        registers[16] = (35)
        registers[17] = (150)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        registers[14] = (0)
        if registers[8] ~= "Fourth" then
            goto p176
        end
        goto p437
        ::p83::
        tick(83)
        if registers[1] then
            goto p56
        end
        goto p310
        ::p85::
        tick(85)
        do
            return 
        end
        ::p86::
        tick(86)
        registers[12] = registers[11][4]
        goto p525
        ::p88::
        tick(88)
        branch_taken = false
        if registers[8] ~= "First" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p463
        end
        goto p614
        ::p90::
        tick(90)
        registers[1] = upvalues[2]["visuals"]
        registers[1] = registers[1]["stubs"]
        goto p83
        ::p108::
        tick(108)
        registers[16] = registers[12]
        goto p288
        ::p110::
        tick(110)
        registers[14] = (255)
        registers[15] = (0)
        registers[16] = (0)
        registers[17] = (255)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        goto p297
        ::p116::
        tick(116)
        registers[22] = upvalues[3][135]
        registers[23] = registers[15]
        registers[24] = registers[6]
        goto p63
        ::p120::
        tick(120)
        registers[19] = upvalues[9]["body_yaw"]
        registers[19] = registers[19]["inverter"]
        goto p379
        ::p129::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p210
        end
        goto p85
        ::p133::
        tick(133)
        registers[29] = registers[21][3]
        registers[30] = registers[21][4]
        registers[(22)](unpack_range(30, registers, 23))
        do
            return 
        end
        ::p138::
        tick(138)
        do
            return 
        end
        ::p139::
        tick(139)
        z = registers[10]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[12] = environment["type"]
        registers[13] = registers[11];
        registers[(12)] = registers[(12)](registers[13])
        goto p150
        ::p145::
        tick(145)
        if registers[8] ~= "Fifth" then
            goto p237
        end
        goto p441
        ::p147::
        registers[2] = registers[1]["manual_arrows"]
        if registers[2] == registers[0] then
            goto p138
        end
        goto p291
        ::p150::
        if registers[12] ~= "number" then
            goto p396
        end
        goto p242
        ::p160::
        tick(160)
        registers[15] = (100)
        registers[16] = (255)
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        q[3] = registers[15]
        q[4] = registers[16]
        registers[13] = (registers[7] == "Left")
        goto p423
        ::p165::
        tick(165)
        m, x = pack_returns(registers[16](unpack_range(18, registers, 17)))
        z = 0
        for f = 16, 17 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[18] = upvalues[8]
        registers[19] = "+"
        registers[20] = registers[15]
        goto p558
        ::p171::
        tick(171)
        registers[(22)](unpack_range(32, registers, 23))
        registers[22] = upvalues[3][135]
        registers[23] = registers[16]
        registers[24] = registers[6]
        goto p445
        ::p176::
        tick(176)
        registers[15] = registers[5] + registers[9]
        registers[15] = registers[15] + registers[14]
        registers[16] = (registers[5] - registers[9])
        goto p41
        ::p180::
        registers[27] = "\226\174\156"
        registers[(18)](unpack_range(27, registers, 19))
        registers[18] = upvalues[3][131]
        registers[19] = registers[5] + registers[9]
        registers[20] = (registers[6] - 1)
        registers[21] = registers[16][1]
        registers[22] = registers[16][2]
        registers[23] = registers[16][3]
        registers[24] = registers[16][4]
        registers[25] = "+c"
        registers[26] = (0)
        registers[27] = "\226\174\158"
        registers[(18)](unpack_range(27, registers, 19))
        registers[18] = upvalues[3][131]
        registers[19] = registers[5] + 1
        registers[20] = registers[6] + registers[14]
        registers[21] = registers[17][1]
        goto p279
        ::p198::
        registers[16] = registers[11]
        goto p295
        ::p200::
        tick(200)
        registers[29] = registers[20][3]
        registers[30] = registers[20][4]
        registers[(22)](unpack_range(30, registers, 23))
        registers[22] = upvalues[3][128]
        goto p467
        ::p205::
        tick(205)
        registers[18] = environment["type"]
        registers[19] = registers[16];
        registers[(18)] = registers[(18)](registers[19])
        if registers[18] ~= "number" then
            goto p176
        end
        goto p223
        ::p210::
        registers[1] = upvalues[1]
        registers[2] = "paint:manual_arrows";
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p485
        end
        goto p488
        ::p215::
        tick(215)
        registers[11] = upvalues[6]
        registers[12] = registers[1]["manual_arrows_cs2_color"]
        registers[13] = new_frame(4)
        registers[14] = (235)
        registers[15] = (90)
        goto p578
        ::p221::
        tick(221)
        if registers[18] then
            goto p358
        end
        goto p255
        ::p223::
        registers[17] = upvalues[3][155]
        registers[18] = registers[15] * registers[15]
        registers[19] = registers[16] * registers[16]
        goto p313
        ::p227::
        tick(227)
        if not registers[19] then
            goto p379
        end
        goto p120
        ::p229::
        registers[13] = registers[11][4]
        goto p276
        ::p231::
        tick(231)
        registers[17] = registers[12]
        goto p474
        ::p233::
        tick(233)
        registers[2] = upvalues[3][32];
        registers[2] = registers[2]()
        if registers[2] == registers[0] then
            goto p548
        end
        goto p413
        ::p237::
        registers[11] = upvalues[6]
        registers[12] = registers[1]["manual_arrows_ts_cl1"]
        registers[13] = new_frame(4)
        registers[14] = (175)
        goto p305
        ::p242::
        registers[12] = upvalues[3][151]
        registers[13] = (30)
        registers[14] = upvalues[3][162]
        registers[15] = (140)
        registers[16] = registers[11]
        m, x = pack_returns(registers[14](unpack_range(16, registers, 15)))
        m = m + 14 - 1
        top = m
        z = 0
        for f = 14, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        registers[9] = registers[12]
        goto p396
        ::p253::
        tick(253)
        registers[13] = (0)
        goto p5
        ::p255::
        registers[18] = registers[13]
        goto p358
        ::p257::
        tick(257)
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        z = 0
        for f = 15, 16 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[17] = environment["type"]
        registers[18] = registers[15];
        registers[(17)] = registers[(17)](registers[18])
        goto p326
        ::p262::
        tick(262)
        registers[21] = registers[13]
        goto p54
        ::p264::
        tick(264)
        registers[12] = upvalues[7]
        registers[13] = registers[5]
        registers[14] = (registers[6] - registers[9])
        registers[15] = registers[11]
        registers[(12)](unpack_range(15, registers, 13))
        goto p61
        ::p276::
        if registers[13] then
            goto p5
        end
        goto p253
        ::p279::
        registers[22] = registers[17][2]
        registers[23] = registers[17][3]
        registers[24] = registers[17][4]
        registers[25] = "+c"
        registers[26] = (0)
        registers[27] = "\226\174\159"
        registers[(18)](unpack_range(27, registers, 19))
        do
            return 
        end
        ::p288::
        tick(288)
        registers[17] = registers[13]
        if not registers[17] then
            goto p474
        end
        goto p231
        ::p291::
        registers[3] = registers[1]["manual_arrows"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        goto p347
        ::p295::
        if registers[16] then
            goto p288
        end
        goto p108
        ::p297::
        registers[11] = registers[11](registers[12], registers[13])
        registers[12] = new_frame(4)
        registers[13] = (100)
        registers[14] = (100)
        goto p160
        ::p302::
        tick(302)
        if registers[15] then
            goto p58
        end
        goto p449
        ::p305::
        registers[15] = (255)
        registers[16] = (0)
        registers[17] = (255)
        goto p22
        ::p310::
        registers[1] = nil
        goto p56
        ::p313::
        registers[18] = registers[18] + registers[19];
        registers[(17)] = registers[(17)](registers[18])
        registers[14] = registers[17] / 6
        goto p176
        ::p317::
        tick(317)
        if registers[20] then
            goto p418
        end
        goto p476
        ::p319::
        tick(319);
        registers[7] = registers[7]()
        registers[8] = upvalues[5];
        registers[8] = registers[8]()
        goto p492
        ::p324::
        registers[17] = registers[11]
        goto p489
        ::p326::
        if registers[17] ~= "number" then
            goto p176
        end
        goto p205
        ::p333::
        tick(333)
        if registers[13] then
            goto p585
        end
        goto p9
        ::p335::
        tick(335)
        registers[12] = (registers[7] == "Left")
        if not registers[12] then
            goto p525
        end
        goto p86
        ::p339::
        tick(339)
        registers[25] = registers[11][3]
        registers[26] = registers[12]
        registers[27] = "+"
        goto p500
        ::p343::
        tick(343)
        registers[19] = (false)
        goto p382
        ::p345::
        tick(345)
        registers[15] = registers[11]
        goto p302
        ::p347::
        if registers[3] then
            goto p233
        end
        goto p138
        ::p349::
        tick(349)
        registers[16] = upvalues[8]
        registers[17] = "+"
        registers[18] = registers[14]
        goto p165
        ::p353::
        registers[30] = registers[17][2]
        registers[31] = registers[17][3]
        registers[32] = registers[17][4]
        goto p171
        ::p358::
        registers[19] = upvalues[9]
        registers[19] = (registers[19] ~= registers[0])
        if not registers[19] then
            goto p227
        end
        goto p51
        ::p362::
        tick(362)
        registers[18] = upvalues[3][131]
        registers[19] = (registers[5] - registers[9])
        registers[20] = (registers[6] - 1)
        goto p34
        ::p372::
        tick(372)
        registers[12] = (0)
        goto p2
        ::p374::
        tick(374)
        if registers[7] ~= "Right" then
            goto p571
        end
        goto p478
        ::p376::
        tick(376)
        registers[29] = registers[15]
        registers[(20)](unpack_range(29, registers, 21))
        do
            return 
        end
        ::p379::
        if registers[19] then
            goto p382
        end
        goto p343
        ::p382::
        registers[20] = registers[19]
        if not registers[20] then
            goto p317
        end
        goto p31
        ::p396::
        tick(396)
        if registers[8] ~= "CS2" then
            goto p88
        end
        goto p215
        ::p411::
        tick(411)
        registers[17] = registers[13]
        goto p555
        ::p413::
        registers[3] = upvalues[3][50]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p425
        end
        goto p548
        ::p418::
        tick(418)
        registers[21] = registers[19]
        if not registers[21] then
            goto p54
        end
        goto p262
        ::p423::
        if registers[13] then
            goto p333
        end
        goto p452
        ::p425::
        registers[3] = upvalues[3][57]
        m, x = pack_returns(registers[3]())
        z = 0
        for f = 3, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = (registers[3] * 0.5)
        registers[6] = (registers[4] * 0.5)
        registers[7] = upvalues[4]
        goto p319
        ::p437::
        registers[15] = upvalues[3][47]
        registers[16] = registers[2]
        registers[17] = "m_vecVelocity"
        goto p257
        ::p441::
        registers[11] = upvalues[6]
        registers[12] = registers[1]["manual_arrows_color"]
        registers[13] = new_frame(4)
        goto p110
        ::p445::
        registers[25] = registers[16] + 13
        registers[26] = (registers[6] - 9)
        registers[27] = registers[16] + 13
        goto p12
        ::p449::
        registers[15] = registers[12]
        goto p58
        ::p452::
        registers[13] = (registers[7] == "Right")
        goto p333
        ::p454::
        tick(454)
        registers[22] = (registers[6] - registers[22])
        registers[23] = registers[11][1]
        registers[24] = registers[11][2]
        goto p339
        ::p463::
        tick(463)
        registers[11] = upvalues[6]
        registers[12] = registers[1]["manual_arrows_color"]
        registers[13] = new_frame(4)
        goto p496
        ::p467::
        registers[23] = registers[16] + 13
        registers[24] = (registers[6] - 9)
        registers[25] = (2)
        registers[26] = (18)
        registers[27] = registers[21][1]
        registers[28] = registers[21][2]
        goto p133
        ::p474::
        if registers[17] then
            goto p362
        end
        goto p527
        ::p476::
        registers[20] = registers[13]
        goto p418
        ::p478::
        registers[12] = upvalues[7]
        registers[13] = registers[5] + registers[9]
        registers[14] = registers[6]
        goto p520
        ::p482::
        tick(482)
        registers[11] = registers[10]["get"]
        if registers[11] == registers[0] then
            goto p396
        end
        goto p139
        ::p485::
        registers[1] = upvalues[2]["visuals"]
        if not registers[1] then
            goto p83
        end
        goto p90
        ::p488::
        do
            return 
        end
        ::p489::
        if registers[17] then
            goto p555
        end
        goto p411
        ::p492::
        registers[9] = (55)
        registers[10] = registers[1]["manual_arrows_offset"]
        if registers[10] == registers[0] then
            goto p396
        end
        goto p482
        ::p496::
        registers[14] = (138)
        registers[15] = (207)
        registers[16] = (255)
        goto p621
        ::p500::
        registers[28] = (0)
        registers[29] = registers[14]
        registers[(20)](unpack_range(29, registers, 21))
        registers[20] = upvalues[3][131]
        registers[21] = registers[5] + registers[9]
        registers[22] = (registers[18] * 0.5)
        registers[21] = (registers[21] - registers[22])
        registers[22] = (registers[19] * 0.5)
        registers[22] = (registers[6] - registers[22])
        registers[23] = registers[11][1]
        goto p549
        ::p518::
        registers[21] = registers[12]
        goto p116
        ::p520::
        registers[15] = registers[11]
        registers[(12)](unpack_range(15, registers, 13))
        goto p61
        ::p525::
        if registers[12] then
            goto p2
        end
        goto p372
        ::p527::
        registers[17] = registers[11]
        goto p362
        ::p548::
        do
            return 
        end
        ::p549::
        registers[24] = registers[11][2]
        registers[25] = registers[11][3]
        registers[26] = registers[13]
        registers[27] = "+"
        registers[28] = (0)
        goto p376
        ::p555::
        registers[18] = (registers[7] == "Left")
        if not registers[18] then
            goto p221
        end
        goto p619
        ::p558::
        m, x = pack_returns(registers[18](unpack_range(20, registers, 19)))
        z = 0
        for f = 18, 19 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[20] = upvalues[3][131]
        registers[21] = (registers[5] - registers[9])
        registers[22] = (registers[16] * 0.5)
        registers[21] = (registers[21] - registers[22])
        registers[22] = (registers[17] * 0.5)
        goto p454
        ::p571::
        if registers[7] ~= "Forward" then
            goto p61
        end
        goto p264
        ::p573::
        registers[15] = "\226\175\136"
        registers[14] = "\226\175\135"
        goto p349
        ::p578::
        registers[16] = (170)
        registers[17] = (255)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        registers[11] = registers[11](registers[12], registers[13])
        if registers[7] ~= "Left" then
            goto p374
        end
        goto p45
        ::p585::
        registers[14] = (registers[9] - 5)
        registers[15] = (registers[7] == "Left")
        if not registers[15] then
            goto p302
        end
        goto p345
        ::p595::
        registers[32] = registers[18][4]
        registers[(22)](unpack_range(32, registers, 23))
        registers[22] = upvalues[3][128]
        registers[23] = (registers[15] - 15)
        registers[24] = (registers[6] - 9)
        registers[25] = (2)
        registers[26] = (18)
        registers[27] = registers[20][1]
        registers[28] = registers[20][2]
        goto p200
        ::p614::
        if registers[8] ~= "Second" then
            goto p145
        end
        goto p463
        ::p619::
        registers[18] = registers[11]
        goto p221
        ::p621::
        registers[17] = (255)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        registers[11] = registers[11](registers[12], registers[13])
        goto p335
    end
end
