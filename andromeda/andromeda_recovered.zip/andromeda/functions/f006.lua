-- Recovered function f6; author names are unavailable.
F.f6 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f6")
        tick(1)
        goto p32
        ::p8::
        tick(8)
        if registers[4] ~= 0 then
            goto p20
        end
        goto p108
        ::p20::
        registers[5] = (1)
        registers[3] = (0)
        goto p76
        ::p23::
        tick(23)
        registers[7] = (registers[6] * 1)
        registers[7] = registers[7] / 0
        goto p110
        ::p26::
        tick(26)
        registers[7] = (registers[6] * 0)
        registers[7] = registers[7] / 0
        goto p112
        ::p32::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (1)
        registers[4] = upvalues[1]
        registers[5] = registers[2]
        goto p96
        ::p60::
        tick(60)
        registers[6] = 1 ^ registers[6]
        registers[6] = -registers[6]
        if registers[5] ~= 0 then
            goto p68
        end
        goto p8
        ::p64::
        tick(64)
        registers[7] = registers[2]
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        goto p60
        ::p68::
        if registers[5] ~= 2047 then
            goto p76
        end
        goto p113
        ::p73::
        tick(73)
        registers[8] = registers[3] + registers[8]
        registers[7] = registers[7] * registers[8]
        do
            return registers[7]
        end
        ::p76::
        registers[7] = (registers[5] - 1023)
        registers[7] = 2 ^ registers[7]
        registers[7] = registers[6] * registers[7]
        registers[8] = registers[4] / 4503599627370496
        goto p73
        ::p96::
        registers[6] = (1)
        registers[7] = (20);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[4] = (registers[4] * 4294967296)
        registers[4] = registers[4] + registers[1]
        registers[5] = upvalues[1]
        registers[6] = registers[2]
        registers[7] = (21)
        registers[8] = (31);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1]
        goto p64
        ::p108::
        registers[7] = (registers[6] * 0)
        do
            return registers[7]
        end
        ::p110::
        tick(110)
        if registers[7] then
            goto p112
        end
        goto p26
        ::p112::
        do
            return registers[7]
        end
        ::p113::
        registers[7] = (registers[4] == 0)
        if not registers[7] then
            goto p110
        end
        goto p23
    end
end
