-- Recovered function f157; author names are unavailable.
F.f157 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2 = nil, nil, nil
        local a = nil
        local tick = new_tick("f157")
        tick(1)
        goto p10
        ::p2::
        tick(2)
        do
            return 
        end
        ::p3::
        tick(3)
        slot_2 = upvalues[1][30];
        slot_2 = slot_2()
        upvalues[0]["planting_start_time"] = slot_2
        goto p2
        ::p7::
        tick(7)
        slot_2 = upvalues[0]["planting_start_time"]
        if slot_2 ~= slot_0 then
            goto p2
        end
        goto p3
        ::p10::
        a = {
            ...,
        }
        slot_1 = a[1]
        if not slot_1 then
            goto p13
        end
        goto p7
        ::p13::
        upvalues[0]["planting_start_time"] = slot_0
        do
            return 
        end
    end
end
