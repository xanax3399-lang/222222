-- Recovered function f442; author names are unavailable.
F.f442 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f442")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        z = registers[1]
        registers[3] = z;
        registers[(2)] = z["build_maps"]
        registers[(2)](registers[3])
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (#registers[2])
        goto p42
        ::p9::
        tick(9)
        registers[6] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p70
        goto p79
        ::p22::
        tick(22)
        registers[6] = registers[1]["maps"]
        registers[6] = registers[6]["visuals"]
        registers[7] = registers[3]["visuals"]
        goto p53
        ::p36::
        tick(36)
        z = registers[1]
        registers[9] = z;
        registers[(8)] = z["decode"]
        registers[10] = registers[2][registers[7]]
        registers[8] = registers[8](registers[9], registers[10])
        goto p86
        ::p42::
        if registers[3] ~= 0 then
            goto p129
        end
        goto p94
        ::p44::
        tick(44)
        registers[4] = upvalues[1][86]
        registers[5] = "play resource/warning.wav"
        registers[(4)](registers[5])
        do
            return 
        end
        ::p53::
        registers[(4)](unpack_range(7, registers, 5))
        registers[4] = upvalues[1][86]
        registers[5] = "play ui\\beepclear"
        goto p91
        ::p70::
        tick(70)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p36
        end
        goto p99
        ::p79::
        tick(79)
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["apply_group"]
        registers[6] = registers[1]["maps"]
        registers[6] = registers[6]["antiaim"]
        registers[7] = registers[3]["antiaim"]
        registers[(4)](unpack_range(7, registers, 5))
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["apply_group"]
        goto p22
        ::p86::
        registers[3] = registers[8]
        registers[8] = environment["type"]
        registers[9] = registers[3]
        goto p109
        ::p91::
        registers[(4)](registers[5])
        do
            return 
        end
        ::p94::
        registers[3] = upvalues[1][86]
        registers[4] = "play resource/warning.wav"
        registers[(3)](registers[4])
        do
            return 
        end
        ::p99::
        tick(99)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = environment["type"]
        registers[5] = registers[3]
        goto p144
        ::p109::;
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] ~= "table" then
            goto p70
        end
        goto p99
        ::p129::
        registers[3] = nil
        registers[4] = (1)
        registers[5] = (#registers[2])
        goto p9
        ::p144::;
        registers[(4)] = registers[(4)](registers[5])
        branch_taken = false
        if registers[4] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p79
        end
        goto p44
    end
end
