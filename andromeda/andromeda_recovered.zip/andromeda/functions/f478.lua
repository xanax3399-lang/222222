-- Recovered function f478; author names are unavailable.
F.f478 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f478")
        tick(1)
        goto p80
        ::p2::
        tick(2)
        slot_2 = upvalues[0]["ragebot"]
        slot_2 = slot_2["enemy_resolver_output"]
        goto p91
        ::p12::
        tick(12)
        z = slot_2
        slot_4 = z;
        slot_3 = z["get"]
        slot_5 = slot_1
        slot_3 = slot_3(slot_4, slot_5)
        slot_3 = (slot_3 == true)
        goto p76
        ::p26::
        tick(26)
        slot_3 = slot_2["get"]
        slot_3 = (slot_3 ~= slot_0)
        ::p46::
        tick(46)
        if not slot_3 then
            goto p76
        end
        goto p12
        ::p62::
        tick(62)
        slot_2 = nil
        ::p65::
        tick(65)
        slot_3 = (slot_2 ~= slot_0)
        if not slot_3 then
            goto p46
        end
        goto p26
        ::p76::
        do
            return slot_3
        end
        ::p80::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["ragebot"]
        slot_2 = (slot_2 ~= slot_0)
        if not slot_2 then
            goto p91
        end
        goto p2
        ::p91::
        if slot_2 then
            goto p65
        end
        goto p62
    end
end
