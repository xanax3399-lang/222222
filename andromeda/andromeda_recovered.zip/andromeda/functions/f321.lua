-- Recovered function f321; author names are unavailable.
F.f321 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f321")
        tick(1)
        goto p87
        ::p18::
        tick(18)
        registers[3] = upvalues[0]["px"]
        registers[4] = (21)
        registers[5] = registers[2]
        goto p69
        ::p28::
        tick(28)
        if registers[1] ~= "hc" then
            goto p82
        end
        registers[3] = upvalues[0]["px"]
        registers[4] = (22)
        registers[5] = registers[2]
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p48::
        tick(48)
        if registers[1] ~= "ping" then
            goto p28
        end
        registers[3] = upvalues[0]["px"]
        registers[4] = (25)
        registers[5] = registers[2]
        goto p70
        ::p60::
        tick(60);
        registers[(3.0)] = registers[(3.0)](registers[4.0])
        if not registers[3] then
            goto p48
        end
        goto p18
        ::p69::
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p70::
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p82::
        registers[3] = upvalues[0]["px"]
        registers[4] = (18)
        registers[5] = registers[2]
        goto p102
        ::p87::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0]["is_bomb_indicator_kind"]
        registers[4] = registers[1]
        goto p60
        ::p102::
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
    end
end
