-- Recovered function f456; author names are unavailable.
F.f456 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f456")
        tick(1)
        goto p63
        ::p2::
        tick(2)
        registers[6] = nil
        do
            return registers[6]
        end
        ::p28::
        tick(28)
        if registers[6] ~= "number" then
            goto p2
        end
        goto p35
        ::p32::
        tick(32)
        if registers[7] ~= "number" then
            goto p2
        end
        goto p79
        ::p35::
        registers[7] = environment["type"]
        a = registers
        z = 8
        q = registers
        q = q[4]
        a[z] = q;
        registers[(7)] = registers[(7)](registers[8])
        goto p32
        ::p41::
        tick(41)
        registers[5] = registers[2]
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        z = 0
        for f = 3, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = environment["type"]
        registers[7] = registers[3];
        registers[(6)] = registers[(6)](registers[7])
        goto p28
        ::p56::
        tick(56)
        registers[6] = upvalues[1]
        a = registers
        z = 7
        q = registers
        q = q[3]
        a[z] = q
        registers[8] = registers[4]
        registers[9] = registers[5]
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p63::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0][47]
        registers[4] = registers[1]
        goto p41
        ::p79::
        registers[8] = environment["type"]
        registers[9] = registers[5];
        registers[(8)] = registers[(8)](registers[9])
        branch_taken = false
        if registers[8] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p56
        end
        goto p2
    end
end
