-- Recovered function f401; author names are unavailable.
F.f401 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local tick = new_tick("f401")
        tick(1)
        goto p89
        ::p5::
        tick(5)
        slot_2 = nil
        do
            return slot_2
        end
        ::p15::
        tick(15)
        slot_3 = upvalues[1]
        slot_4 = slot_2
        do
            return slot_3(slot_4)
        end
        ::p35::
        tick(35)
        if slot_2 ~= slot_0 then
            goto p15
        end
        goto p93
        ::p39::
        tick(39)
        slot_2 = upvalues[0][50]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 then
            goto p51
        end
        goto p5
        ::p51::
        slot_2 = upvalues[0][37]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        goto p35
        ::p89::
        slot_1 = upvalues[0][32];
        slot_1 = slot_1()
        if slot_1 == slot_0 then
            goto p5
        end
        goto p39
        ::p93::
        slot_3 = nil
        do
            return slot_3
        end
    end
end
