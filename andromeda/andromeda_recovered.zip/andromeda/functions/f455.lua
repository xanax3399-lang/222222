-- Recovered function f455; author names are unavailable.
F.f455 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f455")
        tick(1)
        goto p17
        ::p3::
        tick(3)
        slot_4 = slot_2
        do
            return slot_4
        end
        ::p5::
        tick(5)
        slot_4 = slot_3
        do
            return slot_4
        end
        ::p7::
        tick(7)
        slot_3 = slot_2
        do
            return slot_3
        end
        ::p9::
        tick(9)
        z = slot_1
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        slot_4 = environment["type"]
        goto p20
        ::p13::
        tick(13)
        slot_3 = slot_1["get"]
        if slot_3 ~= slot_0 then
            goto p9
        end
        goto p7
        ::p17::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_1 == slot_0 then
            goto p7
        end
        goto p13
        ::p20::
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        branch_taken = false
        if slot_4 ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p5
        end
        goto p3
    end
end
