-- Recovered function f413; author names are unavailable.
F.f413 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f413")
        tick(1)
        goto p33
        ::p11::
        tick(11)
        registers[4] = upvalues[0]["px"]
        registers[5] = (36)
        registers[6] = registers[3]
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p33::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[2] then
            goto p48
        end
        registers[4] = upvalues[0]["px"]
        registers[5] = (12)
        registers[6] = registers[3]
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
        ::p48::
        registers[4] = upvalues[0]["is_bomb_indicator_kind"]
        registers[5] = registers[1];
        registers[(4)] = registers[(4)](registers[5])
        if not registers[4] then
            goto p65
        end
        goto p11
        ::p65::
        tick(65)
        registers[4] = upvalues[0]["px"]
        registers[5] = (35)
        registers[6] = registers[3]
        do
            return registers[(4)](unpack_range(6, registers, 5))
        end
    end
end
