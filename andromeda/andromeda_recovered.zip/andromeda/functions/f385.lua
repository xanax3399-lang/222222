-- Recovered function f385; author names are unavailable.
F.f385 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f385")
        tick(1)
        goto p89
        ::p11::
        tick(11)
        upvalues[1]["capture_frame"] = -1
        upvalues[1]["published_frame"] = -1
        upvalues[1]["published_count"] = 0
        upvalues[1]["last_capture_time"] = 0
        registers[2] = upvalues[1]["update_planting_state"]
        registers[3] = (false)
        goto p41
        ::p20::
        tick(20)
        do
            return 
        end
        ::p21::
        tick(21)
        registers[(2)](registers[3])
        registers[2] = upvalues[2]["set_callback"]
        registers[3] = "indicator"
        registers[4] = upvalues[1]["capture"]
        registers[5] = registers[1]
        goto p61
        ::p33::
        tick(33)
        upvalues[1]["active"] = registers[1]
        upvalues[1]["capture_count"] = 0
        upvalues[1]["render_count"] = 0
        goto p11
        ::p37::
        tick(37)
        do
            return 
        end
        ::p41::
        registers[(2)](registers[3])
        registers[2] = upvalues[1]["clear_table"]
        registers[3] = upvalues[1]["visible_keys"]
        registers[(2)](registers[3])
        registers[2] = upvalues[1]["clear_table"]
        registers[3] = upvalues[1]["current_keys"]
        goto p21
        ::p61::
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[2]["set_callback"]
        registers[3] = "paint"
        registers[4] = upvalues[1]["paint"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        do
            return 
        end
        ::p89::
        registers[1] = upvalues[0]["skip_native_cleanup"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p93
        end
        goto p37
        ::p93::
        registers[1] = upvalues[1]["is_enabled"];
        registers[1] = registers[1]()
        registers[2] = upvalues[1]["active"]
        if registers[2] ~= registers[1] then
            goto p33
        end
        goto p20
    end
end
