-- Recovered function f297; author names are unavailable.
F.f297 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f297")
        tick(1)
        goto p146
        ::p2::
        tick(2);
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if registers[5] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p230
        end
        goto p226
        ::p5::
        tick(5)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.delay%.hidden%.type$"
        registers[9] = registers[9](registers[10], registers[11])
        goto p179
        ::p9::
        tick(9)
        if registers[7] == registers[0] then
            goto p162
        end
        goto p372
        ::p11::
        tick(11)
        if registers[9] then
            goto p280
        end
        goto p311
        ::p13::
        tick(13)
        branch_taken = false
        if registers[2] ~= "Single" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p38
        end
        goto p291
        ::p15::
        tick(15)
        if registers[7] ~= "number" then
            goto p246
        end
        goto p326
        ::p24::
        tick(24)
        registers[4] = registers[2]
        goto p142
        ::p26::
        tick(26)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.yaw_modifiers%.type$"
        registers[9] = registers[9](registers[10], registers[11])
        if not registers[9] then
            goto p332
        end
        if registers[2] ~= "Offset" then
            goto p221
        end
        goto p219
        ::p35::
        tick(35)
        if registers[2] ~= "Duo" then
            goto p221
        end
        goto p101
        ::p37::
        tick(37)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[5]
        end
        ::p38::
        tick(38)
        registers[8] = "Default"
        goto p221
        ::p50::
        tick(50)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.yaw_modifiers%.values$"
        registers[9] = registers[9](registers[10], registers[11])
        if registers[9] then
            goto p151
        end
        goto p114
        ::p55::
        tick(55)
        registers[8] = "Solo"
        goto p221
        ::p57::
        tick(57)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "defensive_pitch_mode"
        registers[9] = registers[9](registers[10], registers[11])
        goto p11
        ::p61::
        tick(61)
        if registers[2] ~= "General" then
            goto p107
        end
        goto p88
        ::p63::
        tick(63)
        if registers[3] == registers[0] then
            goto p318
        end
        goto p50
        ::p67::
        tick(67)
        registers[4] = environment["type"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        goto p258
        ::p72::
        tick(72)
        if registers[2] ~= "Side based" then
            goto p236
        end
        ::p82::
        tick(82)
        registers[8] = "Fluctuate"
        goto p221
        ::p85::
        tick(85)
        registers[9] = nil
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[9]
        end
        ::p88::
        registers[8] = upvalues[1][1]
        goto p221
        ::p90::
        tick(90)
        if not registers[9] then
            goto p318
        end
        goto p151
        ::p92::
        tick(92)
        registers[9] = registers[2]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[9]
        end
        ::p101::
        registers[8] = "Double"
        goto p221
        ::p103::
        tick(103)
        registers[8] = "Solo"
        goto p221
        ::p105::
        tick(105)
        registers[8] = "Double"
        goto p221
        ::p107::
        tick(107)
        if registers[3] == registers[0] then
            goto p293
        end
        goto p157
        ::p110::
        tick(110)
        branch_taken = false
        if registers[2] ~= "Solo" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p38
        end
        goto p13
        ::p113::
        tick(113)
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[4]
        end
        ::p114::
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.yaw_modifiers%.switch$"
        registers[9] = registers[9](registers[10], registers[11])
        goto p90
        ::p118::
        tick(118)
        registers[7] = nil
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[7]
        end
        ::p140::
        tick(140)
        registers[8] = "Default"
        goto p221
        ::p142::
        tick(142)
        if registers[4] then
            goto p113
        end
        goto p352
        ::p146::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = registers[1]["get_list"]
        if registers[4] ~= registers[0] then
            goto p347
        end
        goto p67
        ::p151::
        if registers[2] ~= "Single" then
            goto p35
        end
        goto p103
        ::p153::
        tick(153)
        if registers[2] ~= "Specific" then
            goto p221
        end
        goto p140
        ::p157::
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.delay%.type$"
        registers[9] = registers[9](registers[10], registers[11])
        if registers[9] then
            goto p110
        end
        goto p5
        ::p162::
        registers[8] = registers[2]
        if registers[3] ~= "antiaim.conditions" then
            goto p107
        end
        goto p61
        ::p174::
        tick(174)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "%.yaw%.type$"
        registers[9] = registers[9](registers[10], registers[11])
        if not registers[9] then
            goto p63
        end
        goto p212
        ::p179::
        if not registers[9] then
            goto p293
        end
        goto p110
        ::p181::
        tick(181)
        branch_taken = false
        if registers[2] ~= "L / R" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p210
        end
        goto p324
        ::p183::
        tick(183)
        registers[9] = registers[5]
        registers[10] = registers[2];
        registers[(9)] = registers[(9)](registers[10])
        goto p269
        ::p187::
        tick(187)
        if registers[9] then
            goto p200
        end
        goto p345
        ::p200::
        tick(200)
        registers[8] = registers[9]
        goto p221
        ::p210::
        tick(210)
        registers[8] = "Double"
        goto p221
        ::p212::
        if registers[2] ~= "180" then
            goto p181
        end
        goto p55
        ::p214::
        tick(214)
        branch_taken = false
        if registers[2] ~= "Double" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p82
        end
        goto p72
        ::p219::
        registers[8] = "Off"
        ::p221::
        tick(221)
        registers[9] = registers[5]
        registers[10] = registers[8];
        registers[(9)] = registers[(9)](registers[10])
        if not registers[9] then
            goto p183
        end
        goto p343
        ::p226::
        registers[5] = environment["type"]
        registers[6] = registers[2];
        registers[(5)] = registers[(5)](registers[6])
        goto p375
        ::p230::
        a = D.f298
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[5] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f299
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[7] = environment["type"]
        registers[8] = registers[2];
        registers[(7)] = registers[(7)](registers[8])
        goto p15
        ::p236::
        branch_taken = false
        if registers[2] ~= "Custom" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p140
        end
        goto p153
        ::p246::
        registers[7] = environment["type"]
        registers[8] = registers[2];
        registers[(7)] = registers[(7)](registers[8])
        goto p283
        ::p258::
        registers[4] = (registers[4] == "string")
        if not registers[4] then
            goto p142
        end
        goto p24
        ::p266::
        tick(266)
        registers[5] = registers[2]
        goto p354
        ::p269::
        if not registers[9] then
            goto p85
        end
        goto p92
        ::p280::
        tick(280)
        if registers[2] ~= "Left ~ Right" then
            goto p330
        end
        goto p105
        ::p283::
        branch_taken = false
        if registers[7] ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p297
        end
        goto p118
        ::p286::
        tick(286)
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "defensive_yaw_mode"
        registers[9] = registers[9](registers[10], registers[11])
        if not registers[9] then
            goto p187
        end
        goto p335
        ::p291::
        if registers[2] ~= "Static" then
            goto p214
        end
        goto p38
        ::p293::
        if registers[3] == registers[0] then
            goto p63
        end
        goto p174
        ::p297::
        registers[7] = environment["tonumber"]
        registers[8] = registers[2];
        registers[(7)] = registers[(7)](registers[8])
        goto p9
        ::p311::
        z = registers[3]
        registers[10] = z;
        registers[(9)] = z["find"]
        registers[11] = "defensive_yaw_mode"
        registers[9] = registers[9](registers[10], registers[11])
        if not registers[9] then
            goto p221
        end
        goto p280
        ::p316::
        tick(316)
        registers[5] = nil
        goto p37
        ::p318::
        if registers[3] == registers[0] then
            goto p332
        end
        goto p26
        ::p324::
        if registers[2] ~= "Specific" then
            goto p221
        end
        goto p210
        ::p326::
        registers[7] = registers[6]
        registers[8] = registers[2]
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[(7)](registers[8])
        end
        ::p330::
        if registers[2] ~= "Delay" then
            goto p221
        end
        goto p286
        ::p332::
        if registers[3] == registers[0] then
            goto p221
        end
        goto p57
        ::p335::
        registers[9] = "Delayed"
        goto p187
        ::p343::
        registers[9] = registers[8]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[9]
        end
        ::p345::
        registers[9] = "Double"
        goto p200
        ::p347::
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["get_list"];
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = environment["type"]
        registers[6] = registers[4]
        goto p2
        ::p352::
        registers[4] = nil
        goto p113
        ::p354::
        tick(354)
        if registers[5] then
            goto p37
        end
        goto p316
        ::p372::
        registers[8] = registers[6]
        registers[9] = registers[7]
        do
            if not N then

            else
                for f, F in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[(8)](registers[9])
        end
        ::p375::
        registers[5] = (registers[5] == "string")
        if not registers[5] then
            goto p354
        end
        goto p266
    end
end
