-- Recovered function f248; author names are unavailable.
F.f248 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8 = nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, n, v, R = andromeda_environment, nil, nil, nil
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f248")
        tick(1)
        goto p45
        ::p2::
        tick(2)
        slot_4 = (1)
        slot_5 = (#slot_3)
        slot_6 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_6 + 0
        n = (slot_5 + 0)
        v = (slot_4 - U)
        goto p38
        goto p107
        ::p8::
        tick(8)
        slot_3 = (false)
        do
            return slot_3
        end
        ::p10::
        tick(10)
        if slot_2 ~= slot_0 then
            goto p73
        end
        goto p8
        ::p26::
        tick(26)
        branch_taken = false
        if slot_4 ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p55
        end
        goto p40
        ::p38::
        tick(38)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_7 = v
            branch_taken = true
        end
        if branch_taken then
            goto p98
        end
        goto p107
        ::p40::
        slot_4 = (false)
        do
            return slot_4
        end
        ::p42::
        tick(42);
        slot_4 = slot_4(slot_5)
        if slot_4 ~= "string" then
            goto p93
        end
        goto p103
        ::p45::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        if slot_1 == slot_0 then
            goto p8
        end
        goto p10
        ::p55::
        slot_4 = slot_3[slot_2]
        if slot_4 ~= true then
            goto p2
        end
        goto p101
        ::p59::
        tick(59)
        slot_8 = (true)
        do
            return slot_8
        end
        ::p73::
        z = slot_1
        slot_4 = z;
        slot_3 = z["get"];
        slot_3 = slot_3(slot_4)
        slot_4 = environment["type"]
        slot_5 = slot_3
        goto p42
        ::p93::
        slot_4 = environment["type"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        goto p26
        ::p98::
        slot_8 = slot_3[slot_7]
        if slot_8 ~= slot_2 then
            goto p38
        end
        goto p59
        ::p101::
        tick(101)
        slot_4 = (true)
        do
            return slot_4
        end
        ::p103::
        slot_4 = slot_3 == slot_2
        do
            return slot_4
        end
        ::p107::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_4 = (false)
        do
            return slot_4
        end
    end
end
