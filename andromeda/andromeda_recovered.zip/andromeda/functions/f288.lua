-- Recovered function f288; author names are unavailable.
F.f288 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f288")
        tick(1)
        goto p6
        ::p2::
        tick(2)
        registers[4] = registers[3]["value"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        goto p50
        ::p6::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[1][registers[2]]
        if registers[3] == registers[0] then
            goto p63
        end
        goto p65
        ::p26::
        tick(26)
        branch_taken = false
        if registers[5] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p28
        end
        goto p69
        ::p28::
        registers[5] = upvalues[0]["clamp"]
        registers[6] = upvalues[1][154]
        registers[7] = registers[4] + 0.5;
        registers[(6)] = registers[(6)](registers[7])
        goto p81
        ::p50::
        registers[5] = environment["type"]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        goto p26
        ::p63::
        tick(63)
        registers[4] = nil
        do
            return registers[4]
        end
        ::p65::
        registers[4] = registers[3]["value"]
        if registers[4] ~= registers[0] then
            goto p2
        end
        goto p63
        ::p69::
        tick(69)
        registers[5] = nil
        do
            return registers[5]
        end
        ::p81::
        registers[7] = (0)
        registers[8] = (100)
        do
            return registers[(5)](unpack_range(8, registers, 6))
        end
    end
end
