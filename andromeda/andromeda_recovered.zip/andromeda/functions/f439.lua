-- Recovered function f439; author names are unavailable.
F.f439 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f439")
        tick(1)
        goto p26
        ::p11::
        tick(11)
        registers[4] = registers[4]["cl_updaterate"]
        registers[4] = (registers[4] ~= registers[0])
        if not registers[4] then
            goto p36
        end
        goto p96
        ::p26::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][23];
        registers[2] = registers[2]()
        registers[3] = upvalues[1]["latency_cache"]
        goto p128
        ::p32::
        tick(32)
        registers[5] = (0)
        registers[3] = registers[3](registers[4], registers[5])
        registers[4] = environment["cvar"]
        goto p11
        ::p36::
        tick(36)
        if registers[4] then
            goto p147
        end
        goto p85
        ::p51::
        tick(51)
        registers[3] = upvalues[1]["latency_cache"]
        registers[3] = registers[3]["time"]
        do
            return registers[3]
        end
        ::p57::
        tick(57)
        registers[6] = registers[5]
        do
            return registers[6]
        end
        ::p82::
        tick(82)
        registers[5] = 0.5 / registers[4]
        registers[3] = (registers[3] - registers[5])
        goto p116
        ::p85::
        registers[4] = (0)
        goto p147
        ::p96::
        registers[4] = environment["cvar"]
        registers[4] = registers[4]["cl_updaterate"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get_float"];
        registers[(4)] = registers[(4)](registers[5])
        goto p36
        ::p104::
        tick(104)
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = (0)
        registers[8] = registers[1];
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1]["latency_cache"]
        registers[6]["tick"] = registers[2]
        registers[6] = upvalues[1]["latency_cache"]
        registers[6]["time"] = registers[5]
        goto p57
        ::p114::
        tick(114)
        registers[4] = (0)
        goto p32
        ::p116::
        tick(116)
        registers[5] = upvalues[2]["clamp"]
        registers[6] = upvalues[0][151]
        registers[7] = registers[3]
        registers[8] = (0)
        goto p104
        ::p128::
        registers[3] = registers[3]["tick"]
        if registers[3] ~= registers[2] then
            goto p141
        end
        goto p51
        ::p141::
        registers[3] = upvalues[0][151]
        registers[4] = upvalues[0][67];
        registers[4] = registers[4]()
        if registers[4] then
            goto p32
        end
        goto p114
        ::p147::
        if not (0.001 < registers[4]) then
            goto p116
        end
        goto p82
    end
end
