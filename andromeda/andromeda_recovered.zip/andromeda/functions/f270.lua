-- Recovered function f270; author names are unavailable.
F.f270 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f270")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]["quit_requested"]
        slot_1 = (slot_1 == true)
        do
            return slot_1
        end
    end
end
