-- Recovered function f352; author names are unavailable.
F.f352 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f352")
        tick(1)
        goto p103
        ::p3::
        tick(3)
        if not (registers[3] <= 0) then
            goto p130
        end
        goto p56
        ::p23::
        tick(23)
        if not registers[15] then
            goto p90
        end
        goto p37
        ::p31::
        tick(31)
        if registers[11] then
            goto p47
        end
        goto p163
        ::p33::
        tick(33)
        registers[11] = (registers[11] / registers[9]);
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = registers[5]
        goto p134
        ::p37::
        registers[15] = (0)
        goto p90
        ::p39::
        tick(39)
        registers[19] = registers[19] + registers[20]
        registers[19] = registers[19] * registers[8]
        registers[19] = registers[19] * registers[6]
        do
            return registers[19]
        end
        ::p43::
        tick(43)
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = upvalues[1][151]
        goto p51
        ::p47::
        tick(47)
        registers[12] = registers[4]
        if registers[12] then
            goto p190
        end
        goto p68
        ::p51::
        registers[10] = (1)
        registers[11] = upvalues[1][154]
        registers[12] = (registers[6] * 7)
        goto p116
        ::p56::
        tick(56)
        registers[6] = (0)
        do
            return registers[6]
        end
        ::p59::
        tick(59)
        if registers[6] ~= "number" then
            goto p56
        end
        goto p3
        ::p68::
        registers[12] = (1)
        goto p190
        ::p70::
        tick(70)
        registers[15] = (registers[12] * 0.37)
        registers[14] = registers[14] + registers[15]
        registers[15] = registers[5]
        goto p23
        ::p82::
        tick(82)
        registers[9] = (100);
        registers[6] = registers[6](unpack_range(9, registers, 7))
        registers[6] = (registers[6] * 0.01)
        registers[7] = upvalues[1][161]
        registers[8] = (registers[2] - registers[1]);
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = upvalues[1][162]
        goto p98
        ::p90::
        if registers[15] then
            goto p144
        end
        goto p188
        ::p98::
        registers[9] = (15)
        registers[10] = upvalues[1][151]
        registers[11] = (3)
        registers[12] = (registers[7] * 0.35)
        goto p43
        ::p103::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = environment["type"]
        registers[7] = registers[3];
        registers[(6)] = registers[(6)](registers[7])
        goto p59
        ::p108::
        tick(108)
        registers[18] = 1 - registers[17]
        registers[19] = registers[15] * registers[18]
        registers[20] = registers[16] * registers[17]
        goto p39
        ::p116::;
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = 8 - registers[11]
        registers[9] = registers[9](registers[10], registers[11])
        registers[10] = upvalues[1][154]
        a = upvalues[2];
        registers[11] = a[2][a[1]]["packets"]
        goto p33
        ::p130::
        registers[6] = upvalues[0]["clamp"]
        registers[7] = registers[3]
        registers[8] = (0)
        goto p82
        ::p134::
        if not registers[11] then
            goto p31
        end
        goto p157
        ::p144::
        tick(144)
        registers[14] = registers[14] + registers[15]
        registers[15] = upvalues[1][163]
        registers[16] = registers[14];
        registers[(15)] = registers[(15)](registers[16])
        registers[16] = upvalues[3]
        registers[17] = registers[13];
        registers[(16)] = registers[(16)](registers[17])
        registers[16] = (registers[16] * 2)
        goto p159
        ::p153::
        tick(153)
        registers[15] = (registers[6] * 0.11)
        registers[15] = 0.04 + registers[15]
        registers[14] = registers[14] * registers[15]
        goto p70
        ::p157::
        registers[11] = (17)
        goto p31
        ::p159::
        registers[16] = (registers[16] - 1)
        registers[17] = (registers[6] * 0.5)
        registers[17] = 0.2 + registers[17]
        goto p108
        ::p163::
        registers[11] = (29)
        goto p47
        ::p188::
        registers[15] = (1.9)
        goto p144
        ::p190::
        registers[13] = (registers[10] * 97)
        registers[14] = (registers[12] * 13)
        registers[13] = registers[13] + registers[14]
        registers[13] = registers[13] + registers[11]
        a = upvalues[2];
        registers[14] = a[2][a[1]]["packets"]
        goto p153
    end
end
