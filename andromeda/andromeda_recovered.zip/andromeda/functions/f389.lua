-- Recovered function f389; author names are unavailable.
F.f389 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f389")
        tick(1)
        goto p102
        ::p2::
        tick(2)
        registers[10] = registers[2]
        registers[11] = registers[4]
        registers[12] = registers[6]
        registers[13] = (0)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        goto p83
        ::p17::
        tick(17)
        registers[12] = registers[6]
        registers[13] = (0)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = registers[7]
        registers[(8)](unpack_range(16, registers, 9))
        goto p143
        ::p24::
        tick(24)
        registers[8] = upvalues[0][128]
        registers[9] = registers[1] + registers[4]
        registers[10] = registers[2]
        registers[11] = registers[5]
        goto p17
        ::p51::
        tick(51)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = (true)
        registers[(8)](unpack_range(21, registers, 9))
        do
            return 
        end
        ::p65::
        tick(65)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = registers[7]
        goto p51
        ::p79::
        tick(79)
        if not (0 < registers[5]) then
            goto p143
        end
        goto p24
        ::p83::
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = registers[7]
        registers[21] = (true)
        registers[(8)](unpack_range(21, registers, 9))
        goto p79
        ::p102::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = a[6]
        registers[7] = a[7]
        registers[8] = upvalues[0][129]
        registers[9] = registers[1]
        goto p2
        ::p143::
        registers[8] = upvalues[0][129]
        registers[9] = registers[1] + registers[4]
        registers[9] = registers[9] + registers[5]
        registers[10] = registers[2]
        registers[11] = registers[4]
        registers[12] = registers[6]
        registers[13] = (0)
        goto p65
    end
end
