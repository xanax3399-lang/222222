-- Recovered function f303; author names are unavailable.
F.f303 = function(function_metadata, upvalues)
    local code_metadata, operand_k = function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f303")
        tick(1)
        goto p69
        ::p2::
        tick(2)
        registers[16] = (registers[16] - 472)
        registers[16] = 23732 + registers[16]
        registers[16] = registers[16] + -23276
        registers[9][74] = registers[16]
        registers[15][94] = 68
        registers[8] = nil
        registers[9] = nil
        registers[10] = nil
        registers[11] = nil
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        goto p69
        ::p13::
        tick(13)
        registers[5] = upvalues[1]
        registers[6] = registers[1]
        registers[7] = registers[4]
        goto p36
        ::p24::
        tick(24)
        registers[16] = (21)
        ::p25::
        tick(25)
        if registers[16] then
            goto p2
        end
        registers[16] = (99)
        goto p2
        ::p36::;
        registers[5](registers[6], registers[7])
        registers[5] = upvalues[2]
        registers[6] = registers[4]
        registers[(5)](registers[6])
        goto p92
        ::p41::
        tick(41)
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[(4)](registers[5])
        goto p102
        ::p45::
        tick(45)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[2] = environment["pairs"]
        registers[3] = upvalues[3]["applied"]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(2)]
        n = registers[3]
        U = registers[4]
        goto p102
        goto p2
        ::p59::
        tick(59)
        registers[5] = upvalues[4][42]
        registers[6] = registers[3];
        registers[(5)] = registers[(5)](registers[6])
        if not registers[5] then
            goto p102
        end
        goto p41
        ::p64::
        tick(64)
        registers[4] = upvalues[4][50]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= true then
            goto p41
        end
        goto p59
        ::p69::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["ipairs"]
        registers[3] = upvalues[0]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[2](unpack_range(top, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(2)]
        n = registers[3]
        U = registers[4]
        goto p92
        registers[15] = operand_k
        registers[9] = code_metadata
        registers[16] = constant_cache[5]
        registers[17] = constant_cache[6];
        registers[(16)] = registers[(16)](registers[17])
        registers[16] = (451 ~= registers[16])
        if not registers[16] then
            goto p25
        end
        goto p24
        ::p92::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[3] = z;
            registers[4] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p13
        end
        goto p45
        ::p102::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[3] = z;
            registers[4] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p64
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
    end
end
