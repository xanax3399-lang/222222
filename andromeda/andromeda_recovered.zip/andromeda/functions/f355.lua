-- Recovered function f355; author names are unavailable.
F.f355 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f355")
        tick(1)
        goto p69
        ::p2::
        tick(2)
        registers[3] = (1)
        goto p65
        ::p50::
        tick(50)
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p65
        end
        goto p2
        ::p65::;
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = (1)
        registers[4] = (16)
        do
            return registers[(1)](unpack_range(4, registers, 2))
        end
        ::p69::
        registers[1] = upvalues[0]["clamp"]
        registers[2] = upvalues[1][154]
        registers[3] = upvalues[2]["solo"]
        goto p50
    end
end
