-- Recovered function f461; author names are unavailable.
F.f461 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f461")
        tick(1)
        goto p34
        ::p2::
        tick(2)
        if not slot_3 then
            goto p28
        end
        goto p40
        ::p4::
        tick(4)
        slot_3 = slot_1["options"]
        slot_3 = (slot_3 ~= slot_0)
        goto p2
        ::p28::
        tick(28)
        do
            return slot_3
        end
        ::p34::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (slot_1 ~= slot_0)
        if not slot_3 then
            goto p2
        end
        goto p4
        ::p40::
        slot_3 = slot_1["options"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["get"]
        slot_5 = slot_2
        slot_3 = slot_3(slot_4, slot_5)
        slot_3 = (slot_3 == true)
        goto p28
    end
end
