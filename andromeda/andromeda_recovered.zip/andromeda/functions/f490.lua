-- Recovered function f490; author names are unavailable.
F.f490 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f490")
        tick(1)
        goto p34
        ::p2::
        tick(2)
        slot_1 = upvalues[2]
        slot_1()
        do
            return 
        end
        ::p33::
        tick(33)
        do
            return 
        end
        ::p34::
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["viewmodel_offset_z"];
        slot_1 = slot_1(slot_2)
        if not slot_1 then
            goto p2
        end
        goto p33
    end
end
