-- Recovered function f119; author names are unavailable.
F.f119 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f119")
        tick(1)
        goto p58
        ::p14::
        tick(14)
        registers[8] = (8)
        registers[6] = registers[6](registers[7], registers[8])
        a = registers
        z = 5
        q = registers
        q = q[5]
        m = registers
        x = 6
        m = m[x]
        q = q + m
        a[z] = q
        do
            return registers[5]
        end
        ::p28::
        tick(28)
        registers[5] = upvalues[2]
        registers[6] = registers[4]
        registers[7] = (64)
        goto p106
        ::p45::
        tick(45)
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 65536)
        goto p83
        ::p58::
        registers[1] = upvalues[0]
        registers[2] = upvalues[1]
        registers[3] = (1)
        registers[4] = (4)
        m, x = pack_returns(registers[1](unpack_range(4, registers, 2)))
        z = 0
        for f = 1, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p28
        ::p76::
        tick(76)
        registers[8] = (16)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = (registers[6] * 256)
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[1]
        goto p14
        ::p83::
        registers[5] = registers[5] + registers[6]
        registers[6] = upvalues[2]
        registers[7] = registers[2]
        goto p76
        ::p106::
        registers[5] = registers[5](registers[6], registers[7])
        registers[5] = (registers[5] * 16777216)
        registers[6] = upvalues[2]
        registers[7] = registers[3]
        goto p45
    end
end
