-- Recovered function f98; author names are unavailable.
F.f98 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f98")
        tick(1)
        goto p103
        ::p2::
        tick(2)
        registers[9] = registers[4][4]
        goto p120
        ::p4::
        tick(4)
        registers[7] = registers[10]
        registers[10] = registers[5]["b"]
        if registers[10] then
            goto p34
        end
        registers[10] = registers[5][3]
        goto p34
        ::p16::
        tick(16)
        registers[10] = registers[5][2]
        goto p4
        ::p26::
        tick(26)
        registers[12] = registers[2][3]
        goto p154
        ::p28::
        tick(28)
        registers[11] = registers[7]
        if registers[11] then
            goto p57
        end
        goto p72
        ::p31::
        tick(31)
        registers[10] = registers[5]["r"]
        if registers[10] then
            goto p64
        end
        goto p61
        ::p34::
        registers[8] = registers[10]
        registers[10] = registers[5]["a"]
        if registers[10] then
            goto p175
        end
        goto p98
        ::p50::
        tick(50)
        registers[4] = registers[2][1]
        registers[5] = registers[2][2]
        registers[6] = registers[2][3]
        registers[7] = registers[3]
        do
            return unpack_range(7, registers, (4))
        end
        ::p55::
        tick(55)
        registers[15] = (255)
        goto p129
        ::p57::
        tick(57)
        registers[12] = registers[8]
        if registers[12] then
            goto p154
        end
        goto p26
        ::p61::
        registers[10] = registers[5][1]
        ::p64::
        registers[6] = registers[10]
        registers[10] = registers[5]["g"]
        if registers[10] then
            goto p4
        end
        goto p16
        ::p68::
        tick(68)
        registers[6] = registers[4][1]
        registers[7] = registers[4][2]
        registers[8] = registers[4][3]
        goto p2
        ::p72::
        registers[11] = registers[2][2]
        goto p57
        ::p98::
        registers[10] = registers[5][4]
        goto p175
        ::p101::
        tick(101)
        if registers[10] ~= "table" then
            goto p107
        end
        goto p31
        ::p103::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[1] ~= registers[0] then
            goto p131
        end
        goto p50
        ::p107::
        registers[10] = environment["type"]
        registers[11] = registers[5];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] ~= "number" then
            goto p120
        end
        goto p68
        ::p114::
        tick(114)
        registers[6] = nil
        registers[7] = nil
        registers[8] = nil
        registers[9] = nil
        registers[10] = environment["type"]
        registers[11] = registers[5];
        registers[(10)] = registers[(10)](registers[11])
        goto p101
        ::p120::
        tick(120)
        registers[10] = registers[6]
        if registers[10] then
            goto p28
        end
        goto p167
        ::p129::
        tick(129)
        m, x = pack_returns(registers[13](unpack_range(15, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return unpack_range(top, registers, 10)
        end
        ::p131::
        registers[4] = {
        }
        z = registers[1]
        registers[6] = z;
        registers[(5)] = z["get"]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(4)]
        for f = 1, top - (4) do
            q[(0) + f] = registers[(4) + f]
        end
        registers[5] = registers[4][1]
        goto p114
        ::p154::
        registers[13] = upvalues[0][162]
        registers[14] = registers[3]
        registers[15] = registers[9]
        goto p173
        ::p167::
        registers[10] = registers[2][1]
        goto p28
        ::p173::
        if registers[15] then
            goto p129
        end
        goto p55
        ::p175::
        registers[9] = registers[10]
        goto p120
    end
end
