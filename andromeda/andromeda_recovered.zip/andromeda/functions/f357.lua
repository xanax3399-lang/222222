-- Recovered function f357; author names are unavailable.
F.f357 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f357")
        tick(1)
        goto p28
        ::p5::
        tick(5)
        registers[5] = upvalues[0]["clamp"]
        registers[6] = registers[4]
        registers[7] = (0)
        registers[8] = (100)
        goto p112
        ::p10::
        tick(10)
        registers[5] = (0)
        goto p34
        ::p28::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = environment["tonumber"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] == registers[0] then
            goto p123
        end
        goto p67
        ::p34::
        tick(34)
        registers[4] = registers[5]
        goto p5
        ::p67::
        if not (registers[4] <= 0) then
            goto p5
        end
        goto p123
        ::p69::
        tick(69)
        registers[5] = (0)
        do
            return registers[5]
        end
        ::p71::
        tick(71)
        if not (registers[4] <= 0) then
            goto p87
        end
        goto p69
        ::p87::
        registers[5] = upvalues[1][151]
        registers[6] = (1)
        registers[7] = upvalues[1][154]
        registers[8] = upvalues[1][151]
        registers[9] = (1)
        registers[10] = (registers[1] - 1)
        registers[8] = registers[8](registers[9], registers[10])
        registers[8] = registers[8] * registers[4]
        registers[8] = (registers[8] * 0.01)
        registers[8] = registers[8] + 0.5
        m, x = pack_returns(registers[7](unpack_range(8, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[5](unpack_range(top, registers, 6))
        end
        ::p112::;
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[4] = registers[5]
        if registers[1] <= 1 then
            goto p69
        end
        goto p71
        ::p123::
        registers[5] = registers[3]
        if registers[5] then
            goto p34
        end
        goto p10
    end
end
