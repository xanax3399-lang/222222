-- Recovered function f286; author names are unavailable.
F.f286 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_13, slot_14 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f286")
        tick(1)
        goto p15
        ::p4::
        tick(4)
        slot_9 = slot_1
        do
            return slot_9
        end
        ::p6::
        tick(6)
        slot_10 = upvalues[0]["get_player_multiplier"]
        slot_11 = slot_4
        slot_12 = slot_2
        goto p183
        ::p10::
        tick(10)
        slot_11 = slot_9;
        slot_10 = slot_10(slot_11)
        if slot_10 ~= "number" then
            goto p111
        end
        goto p38
        ::p15::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = a[4]
        slot_5 = a[5]
        if slot_1 == slot_0 then
            goto p151
        end
        goto p159
        ::p18::
        tick(18)
        slot_12 = slot_12 + slot_13
        if not (1 < slot_12) then
            goto p172
        end
        goto p43
        ::p30::
        tick(30)
        if slot_5 == slot_0 then
            goto p172
        end
        goto p102
        ::p38::
        if not (slot_9 <= 0) then
            goto p121
        end
        goto p111
        ::p43::
        branch_taken = false
        if not (not (slot_12 < 900000)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p172
        end
        goto p88
        ::p45::
        tick(45)
        slot_9 = slot_2["z"]
        slot_10 = slot_2["z"]
        slot_9 = slot_9 * slot_10
        slot_8 = slot_8 + slot_9
        if not (slot_8 <= 0.01) then
            goto p194
        end
        goto p4
        ::p53::
        tick(53)
        slot_9 = (0)
        ::p54::
        tick(54)
        slot_7 = slot_7(slot_8, slot_9)
        goto p96
        ::p56::
        tick(56)
        slot_7 = slot_3
        goto p100
        ::p58::
        tick(58)
        slot_7 = upvalues[1][151]
        slot_8 = slot_6
        slot_9 = slot_3
        if slot_9 then
            goto p54
        end
        goto p53
        ::p65::
        tick(65)
        slot_11 = slot_1
        do
            return slot_11
        end
        ::p69::
        tick(69)
        slot_11 = slot_9 * slot_7
        slot_11 = slot_11 * slot_10
        if not (0 < slot_6) then
            goto p30
        end
        goto p222
        ::p73::
        tick(73)
        if not (slot_10 <= 0) then
            goto p69
        end
        goto p65
        ::p88::
        slot_13 = slot_2 * slot_11
        slot_13 = slot_1 + slot_13
        slot_14 = (slot_5 * 0.5)
        slot_14 = slot_14 * slot_11
        slot_14 = slot_14 * slot_11
        slot_13 = slot_13 + slot_14
        do
            return slot_13
        end
        ::p96::
        tick(96)
        if slot_7 then
            goto p100
        end
        goto p56
        ::p98::
        tick(98)
        if slot_10 then
            goto p73
        end
        goto p198
        ::p100::
        if slot_7 then
            goto p200
        end
        goto p149
        ::p102::
        slot_12 = slot_5["x"]
        slot_13 = slot_5["x"]
        slot_12 = slot_12 * slot_13
        slot_13 = slot_5["y"]
        slot_14 = slot_5["y"]
        slot_13 = slot_13 * slot_14
        slot_12 = slot_12 + slot_13
        goto p137
        ::p111::
        slot_10 = slot_1
        do
            return slot_10
        end
        ::p121::
        slot_10 = slot_6 > 0
        if not slot_10 then
            goto p98
        end
        goto p6
        ::p131::
        tick(131)
        slot_8 = slot_2["x"]
        slot_9 = slot_2["x"]
        slot_8 = slot_8 * slot_9
        goto p209
        ::p137::
        slot_13 = slot_5["z"]
        slot_14 = slot_5["z"]
        slot_13 = slot_13 * slot_14
        goto p18
        ::p141::
        tick(141)
        slot_11 = slot_11 + slot_12
        goto p30
        ::p149::
        slot_7 = (0)
        goto p200
        ::p151::
        tick(151)
        slot_6 = slot_1
        do
            return slot_6
        end
        ::p159::
        if slot_2 ~= slot_0 then
            goto p167
        end
        goto p151
        ::p167::
        slot_6 = upvalues[0]["get_ticks"];
        slot_6 = slot_6()
        slot_7 = slot_6 > 0
        if not slot_7 then
            goto p96
        end
        goto p58
        ::p172::
        slot_12 = slot_2 * slot_11
        slot_12 = slot_1 + slot_12
        do
            return slot_12
        end
        ::p181::
        tick(181)
        slot_8 = slot_1
        do
            return slot_8
        end
        ::p183::
        slot_10 = slot_10(slot_11, slot_12)
        goto p98
        ::p194::
        slot_9 = upvalues[1][28];
        slot_9 = slot_9()
        slot_10 = environment["type"]
        goto p10
        ::p198::
        slot_10 = (1)
        goto p73
        ::p200::
        if not (slot_7 <= 0) then
            goto p131
        end
        goto p181
        ::p209::
        slot_9 = slot_2["y"]
        slot_10 = slot_2["y"]
        slot_9 = slot_9 * slot_10
        slot_8 = slot_8 + slot_9
        goto p45
        ::p222::
        slot_12 = upvalues[0]["get_latency_time"]
        slot_13 = slot_9;
        slot_12 = slot_12(slot_13)
        goto p141
    end
end
