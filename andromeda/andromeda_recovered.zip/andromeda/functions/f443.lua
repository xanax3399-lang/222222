-- Recovered function f443; author names are unavailable.
F.f443 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil
        local environment, q = andromeda_environment, nil
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f443")
        tick(1)
        goto p78
        ::p2::
        tick(2)
        slot_3 = upvalues[0]["config"]
        slot_3 = slot_3["list"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["set"]
        goto p145
        ::p14::
        tick(14)
        slot_3 = slot_1["configs_db"]
        slot_3 = slot_3["menu_list"]
        slot_3 = (#slot_3)
        slot_3 = (slot_3 - 1)
        if not (slot_3 < slot_2) then
            goto p76
        end
        goto p119
        ::p33::
        tick(33)
        branch_taken = false
        if slot_3 ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p14
        end
        goto p2
        ::p35::
        tick(35)
        slot_2 = upvalues[0]["config"]
        slot_2 = slot_2["list"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["update"]
        slot_4 = slot_1["configs_db"]
        goto p91
        ::p46::
        tick(46)
        slot_2 = upvalues[0]["config"]
        slot_2 = slot_2["list"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["update"]
        slot_4 = new_frame(1)
        slot_5 = "No configs"
        q = slot_4
        q[1] = slot_5;
        slot_2(slot_3, slot_4)
        slot_2 = upvalues[0]["config"]
        slot_2 = slot_2["list"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["set"]
        slot_4 = (0);
        slot_2(slot_3, slot_4)
        do
            return 
        end
        ::p76::
        tick(76)
        do
            return 
        end
        ::p78::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = slot_1["configs_db"]
        slot_2 = slot_2["menu_list"]
        slot_2 = (#slot_2)
        if slot_2 ~= 0 then
            goto p35
        end
        goto p46
        ::p91::
        slot_4 = slot_4["menu_list"];
        slot_2(slot_3, slot_4)
        slot_2 = upvalues[0]["config"]
        goto p130
        ::p119::
        slot_3 = upvalues[0]["config"]
        slot_3 = slot_3["list"]
        z = slot_3
        slot_4 = z;
        slot_3 = z["set"]
        slot_5 = slot_1["configs_db"]
        slot_5 = slot_5["menu_list"]
        slot_5 = (#slot_5)
        slot_5 = (slot_5 - 1)
        goto p166
        ::p130::
        slot_2 = slot_2["list"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        goto p168
        ::p145::
        slot_5 = (0);
        slot_3(slot_4, slot_5)
        do
            return 
        end
        ::p166::;
        slot_3(slot_4, slot_5)
        goto p76
        ::p168::
        slot_3 = environment["type"]
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        goto p33
    end
end
