-- Recovered function f237; author names are unavailable.
F.f237 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f237")
        tick(1)
        goto p77
        ::p25::
        tick(25)
        slot_2 = upvalues[2][120]
        slot_3 = upvalues[1];
        slot_2 = slot_2(slot_3)
        goto p63
        ::p32::
        tick(32)
        slot_4 = {
        }
        slot_4["type"] = slot_2
        slot_5 = upvalues[4]["get_raw_value"]
        goto p46
        ::p42::
        tick(42)
        do
            return 
        end
        ::p46::
        slot_6 = upvalues[0];
        slot_5 = slot_5(slot_6)
        slot_4["value"] = slot_5
        slot_3[slot_2] = slot_4
        goto p89
        ::p51::
        tick(51)
        slot_3 = upvalues[1]
        if slot_3 ~= slot_0 then
            goto p25
        end
        goto p42
        ::p54::
        tick(54)
        slot_3 = upvalues[0]
        slot_4 = {
        }
        upvalues[3][slot_3] = slot_4
        ::p58::
        tick(58)
        slot_3 = upvalues[0]
        slot_3 = upvalues[3][slot_3]
        slot_4 = slot_3[slot_2]
        if slot_4 ~= slot_0 then
            goto p89
        end
        goto p32
        ::p63::
        slot_3 = upvalues[0]
        slot_3 = upvalues[3][slot_3]
        if slot_3 ~= slot_0 then
            goto p58
        end
        goto p54
        ::p77::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        if slot_2 == slot_0 then
            goto p42
        end
        goto p51
        ::p89::
        slot_4 = upvalues[2][110]
        slot_5 = upvalues[0]
        slot_6 = slot_1;
        slot_4(slot_5, slot_6)
        do
            return 
        end
    end
end
