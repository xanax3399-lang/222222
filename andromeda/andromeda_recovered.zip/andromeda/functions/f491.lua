-- Recovered function f491; author names are unavailable.
F.f491 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f491")
        tick(1)
        goto p44
        ::p2::
        tick(2)
        slot_1 = upvalues[1]
        slot_1()
        slot_1 = upvalues[2]
        slot_1()
        goto p43
        ::p27::
        tick(27)
        slot_1 = upvalues[0]
        z = slot_1
        slot_2 = z;
        slot_1 = z["reset_disable_fakelag"]
        slot_1(slot_2)
        goto p2
        ::p43::
        do
            return 
        end
        ::p44::
        slot_1 = upvalues[0]
        z = slot_1
        slot_2 = z;
        slot_1 = z["unset_aa"]
        slot_1(slot_2)
        goto p27
    end
end
