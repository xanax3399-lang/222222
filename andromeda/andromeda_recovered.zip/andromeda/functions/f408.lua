-- Recovered function f408; author names are unavailable.
F.f408 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f408")
        tick(1)
        goto p286
        ::p2::
        tick(2)
        registers[14] = registers[1]["pitch"]
        registers[14]["type"] = "Custom"
        registers[14] = registers[1]["pitch"]
        registers[15] = upvalues[9]["clamp"]
        registers[16] = registers[13]
        registers[17] = -89
        goto p139
        ::p9::
        tick(9)
        registers[6] = upvalues[2]["is_double_tap"];
        registers[6] = registers[6]()
        registers[7] = upvalues[2]["is_on_shot_antiaim"];
        registers[7] = registers[7]()
        if not registers[7] then
            goto p474
        end
        goto p181
        ::p15::
        tick(15)
        registers[13] = registers[14]
        goto p2
        ::p17::
        tick(17)
        if registers[15] then
            goto p170
        end
        goto p255
        ::p19::
        tick(19)
        registers[6] = (false)
        do
            return registers[6]
        end
        ::p21::
        tick(21)
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"];
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_pitch_refraction_down"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"];
        registers[(17)] = registers[(17)](registers[18])
        goto p573
        ::p28::
        tick(28)
        registers[22] = registers[4]["def_yaw_delayed_randomize"]
        z = registers[22]
        registers[23] = z;
        registers[(22)] = z["get"]
        m, x = pack_returns(registers[22](unpack_range(23, registers, 23)))
        m = m + 22 - 1
        top = m
        z = 0
        for f = 22, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[17](unpack_range(top, registers, 18)))
        z = 0
        for f = 17, 18 do
            z = (z + 1);
            registers[f] = x[z]
        end
        if registers[16] == registers[0] then
            goto p431
        end
        goto p347
        ::p37::
        tick(37)
        registers[12] = registers[4]["def_pitch"]
        z = registers[12]
        registers[13] = z;
        registers[(12)] = z["get"];
        registers[(12)] = registers[(12)](registers[13])
        goto p472
        ::p42::
        tick(42)
        registers[15] = registers[4]["def_yaw_left_value"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        goto p421
        ::p46::
        tick(46)
        if not registers[14] then
            goto p133
        end
        goto p597
        ::p48::
        tick(48)
        registers[18] = registers[4]["def_pitch_fluctuate_mode"]
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"]
        m, x = pack_returns(registers[18](unpack_range(19, registers, 19)))
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[13] = registers[14]
        goto p2
        ::p54::
        tick(54)
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"];
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[4]["def_yaw_delayed_right"]
        z = registers[20]
        registers[21] = z;
        registers[(20)] = z["get"]
        goto p312
        ::p59::
        tick(59)
        registers[11] = registers[9]["left"]
        registers[11] = registers[11] < registers[10]
        goto p205
        ::p62::
        tick(62)
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"];
        registers[(18)] = registers[(18)](registers[19])
        registers[19] = registers[4]["def_yaw_refraction_spin"]
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"]
        goto p340
        ::p67::
        tick(67)
        registers[14] = upvalues[4]
        registers[15] = registers[12];
        registers[(14)] = registers[(14)](registers[15])
        goto p46
        ::p73::
        tick(73)
        registers[14] = upvalues[6]
        registers[15] = registers[4]["def_pitch_sway_left_value"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        registers[16] = registers[4]["def_pitch_sway_right_value"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"]
        goto p651
        ::p81::
        tick(81);
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] then
            goto p411
        end
        goto p179
        ::p84::
        tick(84)
        registers[20] = registers[1]["body_yaw"]
        registers[20]["value"] = registers[19]
        registers[20] = registers[1]["yaw"]
        goto p409
        ::p88::
        tick(88)
        registers[14] = upvalues[5]
        registers[15] = registers[4]["def_pitch_spin_left_value"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        registers[16] = registers[4]["def_pitch_spin_right_value"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"]
        goto p240
        ::p115::
        tick(115)
        registers[13] = registers[14]
        goto p2
        ::p117::
        tick(117)
        if registers[12] ~= "Refraction" then
            goto p353
        end
        goto p251
        ::p119::
        tick(119)
        if registers[14] then
            goto p15
        end
        goto p359
        ::p121::
        tick(121)
        registers[5] = upvalues[1]["builder"]
        registers[5] = registers[5][registers[3]]
        registers[5] = registers[5]["force_defensive"]
        goto p268
        ::p126::
        tick(126);
        registers[(18)] = registers[(18)](registers[19])
        registers[19] = registers[4]["def_yaw_distortion_minus"]
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"]
        m, x = pack_returns(registers[19](unpack_range(20, registers, 20)))
        m = m + 19 - 1
        top = m
        z = 0
        for f = 19, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        registers[14] = registers[15]
        goto p229
        ::p133::
        if registers[12] ~= "Delay" then
            goto p215
        end
        goto p391
        ::p135::
        tick(135)
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"];
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = registers[4]["def_yaw_refraction_right"]
        goto p62
        ::p139::
        registers[18] = (89);
        registers[15] = registers[15](unpack_range(18, registers, 16))
        registers[14]["value"] = registers[15]
        goto p331
        ::p158::
        tick(158)
        registers[15] = upvalues[5]
        registers[16] = registers[4]["def_yaw_spin_left_value"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"]
        goto p522
        ::p168::
        tick(168)
        registers[16] = nil
        goto p435
        ::p170::
        tick(170)
        registers[16] = (registers[15] ~= registers[0])
        if not registers[16] then
            goto p306
        end
        goto p505
        ::p173::
        tick(173)
        registers[15] = registers[4]["def_yaw_right_value"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        goto p188
        ::p179::
        registers[9] = (false)
        do
            return registers[9]
        end
        ::p181::
        registers[7] = not registers[6]
        goto p474
        ::p183::
        tick(183)
        if not registers[8] then
            goto p433
        end
        goto p227
        ::p188::
        tick(188)
        registers[14] = registers[15]
        goto p229
        ::p196::
        tick(196)
        registers[5] = nil
        goto p265
        ::p198::
        tick(198)
        registers[15] = upvalues[1]["builder"]
        registers[15] = registers[15][registers[3]]
        goto p17
        ::p201::
        tick(201)
        z = registers[1]
        registers[16] = z;
        registers[(15)] = z["is_left_side"];
        registers[(15)] = registers[(15)](registers[16])
        if not registers[15] then
            goto p421
        end
        goto p42
        ::p205::
        tick(205)
        if registers[11] then
            goto p37
        end
        goto p375
        ::p215::
        if registers[12] ~= "Spin" then
            goto p460
        end
        goto p88
        ::p217::
        tick(217)
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p220::
        tick(220)
        registers[8] = registers[7]
        goto p441
        ::p222::
        tick(222)
        registers[20]["type"] = "Static"
        registers[20] = registers[1]["body_yaw"]
        registers[20]["freestanding"] = false
        if registers[19] ~= 0 then
            goto p302
        end
        goto p397
        ::p227::
        registers[8] = registers[6]
        goto p433
        ::p229::
        tick(229)
        registers[15] = registers[1]["yaw"]
        registers[16] = upvalues[9]["normalize"]
        registers[17] = registers[1]["yaw"]
        registers[17] = registers[17]["add"]
        goto p499
        ::p240::;
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_pitch_spin_speed"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"]
        m, x = pack_returns(registers[17](unpack_range(18, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[13] = registers[14]
        goto p2
        ::p251::
        registers[14] = upvalues[8]
        registers[15] = registers[1]["defensive_refraction_pitch_state"]
        registers[16] = registers[4]["def_pitch_refraction_up"]
        goto p21
        ::p255::
        registers[15] = nil
        goto p170
        ::p265::
        tick(265)
        if registers[5] ~= registers[0] then
            goto p9
        end
        goto p19
        ::p268::
        tick(268)
        if registers[5] then
            goto p265
        end
        goto p196
        ::p270::
        tick(270)
        registers[13] = (0)
        if registers[12] ~= "Custom" then
            goto p67
        end
        goto p514
        ::p274::
        tick(274)
        registers[2]["force_defensive"] = true
        registers[9] = registers[4]["toggle_builder"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"]
        goto p81
        ::p278::
        tick(278)
        registers[14] = registers[4]["def_pitch_right_value"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        goto p115
        ::p282::
        tick(282)
        registers[4] = upvalues[1]["defensive"]
        registers[4] = registers[4][registers[3]]
        if registers[4] then
            goto p647
        end
        goto p217
        ::p286::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[1]["safehead_active"]
        if not registers[3] then
            goto p355
        end
        goto p555
        ::p302::
        tick(302)
        registers[20] = registers[1]["body_yaw"]
        registers[20] = registers[20]["inverter"]
        if registers[20] then
            goto p84
        end
        goto p658
        ::p306::
        tick(306)
        if registers[16] then
            goto p435
        end
        goto p168
        ::p308::
        tick(308)
        registers[14] = upvalues[9]["random_int"]
        registers[15] = -65
        registers[16] = -45
        goto p317
        ::p312::;
        registers[(20)] = registers[(20)](registers[21])
        registers[21] = registers[4]["def_yaw_delayed_delay"]
        z = registers[21]
        registers[22] = z;
        registers[(21)] = z["get"];
        registers[(21)] = registers[(21)](registers[22])
        goto p28
        ::p317::
        registers[14] = registers[14](registers[15], registers[16])
        registers[13] = registers[14]
        goto p2
        ::p320::
        tick(320)
        registers[14] = registers[4]["def_pitch_left_value"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        goto p666
        ::p331::
        tick(331)
        registers[13] = registers[4]["def_yaw"]
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["get"];
        registers[(13)] = registers[(13)](registers[14])
        branch_taken = false
        if registers[13] ~= "Disabled" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p457
        end
        goto p496
        ::p336::
        tick(336)
        registers[19] = registers[16]["value"]
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"];
        registers[(19)] = registers[(19)](registers[20])
        goto p622
        ::p340::;
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[4]["def_yaw_refraction_timer"]
        z = registers[20]
        registers[21] = z;
        registers[(20)] = z["get"]
        m, x = pack_returns(registers[20](unpack_range(21, registers, 21)))
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        registers[14] = registers[15]
        goto p229
        ::p347::
        registers[19] = registers[16]["type"]
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"];
        registers[(19)] = registers[(19)](registers[20])
        goto p439
        ::p353::
        if registers[12] ~= "Up Switch" then
            goto p2
        end
        goto p308
        ::p355::
        registers[3] = upvalues[0];
        registers[3] = registers[3]()
        if registers[3] then
            goto p282
        end
        goto p468
        ::p359::
        registers[14] = registers[4]["def_pitch_right_delay_value"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        goto p15
        ::p371::
        tick(371)
        registers[11] = registers[9]["left"]
        registers[11] = registers[11] > 0
        goto p407
        ::p375::
        registers[12] = (false)
        do
            return registers[12]
        end
        ::p377::
        tick(377)
        if registers[13] ~= "Refraction" then
            goto p565
        end
        goto p447
        ::p379::
        tick(379)
        if registers[13] ~= "Sway" then
            goto p493
        end
        goto p423
        ::p381::
        tick(381)
        registers[15] = upvalues[4]
        registers[16] = registers[13];
        registers[(15)] = registers[(15)](registers[16])
        if not registers[15] then
            goto p551
        end
        goto p201
        ::p386::
        tick(386)
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"]
        m, x = pack_returns(registers[18](unpack_range(19, registers, 19)))
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        registers[14] = registers[15]
        goto p229
        ::p391::
        registers[14] = registers[1]["defensive_pitch_delay_side"]
        if not registers[14] then
            goto p119
        end
        registers[14] = registers[4]["def_pitch_left_delay_value"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        goto p119
        ::p397::
        registers[19] = -1
        goto p302
        ::p400::
        tick(400);
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = registers[4]["def_yaw_sway_speed"]
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"]
        m, x = pack_returns(registers[18](unpack_range(19, registers, 19)))
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        registers[14] = registers[15]
        goto p229
        ::p407::
        tick(407)
        if not registers[11] then
            goto p205
        end
        goto p59
        ::p409::
        registers[20]["body"] = 0
        goto p431
        ::p411::
        a = upvalues[3];
        registers[9] = a[2][a[1]]["exploits"]
        registers[9] = registers[9]["defensive"]
        registers[10] = registers[4]["duration"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        goto p570
        ::p417::
        tick(417)
        if not registers[5] then
            goto p268
        end
        goto p121
        ::p421::
        if registers[15] then
            goto p188
        end
        goto p173
        ::p423::
        registers[15] = upvalues[6]
        registers[16] = registers[4]["def_yaw_sway_left_value"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"];
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_yaw_sway_right_value"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"]
        goto p400
        ::p431::
        tick(431)
        registers[14] = -registers[17]
        goto p229
        ::p433::
        if registers[8] then
            goto p441
        end
        goto p488
        ::p435::
        registers[17] = upvalues[13]
        registers[18] = registers[1]["defensive_yaw_delayed_state"]
        registers[19] = registers[4]["def_yaw_delayed_left"]
        goto p54
        ::p439::
        if registers[19] ~= "Jitter" then
            goto p431
        end
        goto p336
        ::p441::
        tick(441)
        if registers[8] then
            goto p274
        end
        goto p595
        ::p443::
        tick(443)
        registers[5] = upvalues[1]["builder"]
        registers[5] = registers[5][registers[3]]
        registers[5] = (registers[5] ~= registers[0])
        goto p417
        ::p447::
        registers[15] = upvalues[12]
        registers[16] = registers[1]["defensive_refraction_yaw_state"]
        registers[17] = registers[4]["def_yaw_refraction_left"]
        goto p135
        ::p452::
        tick(452)
        registers[17] = registers[4]["def_pitch_fluctuate_speed"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"];
        registers[(17)] = registers[(17)](registers[18])
        goto p48
        ::p457::
        tick(457)
        registers[14] = (true)
        do
            return registers[14]
        end
        ::p460::
        if registers[12] ~= "Sway" then
            goto p519
        end
        goto p73
        ::p462::
        tick(462)
        registers[18] = upvalues[10][30];
        registers[18] = registers[18]()
        registers[18] = registers[18] * registers[15];
        registers[(17)] = registers[(17)](registers[18])
        goto p512
        ::p468::
        registers[4] = (false)
        do
            return registers[4]
        end
        ::p472::
        branch_taken = false
        if registers[12] ~= "Disabled" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p331
        end
        goto p270
        ::p474::
        z = registers[5]
        registers[9] = z;
        registers[(8)] = z["get"]
        registers[10] = "Double tap"
        registers[8] = registers[8](registers[9], registers[10])
        goto p183
        ::p478::
        tick(478)
        registers[14] = upvalues[7]
        registers[15] = registers[4]["def_pitch_fluctuate_value1"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        goto p590
        ::p488::
        z = registers[5]
        registers[9] = z;
        registers[(8)] = z["get"]
        registers[10] = "On shot anti-aim"
        registers[8] = registers[8](registers[9], registers[10])
        if not registers[8] then
            goto p441
        end
        goto p220
        ::p493::
        if registers[13] ~= "Zurab" then
            goto p553
        end
        goto p603
        ::p496::
        registers[14] = (0)
        if registers[13] ~= "Custom" then
            goto p381
        end
        goto p634
        ::p499::
        registers[17] = registers[17] + registers[14]
        registers[18] = -180
        registers[19] = (180);
        registers[16] = registers[16](unpack_range(19, registers, 17))
        registers[15]["add"] = registers[16]
        goto p457
        ::p505::
        registers[16] = registers[15]["body_yaw"]
        goto p306
        ::p512::
        registers[14] = registers[17] * registers[16]
        goto p229
        ::p514::
        registers[14] = registers[4]["def_pitch_static_value"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        registers[13] = registers[14]
        goto p2
        ::p519::
        if registers[12] ~= "Fluctuate" then
            goto p117
        end
        goto p478
        ::p522::;
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_yaw_spin_right_value"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"];
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = registers[4]["def_yaw_spin_speed"]
        goto p386
        ::p530::
        tick(530);
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_yaw_distortion_randomize"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"];
        registers[(17)] = registers[(17)](registers[18])
        registers[18] = registers[4]["def_yaw_distortion_plus"]
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"]
        goto p126
        ::p551::
        if registers[13] ~= "Spin" then
            goto p379
        end
        goto p158
        ::p553::
        if registers[13] ~= "Distortion" then
            goto p377
        end
        goto p668
        ::p555::
        registers[1]["force_defensive_active"] = false
        registers[2]["force_defensive"] = false
        registers[3] = (false)
        do
            return registers[3]
        end
        ::p565::
        if registers[13] ~= "Delayed" then
            goto p229
        end
        goto p618
        ::p570::
        registers[11] = registers[9]
        if not registers[11] then
            goto p407
        end
        goto p371
        ::p573::
        registers[18] = registers[4]["def_pitch_refraction_spin"]
        z = registers[18]
        registers[19] = z;
        registers[(18)] = z["get"];
        registers[(18)] = registers[(18)](registers[19])
        registers[19] = registers[4]["def_pitch_refraction_timer"]
        z = registers[19]
        registers[20] = z;
        registers[(19)] = z["get"]
        m, x = pack_returns(registers[19](unpack_range(20, registers, 20)))
        m = m + 19 - 1
        top = m
        z = 0
        for f = 19, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[13] = registers[14]
        goto p2
        ::p590::
        registers[16] = registers[4]["def_pitch_fluctuate_value2"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"];
        registers[(16)] = registers[(16)](registers[17])
        goto p452
        ::p595::
        registers[9] = (false)
        do
            return registers[9]
        end
        ::p597::
        z = registers[1]
        registers[15] = z;
        registers[(14)] = z["is_left_side"];
        registers[(14)] = registers[(14)](registers[15])
        if not registers[14] then
            goto p666
        end
        goto p320
        ::p603::
        registers[15] = registers[4]["def_yaw_zurab_speed"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        registers[16] = registers[4]["def_yaw_zurab_range"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"];
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = upvalues[10][163]
        goto p462
        ::p618::
        registers[15] = upvalues[1]["builder"]
        registers[15] = (registers[15] ~= registers[0])
        if not registers[15] then
            goto p17
        end
        goto p198
        ::p622::
        registers[20] = registers[1]["body_yaw"]
        registers[21] = (registers[18] == true)
        registers[20]["inverter"] = registers[21]
        registers[20] = registers[1]["body_yaw"]
        goto p222
        ::p634::
        registers[15] = registers[4]["def_yaw_static_value"]
        z = registers[15]
        registers[16] = z;
        registers[(15)] = z["get"];
        registers[(15)] = registers[(15)](registers[16])
        registers[14] = registers[15]
        goto p229
        ::p647::
        registers[5] = upvalues[1]["builder"]
        registers[5] = (registers[5] ~= registers[0])
        if not registers[5] then
            goto p417
        end
        goto p443
        ::p651::;
        registers[(16)] = registers[(16)](registers[17])
        registers[17] = registers[4]["def_pitch_sway_speed"]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["get"]
        m, x = pack_returns(registers[17](unpack_range(18, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[13] = registers[14]
        goto p2
        ::p658::
        registers[19] = -registers[19]
        goto p84
        ::p666::
        if registers[14] then
            goto p115
        end
        goto p278
        ::p668::
        registers[15] = upvalues[11]
        registers[16] = registers[4]["def_yaw_distortion"]
        z = registers[16]
        registers[17] = z;
        registers[(16)] = z["get"]
        goto p530
    end
end
