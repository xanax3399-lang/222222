-- Recovered function f330; author names are unavailable.
F.f330 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f330")
        tick(1)
        goto p27
        ::p10::
        tick(10)
        slot_2 = slot_1["target"]
        goto p147
        ::p25::
        tick(25)
        slot_5 = (0)
        goto p75
        ::p27::
        tick(27)
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p55
        end
        goto p72
        ::p55::
        tick(55)
        do
            return 
        end
        ::p56::
        tick(56)
        slot_5 = slot_3["miss_streak"]
        if slot_5 then
            goto p75
        end
        goto p25
        ::p59::
        tick(59)
        slot_2 = environment["tonumber"]
        slot_3 = slot_1["target"];
        slot_2 = slot_2(slot_3)
        if slot_2 then
            goto p147
        end
        goto p10
        ::p64::
        tick(64)
        slot_3 = slot_1["reason"]
        branch_taken = false
        if slot_3 ~= "prediction error" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p59
        end
        goto p55
        ::p68::
        tick(68)
        slot_4 = upvalues[1][23];
        slot_4 = slot_4()
        slot_4 = slot_4 + 48
        goto p106
        ::p72::
        slot_2 = slot_1["target"]
        if slot_2 == slot_0 then
            goto p55
        end
        goto p64
        ::p75::
        slot_5 = slot_5 + 1
        slot_6 = (4)
        slot_4 = slot_4(slot_5, slot_6)
        slot_3["miss_streak"] = slot_4
        do
            return 
        end
        ::p81::
        tick(81)
        slot_4["origin"] = slot_0
        slot_4["penalty_until"] = 0
        slot_4["boost_until"] = 0
        slot_4["stable_ticks"] = 0
        slot_4["hit_streak"] = 0
        slot_4["miss_streak"] = 0
        slot_3 = slot_4
        slot_4 = upvalues[0]["player_state"]
        slot_4[slot_2] = slot_3
        goto p68
        ::p106::
        slot_3["penalty_until"] = slot_4
        slot_3["boost_until"] = 0
        slot_3["hit_streak"] = 0
        slot_4 = upvalues[1][162]
        goto p56
        ::p126::
        tick(126)
        slot_4 = {
        }
        slot_4["velocity"] = slot_0
        slot_4["simtime"] = slot_0
        goto p81
        ::p147::
        slot_3 = upvalues[0]["player_state"]
        slot_3 = slot_3[slot_2]
        if slot_3 ~= slot_0 then
            goto p68
        end
        goto p126
    end
end
