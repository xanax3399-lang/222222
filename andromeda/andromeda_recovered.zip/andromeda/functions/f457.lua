-- Recovered function f457; author names are unavailable.
F.f457 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f457")
        tick(1)
        goto p19
        ::p2::
        tick(2)
        do
            return registers[(1)](unpack_range(4, registers, 2))
        end
        ::p15::
        tick(15)
        registers[4] = upvalues[3]["ragebot"]
        registers[4] = registers[4]["extrapolation"]
        goto p46
        ::p19::
        registers[1] = upvalues[0]["clamp"]
        registers[2] = upvalues[1][154]
        registers[3] = upvalues[2]
        goto p72
        ::p46::
        tick(46)
        registers[5] = (0)
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[2] = registers[2](unpack_range(top, registers, 3))
        registers[3] = (0)
        registers[4] = (5)
        goto p2
        ::p72::
        registers[4] = upvalues[3]["ragebot"]
        if not registers[4] then
            goto p46
        end
        goto p15
    end
end
