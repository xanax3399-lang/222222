-- Recovered function f425; author names are unavailable.
F.f425 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local tick = new_tick("f425")
        tick(1)
        goto p9
        ::p2::
        tick(2)
        do
            return 
        end
        ::p9::
        a = {
            ...,
        }
        slot_1 = a[1]
        a = upvalues[0];
        slot_2 = a[2][a[1]]
        if not slot_2 then
            goto p31
        end
        goto p27
        ::p20::
        tick(20)
        a = upvalues[2]
        a[2][a[1]] = slot_1
        do
            return 
        end
        ::p27::
        do
            return 
        end
        ::p31::
        slot_2 = slot_1["realm"]
        slot_3 = upvalues[1];
        slot_3 = slot_3()
        if slot_2 == slot_3 then
            goto p20
        end
        goto p2
    end
end
