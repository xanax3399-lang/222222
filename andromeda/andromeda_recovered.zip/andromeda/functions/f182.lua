-- Recovered function f182; author names are unavailable.
F.f182 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local a = nil
        local tick = new_tick("f182")
        tick(1)
        goto p60
        ::p17::
        tick(17)
        slot_1 = "Forward"
        do
            return slot_1
        end
        ::p20::
        tick(20)
        slot_1 = "Left"
        do
            return slot_1
        end
        ::p40::
        tick(40)
        a = upvalues[0];
        slot_1 = a[2][a[1]]["manual"]
        if slot_1 ~= "Forward" then
            goto p58
        end
        goto p17
        ::p58::
        slot_1 = "Disabled"
        do
            return slot_1
        end
        ::p60::
        a = upvalues[0];
        slot_1 = a[2][a[1]]["manual"]
        if slot_1 ~= "Left" then
            goto p77
        end
        goto p20
        ::p77::
        a = upvalues[0];
        slot_1 = a[2][a[1]]["manual"]
        if slot_1 ~= "Right" then
            goto p40
        end
        slot_1 = "Right"
        do
            return slot_1
        end
    end
end
