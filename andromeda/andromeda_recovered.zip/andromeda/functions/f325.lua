-- Recovered function f325; author names are unavailable.
F.f325 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f325")
        tick(1)
        tick(2)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = slot_1["pitch"]
        slot_2["type"] = "Default"
        slot_2 = slot_1["pitch"]
        slot_2["value"] = 0
        do
            return 
        end
    end
end
