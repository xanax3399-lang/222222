-- Recovered function f117; author names are unavailable.
F.f117 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f117")
        tick(1)
        goto p96
        ::p12::
        tick(12)
        registers[4] = registers[4] + registers[3]
        goto p41
        ::p29::
        tick(29)
        registers[5] = registers[1] % 2
        if not (0 < registers[5]) then
            goto p41
        end
        goto p12
        ::p32::
        tick(32)
        registers[4] = registers[4] + registers[3]
        ::p34::
        tick(34)
        registers[7] = (registers[1] - registers[5])
        registers[1] = registers[7] / 2
        registers[7] = (registers[2] - registers[6])
        registers[2] = registers[7] / 2
        registers[3] = (registers[3] * 2)
        goto p49
        ::p41::
        registers[6] = (registers[1] - registers[5])
        registers[1] = registers[6] / 2
        registers[3] = (registers[3] * 2)
        ::p47::
        tick(47)
        if not (0 < registers[1]) then
            goto p88
        end
        goto p29
        ::p49::
        tick(49)
        if not (0 < registers[1]) then
            goto p92
        end
        goto p94
        ::p82::
        tick(82)
        registers[5] = registers[1] % 2
        registers[6] = registers[2] % 2
        if registers[5] == registers[6] then
            goto p34
        end
        goto p32
        ::p88::
        registers[5] = registers[4]
        do
            return registers[5]
        end
        ::p92::
        tick(92)
        if not (registers[1] < registers[2]) then
            goto p47
        end
        goto p112
        ::p94::
        if not (0 < registers[2]) then
            goto p92
        end
        goto p82
        ::p96::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = (1)
        registers[4] = (0)
        goto p49
        ::p112::
        a = registers
        z = 1
        q = registers
        q = q[2]
        a[z] = q
        goto p47
    end
end
