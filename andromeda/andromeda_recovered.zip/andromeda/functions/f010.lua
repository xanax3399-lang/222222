-- Recovered function f10; author names are unavailable.
F.f10 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local S, z, a = nil, nil, nil
        local tick = new_tick("f10")
        tick(1)
        a = D.f11
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[1] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = upvalues[0]
        a[2][a[1]] = registers[1]
        a = upvalues[1]
        a[2][a[1]] = (0)
        ::p9::
        tick(9)
        goto p9
        error("ANDROMEDA_INVALID_FALLTHROUGH: f10 pc=9", 0)
    end
end
