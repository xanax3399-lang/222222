-- Recovered function f59; author names are unavailable.
F.f59 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local z = nil
        local tick = new_tick("f59")
        tick(1)
        slot_1 = upvalues[0]
        z = slot_1
        slot_2 = z;
        slot_1 = z["dot"]
        slot_3 = (1);
        slot_1(slot_2, slot_3)
        do
            return 
        end
    end
end
