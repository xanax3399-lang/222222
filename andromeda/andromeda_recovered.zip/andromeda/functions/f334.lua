-- Recovered function f334; author names are unavailable.
F.f334 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f334")
        tick(1)
        goto p51
        ::p3::
        tick(3)
        registers[10] = (true)
        registers[(7)](unpack_range(10, registers, 8))
        registers[7] = upvalues[3][141]
        registers[8] = registers[4]
        registers[9] = "Force body yaw value"
        registers[10] = registers[5]["angle"]
        registers[(7)](unpack_range(10, registers, 8))
        registers[7] = upvalues[1]["applied"]
        registers[7][registers[4]] = true
        goto p133
        ::p13::
        tick(13)
        if registers[5] then
            goto p184
        end
        goto p102
        ::p15::
        tick(15)
        registers[5] = upvalues[1]["resolved"]
        registers[5] = registers[5][registers[4]]
        registers[6] = upvalues[1]["correction_until"]
        registers[6] = registers[6][registers[4]]
        if registers[6] then
            goto p143
        end
        goto p116
        ::p35::
        tick(35)
        registers[1] = upvalues[3][23];
        registers[1] = registers[1]()
        registers[2] = environment["ipairs"]
        goto p108
        ::p47::
        tick(47)
        registers[5] = (0)
        goto p118
        ::p51::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p128
        end
        goto p147
        ::p55::
        tick(55)
        registers[7] = upvalues[5]
        registers[8] = registers[4]
        registers[(7)](registers[8])
        goto p133
        ::p79::
        tick(79)
        do
            return 
        end
        ::p102::
        tick(102)
        registers[5] = upvalues[1]["correction_until"]
        registers[5] = registers[5][registers[3]]
        if registers[5] then
            goto p118
        end
        goto p47
        ::p106::
        tick(106)
        branch_taken = false
        if not (not (registers[1] <= registers[6])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p55
        end
        goto p179
        ::p108::
        registers[3] = upvalues[4]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[2](unpack_range(top, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(2)]
        n = registers[3]
        U = registers[4]
        goto p133
        ::p112::
        tick(112)
        registers[5] = upvalues[3][42]
        registers[6] = registers[3];
        registers[(5)] = registers[(5)](registers[6])
        goto p13
        ::p116::
        registers[6] = (0)
        goto p143
        ::p118::
        if not (registers[5] < registers[1]) then
            goto p120
        end
        goto p184
        ::p120::
        tick(120)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[3] = z;
            registers[4] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p174
        end
        goto p135
        ::p122::
        tick(122)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[2] = environment["pairs"]
        registers[3] = upvalues[1]["applied"]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(2)]
        n = registers[3]
        U = registers[4]
        goto p120
        goto p102
        ::p128::
        registers[1] = upvalues[2];
        registers[1] = registers[1]()
        if registers[1] ~= "Auto" then
            goto p35
        end
        goto p79
        ::p133::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[3] = z;
            registers[4] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p15
        end
        goto p122
        ::p135::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p143::
        if registers[5] == registers[0] then
            goto p55
        end
        goto p169
        ::p147::
        registers[1] = upvalues[1]["reset"]
        registers[(1)]()
        do
            return 
        end
        ::p169::
        registers[7] = registers[5]["active"]
        if registers[7] ~= true then
            goto p55
        end
        goto p106
        ::p174::
        registers[4] = upvalues[3][50]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= true then
            goto p184
        end
        goto p112
        ::p179::
        registers[7] = upvalues[3][141]
        registers[8] = registers[4]
        registers[9] = "Force body yaw"
        goto p3
        ::p184::
        registers[4] = upvalues[5]
        registers[5] = registers[3]
        registers[(4)](registers[5])
        goto p120
    end
end
