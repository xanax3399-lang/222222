-- Recovered function f132; author names are unavailable.
F.f132 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f132")
        tick(1)
        goto p96
        ::p31::
        tick(31)
        registers[2] = upvalues[0][128]
        registers[3] = upvalues[1]
        a = upvalues[2];
        registers[4] = a[2][a[1]]
        goto p74
        ::p36::
        tick(36)
        registers[6] = upvalues[3]
        registers[7] = (0)
        registers[8] = (0)
        registers[9] = (0)
        goto p70
        ::p42::
        tick(42)
        registers[13] = (0)
        registers[14] = (210)
        registers[15] = (true)
        goto p102
        ::p57::
        tick(57)
        registers[8] = (0)
        registers[9] = (0)
        registers[10] = (210)
        registers[11] = (0)
        registers[12] = (0)
        registers[13] = (0)
        registers[14] = (0)
        registers[15] = (true)
        goto p82
        ::p66::
        tick(66)
        registers[10] = (210)
        registers[(2)](unpack_range(10, registers, 3))
        goto p126
        ::p70::
        registers[10] = (0)
        registers[11] = (0)
        registers[12] = (0)
        goto p42
        ::p74::
        registers[3] = registers[3] + registers[4]
        registers[4] = registers[1]
        registers[5] = upvalues[4]
        registers[6] = upvalues[3]
        registers[7] = (0)
        registers[8] = (0)
        registers[9] = (0)
        goto p66
        ::p82::
        registers[(2)](unpack_range(15, registers, 3))
        do
            return 
        end
        ::p84::
        tick(84)
        registers[4] = registers[1]
        a = upvalues[2];
        registers[5] = a[2][a[1]]
        registers[6] = upvalues[3]
        registers[7] = (0)
        goto p57
        ::p96::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][129]
        registers[3] = upvalues[1]
        registers[4] = registers[1]
        a = upvalues[2];
        registers[5] = a[2][a[1]]
        goto p36
        ::p102::
        registers[(2)](unpack_range(15, registers, 3))
        registers[2] = upvalues[4]
        if not (0 < registers[2]) then
            goto p126
        end
        goto p31
        ::p126::
        registers[2] = upvalues[0][129]
        registers[3] = upvalues[1]
        a = upvalues[2];
        registers[4] = a[2][a[1]]
        registers[3] = registers[3] + registers[4]
        registers[4] = upvalues[4]
        registers[3] = registers[3] + registers[4]
        goto p84
    end
end
