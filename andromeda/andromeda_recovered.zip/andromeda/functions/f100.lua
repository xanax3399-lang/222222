-- Recovered function f100; author names are unavailable.
F.f100 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f100")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0]["new"]
        registers[4] = registers[1]["r"]
        goto p9
        ::p7::
        tick(7)
        m, x = pack_returns(registers[7](unpack_range(10, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[3](unpack_range(top, registers, 4))
        end
        ::p9::
        registers[5] = registers[1]["g"]
        registers[6] = registers[1]["b"]
        registers[7] = upvalues[1]["clamp"]
        registers[8] = registers[2]
        registers[9] = (0)
        registers[10] = (255)
        goto p7
    end
end
