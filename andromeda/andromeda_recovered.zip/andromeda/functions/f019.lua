-- Recovered function f19; author names are unavailable.
F.f19 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f19")
        tick(1)
        tick(3)
        slot_1 = upvalues[0]["C"]
        slot_1 = slot_1["EnumDisplaySettingsA"]
        do
            return slot_1
        end
    end
end
