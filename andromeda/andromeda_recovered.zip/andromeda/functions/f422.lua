-- Recovered function f422; author names are unavailable.
F.f422 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f422")
        tick(1)
        goto p130
        ::p3::
        tick(3)
        do
            return registers[7]
        end
        ::p4::
        tick(4)
        if registers[4] ~= 0 then
            goto p27
        end
        goto p84
        ::p7::
        tick(7)
        registers[7] = (registers[4] == 0)
        if not registers[7] then
            goto p108
        end
        goto p79
        ::p11::
        tick(11)
        registers[7] = (registers[6] * 0)
        registers[7] = registers[7] / 0
        goto p3
        ::p27::
        registers[5] = (1)
        registers[3] = (0)
        goto p95
        ::p30::
        tick(30)
        do
            return registers[7]
        end
        ::p47::
        tick(47)
        if registers[5] ~= 2047 then
            goto p95
        end
        goto p7
        ::p50::
        tick(50)
        registers[8] = registers[4] / 4503599627370496
        registers[8] = registers[3] + registers[8]
        registers[7] = registers[7] * registers[8]
        goto p30
        ::p79::
        registers[7] = (registers[6] * 1)
        registers[7] = registers[7] / 0
        goto p108
        ::p84::
        registers[7] = (registers[6] * 0)
        do
            return registers[7]
        end
        ::p86::
        tick(86)
        registers[4] = (registers[4] * 4294967296)
        registers[4] = registers[4] + registers[1]
        registers[5] = upvalues[1]
        registers[6] = registers[2]
        registers[7] = (21)
        registers[8] = (31)
        goto p110
        ::p95::
        registers[7] = (registers[5] - 1023)
        registers[7] = 2 ^ registers[7]
        registers[7] = registers[6] * registers[7]
        goto p50
        ::p108::
        if registers[7] then
            goto p3
        end
        goto p11
        ::p110::;
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1]
        a = registers
        z = 7
        q = registers
        q = q[2]
        a[z] = q
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = 1 ^ registers[6]
        registers[6] = -registers[6]
        if registers[5] ~= 0 then
            goto p47
        end
        goto p4
        ::p130::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (1)
        registers[4] = upvalues[1]
        registers[5] = registers[2]
        registers[6] = (1)
        registers[7] = (20);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        goto p86
    end
end
