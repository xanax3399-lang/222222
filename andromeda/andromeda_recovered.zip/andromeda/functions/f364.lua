-- Recovered function f364; author names are unavailable.
F.f364 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f364")
        tick(1)
        goto p95
        ::p2::
        tick(2)
        registers[12] = registers[10]["last_packet"]
        a = upvalues[4];
        registers[13] = a[2][a[1]]["packets"]
        registers[12] = (registers[12] ~= registers[13])
        a = upvalues[4];
        registers[13] = a[2][a[1]]["packets"]
        registers[10]["last_packet"] = registers[13]
        if not (0 < registers[6]) then
            goto p15
        end
        goto p212
        ::p15::
        tick(15)
        if not registers[12] then
            goto p44
        end
        goto p35
        ::p23::
        tick(23)
        registers[13] = registers[6];
        registers[(12)] = registers[(12)](registers[13])
        registers[13] = environment["tostring"]
        registers[14] = registers[7];
        registers[(13)] = registers[(13)](registers[14])
        registers[14] = environment["tostring"]
        registers[15] = registers[8]
        goto p260
        ::p31::
        tick(31)
        registers[13] = (0)
        goto p38
        ::p33::
        tick(33)
        registers[15] = (0)
        goto p176
        ::p35::
        if not (0 < registers[6]) then
            goto p328
        end
        goto p61
        ::p38::
        tick(38)
        if registers[13] then
            goto p289
        end
        goto p68
        ::p40::
        tick(40)
        registers[4]["5-Way"] = registers[5]
        registers[4] = registers[4][registers[3]]
        if registers[4] then
            goto p123
        end
        goto p235
        ::p44::
        tick(44)
        registers[13] = registers[10]["way_index"]
        if registers[13] < 1 then
            goto p309
        end
        goto p128
        ::p47::
        tick(47)
        registers[13] = registers[10]["cycle_ticks"]
        registers[13] = registers[13] + 1
        registers[10]["cycle_ticks"] = registers[13]
        registers[13] = registers[10]["cycle_ticks"]
        branch_taken = false
        if not (not (registers[6] <= registers[13])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p114
        end
        goto p372
        ::p61::
        registers[13] = registers[10]["delay_active"]
        if not registers[13] then
            goto p47
        end
        goto p133
        ::p64::
        tick(64);
        registers[14] = registers[14](unpack_range(17, registers, 15))
        registers[10]["last_add"] = registers[14]
        registers[15] = registers[14]
        do
            return registers[15]
        end
        ::p68::
        registers[13] = upvalues[1]["clamp"]
        registers[14] = registers[10]["last_add"]
        if registers[14] then
            goto p226
        end
        goto p119
        ::p95::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[2]["meta_mode"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = {
        }
        registers[5] = new_frame(2)
        registers[6] = -0.5
        registers[7] = (0.5)
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        registers[4]["2-Way"] = registers[5]
        registers[5] = new_frame(3)
        registers[6] = -0.5
        registers[7] = (0)
        registers[8] = (0.5)
        goto p243
        ::p110::
        tick(110)
        registers[7] = (0)
        goto p332
        ::p114::
        tick(114)
        registers[13] = registers[10]["way_index"]
        registers[13] = registers[13] + 1
        registers[10]["way_index"] = registers[13]
        registers[13] = registers[10]["way_index"]
        goto p341
        ::p119::
        registers[14] = (0)
        goto p226
        ::p121::
        tick(121)
        registers[10]["way_index"] = 1
        goto p44
        ::p123::
        tick(123)
        registers[5] = registers[2]["meta_offset"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[0][154]
        goto p304
        ::p128::
        registers[14] = (#registers[4])
        if not (registers[14] < registers[13]) then
            goto p337
        end
        goto p309
        ::p133::
        tick(133)
        registers[13] = registers[10]["delay_ticks"]
        registers[13] = registers[13] + 1
        registers[10]["delay_ticks"] = registers[13]
        registers[13] = registers[10]["delay_ticks"]
        branch_taken = false
        if not (not (registers[13] <= registers[7])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p171
        end
        goto p352
        ::p139::
        tick(139)
        registers[10]["last_packet"] = registers[0]
        goto p2
        ::p171::
        registers[10]["delay_active"] = false
        registers[10]["delay_ticks"] = 0
        registers[10]["cycle_ticks"] = 0
        goto p114
        ::p176::
        tick(176)
        registers[15] = registers[5] * registers[15]
        registers[16] = -180
        registers[17] = (180)
        goto p64
        ::p181::
        tick(181)
        registers[16] = (200);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[6] = registers[13]
        goto p15
        ::p191::
        tick(191)
        registers[10]["last_add"] = registers[13]
        registers[13] = registers[10]["last_add"]
        do
            return registers[13]
        end
        ::p194::
        tick(194);
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = (5)
        registers[10] = (30);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        goto p218
        ::p212::
        registers[13] = upvalues[1]["clamp"]
        registers[14] = registers[6]
        registers[15] = (5)
        goto p181
        ::p216::
        tick(216)
        registers[9] = upvalues[3][1]
        goto p281
        ::p218::
        registers[8] = registers[2]["meta_safe_yaw"]
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["get"];
        registers[(8)] = registers[(8)](registers[9])
        goto p272
        ::p222::
        tick(222)
        registers[10]["delay_ticks"] = 0
        registers[10]["delay_active"] = false
        registers[10]["last_add"] = 0
        goto p139
        ::p226::
        registers[15] = -180
        registers[16] = (180);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p289
        ::p230::
        tick(230)
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        if registers[9] then
            goto p194
        end
        goto p241
        ::p235::
        registers[4] = new_frame(2)
        registers[5] = -0.5
        registers[6] = (0.5)
        q = registers[(4)]
        q[1] = registers[5]
        q[2] = registers[6]
        goto p123
        ::p241::
        registers[9] = (15)
        goto p194
        ::p243::
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        registers[4]["3-Way"] = registers[5]
        registers[5] = new_frame(5)
        goto p297
        ::p248::
        tick(248)
        registers[13] = upvalues[1]["clamp"]
        registers[14] = registers[10]["last_add"]
        if registers[14] then
            goto p293
        end
        goto p344
        ::p260::;
        registers[(14)] = registers[(14)](registers[15])
        registers[14] = "|"..registers[14]
        registers[13] = (registers[13]..registers[14])
        registers[13] = "|"..registers[13]
        registers[12] = (registers[12]..registers[13])
        registers[12] = "|"..registers[12]
        registers[11] = (registers[11]..registers[12])
        registers[11] = "|"..registers[11]
        registers[11] = (registers[3]..registers[11])
        registers[12] = registers[10]["signature"]
        if registers[12] == registers[11] then
            goto p2
        end
        goto p285
        ::p272::
        a = upvalues[2];
        registers[9] = a[2][a[1]]["current"]
        if registers[9] then
            goto p281
        end
        goto p216
        ::p281::
        registers[10] = registers[1]["hidden_modifier_meta_states"]
        registers[10] = registers[10][registers[9]]
        if registers[10] ~= registers[0] then
            goto p323
        end
        goto p313
        ::p285::
        registers[10]["signature"] = registers[11]
        registers[10]["way_index"] = 0
        registers[10]["cycle_ticks"] = 0
        goto p222
        ::p289::
        registers[10]["last_add"] = registers[13]
        registers[13] = registers[10]["last_add"]
        do
            return registers[13]
        end
        ::p293::
        tick(293)
        registers[15] = -180
        registers[16] = (180);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        goto p191
        ::p297::
        registers[6] = -0.75
        registers[7] = (1)
        registers[8] = (0)
        registers[9] = (0.4)
        registers[10] = -0.25
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        q[5] = registers[10]
        goto p40
        ::p304::
        registers[7] = registers[2]["meta_delay_cycle"]
        z = registers[7]
        registers[8] = z;
        registers[(7)] = z["get"];
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] then
            goto p332
        end
        goto p110
        ::p309::
        registers[13] = (1)
        registers[10]["way_index"] = registers[13]
        goto p337
        ::p313::
        registers[11] = {
        }
        registers[11]["signature"] = registers[0]
        registers[11]["way_index"] = 0
        registers[11]["cycle_ticks"] = 0
        registers[11]["delay_ticks"] = 0
        registers[11]["delay_active"] = false
        goto p347
        ::p321::
        tick(321)
        registers[13] = (0)
        goto p355
        ::p323::
        tick(323)
        registers[11] = environment["tostring"]
        registers[12] = registers[5];
        registers[(11)] = registers[(11)](registers[12])
        registers[12] = environment["tostring"]
        goto p23
        ::p328::
        registers[10]["delay_active"] = false
        registers[10]["delay_ticks"] = 0
        registers[10]["cycle_ticks"] = 0
        goto p114
        ::p332::;
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = upvalues[1]["clamp"]
        registers[8] = upvalues[0][154]
        registers[9] = registers[2]["meta_delay_time"]
        goto p230
        ::p337::
        registers[14] = upvalues[1]["clamp"]
        registers[15] = registers[4][registers[13]]
        if registers[15] then
            goto p176
        end
        goto p33
        ::p341::
        registers[14] = (#registers[4])
        if not (registers[14] < registers[13]) then
            goto p44
        end
        goto p121
        ::p344::
        registers[14] = (0)
        goto p293
        ::p347::
        registers[11]["last_add"] = 0
        registers[11]["last_packet"] = registers[0]
        registers[10] = registers[11]
        registers[11] = registers[1]["hidden_modifier_meta_states"]
        goto p377
        ::p352::
        registers[13] = registers[8]
        if not registers[13] then
            goto p38
        end
        goto p31
        ::p355::
        tick(355)
        if registers[13] then
            goto p191
        end
        goto p248
        ::p372::
        registers[10]["delay_active"] = true
        registers[10]["delay_ticks"] = 0
        registers[13] = registers[8]
        if not registers[13] then
            goto p355
        end
        goto p321
        ::p377::
        registers[11][registers[9]] = registers[10]
        goto p323
    end
end
