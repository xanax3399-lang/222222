-- Recovered function f296; author names are unavailable.
F.f296 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f296")
        tick(1)
        goto p74
        ::p10::
        tick(10)
        if registers[12] then
            goto p69
        end
        goto p104
        ::p20::
        tick(20)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = registers[3]
        do
            return registers[4]
        end
        ::p32::
        tick(32)
        registers[7] = registers[6]["type"]
        if registers[7] ~= "color_picker" then
            goto p92
        end
        registers[7] = {
        }
        z = registers[6]
        registers[9] = z;
        registers[(8)] = z["get"]
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(7)]
        for f = 1, top - (7) do
            q[(0) + f] = registers[(7) + f]
        end
        registers[3][registers[5]] = registers[7]
        goto p119
        ::p62::
        tick(62)
        registers[7] = registers[6]["type"]
        if registers[7] ~= "multiselect" then
            goto p32
        end
        goto p121
        ::p65::
        tick(65)
        z = registers[6]
        registers[8] = z;
        registers[(7)] = z["get"];
        registers[(7)] = registers[(7)](registers[8])
        registers[3][registers[5]] = registers[7]
        goto p119
        ::p69::
        tick(69)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        registers[3][registers[5]] = registers[10]
        goto p119
        ::p74::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = {
        }
        registers[4] = environment["pairs"]
        registers[5] = registers[2]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        z = 0
        for f = 4, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(4)]
        n = registers[5]
        U = registers[6]
        goto p119
        ::p80::
        tick(80)
        registers[7] = registers[6]["type"]
        branch_taken = false
        if registers[7] ~= "label" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p119
        end
        goto p101
        ::p84::
        tick(84)
        z = registers[6]
        registers[8] = z;
        registers[(7)] = z["get"]
        m, x = pack_returns(registers[7](unpack_range(8, registers, 8)))
        z = 0
        for f = 7, 9 do
            z = (z + 1);
            registers[f] = x[z]
        end
        if registers[8] == registers[0] then
            goto p119
        end
        registers[10] = new_frame(2)
        registers[11] = registers[8]
        registers[12] = registers[9]
        goto p10
        ::p92::
        registers[7] = registers[6]["type"]
        if registers[7] ~= "hotkey" then
            goto p65
        end
        goto p84
        ::p101::
        registers[8] = registers[6]["type"]
        branch_taken = false
        if registers[8] ~= "button" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p119
        end
        goto p62
        ::p104::
        registers[12] = (0)
        goto p69
        ::p119::
        tick(119)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[5] = z;
            registers[6] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p80
        end
        goto p20
        ::p121::
        registers[7] = upvalues[0]
        z = registers[6]
        registers[9] = z;
        registers[(8)] = z["get"]
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[3][registers[5]] = registers[7]
        goto p119
    end
end
