-- Recovered function f143; author names are unavailable.
F.f143 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f143")
        tick(1)
        goto p169
        ::p2::
        tick(2)
        z = slot_4
        slot_5 = z;
        slot_4 = z["override"]
        slot_6 = (false);
        slot_4(slot_5, slot_6)
        slot_4 = upvalues[1]["antiaim"]
        slot_4 = slot_4["fakelag"]
        goto p29
        ::p20::
        tick(20)
        slot_3 = upvalues[1]["is_fake_duck"];
        slot_3 = slot_3()
        if not slot_3 then
            goto p128
        end
        goto p75
        ::p24::
        tick(24)
        z = slot_2
        slot_5 = z;
        slot_4 = z["get"]
        slot_6 = "Standing"
        slot_4 = slot_4(slot_5, slot_6)
        if not slot_4 then
            goto p126
        end
        goto p165
        ::p29::
        slot_4 = slot_4["variance"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["override"]
        slot_6 = (0)
        goto p69
        ::p34::
        tick(34)
        if not slot_4 then
            goto p24
        end
        goto p97
        ::p59::
        tick(59)
        slot_3 = (true)
        goto p126
        ::p69::;
        slot_4(slot_5, slot_6)
        slot_4 = upvalues[1]["antiaim"]
        slot_4 = slot_4["fakelag"]
        goto p122
        ::p74::
        tick(74)
        do
            return 
        end
        ::p75::
        z = slot_1
        slot_4 = z;
        slot_3 = z["reset_disable_fakelag"]
        slot_3(slot_4)
        do
            return 
        end
        ::p87::
        tick(87)
        slot_3 = (true)
        goto p126
        ::p89::
        tick(89)
        z = slot_1
        slot_5 = z;
        slot_4 = z["reset_disable_fakelag"]
        slot_4(slot_5)
        goto p74
        ::p97::
        slot_4 = upvalues[1]["is_on_shot_antiaim"]
        slot_5 = "no dt";
        slot_4 = slot_4(slot_5)
        if not slot_4 then
            goto p24
        end
        goto p118
        ::p102::
        tick(102)
        z = slot_2
        slot_5 = z;
        slot_4 = z["get"]
        slot_6 = "Hide Shots"
        slot_4 = slot_4(slot_5, slot_6)
        goto p34
        ::p108::
        tick(108)
        slot_4 = upvalues[1]["is_double_tap"];
        slot_4 = slot_4()
        if not slot_4 then
            goto p102
        end
        goto p59
        ::p118::
        slot_3 = (true)
        goto p126
        ::p122::
        slot_4 = slot_4["limit"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["override"]
        slot_6 = (1)
        goto p158
        ::p126::
        tick(126)
        if not slot_3 then
            goto p89
        end
        goto p176
        ::p128::
        slot_3 = (false)
        z = slot_2
        slot_5 = z;
        slot_4 = z["get"]
        slot_6 = "Double Tap"
        goto p147
        ::p133::
        tick(133)
        z = slot_1
        slot_4 = z;
        slot_3 = z["reset_disable_fakelag"]
        slot_3(slot_4)
        do
            return 
        end
        ::p147::
        slot_4 = slot_4(slot_5, slot_6)
        if not slot_4 then
            goto p102
        end
        goto p108
        ::p158::;
        slot_4(slot_5, slot_6)
        goto p74
        ::p165::
        z = slot_1
        slot_5 = z;
        slot_4 = z["is_player_standing"];
        slot_4 = slot_4(slot_5)
        if not slot_4 then
            goto p126
        end
        goto p87
        ::p169::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["antiaim"]
        slot_2 = slot_2["features"]
        slot_2 = slot_2["disable_fakelag"]
        if slot_2 ~= slot_0 then
            goto p20
        end
        goto p133
        ::p176::
        slot_4 = upvalues[1]["antiaim"]
        slot_4 = slot_4["fakelag"]
        slot_4 = slot_4["on"]
        goto p2
    end
end
