-- Recovered function f91; author names are unavailable.
F.f91 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f91")
        tick(1)
        registers[1] = upvalues[0]
        registers[2] = environment["client"]
        registers[2] = registers[2]["random_int"]
        registers[3] = (12345)
        registers[4] = (54321)
        m, x = pack_returns(registers[2](unpack_range(4, registers, 3)))
        m = m + 2 - 1
        top = m
        z = 0
        for f = 2, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
    end
end
