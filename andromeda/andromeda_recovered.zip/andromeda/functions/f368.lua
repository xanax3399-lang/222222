-- Recovered function f368; author names are unavailable.
F.f368 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f368")
        tick(1)
        goto p116
        ::p23::
        tick(23)
        slot_4 = slot_2
        slot_3(slot_4)
        do
            return 
        end
        ::p37::
        tick(37)
        slot_3 = upvalues[1]["miss_counter"]
        slot_3[slot_2] = 1
        slot_3 = upvalues[1]["correction_until"]
        slot_3[slot_2] = slot_0
        slot_3 = upvalues[2]
        goto p23
        ::p45::
        tick(45)
        if slot_2 then
            goto p112
        end
        goto p69
        ::p48::
        tick(48)
        slot_2 = environment["tonumber"]
        slot_3 = slot_1["target"];
        slot_2 = slot_2(slot_3)
        goto p45
        ::p61::
        tick(61)
        do
            return 
        end
        ::p69::
        slot_2 = slot_1["target"]
        goto p112
        ::p72::
        tick(72)
        slot_3[slot_2] = slot_0
        slot_3 = upvalues[2]
        slot_4 = slot_2
        slot_3(slot_4)
        do
            return 
        end
        ::p77::
        tick(77)
        slot_3 = upvalues[1]["wraith"]
        slot_3 = slot_3["misses"]
        slot_3[slot_2] = slot_0
        slot_3 = upvalues[1]["wraith"]
        slot_3 = slot_3["miss_side"]
        slot_3[slot_2] = slot_0
        slot_3 = upvalues[1]["wraith"]
        slot_3 = slot_3["miss_until"]
        goto p72
        ::p112::
        slot_3 = upvalues[0];
        slot_3 = slot_3()
        if slot_3 ~= "Auto" then
            goto p37
        end
        goto p77
        ::p116::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p61
        end
        slot_2 = slot_1["target"]
        if slot_2 ~= slot_0 then
            goto p48
        end
        goto p61
    end
end
