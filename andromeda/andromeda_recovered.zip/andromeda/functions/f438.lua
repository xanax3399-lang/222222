-- Recovered function f438; author names are unavailable.
F.f438 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local branch_taken = nil
        local tick = new_tick("f438")
        tick(1)
        goto p59
        ::p38::
        tick(38)
        registers[4] = upvalues[0]["restore_all"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "level_init"
        goto p63
        ::p59::
        registers[1] = upvalues[0]["get_ticks"];
        registers[1] = registers[1]()
        registers[1] = registers[1] > 0
        goto p123
        ::p63::
        registers[4] = upvalues[0]["clear_state"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        goto p98
        ::p68::
        tick(68)
        registers[2] = upvalues[0]["clear_state"]
        registers[(2)]()
        goto p116
        ::p96::
        tick(96)
        do
            return 
        end
        ::p98::
        registers[3] = "aim_miss"
        registers[4] = upvalues[0]["aim_miss"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "aim_hit"
        registers[4] = upvalues[0]["aim_hit"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p116
        end
        goto p68
        ::p112::
        tick(112)
        upvalues[0]["active"] = registers[1]
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "setup_command"
        goto p117
        ::p116::
        do
            return 
        end
        ::p117::
        registers[4] = upvalues[0]["setup_command"]
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "run_command"
        goto p38
        ::p123::
        registers[2] = upvalues[0]["active"]
        if registers[2] ~= registers[1] then
            goto p112
        end
        goto p96
    end
end
