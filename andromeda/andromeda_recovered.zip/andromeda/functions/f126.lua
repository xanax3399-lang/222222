-- Recovered function f126; author names are unavailable.
F.f126 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f126")
        tick(1)
        slot_1 = upvalues[0]["defensive_yaw_delayed_state"]
        slot_1["flicker"] = false
        slot_1 = upvalues[0]["defensive_yaw_delayed_state"]
        slot_1["last_flick_at"] = 0
        do
            return 
        end
    end
end
