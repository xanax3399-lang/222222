-- Recovered function f53; author names are unavailable.
F.f53 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, U, _, S, z, a = 0, nil, nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f53")
        tick(1)
        goto p501
        ::p3::
        tick(3)
        registers[33] = (0)
        registers[34] = (1)
        registers[35] = (2)
        registers[36] = (3)
        goto p484
        ::p11::
        tick(11)
        registers[13]["__concat"] = registers[12]
        registers[13]["__index"] = registers[12]
        registers[13]["__newindex"] = registers[12]
        registers[13]["__metatable"] = false
        registers[14] = registers[6]
        goto p562
        ::p23::
        tick(23)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[22] = v
            branch_taken = true
        end
        if branch_taken then
            goto p581
        end
        goto p531
        ::p25::
        tick(25)
        registers[12] = new_frame(4)
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = registers[5]
        registers[18] = registers[1]
        goto p774
        ::p30::
        tick(30)
        registers[15] = registers[16]
        registers[16] = registers[14] + registers[14]
        registers[17] = registers[14] * registers[14]
        registers[17] = (registers[17] / registers[14])
        goto p733
        ::p35::
        tick(35)
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        goto p476
        ::p39::
        tick(39)
        registers[2] = (222)
        goto p219
        ::p41::
        tick(41)
        registers[23] = (0)
        a = registers
        z = 24;
        a[z] = 15
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        goto p743
        ::p49::
        tick(49)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        if not registers[15] then
            goto p307
        end
        goto p489
        ::p53::
        tick(53)
        registers[16] = registers[14]
        goto p30
        ::p55::
        tick(55)
        registers[22] = (9)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        goto p371
        ::p60::
        tick(60)
        registers[17][0] = 8
        registers[18] = (9)
        registers[19] = (10)
        goto p750
        ::p64::
        tick(64)
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        goto p397
        ::p68::
        tick(68)
        registers[17] = registers[2] % 256
        registers[12][registers[16]] = registers[17]
        registers[2] = registers[2] / 256
        registers[17] = registers[2] % 1
        registers[2] = (registers[2] - registers[17])
        goto p148
        ::p74::
        tick(74)
        registers[28] = registers[1]
        registers[29] = registers[25]
        registers[27] = registers[27](registers[28], registers[29])
        registers[28] = registers[17][registers[19]]
        registers[29] = registers[17][registers[20]]
        registers[28] = registers[28] + registers[29]
        goto p658
        ::p81::
        tick(81)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[17] = z;
            registers[18] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p568
        end
        goto p49
        ::p83::
        tick(83)
        registers[34] = (5)
        registers[35] = (4)
        registers[36] = (3)
        goto p353
        ::p87::
        tick(87)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        goto p782
        ::p92::
        tick(92)
        registers[9][0] = registers[10]
        registers[10] = new_frame(15)
        registers[10][0] = 1
        goto p668
        ::p102::
        tick(102)
        registers[28] = (11)
        registers[29] = (8)
        registers[30] = (9)
        registers[31] = (6)
        registers[32] = (7)
        goto p162
        ::p108::
        tick(108)
        registers[24] = (15)
        registers[25] = (0)
        registers[26] = (1)
        registers[27] = (2)
        registers[28] = (3)
        goto p64
        ::p114::
        tick(114)
        if not registers[16] then
            goto p126
        end
        goto p227
        ::p122::
        tick(122)
        registers[3] = "\191";
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = environment["math"]
        goto p680
        ::p126::
        tick(126)
        registers[15] = registers[16]
        registers[16] = registers[14] < registers[14]
        if not registers[16] then
            goto p662
        end
        goto p464
        ::p137::
        tick(137)
        if registers[16] then
            goto p30
        end
        goto p53
        ::p139::
        tick(139)
        registers[14] = registers[7]
        registers[15] = registers[12];
        registers[(14)] = registers[(14)](registers[15])
        goto p305
        ::p144::
        tick(144)
        registers[26] = (13)
        registers[27] = (12)
        q = registers[(12)]
        q[1] = registers[13]
        q[2] = registers[14]
        q[3] = registers[15]
        q[4] = registers[16]
        q[5] = registers[17]
        q[6] = registers[18]
        q[7] = registers[19]
        q[8] = registers[20]
        q[9] = registers[21]
        q[10] = registers[22]
        q[11] = registers[23]
        q[12] = registers[24]
        q[13] = registers[25]
        q[14] = registers[26]
        q[15] = registers[27]
        goto p738
        ::p148::
        tick(148)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p68
        end
        goto p422
        ::p150::
        tick(150)
        registers[16][registers[13]] = registers[22]
        registers[17][registers[13]] = registers[13]
        registers[22] = registers[14] * registers[13]
        registers[22] = registers[22] + registers[15]
        registers[13] = registers[22] % 256
        goto p472
        ::p156::
        tick(156)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (2)
        goto p295
        ::p162::
        registers[33] = (4)
        registers[34] = (5)
        registers[35] = (2)
        goto p194
        ::p166::
        tick(166)
        registers[4] = environment["string"]
        registers[4] = registers[4]["char"]
        registers[5] = environment["string"]
        registers[5] = registers[5]["byte"]
        registers[6] = environment["setmetatable"]
        goto p393
        ::p180::
        tick(180)
        registers[31] = (4)
        registers[32] = (7)
        registers[33] = (6)
        q = registers[(18)]
        q[1] = registers[19]
        q[2] = registers[20]
        q[3] = registers[21]
        q[4] = registers[22]
        q[5] = registers[23]
        q[6] = registers[24]
        q[7] = registers[25]
        q[8] = registers[26]
        q[9] = registers[27]
        q[10] = registers[28]
        q[11] = registers[29]
        q[12] = registers[30]
        q[13] = registers[31]
        q[14] = registers[32]
        q[15] = registers[33]
        registers[19] = new_frame(15)
        registers[19][0] = 10
        registers[20] = (11)
        registers[21] = (8)
        registers[22] = (9)
        goto p156
        ::p190::
        tick(190)
        registers[11] = new_frame(15)
        registers[11][0] = 2
        registers[12] = (3)
        goto p523
        ::p194::
        registers[36] = (3)
        registers[37] = (0)
        registers[38] = (1)
        q = registers[(23)]
        q[1] = registers[24]
        q[2] = registers[25]
        q[3] = registers[26]
        q[4] = registers[27]
        q[5] = registers[28]
        q[6] = registers[29]
        q[7] = registers[30]
        q[8] = registers[31]
        q[9] = registers[32]
        q[10] = registers[33]
        q[11] = registers[34]
        q[12] = registers[35]
        q[13] = registers[36]
        q[14] = registers[37]
        q[15] = registers[38]
        goto p288
        ::p199::
        tick(199)
        registers[16] = new_frame(15)
        registers[16][0] = 7
        a = registers
        z = 17;
        a[z] = 6
        registers[18] = (5)
        registers[19] = (4)
        registers[20] = (3)
        registers[21] = (2)
        registers[22] = (1)
        goto p41
        ::p209::
        tick(209)
        registers[13] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[13]()
        end
        ::p211::
        tick(211)
        registers[23][0] = 14
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (10)
        goto p102
        ::p219::
        tick(219)
        if registers[2] then
            goto p536
        end
        goto p455
        ::p221::
        tick(221)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (1)
        registers[19] = (0)
        registers[20] = (3)
        goto p274
        ::p227::
        registers[16] = (registers[14] ~= registers[14])
        goto p126
        ::p229::
        tick(229)
        registers[13] = (2)
        a = registers
        z = 14;
        a[z] = 1
        registers[15] = (0)
        registers[16] = (7)
        registers[17] = (6)
        registers[18] = (5)
        registers[19] = (4)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (9)
        registers[23] = (8)
        registers[24] = (15)
        registers[25] = (14)
        goto p144
        ::p245::
        tick(245)
        registers[17] = registers[14]
        registers[18] = registers[14]
        registers[16] = registers[16](registers[17], registers[18])
        if not registers[16] then
            goto p137
        end
        goto p666
        ::p254::
        tick(254)
        registers[15] = registers[16]
        registers[16] = registers[14]
        registers[17] = registers[14]
        registers[18] = registers[14]
        goto p704
        ::p259::
        tick(259)
        registers[2] = (registers[2] - 88)
        registers[2] = -1965960800 + registers[2]
        registers[3] = registers
        goto p166
        ::p263::
        tick(263)
        registers[29] = (10)
        registers[30] = (9)
        registers[31] = (8)
        registers[32] = (7)
        registers[33] = (6)
        goto p83
        ::p269::
        tick(269)
        registers[25] = (8)
        registers[26] = (9)
        registers[27] = (10)
        goto p457
        ::p274::
        registers[21] = (2)
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (9)
        registers[27] = (8)
        registers[28] = (11)
        registers[29] = (10)
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        q[5] = registers[19]
        q[6] = registers[20]
        q[7] = registers[21]
        q[8] = registers[22]
        q[9] = registers[23]
        q[10] = registers[24]
        q[11] = registers[25]
        q[12] = registers[26]
        q[13] = registers[27]
        q[14] = registers[28]
        q[15] = registers[29]
        registers[15] = new_frame(15)
        registers[15][0] = 6
        goto p348
        ::p288::
        registers[24] = new_frame(15)
        registers[24][0] = 15
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (11)
        goto p263
        ::p295::
        registers[28] = (3)
        a = registers
        z = 29;
        a[z] = 0
        registers[30] = (1)
        registers[31] = (6)
        goto p332
        ::p301::
        tick(301)
        registers[37] = (2)
        q = registers[(22)]
        q[1] = registers[23]
        q[2] = registers[24]
        q[3] = registers[25]
        q[4] = registers[26]
        q[5] = registers[27]
        q[6] = registers[28]
        q[7] = registers[29]
        q[8] = registers[30]
        q[9] = registers[31]
        q[10] = registers[32]
        q[11] = registers[33]
        q[12] = registers[34]
        q[13] = registers[35]
        q[14] = registers[36]
        q[15] = registers[37]
        registers[23] = new_frame(15)
        goto p211
        ::p305::
        if registers[14] == registers[0] then
            goto p798
        end
        goto p209
        ::p307::
        tick(307)
        registers[16] = registers[11]
        do
            if not N then

            else
                for f, F, u in next, N do
                    if f >= 1 then
                        F[2] = F;
                        F[3] = registers[f]
                        F[1] = (3)
                        N[f] = (nil)
                    end
                end
            end
            return registers[16]()
        end
        ::p309::
        tick(309)
        registers[18] = (9)
        registers[19] = (8)
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (13)
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        goto p190
        ::p319::
        tick(319)
        registers[23] = (12)
        registers[24] = (15)
        registers[25] = (14)
        registers[26] = (1)
        registers[27] = (0)
        registers[28] = (3)
        registers[29] = (2)
        registers[30] = (5)
        goto p180
        ::p328::
        tick(328)
        registers[22] = (9)
        registers[23] = (8)
        registers[24] = (15)
        goto p540
        ::p332::
        registers[32] = (7)
        registers[33] = (4)
        registers[34] = (5)
        goto p697
        ::p336::
        tick(336)
        registers[24] = registers[24] + 1
        registers[24] = registers[12][registers[24]]
        registers[23] = registers[23] + registers[24]
        goto p466
        ::p340::
        tick(340)
        registers[16] = (7)
        registers[17] = (0)
        registers[18] = (1)
        registers[19] = (2)
        registers[20] = (3)
        registers[21] = (12)
        goto p729
        ::p347::
        tick(347)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[21] + 0
        n = (registers[20] + 0)
        v = (registers[19] - U)
        goto p23
        ::p348::
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        registers[19] = (2)
        goto p405
        ::p353::
        registers[37] = (2)
        registers[38] = (1)
        registers[39] = (0)
        q = registers[(24)]
        q[1] = registers[25]
        q[2] = registers[26]
        q[3] = registers[27]
        q[4] = registers[28]
        q[5] = registers[29]
        q[6] = registers[30]
        q[7] = registers[31]
        q[8] = registers[32]
        q[9] = registers[33]
        q[10] = registers[34]
        q[11] = registers[35]
        q[12] = registers[36]
        q[13] = registers[37]
        q[14] = registers[38]
        q[15] = registers[39]
        q = registers[(9)]
        q[1] = registers[10]
        q[2] = registers[11]
        q[3] = registers[12]
        q[4] = registers[13]
        q[5] = registers[14]
        q[6] = registers[15]
        q[7] = registers[16]
        q[8] = registers[17]
        q[9] = registers[18]
        q[10] = registers[19]
        q[11] = registers[20]
        q[12] = registers[21]
        q[13] = registers[22]
        q[14] = registers[23]
        q[15] = registers[24]
        a = D.f54
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p570
        ::p365::
        tick(365)
        registers[17] = registers[14]
        registers[18] = registers[14]
        m, x = pack_returns(registers[18]())
        m = m + 18 - 1
        top = m
        z = 0
        for f = 18, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        a = D.f55
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        goto p245
        ::p371::
        registers[26] = (13)
        q = registers[(11)]
        q[1] = registers[12]
        q[2] = registers[13]
        q[3] = registers[14]
        q[4] = registers[15]
        q[5] = registers[16]
        q[6] = registers[17]
        q[7] = registers[18]
        q[8] = registers[19]
        q[9] = registers[20]
        q[10] = registers[21]
        q[11] = registers[22]
        q[12] = registers[23]
        q[13] = registers[24]
        q[14] = registers[25]
        q[15] = registers[26]
        registers[12] = new_frame(15)
        registers[12][0] = 3
        goto p229
        ::p384::
        tick(384)
        registers[14] = (4)
        registers[15] = (5)
        registers[16] = (6)
        registers[17] = (7)
        registers[18] = (8)
        registers[19] = (9)
        registers[20] = (10)
        registers[21] = (11)
        goto p722
        ::p393::
        registers[7] = environment["getmetatable"]
        registers[8] = environment["next"]
        registers[9] = new_frame(15)
        goto p619
        ::p397::
        registers[32] = (7)
        q = registers[(17)]
        q[1] = registers[18]
        q[2] = registers[19]
        q[3] = registers[20]
        q[4] = registers[21]
        q[5] = registers[22]
        q[6] = registers[23]
        q[7] = registers[24]
        q[8] = registers[25]
        q[9] = registers[26]
        q[10] = registers[27]
        q[11] = registers[28]
        q[12] = registers[29]
        q[13] = registers[30]
        q[14] = registers[31]
        q[15] = registers[32]
        registers[18] = new_frame(15)
        registers[18][0] = 9
        registers[19] = (8)
        goto p577
        ::p405::
        registers[20] = (3)
        registers[21] = (0)
        registers[22] = (1)
        registers[23] = (14)
        registers[24] = (15)
        registers[25] = (12)
        registers[26] = (13)
        registers[27] = (10)
        registers[28] = (11)
        goto p809
        ::p415::
        tick(415)
        registers[13]["__eq"] = registers[12]
        registers[13]["__lt"] = registers[12]
        registers[13]["__le"] = registers[12]
        goto p11
        ::p422::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = registers[12][3]
        registers[14] = registers[12][1]
        goto p759
        ::p445::
        tick(445)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (255)
        registers[21] = (1)
        goto p347
        ::p451::
        tick(451)
        registers[26] = registers[19] + 1
        registers[19] = registers[26] % 256
        registers[26] = registers[17][registers[19]]
        goto p593
        ::p455::
        registers[2] = (345)
        goto p536
        ::p457::
        registers[28] = (11)
        registers[29] = (4)
        registers[30] = (5)
        registers[31] = (6)
        registers[32] = (7)
        goto p3
        ::p464::
        registers[16] = registers[14] > registers[14]
        goto p662
        ::p466::
        registers[18] = registers[23] % 256
        registers[23] = registers[17][registers[18]]
        registers[25] = registers[17][registers[22]]
        registers[17][registers[18]] = registers[25]
        registers[17][registers[22]] = registers[23]
        goto p23
        ::p472::
        tick(472)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[21] = v
            branch_taken = true
        end
        if branch_taken then
            goto p716
        end
        goto p445
        ::p474::
        tick(474)
        registers[15] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p148
        ::p476::
        registers[28] = (11)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        q[5] = registers[18]
        q[6] = registers[19]
        q[7] = registers[20]
        q[8] = registers[21]
        q[9] = registers[22]
        q[10] = registers[23]
        q[11] = registers[24]
        q[12] = registers[25]
        q[13] = registers[26]
        q[14] = registers[27]
        q[15] = registers[28]
        registers[14] = new_frame(15)
        registers[14][0] = 5
        registers[15] = (4)
        goto p221
        ::p484::
        q = registers[(21)]
        q[1] = registers[22]
        q[2] = registers[23]
        q[3] = registers[24]
        q[4] = registers[25]
        q[5] = registers[26]
        q[6] = registers[27]
        q[7] = registers[28]
        q[8] = registers[29]
        q[9] = registers[30]
        q[10] = registers[31]
        q[11] = registers[32]
        q[12] = registers[33]
        q[13] = registers[34]
        q[14] = registers[35]
        q[15] = registers[36]
        registers[22] = new_frame(15)
        registers[22][0] = 13
        registers[23] = (12)
        goto p87
        ::p489::
        if registers[13] == registers[14] then
            goto p25
        end
        goto p307
        ::p501::
        _, Q = pack_returns(...)
        registers[1] = Q[W]
        registers[2] = environment["string"]
        registers[2] = registers[2]["len"]
        goto p122
        ::p513::
        tick(513)
        registers[14][registers[14]] = registers[14]
        registers[16] = registers[14][registers[14]]
        registers[14][registers[14]] = registers[16]
        registers[12] = registers[3]
        if not registers[12] then
            goto p209
        end
        goto p606
        ::p519::
        tick(519);
        registers[(3)] = registers[(3)](registers[4])
        registers[2] = (registers[2] ~= registers[3])
        if not registers[2] then
            goto p219
        end
        goto p39
        ::p523::
        registers[13] = (0)
        registers[14] = (1)
        registers[15] = (6)
        registers[16] = (7)
        registers[17] = (4)
        registers[18] = (5)
        goto p755
        ::p531::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[19] = (0)
        registers[20] = (0)
        goto p557
        ::p536::
        registers[2] = registers[2] + 277
        registers[2] = (registers[2] - 357)
        registers[2] = registers[2] + 178
        goto p259
        ::p540::
        registers[25] = (14)
        registers[26] = (13)
        registers[27] = (12)
        registers[28] = (3)
        registers[29] = (2)
        registers[30] = (1)
        registers[31] = (0)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (5)
        registers[35] = (4)
        goto p625
        ::p552::
        tick(552)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[22] = registers[21]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[22]
        end
        ::p555::
        tick(555)
        registers[18] = nil
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(16)]
        n = registers[17]
        U = registers[18]
        goto p81
        ::p557::
        registers[21] = ""
        registers[22] = (5)
        registers[23] = (#registers[1])
        registers[24] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[24] + 0
        n = (registers[23] + 0)
        v = (registers[22] - U)
        goto p672
        ::p562::
        registers[15] = {
        }
        registers[16] = registers[13]
        registers[14] = registers[14](registers[15], registers[16])
        registers[15] = registers[14]
        registers[16] = registers[14]
        goto p365
        ::p568::
        if registers[13] ~= registers[18] then
            goto p81
        end
        goto p694
        ::p570::
        a = D.f56
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        a = D.f58
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[13] = {
        }
        registers[13]["__tostring"] = registers[11]
        registers[13]["__call"] = registers[12]
        registers[13]["__add"] = registers[12]
        goto p674
        ::p577::
        registers[20] = (11)
        registers[21] = (10)
        registers[22] = (13)
        goto p319
        ::p581::
        registers[23] = registers[17][registers[22]]
        registers[23] = registers[18] + registers[23]
        registers[24] = registers[22] % 8
        goto p336
        ::p593::
        registers[26] = registers[20] + registers[26]
        registers[20] = registers[26] % 256
        registers[26] = registers[17][registers[20]]
        registers[28] = registers[17][registers[19]]
        a = registers
        z = 17
        a = a[z]
        z = registers
        q = (20)
        z = z[q]
        q = registers
        m = 28
        q = q[m]
        a[z] = q
        registers[17][registers[19]] = registers[26]
        registers[26] = registers[10]
        registers[27] = registers[5]
        goto p74
        ::p606::
        registers[13] = environment["type"]
        a = registers
        z = 14
        q = registers
        q = q[12]
        a[z] = q;
        registers[(13)] = registers[(13)](registers[14])
        if registers[13] ~= "table" then
            goto p209
        end
        goto p139
        ::p613::
        tick(613)
        registers[26] = registers[16][registers[26]]
        registers[21] = (registers[21]..registers[26])
        goto p672
        ::p616::
        tick(616)
        registers[19] = (255)
        registers[20] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[20] + 0
        n = (registers[19] + 0)
        v = (registers[18] - U)
        goto p472
        ::p619::
        registers[10] = new_frame(15)
        registers[10][0] = 0
        registers[11] = (1)
        registers[12] = (2)
        registers[13] = (3)
        goto p384
        ::p625::
        q = registers[(20)]
        q[1] = registers[21]
        q[2] = registers[22]
        q[3] = registers[23]
        q[4] = registers[24]
        q[5] = registers[25]
        q[6] = registers[26]
        q[7] = registers[27]
        q[8] = registers[28]
        q[9] = registers[29]
        q[10] = registers[30]
        q[11] = registers[31]
        q[12] = registers[32]
        q[13] = registers[33]
        q[14] = registers[34]
        q[15] = registers[35]
        registers[21] = new_frame(15)
        registers[21][0] = 12
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        goto p269
        ::p645::
        tick(645)
        registers[16] = (registers[14] >= registers[14])
        goto p254
        ::p653::
        tick(653)
        registers[14] = (5)
        registers[15] = (4)
        registers[16] = (7)
        registers[17] = (6)
        goto p309
        ::p658::
        registers[28] = registers[28] % 256
        registers[28] = registers[17][registers[28]]
        registers[26] = registers[26](registers[27], registers[28])
        goto p613
        ::p662::
        registers[15] = registers[16]
        registers[16] = (registers[14] <= registers[14])
        if not registers[16] then
            goto p254
        end
        goto p645
        ::p666::
        registers[16] = registers[14]
        goto p137
        ::p668::
        registers[11] = (0)
        registers[12] = (3)
        registers[13] = (2)
        goto p653
        ::p672::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[25] = v
            branch_taken = true
        end
        if branch_taken then
            goto p451
        end
        goto p552
        ::p674::
        registers[13]["__sub"] = registers[12]
        registers[13]["__mul"] = registers[12]
        registers[13]["__div"] = registers[12]
        registers[13]["__mod"] = registers[12]
        registers[13]["__pow"] = registers[12]
        goto p415
        ::p680::
        registers[3] = registers[3]["ceil"]
        registers[4] = environment["math"]
        registers[4] = registers[4]["pi"]
        goto p519
        ::p694::
        registers[15] = (true)
        registers[12][registers[17]] = registers[14]
        goto p81
        ::p697::
        q = registers[(19)]
        q[1] = registers[20]
        q[2] = registers[21]
        q[3] = registers[22]
        q[4] = registers[23]
        q[5] = registers[24]
        q[6] = registers[25]
        q[7] = registers[26]
        q[8] = registers[27]
        q[9] = registers[28]
        q[10] = registers[29]
        q[11] = registers[30]
        q[12] = registers[31]
        q[13] = registers[32]
        q[14] = registers[33]
        q[15] = registers[34]
        registers[20] = new_frame(15)
        registers[20][0] = 11
        registers[21] = (10)
        goto p328
        ::p704::
        registers[19] = registers[14]
        registers[20] = registers[14];
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[14]
        m, x = pack_returns(registers[20]())
        m = m + 20 - 1
        top = m
        z = 0
        for f = 20, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[16](unpack_range(top, registers, 17))
        registers[16] = registers[14]
        registers[17] = (registers[14]..registers[14])
        registers[18] = registers[14]..""
        registers[19] = ""..registers[14]
        registers[(16)](unpack_range(19, registers, 17))
        goto p513
        ::p716::
        registers[22] = registers[4]
        registers[23] = registers[13];
        registers[(22)] = registers[(22)](registers[23])
        goto p150
        ::p722::
        registers[22] = (12)
        registers[23] = (13)
        registers[24] = (14)
        registers[25] = (15)
        q = registers[(10)]
        q[1] = registers[11]
        q[2] = registers[12]
        q[3] = registers[13]
        q[4] = registers[14]
        q[5] = registers[15]
        q[6] = registers[16]
        q[7] = registers[17]
        q[8] = registers[18]
        q[9] = registers[19]
        q[10] = registers[20]
        q[11] = registers[21]
        q[12] = registers[22]
        q[13] = registers[23]
        q[14] = registers[24]
        q[15] = registers[25]
        goto p92
        ::p729::
        registers[22] = (13)
        registers[23] = (14)
        registers[24] = (15)
        goto p35
        ::p733::
        registers[18] = (registers[14] ^ registers[14])
        registers[17] = registers[17] % registers[18]
        registers[15] = (registers[16] - registers[17])
        registers[16] = registers[14] == registers[14]
        goto p114
        ::p738::
        registers[13] = new_frame(15)
        registers[13][0] = 4
        registers[14] = (5)
        registers[15] = (6)
        goto p340
        ::p743::
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (9)
        registers[31] = (8)
        q = registers[(16)]
        q[1] = registers[17]
        q[2] = registers[18]
        q[3] = registers[19]
        q[4] = registers[20]
        q[5] = registers[21]
        q[6] = registers[22]
        q[7] = registers[23]
        q[8] = registers[24]
        q[9] = registers[25]
        q[10] = registers[26]
        q[11] = registers[27]
        q[12] = registers[28]
        q[13] = registers[29]
        q[14] = registers[30]
        q[15] = registers[31]
        registers[17] = new_frame(15)
        goto p60
        ::p750::
        registers[20] = (11)
        registers[21] = (12)
        registers[22] = (13)
        registers[23] = (14)
        goto p108
        ::p755::
        registers[19] = (10)
        registers[20] = (11)
        registers[21] = (8)
        goto p55
        ::p759::
        registers[14] = registers[14] % 64
        registers[14] = 4 * registers[14]
        a = registers
        z = (14)
        q = registers
        m = 14
        q = q[m]
        m = 1
        q = (q + m);
        a[z] = q
        registers[15] = registers[12][2]
        registers[15] = registers[15] % 128
        registers[15] = 2 * registers[15]
        registers[15] = (registers[15] - 1)
        registers[16] = {
        }
        registers[17] = {
        }
        registers[18] = (0)
        goto p616
        ::p774::
        registers[19] = (1)
        registers[20] = (4)
        m, x = pack_returns(registers[17](unpack_range(20, registers, 18)))
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(12)]
        for f = 1, top - (12) do
            q[(0) + f] = registers[(12) + f]
        end
        registers[13] = (1)
        registers[14] = (4)
        goto p474
        ::p782::
        registers[28] = (11)
        registers[29] = (10)
        registers[30] = (5)
        registers[31] = (4)
        registers[32] = (7)
        registers[33] = (6)
        registers[34] = (1)
        registers[35] = (0)
        registers[36] = (3)
        goto p301
        ::p798::
        registers[13] = registers[6]
        registers[14] = registers[12]
        registers[15] = nil;
        registers[13](registers[14], registers[15])
        registers[13] = {
        }
        registers[14] = {
        }
        registers[15] = (false)
        registers[16] = registers[8]
        registers[17] = registers[12]
        goto p555
        ::p809::
        registers[29] = (8)
        registers[30] = (9)
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        q[3] = registers[18]
        q[4] = registers[19]
        q[5] = registers[20]
        q[6] = registers[21]
        q[7] = registers[22]
        q[8] = registers[23]
        q[9] = registers[24]
        q[10] = registers[25]
        q[11] = registers[26]
        q[12] = registers[27]
        q[13] = registers[28]
        q[14] = registers[29]
        q[15] = registers[30]
        goto p199
    end
end
