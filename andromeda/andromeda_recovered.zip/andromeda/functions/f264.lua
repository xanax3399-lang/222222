-- Recovered function f264; author names are unavailable.
F.f264 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f264")
        tick(1)
        goto p322
        ::p2::
        tick(2)
        registers[8] = 1.06 + registers[8]
        registers[6] = registers[6] * registers[8]
        goto p69
        ::p5::
        tick(5)
        registers[9] = (0)
        goto p274
        ::p13::
        tick(13)
        registers[3] = registers[4]
        registers[4] = upvalues[0]["player_state"]
        registers[4][registers[1]] = registers[3]
        goto p177
        ::p17::
        tick(17)
        registers[8] = (0)
        goto p354
        ::p27::
        tick(27)
        registers[5] = upvalues[1][155]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = upvalues[0]["get_overpredict_multiplier"];
        registers[6] = registers[6]()
        branch_taken = false
        if not (not (registers[5] < 100)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p192
        end
        goto p140
        ::p34::
        tick(34)
        registers[5] = (registers[5] * 0.9)
        goto p74
        ::p43::
        tick(43)
        registers[10] = registers[10] * registers[11]
        registers[9] = registers[9] + registers[10]
        branch_taken = false
        if not (not (registers[9] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        goto p332
        ::p47::
        tick(47)
        registers[3]["velocity"] = registers[2]
        registers[5] = (0)
        do
            return registers[5]
        end
        ::p54::
        tick(54)
        registers[11] = upvalues[1][162]
        registers[12] = registers[3]["stable_ticks"]
        if registers[12] then
            goto p327
        end
        goto p121
        ::p58::
        tick(58)
        registers[4] = {
        }
        registers[4]["velocity"] = registers[0]
        registers[4]["simtime"] = registers[0]
        registers[4]["origin"] = registers[0]
        registers[4]["penalty_until"] = 0
        goto p239
        ::p64::
        tick(64)
        registers[6] = (registers[6] * 1.15)
        goto p117
        ::p69::
        tick(69)
        registers[8] = registers[3]["stable_ticks"]
        if registers[8] then
            goto p354
        end
        goto p17
        ::p72::
        tick(72)
        branch_taken = false
        if not (not (registers[4] < 1225)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p310
        end
        goto p47
        ::p74::
        tick(74)
        registers[6] = upvalues[2]["clamp"]
        registers[7] = registers[5]
        registers[8] = (0.45)
        registers[9] = (2)
        goto p221
        ::p85::
        tick(85)
        registers[9] = (registers[9] * 0.08)
        registers[9] = 0.82 - registers[9]
        registers[10] = (0.52)
        goto p246
        ::p89::
        tick(89)
        registers[11] = upvalues[1][151]
        registers[12] = registers[3]["stable_ticks"]
        if registers[12] then
            goto p99
        end
        goto p219
        ::p93::
        tick(93)
        registers[8] = registers[3]["boost_until"]
        registers[9] = upvalues[1][23];
        registers[9] = registers[9]()
        if not (registers[9] < registers[8]) then
            goto p69
        end
        goto p104
        ::p99::
        tick(99)
        registers[12] = (registers[12] - 2)
        registers[13] = (0)
        registers[11] = registers[11](registers[12], registers[13])
        registers[3]["stable_ticks"] = registers[11]
        goto p159
        ::p104::
        registers[8] = upvalues[1][162]
        registers[9] = registers[3]["hit_streak"]
        if registers[9] then
            goto p274
        end
        goto p5
        ::p108::
        tick(108)
        registers[4] = (0)
        do
            return registers[4]
        end
        ::p115::
        tick(115)
        registers[5] = (registers[5] * 1.15)
        goto p74
        ::p117::
        tick(117)
        registers[7] = registers[3]["velocity"]
        if registers[7] == registers[0] then
            goto p159
        end
        goto p289
        ::p121::
        registers[12] = (0)
        goto p327
        ::p140::
        registers[6] = (registers[6] * 0.65)
        goto p117
        ::p145::
        registers[10] = upvalues[1][161]
        registers[11] = upvalues[1][155]
        registers[12] = registers[8]
        goto p298
        ::p155::
        tick(155)
        branch_taken = false
        if not (not (registers[4] < 180)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p294
        end
        goto p34
        ::p159::
        tick(159)
        registers[3]["velocity"] = registers[2]
        registers[8] = registers[3]["penalty_until"]
        registers[9] = upvalues[1][23];
        registers[9] = registers[9]()
        if not (registers[9] < registers[8]) then
            goto p93
        end
        goto p215
        ::p166::
        tick(166)
        if not (240 < registers[5]) then
            goto p117
        end
        goto p64
        ::p168::
        tick(168)
        registers[4] = (1)
        do
            return registers[4]
        end
        ::p170::
        tick(170)
        registers[8] = upvalues[2]["clamp"]
        registers[9] = registers[6]
        registers[10] = (0.45)
        registers[11] = (2.25)
        do
            return registers[(8)](unpack_range(11, registers, 9))
        end
        ::p175::
        tick(175)
        registers[5] = (registers[5] * 0.65)
        goto p74
        ::p177::
        tick(177)
        registers[4] = registers[2]["x"]
        registers[5] = registers[2]["x"]
        registers[4] = registers[4] * registers[5]
        registers[5] = registers[2]["y"]
        registers[6] = registers[2]["y"]
        registers[5] = registers[5] * registers[6]
        registers[4] = registers[4] + registers[5]
        goto p72
        ::p192::
        branch_taken = false
        if not (not (registers[5] < 180)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p166
        end
        goto p325
        ::p201::
        tick(201)
        registers[9] = registers[2]["x"]
        registers[10] = registers[7]["x"]
        registers[9] = registers[9] * registers[10]
        registers[10] = registers[2]["y"]
        registers[11] = registers[7]["y"]
        goto p43
        ::p212::
        tick(212)
        registers[3]["velocity"] = registers[2]
        registers[5] = (1)
        do
            return registers[5]
        end
        ::p215::
        registers[8] = upvalues[2]["clamp"]
        registers[9] = registers[3]["miss_streak"]
        if registers[9] then
            goto p85
        end
        goto p272
        ::p219::
        registers[12] = (0)
        goto p99
        ::p221::
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p239::
        registers[4]["boost_until"] = 0
        registers[4]["stable_ticks"] = 0
        registers[4]["hit_streak"] = 0
        registers[4]["miss_streak"] = 0
        goto p13
        ::p244::
        tick(244)
        registers[6] = (registers[6] * 1.05)
        goto p170
        ::p246::
        registers[11] = (0.82);
        registers[8] = registers[8](unpack_range(11, registers, 9))
        registers[6] = registers[6] * registers[8]
        goto p93
        ::p250::
        tick(250)
        registers[4] = upvalues[0]["is_overpredict_enabled"];
        registers[4] = registers[4]()
        if registers[4] then
            goto p314
        end
        goto p168
        ::p262::
        tick(262)
        registers[3] = upvalues[0]["player_state"]
        registers[3] = registers[3][registers[1]]
        if registers[3] ~= registers[0] then
            goto p177
        end
        goto p58
        ::p272::
        registers[9] = (0)
        goto p85
        ::p274::
        registers[9] = (registers[9] * 0.025)
        registers[10] = (0.08)
        registers[8] = registers[8](registers[9], registers[10])
        goto p2
        ::p289::
        registers[8] = registers[7]["x"]
        registers[9] = registers[7]["x"]
        registers[8] = registers[8] * registers[9]
        goto p356
        ::p294::
        if not (240 < registers[4]) then
            goto p74
        end
        goto p115
        ::p298::;
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[5] - registers[11]);
        registers[(10)] = registers[(10)](registers[11])
        branch_taken = false
        if not (not (registers[10] < 22)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p89
        end
        goto p54
        ::p310::
        registers[5] = upvalues[0]["is_overpredict_enabled"];
        registers[5] = registers[5]()
        if registers[5] then
            goto p27
        end
        goto p212
        ::p314::
        registers[4] = upvalues[1][155]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        registers[5] = upvalues[0]["get_overpredict_multiplier"];
        registers[5] = registers[5]()
        branch_taken = false
        if not (not (registers[4] < 100)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p155
        end
        goto p175
        ::p322::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[1] ~= registers[0] then
            goto p262
        end
        goto p347
        ::p325::
        registers[6] = (registers[6] * 0.9)
        goto p117
        ::p327::
        registers[12] = registers[12] + 1
        registers[13] = (12)
        registers[11] = registers[11](registers[12], registers[13])
        registers[3]["stable_ticks"] = registers[11]
        goto p159
        ::p332::
        registers[6] = (registers[6] * 0.55)
        registers[3]["stable_ticks"] = 0
        goto p159
        ::p347::
        registers[3] = registers[2]["x"]
        registers[4] = registers[2]["x"]
        registers[3] = registers[3] * registers[4]
        registers[4] = registers[2]["y"]
        registers[5] = registers[2]["y"]
        goto p362
        ::p354::
        branch_taken = false
        if not (not (4 <= registers[8])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p170
        end
        goto p244
        ::p356::
        registers[9] = registers[7]["y"]
        registers[10] = registers[7]["y"]
        registers[9] = registers[9] * registers[10]
        registers[8] = registers[8] + registers[9]
        if not (1225 < registers[8]) then
            goto p159
        end
        goto p201
        ::p362::
        registers[4] = registers[4] * registers[5]
        registers[3] = registers[3] + registers[4]
        branch_taken = false
        if not (not (registers[3] < 1225)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p250
        end
        goto p108
    end
end
