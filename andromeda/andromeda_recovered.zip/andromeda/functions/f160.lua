-- Recovered function f160; author names are unavailable.
F.f160 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f160")
        tick(1)
        goto p105
        ::p8::
        tick(8)
        registers[5] = upvalues[0][36]
        registers[6] = registers[2]
        registers[7] = "m_flPoseParameter"
        registers[8] = upvalues[0][150];
        registers[8] = registers[8]()
        goto p150
        ::p32::
        tick(32)
        registers[9] = (7)
        registers[(5)](unpack_range(9, registers, 6))
        registers[5] = upvalues[0][36]
        goto p69
        ::p42::
        tick(42)
        do
            return 
        end
        ::p61::
        tick(61)
        registers[3]["weight"] = 1
        registers[5] = upvalues[0][26];
        registers[5] = registers[5]()
        registers[5] = (registers[5] * 0.55)
        registers[5] = registers[5] % 1
        goto p94
        ::p69::
        registers[6] = registers[2]
        registers[7] = "m_flPoseParameter"
        registers[8] = upvalues[0][150];
        registers[8] = registers[8]()
        registers[9] = (6)
        registers[(5)](unpack_range(9, registers, 6))
        goto p42
        ::p76::
        tick(76)
        if registers[4] ~= "Off" then
            goto p144
        end
        goto p102
        ::p80::
        tick(80)
        registers[7] = "m_flPoseParameter"
        registers[8] = upvalues[0][150];
        registers[8] = registers[8]()
        goto p32
        ::p94::
        registers[3]["cycle"] = registers[5]
        do
            return 
        end
        ::p102::
        tick(102)
        do
            return 
        end
        ::p105::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if registers[2] == registers[0] then
            goto p171
        end
        goto p134
        ::p117::
        tick(117)
        registers[5] = registers[1]["air_legs_weight"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        goto p175
        ::p124::
        tick(124)
        if registers[4] ~= "Moonwalk" then
            goto p137
        end
        goto p61
        ::p127::
        tick(127)
        registers[4] = registers[1]["air_legs"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        goto p76
        ::p134::
        if registers[3] ~= registers[0] then
            goto p127
        end
        goto p171
        ::p137::
        if registers[4] ~= "Kangaroo" then
            goto p42
        end
        goto p8
        ::p144::
        if registers[4] ~= "Static" then
            goto p124
        end
        goto p117
        ::p150::
        registers[9] = (3)
        registers[(5)](unpack_range(9, registers, 6))
        registers[5] = upvalues[0][36]
        registers[6] = registers[2]
        goto p80
        ::p155::
        tick(155)
        registers[(6)](unpack_range(10, registers, 7))
        do
            return 
        end
        ::p171::
        do
            return 
        end
        ::p175::
        registers[6] = upvalues[0][36]
        registers[7] = registers[2]
        registers[8] = "m_flPoseParameter"
        registers[9] = (registers[5] * 0.01)
        registers[10] = (6)
        goto p155
    end
end
