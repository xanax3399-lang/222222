-- Recovered function f434; author names are unavailable.
F.f434 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f434")
        tick(1)
        goto p74
        ::p2::
        tick(2)
        slot_2 = (slot_2 == "table")
        if not slot_2 then
            goto p17
        end
        goto p27
        ::p10::
        tick(10)
        slot_2 = environment["type"]
        slot_3 = slot_1["set"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == "function")
        ::p15::
        tick(15)
        if not slot_2 then
            goto p50
        end
        goto p20
        ::p17::
        tick(17)
        if not slot_2 then
            goto p15
        end
        goto p10
        ::p20::
        slot_2 = environment["type"]
        slot_3 = slot_1["type"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == "string")
        goto p50
        ::p27::
        slot_2 = environment["type"]
        slot_3 = slot_1["get"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == "function")
        goto p17
        ::p50::
        do
            return slot_2
        end
        ::p74::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        goto p2
    end
end
