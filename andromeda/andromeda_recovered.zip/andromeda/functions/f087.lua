-- Recovered function f87; author names are unavailable.
F.f87 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f87")
        tick(1)
        goto p68
        ::p2::
        tick(2)
        registers[4] = ""
        branch_taken = false
        if not (not (registers[1] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p39
        end
        goto p43
        ::p5::
        tick(5)
        if registers[1] ~= 0 then
            goto p39
        end
        goto p46
        ::p9::
        tick(9)
        registers[6] = registers[5] + 1
        registers[6] = registers[2][registers[6]]
        registers[3] = (registers[6]..registers[3])
        goto p5
        ::p13::
        tick(13)
        registers[11] = "8"
        registers[12] = "9"
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        q[3] = registers[5]
        q[4] = registers[6]
        q[5] = registers[7]
        q[6] = registers[8]
        q[7] = registers[9]
        q[8] = registers[10]
        q[9] = registers[11]
        q[10] = registers[12]
        a = registers
        z = 3;
        a[z] = ""
        goto p2
        ::p39::
        tick(39)
        registers[5] = registers[1] % 10
        registers[6] = (registers[1] - registers[5])
        registers[1] = registers[6] / 10
        goto p9
        ::p43::
        registers[4] = "-"
        registers[1] = -registers[1]
        goto p39
        ::p46::
        registers[5] = (registers[4]..registers[3])
        do
            return registers[5]
        end
        ::p68::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = new_frame(10)
        registers[3] = "0"
        registers[4] = "1"
        registers[5] = "2"
        registers[6] = "3"
        registers[7] = "4"
        registers[8] = "5"
        registers[9] = "6"
        registers[10] = "7"
        goto p13
    end
end
