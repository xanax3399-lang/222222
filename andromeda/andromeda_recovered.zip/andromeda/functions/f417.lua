-- Recovered function f417; author names are unavailable.
F.f417 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local tick = new_tick("f417")
        tick(1)
        goto p5
        ::p3::
        tick(3)
        do
            return 
        end
        ::p5::
        slot_1 = environment["client"]
        slot_1 = slot_1["unset_event_callback"]
        slot_2 = "finish_command"
        slot_3 = upvalues[0];
        slot_1(slot_2, slot_3)
        goto p3
    end
end
