-- Recovered function f449; author names are unavailable.
F.f449 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f449")
        tick(1)
        goto p6
        ::p2::
        tick(2)
        slot_5 = slot_2
        if slot_5 then
            goto p24
        end
        goto p20
        ::p5::
        tick(5)
        do
            return slot_7
        end
        ::p6::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = slot_1
        if slot_4 then
            goto p2
        end
        slot_4 = (0)
        goto p2
        ::p11::
        tick(11)
        slot_6 = slot_6 * slot_7
        slot_6 = slot_6 % 1
        slot_7 = (slot_5 - slot_4)
        slot_7 = slot_7 * slot_6
        slot_7 = slot_4 + slot_7
        goto p5
        ::p17::
        tick(17)
        slot_7 = (1)
        goto p11
        ::p20::
        slot_5 = slot_4
        goto p24
        ::p22::
        tick(22)
        if slot_7 then
            goto p11
        end
        goto p17
        ::p24::
        slot_6 = upvalues[0][30];
        slot_6 = slot_6()
        slot_7 = slot_3
        goto p22
    end
end
