-- Recovered function f337; author names are unavailable.
F.f337 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f337")
        tick(1)
        goto p59
        ::p4::
        tick(4)
        upvalues[0]["hotkey_active"] = false
        do
            return 
        end
        ::p6::
        tick(6)
        registers[2] = upvalues[1][37]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = upvalues[0]["get_weapon_type"]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= registers[0] then
            goto p19
        end
        goto p4
        ::p19::
        registers[4] = upvalues[2]["ragebot"]
        registers[4] = registers[4]["hitchance"]
        registers[4] = registers[4][registers[3]]
        goto p83
        ::p23::
        tick(23)
        registers[2] = upvalues[1][50]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        goto p41
        ::p34::
        tick(34)
        upvalues[0]["hotkey_active"] = false
        do
            return 
        end
        ::p36::
        tick(36)
        upvalues[0]["hotkey_active"] = false
        do
            return 
        end
        ::p41::
        if registers[2] then
            goto p6
        end
        goto p93
        ::p43::
        tick(43)
        registers[5] = upvalues[0]["get_value"]
        registers[6] = registers[1]
        registers[7] = registers[3]
        goto p130
        ::p48::
        tick(48)
        registers[6] = upvalues[0]["set_hitchance"]
        registers[7] = registers[5]
        registers[(6)](registers[7])
        goto p125
        ::p59::
        upvalues[0]["updated_this_tick"] = false
        upvalues[0]["indicator_value"] = registers[0]
        registers[1] = upvalues[0]["is_enabled"];
        registers[1] = registers[1]()
        if registers[1] then
            goto p100
        end
        goto p36
        ::p82::
        tick(82)
        do
            return 
        end
        ::p83::
        if registers[4] ~= registers[0] then
            goto p43
        end
        goto p34
        ::p93::
        tick(93)
        upvalues[0]["hotkey_active"] = false
        do
            return 
        end
        ::p100::
        tick(100)
        registers[1] = upvalues[1][32];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p93
        end
        goto p23
        ::p125::
        upvalues[0]["active"] = true
        upvalues[0]["updated_this_tick"] = true
        upvalues[0]["indicator_value"] = registers[5]
        do
            return 
        end
        ::p130::
        registers[8] = registers[4];
        registers[5] = registers[5](unpack_range(8, registers, 6))
        if registers[5] ~= registers[0] then
            goto p48
        end
        goto p82
    end
end
