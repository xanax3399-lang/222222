-- Recovered function f311; author names are unavailable.
F.f311 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f311")
        tick(1)
        goto p88
        ::p2::
        tick(2)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["cam_idealdist"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        goto p109
        ::p6::
        tick(6)
        if registers[1] == registers[0] then
            goto p146
        end
        goto p140
        ::p8::
        tick(8)
        registers[3] = upvalues[2];
        registers[1](registers[2], registers[3])
        goto p146
        ::p20::
        tick(20)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_maxdistance"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        registers[3] = upvalues[3];
        registers[1](registers[2], registers[3])
        ::p25::
        tick(25)
        do
            return 
        end
        ::p28::
        tick(28)
        registers[3] = (200);
        registers[1](registers[2], registers[3])
        goto p25
        ::p42::
        tick(42)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_maxdistance"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        goto p28
        ::p54::
        tick(54)
        registers[1] = environment["cvar"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q["cam_idealdist"]
        a[z] = q
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        registers[3] = upvalues[1];
        registers[1](registers[2], registers[3])
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_mindistance"]
        goto p6
        ::p73::
        tick(73)
        registers[1] = environment["cvar"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q["c_maxdistance"]
        a[z] = q
        if registers[1] == registers[0] then
            goto p25
        end
        goto p42
        ::p88::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["cam_idealdist"]
        if registers[1] ~= registers[0] then
            goto p150
        end
        goto p139
        ::p109::
        registers[3] = upvalues[0]["thirdperson_distance"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"]
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_mindistance"]
        if registers[1] == registers[0] then
            goto p73
        end
        goto p155
        ::p125::
        tick(125)
        registers[3] = (10);
        registers[1](registers[2], registers[3])
        goto p73
        ::p139::
        do
            return 
        end
        ::p140::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_mindistance"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        goto p8
        ::p144::
        tick(144)
        if not registers[1] then
            goto p54
        end
        goto p2
        ::p146::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_maxdistance"]
        if registers[1] == registers[0] then
            goto p25
        end
        goto p20
        ::p150::
        registers[1] = upvalues[0]["thirdperson"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        goto p144
        ::p155::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["c_mindistance"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        goto p125
    end
end
