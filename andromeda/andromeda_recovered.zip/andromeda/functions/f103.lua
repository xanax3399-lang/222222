-- Recovered function f103; author names are unavailable.
F.f103 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f103")
        tick(1)
        goto p171
        ::p2::
        tick(2)
        registers[3] = registers[1]["enabled"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        goto p85
        ::p6::
        tick(6)
        registers[4] = not registers[3]
        if registers[4] then
            goto p175
        end
        goto p52
        ::p9::
        tick(9)
        registers[2] = registers[1]["enabled"]
        if registers[2] == registers[0] then
            goto p147
        end
        goto p2
        ::p13::
        tick(13)
        registers[2] = upvalues[2];
        registers[2] = registers[2]()
        if registers[2] ~= registers[0] then
            goto p117
        end
        goto p157
        ::p31::
        tick(31)
        if not registers[3] then
            goto p107
        end
        goto p138
        ::p33::
        tick(33)
        if registers[5] then
            goto p191
        end
        goto p76
        ::p44::
        tick(44)
        registers[6] = upvalues[1]["apply_smooth_animfix"]
        registers[7] = registers[1]
        registers[8] = registers[5]
        goto p136
        ::p48::
        tick(48)
        registers[5] = upvalues[5]
        registers[6] = registers[2];
        registers[(5)] = registers[(5)](registers[6])
        goto p33
        ::p52::
        registers[4] = upvalues[4]
        registers[5] = registers[1]
        registers[6] = "Lean"
        registers[4] = registers[4](registers[5], registers[6])
        goto p175
        ::p57::
        tick(57)
        do
            return 
        end
        ::p76::
        registers[5] = nil
        goto p191
        ::p80::
        tick(80)
        if registers[5] == registers[0] then
            goto p31
        end
        goto p44
        ::p83::
        tick(83)
        if registers[5] == registers[0] then
            goto p143
        end
        goto p128
        ::p85::
        if registers[3] then
            goto p13
        end
        goto p147
        ::p87::
        tick(87)
        registers[4] = registers[4](registers[5], registers[6])
        ::p95::
        tick(95)
        registers[5] = registers[4]
        if not registers[5] then
            goto p33
        end
        goto p48
        ::p107::
        z = registers[5]
        registers[7] = z;
        registers[(6)] = z["get_anim_overlay"]
        registers[8] = (6)
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[1]["apply_air_legs"]
        registers[8] = registers[1]
        registers[9] = registers[2]
        registers[10] = registers[6]
        registers[(7)](unpack_range(10, registers, 8))
        goto p83
        ::p117::
        registers[3] = upvalues[3]
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        goto p6
        ::p128::
        tick(128)
        z = registers[5]
        registers[7] = z;
        registers[(6)] = z["get_anim_overlay"]
        registers[8] = (12)
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[1]["apply_move_lean"]
        registers[8] = registers[1]
        goto p194
        ::p136::;
        registers[6](registers[7], registers[8])
        goto p31
        ::p138::
        registers[6] = upvalues[1]["apply_ground_legs"]
        registers[7] = registers[1]
        registers[8] = registers[2];
        registers[6](registers[7], registers[8])
        goto p83
        ::p143::
        tick(143)
        do
            return 
        end
        ::p147::
        tick(147)
        registers[2] = upvalues[1]["reset"]
        registers[(2)]()
        do
            return 
        end
        ::p157::
        registers[3] = upvalues[1]["reset"]
        registers[(3)]()
        do
            return 
        end
        ::p171::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p147
        end
        goto p9
        ::p175::
        if registers[4] then
            goto p95
        end
        goto p187
        ::p177::
        tick(177)
        if registers[5] ~= registers[0] then
            goto p80
        end
        goto p57
        ::p187::
        registers[4] = upvalues[4]
        registers[5] = registers[1]
        registers[6] = "Smooth"
        goto p87
        ::p191::
        if not registers[4] then
            goto p80
        end
        goto p177
        ::p194::
        registers[9] = registers[6];
        registers[7](registers[8], registers[9])
        goto p143
    end
end
