-- Recovered function f469; author names are unavailable.
F.f469 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f469")
        tick(1)
        goto p3
        ::p2::
        tick(2)
        do
            return 
        end
        ::p3::
        slot_1 = upvalues[0]["skip_native_cleanup"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p8
        end
        goto p2
        ::p8::
        slot_1 = upvalues[1]["reset"]
        slot_1()
        do
            return 
        end
    end
end
