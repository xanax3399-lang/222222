-- Recovered function f356; author names are unavailable.
F.f356 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local a = nil
        local tick = new_tick("f356")
        tick(1)
        goto p72
        ::p19::
        tick(19)
        slot_1 = -1
        do
            return slot_1
        end
        ::p44::
        tick(44)
        a = upvalues[0];
        slot_1 = a[2][a[1]]["air"]
        if not slot_1 then
            goto p47
        end
        goto p50
        ::p47::
        slot_1 = upvalues[1]
        if slot_1 then
            goto p19
        end
        goto p86
        ::p50::
        tick(50)
        slot_1 = -2
        do
            return slot_1
        end
        ::p72::
        a = upvalues[0];
        slot_1 = a[2][a[1]]["peeking"]
        if slot_1 then
            goto p50
        end
        goto p44
        ::p84::
        tick(84)
        slot_1 = (1)
        do
            return slot_1
        end
        ::p86::
        a = upvalues[0];
        slot_1 = a[2][a[1]]["moving"]
        if not slot_1 then
            goto p84
        end
        goto p19
    end
end
