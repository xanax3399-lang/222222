-- Recovered function f283; author names are unavailable.
F.f283 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f283")
        tick(1)
        goto p165
        ::p2::
        tick(2)
        if registers[14] ~= "bomb_planting" then
            goto p149
        end
        goto p145
        ::p4::
        tick(4)
        registers[19] = upvalues[1][136]
        registers[20] = registers[7]
        registers[21] = registers[18]
        m, x = pack_returns(registers[19](unpack_range(21, registers, 20)))
        z = 0
        for f = 19, 20 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[21] = upvalues[1][154]
        registers[22] = registers[20]
        if registers[22] then
            goto p127
        end
        goto p68
        ::p13::
        tick(13)
        registers[14] = registers[14] + 0.5;
        registers[(13)] = registers[(13)](registers[14])
        registers[13] = (registers[2] - registers[13])
        registers[14] = registers[1]["kind"]
        goto p84
        ::p19::
        tick(19)
        registers[24] = upvalues[0]["get_text_offset"]
        registers[25] = registers[14]
        registers[26] = registers[23]
        registers[27] = registers[6]
        goto p175
        ::p33::
        tick(33)
        branch_taken = false
        if registers[10] ~= false then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p288
        end
        goto p206
        ::p36::
        tick(36)
        registers[18] = ""
        goto p4
        ::p38::
        tick(38)
        registers[18] = (registers[5] - registers[15])
        registers[18] = (registers[18] * 0.5)
        registers[18] = registers[18] + 0.5
        goto p195
        ::p42::
        tick(42)
        registers[29] = upvalues[1][131]
        registers[30] = registers[24]
        registers[31] = registers[21]
        goto p264
        ::p47::
        tick(47)
        registers[13] = upvalues[1][154]
        registers[14] = upvalues[0]["px"]
        registers[15] = (26)
        registers[16] = registers[6]
        registers[14] = registers[14](registers[15], registers[16])
        registers[14] = registers[14] * registers[12]
        goto p13
        ::p54::
        tick(54)
        registers[28] = upvalues[2]["clamp"]
        registers[29] = registers[1]["a"]
        if registers[29] then
            goto p248
        end
        goto p125
        ::p59::
        tick(59)
        branch_taken = false
        if registers[14] ~= "bomb" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        goto p218
        ::p62::
        tick(62)
        if not registers[23] then
            goto p19
        end
        goto p225
        ::p66::
        tick(66)
        branch_taken = false
        if registers[22] ~= false then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p42
        end
        goto p190
        ::p68::
        registers[22] = (8)
        goto p127
        ::p70::
        tick(70)
        if registers[14] ~= "fatal" then
            goto p59
        end
        goto p121
        ::p72::
        tick(72)
        if registers[18] then
            goto p4
        end
        goto p36
        ::p75::
        tick(75)
        if registers[14] ~= "hc" then
            goto p33
        end
        goto p239
        ::p84::
        registers[15] = upvalues[0]["get_icon_size"]
        registers[16] = registers[14]
        registers[17] = registers[6]
        goto p157
        ::p97::
        tick(97)
        registers[12] = upvalues[0]["get_animation_slide"]
        registers[13] = registers[1]["key"];
        registers[(12)] = registers[(12)](registers[13])
        goto p47
        ::p103::
        tick(103)
        registers[36] = registers[26]
        registers[37] = registers[27]
        registers[38] = registers[28]
        registers[39] = "f"
        goto p221
        ::p115::
        tick(115)
        registers[27] = (210)
        registers[26] = (220)
        registers[25] = (230)
        goto p33
        ::p119::
        tick(119)
        registers[25] = (255)
        goto p312
        ::p121::
        registers[27] = (55)
        registers[26] = (45)
        registers[25] = (220)
        goto p33
        ::p125::
        registers[29] = (255)
        goto p248
        ::p127::
        registers[22] = (registers[5] - registers[22])
        registers[22] = (registers[22] * 0.5)
        registers[22] = registers[22] + 0.5
        goto p272
        ::p132::
        tick(132)
        registers[27] = (255)
        goto p54
        ::p134::
        tick(134)
        registers[26] = (255)
        ::p138::
        tick(138)
        registers[27] = registers[1]["b"]
        if registers[27] then
            goto p54
        end
        goto p132
        ::p141::
        tick(141)
        registers[33] = registers[15]
        registers[34] = registers[15]
        registers[35] = registers[25]
        goto p103
        ::p145::
        tick(145)
        registers[27] = (115)
        registers[26] = (105)
        registers[25] = (225)
        goto p33
        ::p149::
        if registers[14] ~= "bomb_hp" then
            goto p75
        end
        goto p115
        ::p157::
        registers[15] = registers[15](registers[16], registers[17])
        registers[16] = upvalues[0]["get_icon_offset"]
        registers[17] = registers[14]
        registers[18] = registers[6]
        registers[16] = registers[16](registers[17], registers[18])
        registers[16] = registers[13] + registers[16]
        registers[17] = upvalues[1][154]
        goto p38
        ::p165::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = a[6]
        registers[7] = a[7]
        registers[8] = a[8]
        registers[9] = a[9]
        registers[10] = a[10]
        registers[11] = registers[8]
        if registers[11] then
            goto p203
        end
        goto p186
        ::p175::;
        registers[24] = registers[24](unpack_range(27, registers, 25))
        registers[24] = registers[13] + registers[24]
        registers[25] = registers[1]["r"]
        goto p269
        ::p186::
        registers[11] = upvalues[0]["get_animation_alpha"]
        registers[12] = registers[1]["key"];
        registers[(11)] = registers[(11)](registers[12])
        goto p203
        ::p190::
        registers[29] = upvalues[1][139]
        registers[30] = registers[22]
        registers[31] = registers[16]
        registers[32] = registers[17]
        goto p141
        ::p195::;
        registers[(17)] = registers[(17)](registers[18])
        registers[17] = registers[3] + registers[17]
        registers[18] = registers[1]["text"]
        goto p72
        ::p199::
        tick(199)
        registers[24] = registers[15]
        registers[22] = registers[22](registers[23], registers[24])
        registers[23] = (registers[22] ~= registers[0])
        goto p62
        ::p203::
        registers[12] = registers[9]
        if registers[12] then
            goto p47
        end
        goto p97
        ::p206::
        registers[29] = upvalues[0]["draw_row_background"]
        registers[30] = registers[13]
        registers[31] = registers[3]
        registers[32] = registers[4]
        goto p284
        ::p218::
        branch_taken = false
        if registers[14] ~= "planted_bomb" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p145
        end
        goto p2
        ::p221::
        registers[(29)](unpack_range(39, registers, 30))
        goto p42
        ::p225::
        registers[23] = (registers[22] ~= false)
        goto p19
        ::p236::
        tick(236)
        registers[38] = registers[18]
        registers[(29)](unpack_range(38, registers, 30))
        do
            return 
        end
        ::p239::
        registers[27] = (220)
        registers[26] = (220)
        registers[25] = (220)
        goto p33
        ::p248::
        registers[30] = (0)
        registers[31] = (255);
        registers[28] = registers[28](unpack_range(31, registers, 29))
        goto p70
        ::p264::
        registers[32] = registers[25]
        registers[33] = registers[26]
        registers[34] = registers[27]
        goto p290
        ::p269::
        if registers[25] then
            goto p312
        end
        goto p119
        ::p272::;
        registers[(21)] = registers[(21)](registers[22])
        registers[21] = registers[3] + registers[21]
        registers[22] = upvalues[0]["get_texture"]
        registers[23] = registers[14]
        goto p199
        ::p284::
        registers[33] = registers[5]
        registers[34] = registers[11]
        registers[(29)](unpack_range(34, registers, 30))
        ::p288::
        if registers[22] == registers[0] then
            goto p42
        end
        goto p66
        ::p290::
        registers[35] = registers[28]
        registers[36] = registers[7]
        registers[37] = (0)
        goto p236
        ::p312::
        registers[26] = registers[1]["g"]
        if registers[26] then
            goto p138
        end
        goto p134
    end
end
