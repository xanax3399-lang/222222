-- Recovered function f199; author names are unavailable.
F.f199 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f199")
        tick(1)
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["ping"]
        registers[1] = registers[1][1]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if not registers[1] then
            goto p38
        end
        goto p78
        ::p38::
        tick(38)
        do
            return registers[1]
        end
        ::p39::
        tick(39)
        registers[1] = registers[1]["hotkey"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        goto p38
        ::p78::
        registers[1] = upvalues[0]["visuals"]
        registers[1] = registers[1]["ping"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q[(1)]
        a[z] = q
        goto p39
    end
end
