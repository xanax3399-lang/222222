-- Recovered function f362; author names are unavailable.
F.f362 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f362")
        tick(1)
        slot_1 = upvalues[0]
        a = upvalues[1];
        slot_2 = a[2][a[1]]["switch_count"];
        slot_1 = slot_1(slot_2)
        a = upvalues[2];
        slot_2 = a[2][a[1]]["packets"]
        slot_2 = slot_2 + slot_1
        a = upvalues[1];
        a[2][a[1]]["next_switch_packet"] = slot_2
        a = upvalues[1];
        slot_2 = a[2][a[1]]["next_switch_packet"]
        upvalues[3]["delay_next_switch_packet"] = slot_2
        upvalues[3]["delay_packets"] = slot_1
        do
            return 
        end
    end
end
