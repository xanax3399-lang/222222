-- Recovered function f81; author names are unavailable.
F.f81 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f81")
        tick(1)
        registers[1] = environment["setfenv"]
        registers[2] = environment["rawget"]
        registers[3] = upvalues[0]["__index"]
        registers[4] = "tostring"
        registers[2] = registers[2](registers[3], registers[4])
        registers[3] = {
        }
        do
            return registers[(1)](unpack_range(3, registers, 2))
        end
    end
end
