-- Recovered function f307; author names are unavailable.
F.f307 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f307")
        tick(1)
        goto p51
        ::p2::
        tick(2)
        do
            return 
        end
        ::p36::
        tick(36)
        registers[4] = registers[3]["eye_angles_y"]
        registers[5] = registers[3]["goal_feet_yaw"]
        registers[6] = upvalues[1]["normalize"]
        registers[7] = (registers[4] - registers[5])
        registers[8] = -180
        registers[9] = (180)
        do
            return registers[(6)](unpack_range(9, registers, 7))
        end
        ::p43::
        tick(43)
        z = registers[2]
        registers[4] = z;
        registers[(3)] = z["get_anim_state"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] ~= registers[0] then
            goto p36
        end
        goto p65
        ::p51::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= registers[0] then
            goto p43
        end
        goto p2
        ::p65::
        do
            return 
        end
    end
end
