-- Recovered function f247; author names are unavailable.
F.f247 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f247")
        tick(1)
        goto p5
        ::p2::
        tick(2)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[2] = z;
            registers[3] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p31
        end
        goto p10
        ::p5::
        registers[1] = upvalues[0]["restore_all"]
        registers[(1)]()
        registers[1] = environment["pairs"]
        registers[2] = upvalues[0]["player_state"]
        goto p73
        ::p10::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[0]["latency_cache"]
        registers[1]["tick"] = -1
        goto p75
        ::p31::
        registers[3] = upvalues[0]["player_state"]
        registers[3][registers[2]] = registers[0]
        goto p2
        ::p73::
        m, x = pack_returns(registers[1](unpack_range(2, registers, 2)))
        z = 0
        for f = 1, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(1)]
        n = registers[2]
        U = registers[3]
        goto p2
        ::p75::
        registers[1] = upvalues[0]["latency_cache"]
        registers[1]["time"] = 0
        do
            return 
        end
    end
end
