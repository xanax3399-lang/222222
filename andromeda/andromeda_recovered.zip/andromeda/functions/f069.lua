-- Recovered function f69; author names are unavailable.
F.f69 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f69")
        tick(1)
        goto p26
        ::p9::
        tick(9)
        slot_5 = slot_1 % 16
        slot_6 = slot_2 % 16
        slot_7 = upvalues[0][slot_5]
        slot_7 = slot_7[slot_6]
        goto p66
        ::p15::
        tick(15)
        if not (0 < slot_2) then
            goto p30
        end
        goto p9
        ::p22::
        tick(22)
        slot_3 = (slot_3 * 16)
        ::p24::
        tick(24)
        if not (0 < slot_1) then
            goto p30
        end
        goto p15
        ::p26::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p24
        ::p30::
        slot_5 = slot_1 * slot_3
        slot_5 = slot_4 + slot_5
        slot_6 = slot_2 * slot_3
        goto p73
        ::p66::
        slot_7 = slot_7 * slot_3
        slot_4 = slot_4 + slot_7
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 16
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 16
        goto p22
        ::p73::
        slot_5 = slot_5 + slot_6
        do
            return slot_5
        end
    end
end
