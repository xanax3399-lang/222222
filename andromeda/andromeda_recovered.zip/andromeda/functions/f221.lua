-- Recovered function f221; author names are unavailable.
F.f221 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f221")
        tick(1)
        goto p28
        ::p16::
        tick(16)
        slot_5["order"] = slot_7
        slot_5["sequence"] = slot_4
        slot_7 = upvalues[1]["get_animation_key"]
        goto p210
        ::p28::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]["skip_native_cleanup"];
        slot_2 = slot_2()
        if not slot_2 then
            goto p76
        end
        goto p79
        ::p33::
        tick(33)
        slot_5 = slot_3
        goto p88
        ::p42::
        tick(42)
        slot_4(slot_5)
        slot_4 = upvalues[1]["capture_count"]
        slot_5 = upvalues[1]["max_items"]
        goto p191
        ::p46::
        tick(46)
        slot_7 = (255)
        goto p123
        ::p49::
        tick(49)
        if slot_2 then
            goto p144
        end
        goto p180
        ::p74::
        tick(74)
        if slot_5 ~= slot_0 then
            goto p108
        end
        goto p146
        ::p76::
        slot_2 = upvalues[1]["active"]
        if slot_2 then
            goto p205
        end
        goto p143
        ::p79::
        slot_2 = (true)
        do
            return slot_2
        end
        ::p88::
        tick(88)
        if slot_5 then
            goto p42
        end
        goto p208
        ::p91::
        tick(91)
        slot_3 = upvalues[2][29];
        slot_3 = slot_3()
        slot_4 = upvalues[1]["begin_capture_frame"]
        slot_5 = environment["type"]
        slot_6 = slot_3;
        slot_5 = slot_5(slot_6)
        slot_5 = (slot_5 == "number")
        if not slot_5 then
            goto p88
        end
        goto p33
        ::p100::
        tick(100)
        slot_4 = (true)
        do
            return slot_4
        end
        ::p102::
        tick(102)
        slot_4 = upvalues[1]["capture_count"]
        slot_4 = slot_4 + 1
        slot_5 = upvalues[1]["capture_items"]
        slot_5 = slot_5[slot_4]
        goto p74
        ::p108::
        tick(108)
        slot_6 = environment["tostring"]
        slot_7 = slot_2;
        slot_6 = slot_6(slot_7)
        slot_7 = slot_1["r"]
        if slot_7 then
            goto p199
        end
        goto p128
        ::p123::
        tick(123)
        slot_5["a"] = slot_7
        slot_7 = upvalues[1]["classify"]
        slot_8 = slot_6
        goto p131
        ::p128::
        slot_7 = (255)
        goto p199
        ::p131::;
        slot_7 = slot_7(slot_8)
        slot_5["kind"] = slot_7
        slot_7 = upvalues[1]["normalize_text"]
        slot_8 = slot_5["kind"]
        slot_9 = slot_6
        slot_7 = slot_7(slot_8, slot_9)
        slot_5["text"] = slot_7
        slot_7 = upvalues[1]["get_order"]
        slot_8 = slot_5["kind"]
        slot_9 = slot_5["text"]
        slot_7 = slot_7(slot_8, slot_9)
        goto p16
        ::p143::
        do
            return 
        end
        ::p144::
        tick(144)
        if slot_2 ~= slot_0 then
            goto p91
        end
        goto p172
        ::p146::
        slot_6 = {
        }
        slot_5 = slot_6
        slot_6 = upvalues[1]["capture_items"]
        goto p226
        ::p158::
        tick(158)
        slot_7 = (255)
        goto p228
        ::p163::
        tick(163)
        slot_2 = slot_1["text"]
        goto p49
        ::p172::
        slot_3 = (true)
        do
            return slot_3
        end
        ::p174::
        tick(174)
        upvalues[1]["capture_count"] = slot_4
        slot_7 = upvalues[2][30];
        slot_7 = slot_7()
        upvalues[1]["last_capture_time"] = slot_7
        goto p189
        ::p180::
        slot_2 = nil
        goto p144
        ::p182::
        tick(182)
        slot_5["g"] = slot_7
        slot_7 = slot_1["b"]
        if slot_7 then
            goto p228
        end
        goto p158
        ::p186::
        tick(186)
        slot_7 = (255)
        goto p182
        ::p189::
        slot_7 = (true)
        do
            return slot_7
        end
        ::p191::
        branch_taken = false
        if not (not (slot_5 <= slot_4)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p102
        end
        goto p100
        ::p199::
        slot_5["r"] = slot_7
        slot_7 = slot_1["g"]
        if slot_7 then
            goto p182
        end
        goto p186
        ::p205::
        slot_2 = (slot_1 ~= slot_0)
        if not slot_2 then
            goto p49
        end
        goto p163
        ::p208::
        slot_5 = (0)
        goto p42
        ::p210::
        slot_8 = slot_5["kind"]
        slot_9 = slot_5["text"]
        slot_7 = slot_7(slot_8, slot_9)
        slot_5["key"] = slot_7
        goto p174
        ::p226::
        slot_6[slot_4] = slot_5
        goto p108
        ::p228::
        slot_5["b"] = slot_7
        slot_7 = slot_1["a"]
        if slot_7 then
            goto p123
        end
        goto p46
    end
end
