-- Recovered function f437; author names are unavailable.
F.f437 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f437")
        tick(1)
        goto p23
        ::p3::
        tick(3)
        slot_2 = ""
        ::p6::
        tick(6)
        do
            return slot_2
        end
        ::p17::
        tick(17)
        slot_2 = ""
        do
            return slot_2
        end
        ::p23::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        branch_taken = false
        if slot_2 ~= "string" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p52
        end
        goto p17
        ::p52::
        z = slot_1
        slot_3 = z;
        slot_2 = z["match"]
        slot_4 = "^%s*(.-)%s*$"
        slot_2 = slot_2(slot_3, slot_4)
        if slot_2 then
            goto p6
        end
        goto p3
    end
end
