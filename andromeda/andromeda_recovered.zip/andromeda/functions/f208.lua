-- Recovered function f208; author names are unavailable.
F.f208 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f208")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        z = slot_1
        slot_3 = z;
        slot_2 = z["set_visible"]
        slot_4 = (false);
        slot_2(slot_3, slot_4)
        do
            return 
        end
    end
end
