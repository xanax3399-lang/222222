-- Recovered function f168; author names are unavailable.
F.f168 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f168")
        tick(1)
        registers[1] = environment["pairs"]
        registers[2] = upvalues[0]["shifted_players"]
        m, x = pack_returns(registers[1](unpack_range(2, registers, 2)))
        z = 0
        for f = 1, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p15
        ::p7::
        tick(7)
        registers[4] = upvalues[1][36]
        registers[5] = registers[2]
        registers[6] = "m_vecOrigin"
        registers[7] = registers[3]["x"]
        registers[8] = registers[3]["y"]
        registers[9] = registers[3]["z"]
        registers[(4)](unpack_range(9, registers, 5))
        goto p27
        ::p15::
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(1)]
        n = registers[2]
        U = registers[3]
        goto p44
        goto p44
        ::p27::
        tick(27)
        registers[4] = upvalues[0]["shifted_players"]
        registers[4][registers[2]] = registers[0]
        goto p44
        ::p31::
        tick(31)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p44::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[2] = z;
            registers[3] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p46
        end
        goto p31
        ::p46::
        registers[4] = upvalues[1][50]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        if not registers[4] then
            goto p27
        end
        goto p7
    end
end
