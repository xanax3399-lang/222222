-- Recovered function f335; author names are unavailable.
F.f335 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f335")
        tick(1)
        goto p115
        ::p3::
        tick(3)
        registers[11] = registers[3];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] then
            goto p261
        end
        goto p346
        ::p9::
        tick(9);
        registers[(9)] = registers[(9)](registers[10])
        registers[8] = registers[8] + registers[9]
        registers[7][registers[3]] = registers[8]
        goto p71
        ::p13::
        tick(13)
        registers[6] = (58)
        goto p378
        ::p16::
        tick(16)
        registers[4] = registers[4] + 1
        registers[5] = upvalues[3]["miss_counter"]
        registers[5][registers[3]] = registers[4]
        goto p312
        ::p20::
        tick(20)
        registers[3] = registers[1]["target"]
        goto p305
        ::p32::
        tick(32)
        registers[6] = registers[5]["stable_side"]
        registers[6] = registers[6] > 0
        if not registers[6] then
            goto p98
        end
        goto p327
        ::p37::
        tick(37)
        registers[2] = environment["tostring"]
        registers[3] = registers[1]["reason"]
        if registers[3] then
            goto p333
        end
        goto p183
        ::p47::
        tick(47)
        registers[6] = (4)
        goto p89
        ::p62::
        tick(62)
        do
            return 
        end
        ::p65::
        tick(65)
        registers[7] = upvalues[4]
        registers[8] = "Logging";
        registers[(7)] = registers[(7)](registers[8])
        if not registers[7] then
            goto p292
        end
        goto p147
        ::p71::
        registers[7] = upvalues[4]
        registers[8] = "Logging";
        registers[(7)] = registers[(7)](registers[8])
        goto p277
        ::p75::
        tick(75)
        registers[3] = registers[1]["target"]
        if registers[3] ~= registers[0] then
            goto p37
        end
        goto p326
        ::p85::
        tick(85)
        registers[5] = registers[5] + 1
        registers[6] = nil
        if not (0 < registers[4]) then
            goto p151
        end
        goto p355
        ::p89::
        tick(89)
        if registers[6] then
            goto p100
        end
        goto p322
        ::p92::
        tick(92)
        registers[11] = upvalues[3]["miss_counter"]
        registers[11] = registers[11][registers[3]]
        m, x = pack_returns(registers[8](unpack_range(11, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[7](unpack_range(top, registers, 8))
        goto p292
        ::p98::
        tick(98)
        if registers[6] then
            goto p120
        end
        goto p285
        ::p100::
        tick(100)
        registers[5]["negative_votes"] = registers[6]
        registers[6] = upvalues[1][162]
        registers[7] = registers[5]["jitter_ticks"]
        if registers[7] then
            goto p308
        end
        goto p194
        ::p105::
        tick(105)
        if registers[2] ~= true then
            goto p326
        end
        goto p348
        ::p113::
        tick(113)
        registers[6] = registers[5]["last_side"]
        goto p338
        ::p115::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        goto p105
        ::p120::
        tick(120)
        registers[5]["positive_votes"] = registers[6]
        registers[6] = registers[5]["stable_side"]
        registers[6] = (registers[6] < 0)
        goto p238
        ::p124::
        tick(124)
        registers[4] = (0)
        goto p224
        ::p126::
        tick(126)
        registers[9] = "[Andromeda] Custom resolver miss adapt: %s -> phase %d"
        registers[10] = upvalues[1][43]
        registers[11] = registers[3];
        registers[(10)] = registers[(10)](registers[11])
        if registers[10] then
            goto p92
        end
        goto p236
        ::p132::
        tick(132)
        registers[4] = upvalues[1][33]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p302
        ::p147::
        registers[7] = upvalues[1][70]
        registers[8] = environment["string"]
        registers[8] = registers[8]["format"]
        goto p126
        ::p151::
        branch_taken = false
        if not (not (registers[4] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p179
        end
        goto p351
        ::p153::
        tick(153)
        registers[4] = upvalues[3]["wraith"]
        registers[4] = registers[4]["last_value"]
        registers[4] = registers[4][registers[3]]
        if registers[4] then
            goto p224
        end
        goto p124
        ::p160::
        tick(160)
        registers[5]["jitter_ticks"] = registers[6]
        goto p169
        ::p167::
        tick(167)
        branch_taken = false
        if registers[2] ~= "resolver" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p256
        end
        goto p321
        ::p169::
        tick(169)
        registers[6] = upvalues[1][162]
        registers[7] = (registers[4] - 1)
        registers[7] = (registers[7] * 0.18)
        registers[8] = (0.75)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = 0.85 + registers[6]
        registers[7] = upvalues[3]["correction_until"]
        registers[8] = upvalues[1][23];
        registers[8] = registers[8]()
        goto p185
        ::p179::
        registers[7] = registers[5] % 2
        if registers[7] ~= 0 then
            goto p13
        end
        goto p200
        ::p183::
        registers[3] = "?"
        goto p333
        ::p185::
        registers[9] = upvalues[1][154]
        registers[10] = upvalues[1][28];
        registers[10] = registers[10]()
        goto p341
        ::p189::
        tick(189)
        registers[6] = -registers[6]
        registers[5]["stable_side"] = registers[6]
        registers[6] = registers[5]["stable_side"]
        registers[5]["last_side"] = registers[6]
        goto p32
        ::p194::
        registers[7] = (0)
        goto p308
        ::p196::
        tick(196)
        registers[4] = upvalues[2];
        registers[4] = registers[4]()
        if registers[4] ~= "Auto" then
            goto p287
        end
        goto p153
        ::p200::
        registers[6] = -58
        goto p378
        ::p204::
        tick(204)
        registers[7][registers[3]] = registers[6]
        registers[7] = upvalues[3]["wraith"]
        registers[7] = registers[7]["miss_until"]
        goto p293
        ::p220::
        tick(220)
        registers[11] = upvalues[1][28];
        registers[11] = registers[11]()
        registers[10] = (registers[10] / registers[11])
        goto p9
        ::p224::
        registers[5] = upvalues[3]["wraith"]
        registers[5] = registers[5]["misses"]
        registers[5] = registers[5][registers[3]]
        if registers[5] then
            goto p85
        end
        goto p267
        ::p236::
        registers[10] = registers[3]
        goto p92
        ::p238::
        if not registers[6] then
            goto p89
        end
        goto p47
        ::p250::
        tick(250)
        registers[7] = upvalues[1][70]
        registers[8] = environment["string"]
        registers[8] = registers[8]["format"]
        registers[9] = "[Andromeda] Auto resolver adapt: %s -> %d"
        registers[10] = upvalues[1][43]
        goto p3
        ::p256::
        tick(256)
        registers[3] = environment["tonumber"]
        registers[4] = registers[1]["target"];
        registers[(3)] = registers[(3)](registers[4])
        if registers[3] then
            goto p305
        end
        goto p20
        ::p261::
        tick(261)
        registers[11] = registers[6]
        m, x = pack_returns(registers[8](unpack_range(11, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[7](unpack_range(top, registers, 8))
        goto p284
        ::p267::
        registers[5] = (0)
        goto p85
        ::p277::
        if not registers[7] then
            goto p284
        end
        goto p250
        ::p284::
        do
            return 
        end
        ::p285::
        registers[6] = (0)
        goto p120
        ::p287::
        registers[4] = upvalues[3]["miss_counter"]
        registers[4] = registers[4][registers[3]]
        if registers[4] then
            goto p317
        end
        goto p324
        ::p292::
        do
            return 
        end
        ::p293::
        registers[8] = upvalues[1][23];
        registers[8] = registers[8]()
        registers[9] = upvalues[1][154]
        registers[10] = upvalues[1][162]
        registers[11] = (registers[5] * 0.12)
        registers[12] = (0.55)
        registers[10] = registers[10](registers[11], registers[12])
        registers[10] = 0.9 + registers[10]
        goto p220
        ::p302::
        branch_taken = false
        if registers[4] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p196
        end
        goto p62
        ::p305::
        if registers[3] == registers[0] then
            goto p62
        end
        goto p132
        ::p308::
        registers[7] = registers[7] + 4
        registers[8] = (12)
        registers[6] = registers[6](registers[7], registers[8])
        goto p160
        ::p312::
        registers[5] = upvalues[3]["records"]
        registers[5] = registers[5][registers[3]]
        if registers[5] == registers[0] then
            goto p169
        end
        goto p329
        ::p317::
        tick(317)
        registers[5] = upvalues[5]
        registers[5] = (#registers[5])
        registers[4] = registers[4] % registers[5]
        goto p16
        ::p321::
        do
            return 
        end
        ::p322::
        registers[6] = (0)
        goto p100
        ::p324::
        registers[4] = (1)
        goto p317
        ::p326::
        tick(326)
        do
            return 
        end
        ::p327::
        registers[6] = (4)
        goto p98
        ::p329::
        registers[6] = registers[5]["stable_side"]
        if registers[6] then
            goto p338
        end
        goto p113
        ::p333::;
        registers[(2)] = registers[(2)](registers[3])
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["lower"];
        registers[(2)] = registers[(2)](registers[3])
        branch_taken = false
        if registers[2] ~= "?" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p256
        end
        goto p167
        ::p338::
        if registers[6] then
            goto p189
        end
        goto p353
        ::p341::
        registers[10] = (registers[6] / registers[10]);
        registers[(9)] = registers[(9)](registers[10])
        registers[8] = registers[8] + registers[9]
        registers[7][registers[3]] = registers[8]
        goto p65
        ::p346::
        registers[10] = registers[3]
        goto p261
        ::p348::
        if registers[1] == registers[0] then
            goto p326
        end
        goto p75
        ::p351::
        registers[6] = (58)
        goto p378
        ::p353::
        registers[6] = (1)
        goto p189
        ::p355::
        registers[6] = -58
        ::p378::
        registers[7] = upvalues[3]["wraith"]
        registers[7] = registers[7]["misses"]
        registers[7][registers[3]] = registers[5]
        registers[7] = upvalues[3]["wraith"]
        registers[7] = registers[7]["miss_side"]
        goto p204
    end
end
