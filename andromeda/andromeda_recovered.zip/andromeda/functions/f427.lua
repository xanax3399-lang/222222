-- Recovered function f427; author names are unavailable.
F.f427 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f427")
        tick(1)
        goto p34
        ::p2::
        tick(2)
        do
            return slot_1
        end
        ::p34::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["body_aim"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        slot_1 = (slot_1 == true)
        goto p2
    end
end
