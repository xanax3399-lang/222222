-- Recovered function f493; author names are unavailable.
F.f493 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, S, z, a = 0, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f493")
        tick(1)
        goto p39
        ::p11::
        tick(11)
        registers[6] = registers[7]
        registers[7] = registers[1]["defensive_yaw_double_states"]
        registers[7] = registers[7][registers[5]]
        goto p302
        ::p18::
        tick(18)
        registers[15] = registers[7]["side"]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[15]
        end
        ::p21::
        tick(21)
        registers[13] = registers[1]["body_yaw"]
        registers[13] = registers[13]["inverter"]
        registers[13] = (registers[13] == true)
        registers[7]["side"] = registers[13]
        registers[13] = registers[1]["body_yaw"]
        registers[14] = registers[7]["side"]
        goto p104
        ::p35::
        tick(35)
        registers[15] = registers[1]["body_yaw"]
        registers[16] = registers[7]["side"]
        registers[16] = (registers[16] == true)
        goto p238
        ::p39::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = registers[3]
        if registers[5] then
            goto p98
        end
        a = upvalues[0];
        registers[5] = a[2][a[1]]["current"]
        goto p98
        ::p54::
        tick(54)
        registers[15] = registers[1]["body_yaw"]
        registers[16] = registers[7]["side"]
        registers[16] = (registers[16] == true)
        goto p314
        ::p59::
        tick(59)
        registers[9] = (1)
        goto p242
        ::p68::
        tick(68)
        a = upvalues[4];
        registers[13] = a[2][a[1]]["exploits"]
        registers[13] = registers[13]["charged"]
        registers[13] = (registers[13] == true)
        if not registers[13] then
            goto p163
        end
        goto p224
        ::p75::
        tick(75)
        a = upvalues[4];
        registers[10] = a[2][a[1]]["exploits"]
        registers[10] = registers[10]["charged"]
        registers[10] = (registers[10] == true)
        goto p100
        ::p95::
        tick(95)
        registers[13] = (0)
        goto p269
        ::p98::
        if registers[5] then
            goto p325
        end
        goto p281
        ::p100::
        tick(100)
        registers[11] = registers[7]["last_exploit_key_active"]
        registers[11] = (registers[11] ~= registers[0])
        if not registers[11] then
            goto p341
        end
        goto p292
        ::p104::
        registers[14] = (registers[14] == true)
        registers[13]["inverter"] = registers[14]
        registers[13] = registers[7]["switch_count"]
        if registers[13] then
            goto p269
        end
        goto p95
        ::p115::
        tick(115)
        registers[15] = registers[2]["chokedcommands"]
        branch_taken = false
        if registers[15] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p127
        end
        goto p319
        ::p123::
        tick(123)
        registers[15] = registers[1]["body_yaw"]
        registers[15] = registers[15]["inverter"]
        registers[15] = (registers[15] == true)
        goto p207
        ::p127::
        tick(127)
        registers[15] = registers[7]["next_switch_packet"]
        if registers[15] ~= registers[0] then
            goto p250
        end
        goto p289
        ::p130::
        tick(130)
        registers[7]["signature"] = registers[12]
        registers[7]["switch_count"] = 0
        registers[15] = registers[1]["body_yaw"]
        registers[15] = registers[15]["inverter"]
        registers[15] = (registers[15] == true)
        registers[7]["side"] = registers[15]
        goto p54
        ::p157::
        tick(157)
        registers[11] = registers[7]["last_exploit_charged"]
        registers[11] = (registers[11] ~= registers[10])
        goto p341
        ::p160::
        tick(160)
        registers[10] = registers[9]
        if not registers[10] then
            goto p100
        end
        goto p75
        ::p163::
        tick(163)
        registers[14] = upvalues[5]["ragebot"]
        registers[14] = registers[14]["double_tap_fl"]
        z = registers[14]
        registers[15] = z;
        registers[(14)] = z["get"];
        registers[(14)] = registers[(14)](registers[15])
        if not registers[13] then
            goto p266
        end
        goto p307
        ::p175::
        tick(175)
        if registers[9] then
            goto p160
        end
        goto p191
        ::p187::
        tick(187)
        registers[15] = registers[7]["switch_count"]
        registers[15] = registers[15] + 1
        registers[7]["switch_count"] = registers[15]
        goto p247
        ::p191::
        registers[9] = upvalues[5]["is_on_shot_antiaim"]
        registers[10] = "no dt";
        registers[(9)] = registers[(9)](registers[10])
        goto p160
        ::p195::
        tick(195)
        registers[8]["signature"] = registers[0]
        registers[8]["last_exploit_key_active"] = registers[0]
        registers[8]["last_exploit_charged"] = registers[0]
        registers[7] = registers[8]
        registers[8] = registers[1]["defensive_yaw_double_states"]
        registers[8][registers[5]] = registers[7]
        ::p202::
        tick(202)
        a = D.f494
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[8] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[9] = upvalues[5]["is_double_tap"]
        registers[10] = "key";
        registers[(9)] = registers[(9)](registers[10])
        goto p175
        ::p207::
        registers[7]["side"] = registers[15]
        a = upvalues[4];
        registers[15] = a[2][a[1]]["packets"]
        registers[15] = registers[15] + 1
        registers[7]["next_switch_packet"] = registers[15]
        registers[7]["signature"] = registers[0]
        goto p18
        ::p214::
        tick(214)
        if registers[2] == registers[0] then
            goto p127
        end
        goto p115
        ::p217::
        tick(217)
        registers[13] = registers[7]["side"]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[13]
        end
        ::p219::
        tick(219)
        registers[15] = registers[1]["body_yaw"]
        registers[16] = registers[7]["side"]
        registers[16] = (registers[16] == true)
        registers[15]["inverter"] = registers[16]
        goto p187
        ::p224::
        registers[13] = upvalues[5]["is_double_tap"];
        registers[13] = registers[13]()
        if registers[13] then
            goto p163
        end
        goto p310
        ::p234::
        tick(234)
        registers[15] = registers[7]["side"]
        registers[15] = not registers[15]
        registers[7]["side"] = registers[15]
        goto p219
        ::p238::
        registers[15]["inverter"] = registers[16]
        registers[15] = registers[7]["side"]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[15]
        end
        ::p242::
        tick(242);
        registers[(8)] = registers[(8)](registers[9])
        registers[9] = (1)
        registers[10] = (16);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        goto p11
        ::p247::
        registers[15] = registers[8]
        registers[(15)]()
        goto p35
        ::p250::
        tick(250)
        a = upvalues[4];
        registers[15] = a[2][a[1]]["packets"]
        registers[16] = registers[7]["next_switch_packet"]
        branch_taken = false
        if not (not (registers[16] <= registers[15])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p35
        end
        goto p234
        ::p254::
        tick(254)
        registers[8] = {
        }
        registers[9] = registers[1]["body_yaw"]
        registers[9] = registers[9]["inverter"]
        registers[9] = (registers[9] == true)
        registers[8]["side"] = registers[9]
        a = upvalues[4];
        registers[9] = a[2][a[1]]["packets"]
        registers[9] = registers[9] + 1
        registers[8]["next_switch_packet"] = registers[9]
        registers[8]["switch_count"] = 0
        goto p195
        ::p266::
        tick(266)
        registers[15] = registers[7]["signature"]
        if registers[15] == registers[12] then
            goto p214
        end
        goto p130
        ::p269::
        registers[7]["switch_count"] = registers[13]
        registers[13] = registers[8]
        registers[(13)]()
        goto p217
        ::p281::
        registers[5] = upvalues[1][1]
        goto p325
        ::p289::
        registers[15] = registers[8]
        registers[(15)]()
        goto p250
        ::p292::
        registers[11] = registers[7]["last_exploit_key_active"]
        registers[11] = (registers[11] ~= registers[9])
        if registers[11] then
            goto p341
        end
        goto p157
        ::p302::
        if registers[7] ~= registers[0] then
            goto p202
        end
        goto p254
        ::p304::
        tick(304)
        registers[15] = registers[7]["side"]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[15]
        end
        ::p307::
        a = upvalues[4];
        registers[15] = a[2][a[1]]["fakelag"]
        if not (registers[14] < registers[15]) then
            goto p266
        end
        goto p123
        ::p310::
        registers[13] = upvalues[5]["is_on_shot_antiaim"];
        registers[13] = registers[13]()
        goto p163
        ::p314::
        registers[15]["inverter"] = registers[16]
        registers[15] = registers[8]
        registers[(15)]()
        goto p304
        ::p319::
        registers[15] = registers[1]["body_yaw"]
        registers[16] = registers[7]["side"]
        registers[16] = (registers[16] == true)
        registers[15]["inverter"] = registers[16]
        registers[15] = registers[7]["side"]
        do
            if not N then

            else
                for T, environment, W in next, N do
                    if not (T >= 1) then

                    else
                        environment[2] = environment;
                        environment[3] = registers[T];
                        environment[1] = (3)
                        N[T] = nil
                    end
                end
            end
            return registers[15]
        end
        ::p325::
        registers[6] = registers[4]["def_yaw_delay"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"];
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = upvalues[2]["clamp"]
        registers[8] = upvalues[3][154]
        registers[9] = registers[6]
        if registers[9] then
            goto p242
        end
        goto p59
        ::p341::
        registers[12] = environment["tostring"]
        registers[13] = registers[6];
        registers[(12)] = registers[(12)](registers[13])
        registers[7]["last_exploit_key_active"] = registers[9]
        registers[7]["last_exploit_charged"] = registers[10]
        if not registers[11] then
            goto p68
        end
        goto p21
    end
end
