-- Recovered function f409; author names are unavailable.
F.f409 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f409")
        tick(1)
        goto p38
        ::p8::
        tick(8)
        registers[2] = registers[2](registers[3], registers[4])
        registers[3] = environment["type"]
        registers[4] = registers[2]
        goto p51
        ::p19::
        tick(19)
        registers[3] = (0)
        do
            return registers[3]
        end
        ::p22::
        tick(22)
        registers[3] = upvalues[0][151]
        registers[4] = (0)
        registers[5] = registers[2]
        do
            return registers[(3)](unpack_range(5, registers, 4))
        end
        ::p38::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][47]
        registers[3] = registers[1]
        registers[4] = "m_iHealth"
        goto p8
        ::p51::;
        registers[(3)] = registers[(3)](registers[4])
        branch_taken = false
        if registers[3] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p22
        end
        goto p19
    end
end
