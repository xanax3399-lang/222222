-- Recovered function f124; author names are unavailable.
F.f124 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f124")
        tick(1)
        goto p17
        ::p3::
        tick(3)
        registers[9] = registers[1]["segments"]
        registers[9] = registers[9][registers[8]]
        registers[10] = upvalues[0][136]
        goto p60
        ::p7::
        tick(7)
        registers[5] = (1)
        registers[6] = registers[1]["segments"]
        registers[6] = (#registers[6])
        registers[7] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[7] + 0
        n = (registers[6] + 0)
        v = (registers[5] - U)
        goto p55
        ::p12::
        tick(12)
        registers[3] = registers[3] + registers[12]
        registers[12] = upvalues[0][151]
        registers[13] = registers[4]
        goto p57
        ::p17::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = (0)
        registers[4] = (0)
        goto p7
        ::p55::
        tick(55)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[8] = v
            branch_taken = true
        end
        if branch_taken then
            goto p3
        end
        goto p87
        ::p57::
        registers[14] = registers[11]
        if registers[14] then
            goto p66
        end
        goto p77
        ::p60::
        registers[11] = registers[2]
        registers[12] = registers[9][1]
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        z = 0
        for f = 10, 11 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[10]
        if registers[12] then
            goto p12
        end
        goto p80
        ::p66::
        tick(66)
        registers[12] = registers[12](registers[13], registers[14])
        registers[4] = registers[12]
        goto p55
        ::p77::
        registers[14] = (0)
        goto p66
        ::p80::
        registers[12] = (0)
        goto p12
        ::p87::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[5] = registers[3]
        registers[6] = registers[4]
        do
            return unpack_range(6, registers, (5))
        end
    end
end
