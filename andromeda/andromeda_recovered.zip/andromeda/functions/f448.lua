-- Recovered function f448; author names are unavailable.
F.f448 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f448")
        tick(1)
        goto p3
        ::p2::
        tick(2)
        do
            return slot_2
        end
        ::p3::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = (slot_1 == "Double")
        if slot_2 then
            goto p2
        end
        slot_2 = (slot_1 == "Left ~ Right")
        goto p2
    end
end
