-- Recovered function f245; author names are unavailable.
F.f245 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f245")
        tick(1)
        goto p34
        ::p10::
        tick(10);
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] == "table")
        if not registers[4] then
            goto p111
        end
        goto p54
        ::p21::
        tick(21)
        registers[6] = environment["tonumber"]
        registers[7] = registers[2]["revision"];
        registers[(6)] = registers[(6)](registers[7])
        if registers[6] then
            goto p58
        end
        goto p48
        ::p26::
        tick(26)
        registers[6] = registers[2]
        registers[7] = (false)
        do
            return unpack_range(7, registers, (6))
        end
        ::p30::
        tick(30)
        registers[6] = {
        }
        registers[7] = (false)
        do
            return unpack_range(7, registers, (6))
        end
        ::p34::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][121]
        registers[3] = registers[1]["db"];
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = upvalues[0][121]
        registers[4] = registers[1]["backup_db"];
        registers[(3)] = registers[(3)](registers[4])
        registers[4] = environment["type"]
        registers[5] = registers[2];
        registers[(4)] = registers[(4)](registers[5])
        goto p107
        ::p45::
        tick(45)
        registers[8] = registers[3]
        registers[9] = (true)
        do
            return unpack_range(9, registers, (8))
        end
        ::p48::
        registers[6] = (0)
        goto p58
        ::p50::
        tick(50)
        registers[7] = (0)
        goto p92
        ::p54::
        if not registers[5] then
            goto p111
        end
        goto p21
        ::p56::
        tick(56)
        if not registers[5] then
            goto p30
        end
        goto p63
        ::p58::
        tick(58)
        registers[7] = environment["tonumber"]
        registers[8] = registers[3]["revision"];
        registers[(7)] = registers[(7)](registers[8])
        if registers[7] then
            goto p92
        end
        goto p50
        ::p63::
        registers[6] = registers[3]
        registers[7] = (true)
        do
            return unpack_range(7, registers, (6))
        end
        ::p77::
        tick(77)
        registers[8] = registers[2]
        registers[9] = (false)
        do
            return unpack_range(9, registers, (8))
        end
        ::p92::
        if not (registers[6] < registers[7]) then
            goto p77
        end
        goto p45
        ::p107::
        registers[4] = (registers[4] == "table")
        registers[5] = environment["type"]
        registers[6] = registers[3]
        goto p10
        ::p111::
        if not registers[4] then
            goto p56
        end
        goto p26
    end
end
