-- Recovered function f320; author names are unavailable.
F.f320 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f320")
        tick(1)
        goto p128
        ::p4::
        tick(4)
        registers[11] = registers[11] * registers[12]
        registers[11] = registers[11] + 0.5;
        registers[(10)] = registers[(10)](registers[11])
        registers[10] = (registers[2] - registers[10])
        goto p151
        ::p10::
        tick(10)
        if registers[17] then
            goto p68
        end
        goto p65
        ::p12::
        tick(12)
        registers[12] = (0)
        goto p4
        ::p20::
        tick(20)
        if registers[16] then
            goto p91
        end
        goto p147
        ::p23::
        tick(23)
        registers[14] = registers[10] + registers[14]
        registers[15] = upvalues[0][154]
        registers[16] = registers[13]
        goto p20
        ::p28::
        tick(28)
        registers[20] = upvalues[0][131]
        registers[21] = registers[14]
        registers[22] = registers[15]
        registers[23] = registers[17]
        goto p99
        ::p42::
        tick(42)
        registers[20] = registers[1]["kind"]
        if registers[20] ~= "fatal" then
            goto p28
        end
        goto p134
        ::p45::
        tick(45)
        if registers[12] then
            goto p4
        end
        goto p12
        ::p55::
        tick(55)
        registers[17] = (230)
        registers[18] = (220)
        registers[19] = (210)
        goto p42
        ::p59::
        tick(59)
        registers[15] = (registers[4] - registers[15])
        registers[15] = (registers[15] * 0.5)
        registers[15] = registers[15] + 0.5;
        registers[(14)] = registers[(14)](registers[15])
        goto p23
        ::p65::
        registers[17] = (255)
        ::p68::
        registers[18] = (0)
        registers[19] = (255);
        registers[16] = registers[16](unpack_range(19, registers, 17))
        goto p55
        ::p72::
        tick(72)
        registers[15] = (0)
        goto p59
        ::p74::
        tick(74)
        registers[12] = upvalues[0][136]
        registers[13] = registers[7]
        registers[14] = registers[11]
        m, x = pack_returns(registers[12](unpack_range(14, registers, 13)))
        z = 0
        for f = 12, 13 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = upvalues[0][154]
        registers[15] = registers[12]
        if registers[15] then
            goto p59
        end
        goto p72
        ::p91::
        tick(91)
        registers[16] = (registers[5] - registers[16])
        registers[16] = (registers[16] * 0.5)
        registers[16] = registers[16] + 0.5;
        registers[(15)] = registers[(15)](registers[16])
        registers[15] = registers[3] + registers[15]
        registers[16] = upvalues[2]["clamp"]
        registers[17] = registers[1]["a"]
        goto p10
        ::p99::
        registers[24] = registers[18]
        registers[25] = registers[19]
        registers[26] = registers[16]
        registers[27] = registers[7]
        registers[28] = (0)
        registers[29] = registers[11]
        registers[(20)](unpack_range(29, registers, 21))
        do
            return 
        end
        ::p124::
        tick(124)
        registers[13] = registers[6]
        registers[11] = registers[11](registers[12], registers[13])
        registers[12] = registers[9]
        goto p45
        ::p128::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = a[6]
        registers[7] = a[7]
        registers[8] = a[8]
        registers[9] = a[9]
        registers[10] = upvalues[0][154]
        registers[11] = upvalues[1]["px"]
        registers[12] = (26)
        goto p124
        ::p134::
        registers[19] = (55)
        registers[18] = (45)
        registers[17] = (220)
        goto p28
        ::p145::
        tick(145)
        registers[11] = ""
        goto p74
        ::p147::
        registers[16] = (8)
        goto p91
        ::p151::
        registers[11] = registers[1]["text"]
        if registers[11] then
            goto p74
        end
        goto p145
    end
end
