-- Recovered function f372; author names are unavailable.
F.f372 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f372")
        tick(1)
        tick(2)
        registers[1] = upvalues[0]["update_callbacks"]
        registers[2] = upvalues[0]["is_enabled"]
        m, x = pack_returns(registers[2]())
        m = m + 2 - 1
        top = m
        z = 0
        for f = 2, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        do
            return 
        end
    end
end
