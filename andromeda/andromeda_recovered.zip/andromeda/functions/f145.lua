-- Recovered function f145; author names are unavailable.
F.f145 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local tick = new_tick("f145")
        tick(1)
        goto p44
        ::p8::
        tick(8)
        slot_1["backtrack_cleaner_timer"] = 0
        do
            return 
        end
        ::p10::
        tick(10)
        if slot_6 ~= slot_0 then
            goto p135
        end
        goto p8
        ::p18::
        tick(18)
        slot_8 = upvalues[0][154]
        slot_9 = slot_1["backtrack_cleaner_timer"]
        slot_9 = slot_9 / 11;
        slot_8 = slot_8(slot_9)
        goto p141
        ::p24::
        tick(24)
        slot_1["backtrack_cleaner_timer"] = 0
        do
            return 
        end
        ::p26::
        tick(26)
        do
            return 
        end
        ::p27::
        tick(27)
        slot_5 = upvalues[0][47]
        slot_6 = slot_4
        slot_7 = "m_bFreezePeriod"
        slot_5 = slot_5(slot_6, slot_7)
        if slot_5 ~= 1 then
            goto p59
        end
        goto p24
        ::p42::
        tick(42)
        slot_1["backtrack_cleaner_timer"] = 0
        do
            return 
        end
        ::p44::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        z = slot_1
        slot_5 = z;
        slot_4 = z["is_invalid_tick_cleaner_enabled"]
        slot_6 = slot_3
        slot_4 = slot_4(slot_5, slot_6)
        goto p139
        ::p49::
        tick(49)
        slot_7 = (slot_7 * 11)
        slot_8 = slot_1["backtrack_cleaner_timer"]
        if not (slot_8 < slot_7) then
            goto p55
        end
        goto p18
        ::p55::
        slot_8 = slot_1["backtrack_cleaner_timer"]
        slot_9 = slot_7 + 32
        if not (slot_8 < slot_9) then
            goto p70
        end
        goto p106
        ::p59::
        tick(59)
        slot_5 = upvalues[0][32];
        slot_5 = slot_5()
        slot_6 = upvalues[0][52];
        slot_6 = slot_6()
        if slot_5 == slot_0 then
            goto p8
        end
        goto p127
        ::p70::
        slot_1["backtrack_cleaner_timer"] = 0
        goto p26
        ::p103::
        tick(103)
        slot_1["backtrack_cleaner_timer"] = slot_8
        goto p26
        ::p106::
        slot_2["force_defensive"] = true
        slot_8 = slot_1["backtrack_cleaner_timer"]
        slot_8 = slot_8 + 1
        goto p103
        ::p127::
        slot_7 = upvalues[0][50]
        slot_8 = slot_5;
        slot_7 = slot_7(slot_8)
        if not slot_7 then
            goto p8
        end
        goto p10
        ::p135::
        slot_1["force_defensive_active"] = true
        slot_7 = upvalues[1]
        slot_7 = (#slot_7)
        goto p49
        ::p139::
        if slot_4 then
            goto p167
        end
        goto p42
        ::p141::
        slot_8 = slot_8 + 1
        slot_9 = upvalues[1][slot_8]
        slot_9 = (slot_9 == true)
        slot_2["force_defensive"] = slot_9
        slot_9 = slot_1["backtrack_cleaner_timer"]
        slot_9 = slot_9 + 1
        slot_1["backtrack_cleaner_timer"] = slot_9
        goto p26
        ::p167::
        slot_4 = upvalues[0][44];
        slot_4 = slot_4()
        if slot_4 == slot_0 then
            goto p59
        end
        goto p27
    end
end
