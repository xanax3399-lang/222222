-- Recovered function f230; author names are unavailable.
F.f230 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f230")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]["defensive_refraction_pitch_state"]
        slot_1["initialized"] = false
        slot_1 = upvalues[0]["defensive_refraction_yaw_state"]
        slot_1["initialized"] = false
        do
            return 
        end
    end
end
