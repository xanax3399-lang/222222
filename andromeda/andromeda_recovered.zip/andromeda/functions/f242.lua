-- Recovered function f242; author names are unavailable.
F.f242 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f242")
        tick(1)
        goto p147
        ::p3::
        tick(3)
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p7::
        tick(7)
        registers[7] = environment["peeking_time"]
        registers[6] = (registers[6] - registers[7]);
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if not (not (registers[3] <= registers[5])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p12
        end
        goto p137
        ::p12::
        registers[5] = (true)
        do
            return registers[5]
        end
        ::p34::
        tick(34)
        registers[5] = upvalues[0][161]
        registers[6] = upvalues[0][23];
        registers[6] = registers[6]()
        goto p7
        ::p57::
        tick(57)
        registers[7] = "Hit"
        registers[5] = registers[5](registers[6], registers[7])
        if not registers[5] then
            goto p105
        end
        goto p134
        ::p62::
        tick(62)
        if registers[2] then
            goto p139
        end
        ::p74::
        tick(74)
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p84::
        tick(84)
        registers[5] = registers[5](registers[6], registers[7])
        if not registers[5] then
            goto p87
        end
        goto p3
        ::p87::
        registers[5] = environment["entity"]
        registers[5] = registers[5]["get_flag"]
        registers[6] = registers[2]
        goto p57
        ::p91::
        tick(91)
        registers[5] = upvalues[0][23];
        registers[5] = registers[5]()
        environment["peeking_time"] = registers[5]
        registers[5] = upvalues[0][23];
        registers[5] = registers[5]()
        environment["latest_time_peek"] = registers[5]
        goto p34
        ::p105::
        environment["peeking_time"] = registers[0]
        environment["latest_time_peek"] = registers[0]
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p109::
        tick(109)
        if not registers[4] then
            goto p74
        end
        goto p62
        ::p134::
        registers[5] = environment["latest_time_peek"]
        if registers[5] ~= registers[0] then
            goto p34
        end
        goto p91
        ::p137::
        registers[5] = (false)
        do
            return registers[5]
        end
        ::p139::
        registers[5] = environment["entity"]
        a = registers
        z = (5)
        q = registers
        q = q[5]
        q = q["get_flag"]
        a[z] = q
        registers[6] = registers[2]
        registers[7] = "Occluded"
        goto p84
        ::p147::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        if not registers[1] then
            goto p74
        end
        goto p109
    end
end
