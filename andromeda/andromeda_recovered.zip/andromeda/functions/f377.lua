-- Recovered function f377; author names are unavailable.
F.f377 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f377")
        tick(1)
        goto p39
        ::p24::
        tick(24)
        registers[1] = upvalues[1]["set_callback"]
        registers[2] = "indicator"
        registers[3] = upvalues[0]["capture"]
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        goto p42
        ::p31::
        tick(31)
        registers[4] = (false)
        registers[(1)](unpack_range(4, registers, 2))
        ::p37::
        tick(37)
        upvalues[0]["active"] = false
        do
            return 
        end
        ::p39::
        registers[1] = upvalues[0]["active"]
        if not registers[1] then
            goto p37
        end
        goto p24
        ::p42::
        registers[1] = upvalues[1]["set_callback"]
        registers[2] = "paint"
        registers[3] = upvalues[0]["paint"]
        goto p31
    end
end
