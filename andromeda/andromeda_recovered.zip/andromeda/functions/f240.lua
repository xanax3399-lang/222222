-- Recovered function f240; author names are unavailable.
F.f240 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local environment, n, v, R = andromeda_environment, nil, nil, nil
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f240")
        tick(1)
        goto p46
        ::p22::
        tick(22)
        if not slot_5 then
            goto p89
        end
        goto p95
        ::p32::
        tick(32)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_8 = v
            branch_taken = true
        end
        if branch_taken then
            goto p112
        end
        goto p85
        ::p46::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = slot_1["configs_db"]
        slot_3 = slot_3["cfg_list"]
        slot_3 = slot_3[slot_2]
        if slot_3 then
            goto p130
        end
        goto p117
        ::p59::
        tick(59)
        slot_10 = slot_10["menu_list"]
        slot_11 = slot_8;
        slot_9(slot_10, slot_11)
        goto p32
        ::p73::
        tick(73)
        slot_9 = environment["table"]
        slot_9 = slot_9["remove"]
        slot_10 = slot_1["configs_db"]
        slot_10 = slot_10["cfg_list"]
        slot_11 = slot_8
        goto p99
        ::p84::
        tick(84)
        do
            return 
        end
        ::p85::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        z = slot_1
        slot_6 = z;
        slot_5 = z["write_db"];
        slot_5 = slot_5(slot_6)
        goto p22
        ::p89::
        slot_5 = upvalues[0][86]
        slot_6 = "play resource/warning.wav"
        slot_5(slot_6)
        goto p84
        ::p93::
        tick(93)
        slot_7 = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_7 + 0
        n = (slot_6 + 0)
        v = (slot_5 - U)
        goto p32
        ::p95::
        slot_5 = upvalues[0][86]
        slot_6 = "play ui\\beepclear"
        slot_5(slot_6)
        goto p84
        ::p99::;
        slot_9(slot_10, slot_11)
        slot_9 = environment["table"]
        slot_9 = slot_9["remove"]
        slot_10 = slot_1["configs_db"]
        goto p59
        ::p112::
        slot_9 = slot_1["configs_db"]
        slot_9 = slot_9["cfg_list"]
        slot_9 = slot_9[slot_8]
        goto p121
        ::p117::
        slot_4 = upvalues[0][86]
        slot_5 = "play resource/warning.wav"
        slot_4(slot_5)
        do
            return 
        end
        ::p121::
        slot_9 = slot_9[1]
        if slot_9 ~= slot_4 then
            goto p32
        end
        goto p73
        ::p130::
        slot_4 = slot_3[1]
        slot_5 = slot_1["configs_db"]
        slot_5 = slot_5["cfg_list"]
        slot_5 = (#slot_5)
        slot_6 = (1)
        goto p93
    end
end
