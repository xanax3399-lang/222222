-- Recovered function f308; author names are unavailable.
F.f308 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f308")
        tick(1)
        goto p171
        ::p10::
        tick(10)
        registers[3] = (0)
        do
            return registers[3]
        end
        ::p12::
        tick(12)
        registers[17] = -1
        goto p152
        ::p14::
        tick(14)
        z = registers[8]
        registers[9] = z;
        registers[(8)] = z["init_from_angles"]
        registers[10] = (0)
        registers[11] = registers[5]["y"]
        registers[11] = registers[11] + 90
        goto p108
        ::p19::
        tick(19)
        registers[16] = registers[13] > 0
        if registers[16] then
            goto p197
        end
        goto p190
        ::p23::
        tick(23)
        if not registers[16] then
            goto p50
        end
        goto p55
        ::p25::
        tick(25)
        if registers[12] == registers[2] then
            goto p112
        end
        goto p106
        ::p27::
        tick(27)
        m, x = pack_returns(registers[8](unpack_range(10, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[8] = upvalues[0];
        registers[8] = registers[8]()
        goto p14
        ::p46::
        tick(46)
        registers[15] = registers[1]
        registers[16] = registers[11]["x"]
        registers[17] = registers[11]["y"]
        goto p114
        ::p50::
        registers[17] = (0)
        do
            return registers[17]
        end
        ::p53::
        tick(53)
        if registers[2] ~= registers[0] then
            goto p183
        end
        goto p58
        ::p55::
        registers[17] = registers[13] > registers[15]
        if not registers[17] then
            goto p152
        end
        goto p12
        ::p58::
        registers[3] = (0)
        do
            return registers[3]
        end
        ::p60::
        tick(60)
        registers[5] = upvalues[1][46]
        registers[6] = registers[2]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = registers[4](unpack_range(top, registers, 5))
        registers[5] = upvalues[0]
        registers[6] = (registers[4] - registers[3])
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["angles"]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[6] = upvalues[0]
        registers[7] = upvalues[1][91]
        m, x = pack_returns(registers[7]())
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[0]
        registers[8] = upvalues[1][39]
        registers[9] = registers[2]
        registers[10] = (3)
        goto p27
        ::p78::
        tick(78)
        do
            return registers[17]
        end
        ::p86::
        tick(86)
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["init_from_angles"]
        registers[11] = (0)
        registers[12] = registers[5]["y"]
        registers[12] = (registers[12] - 90);
        registers[9] = registers[9](unpack_range(12, registers, 10))
        registers[10] = (registers[8] * 31)
        goto p192
        ::p93::
        tick(93)
        registers[12] = upvalues[1][58]
        registers[13] = registers[1]
        registers[14] = registers[10]["x"]
        registers[15] = registers[10]["y"]
        goto p148
        ::p104::
        tick(104)
        registers[15] = (0)
        goto p19
        ::p106::
        registers[13] = (0)
        goto p112
        ::p108::;
        registers[8] = registers[8](unpack_range(11, registers, 9))
        registers[9] = upvalues[0];
        registers[9] = registers[9]()
        goto p86
        ::p112::
        if registers[14] == registers[2] then
            goto p19
        end
        goto p104
        ::p114::
        registers[18] = registers[11]["z"]
        registers[19] = registers[7]["x"]
        registers[20] = registers[7]["y"]
        goto p154
        ::p148::
        registers[16] = registers[10]["z"]
        registers[17] = registers[7]["x"]
        registers[18] = registers[7]["y"]
        goto p159
        ::p152::
        if registers[17] then
            goto p78
        end
        goto p213
        ::p154::
        registers[21] = registers[7]["z"]
        registers[22] = (false)
        m, x = pack_returns(registers[14](unpack_range(22, registers, 15)))
        z = 0
        for f = 14, 15 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p25
        ::p159::
        registers[19] = registers[7]["z"]
        registers[20] = (false)
        m, x = pack_returns(registers[12](unpack_range(20, registers, 13)))
        z = 0
        for f = 12, 13 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = upvalues[1][58]
        goto p46
        ::p171::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[1] ~= registers[0] then
            goto p53
        end
        goto p10
        ::p183::
        registers[3] = upvalues[0]
        registers[4] = upvalues[1][46]
        registers[5] = registers[1]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        registers[4] = upvalues[0]
        goto p60
        ::p190::
        registers[16] = registers[15] > 0
        goto p197
        ::p192::
        registers[10] = registers[6] + registers[10]
        registers[11] = (registers[9] * 31)
        registers[11] = registers[6] + registers[11]
        goto p93
        ::p197::
        if not registers[16] then
            goto p23
        end
        goto p215
        ::p213::
        registers[17] = (1)
        goto p78
        ::p215::
        registers[16] = (registers[13] ~= registers[15])
        goto p23
    end
end
