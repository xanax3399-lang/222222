-- Recovered function f305; author names are unavailable.
F.f305 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f305")
        tick(1)
        goto p14
        ::p11::
        tick(11)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[3] = z;
            registers[4] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p48
        end
        goto p50
        ::p14::
        tick(14)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["pairs"]
        registers[3] = registers[1]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p53
        ::p34::
        tick(34)
        registers[13] = 16759 + registers[13]
        registers[13] = registers[13] + -17136
        registers[11][48] = registers[13]
        registers[12][13] = 13
        registers[5] = nil
        registers[6] = nil
        registers[7] = nil
        registers[8] = nil
        registers[9] = nil
        registers[10] = nil
        registers[11] = nil
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        goto p14
        ::p48::
        tick(48)
        registers[1][registers[3]] = registers[0]
        goto p11
        ::p50::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p53::
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(2)]
        n = registers[3]
        U = registers[4]
        goto p11
        if registers[13] then
            goto p34
        end
        registers[13] = (402)
        goto p34
    end
end
