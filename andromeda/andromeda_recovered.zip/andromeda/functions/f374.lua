-- Recovered function f374; author names are unavailable.
F.f374 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f374")
        tick(1)
        goto p61
        ::p4::
        tick(4)
        if slot_1 ~= 0 then
            goto p55
        end
        ::p13::
        tick(13)
        slot_2 = "?"
        do
            return slot_2
        end
        ::p34::
        tick(34)
        if slot_2 ~= "" then
            goto p72
        end
        goto p53
        ::p49::
        tick(49)
        slot_4 = slot_2;
        slot_3 = slot_3(slot_4)
        if slot_3 ~= "string" then
            goto p53
        end
        goto p34
        ::p53::
        slot_3 = "?"
        do
            return slot_3
        end
        ::p55::
        slot_2 = upvalues[0][43]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        slot_3 = environment["type"]
        goto p49
        ::p61::
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 == slot_0 then
            goto p13
        end
        goto p4
        ::p72::
        slot_3 = slot_2
        do
            return slot_3
        end
    end
end
