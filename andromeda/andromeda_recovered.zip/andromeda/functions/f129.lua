-- Recovered function f129; author names are unavailable.
F.f129 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f129")
        tick(1)
        goto p43
        ::p3::
        tick(3)
        registers[19] = "%.1f"
        registers[20] = registers[12]
        registers[18] = registers[18](registers[19], registers[20])
        registers[19] = "K/D"
        goto p78
        ::p8::
        tick(8);
        registers[(42)] = registers[(42)](registers[43])
        registers[42] = registers[22] + registers[42]
        registers[43] = registers[36][1]
        registers[44] = registers[36][2]
        registers[45] = registers[36][3]
        registers[46] = registers[36][4]
        registers[47] = registers[37]
        registers[48] = (0)
        registers[49] = registers[35]["text"]
        goto p207
        ::p20::
        tick(20)
        registers[34] = registers[27]
        registers[35] = (0)
        registers[36] = (0)
        registers[37] = (0)
        registers[38] = (0)
        registers[39] = (0)
        registers[40] = (0)
        goto p174
        ::p28::
        tick(28)
        registers[39] = registers[40]
        registers[40] = upvalues[2][131]
        registers[41] = registers[30]
        goto p471
        ::p33::
        tick(33)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p35::
        tick(35)
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        a = D.f130
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[16] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[17] = upvalues[5]
        registers[18] = registers[1]
        registers[19] = "FPS"
        goto p498
        ::p41::
        tick(41)
        registers[28] = (0)
        goto p487
        ::p43::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = upvalues[0]
        registers[6] = upvalues[1]
        m, x = pack_returns(registers[6]())
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        a = D.f131
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[7] = upvalues[3];
        registers[7] = registers[7]()
        registers[8] = upvalues[2][151]
        goto p385
        ::p53::
        tick(53)
        registers[30] = upvalues[2][128]
        registers[31] = registers[21] + registers[24]
        registers[32] = registers[26]
        registers[33] = registers[25]
        goto p431
        ::p65::
        tick(65)
        registers[17] = upvalues[5]
        registers[18] = registers[1]
        registers[19] = "K/D ratio"
        registers[17] = registers[17](registers[18], registers[19])
        if not registers[17] then
            goto p331
        end
        goto p562
        ::p71::
        tick(71)
        m, x = pack_returns(registers[27](unpack_range(28, registers, 28)))
        m = m + 27 - 1
        top = m
        z = 0
        for f = 27, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[25] = registers[25](unpack_range(top, registers, 26))
        registers[24] = registers[25]
        registers[25] = upvalues[2][151]
        registers[26] = (0)
        registers[27] = (registers[24] * 2)
        goto p293
        ::p78::;
        registers[17](registers[18], registers[19])
        goto p331
        ::p88::
        tick(88)
        registers[22] = registers[10]
        if registers[22] then
            goto p187
        end
        goto p200
        ::p93::
        tick(93)
        registers[24] = "Top Center"
        goto p446
        ::p96::
        tick(96)
        registers[16]["gap"] = 0
        registers[17] = {
        }
        registers[17]["text"] = "sense"
        goto p190
        ::p100::
        tick(100)
        m, x = pack_returns(registers[38](unpack_range(40, registers, 39)))
        z = 0
        for f = 38, 39 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[40] = registers[38]
        if registers[40] then
            goto p154
        end
        goto p229
        ::p113::
        tick(113)
        registers[35] = registers[15][registers[34]]
        registers[36] = registers[35]["color"]
        registers[37] = registers[35]["flags"]
        if registers[37] then
            goto p196
        end
        goto p163
        ::p119::
        tick(119)
        registers[21] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[21] + 0
        n = (registers[20] + 0)
        v = (registers[19] - U)
        goto p124
        ::p121::
        tick(121)
        registers[19] = (255)
        q = registers[(15)]
        q[1] = registers[16]
        q[2] = registers[17]
        q[3] = registers[18]
        q[4] = registers[19]
        goto p512
        ::p124::
        tick(124)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[22] = v
            branch_taken = true
        end
        if branch_taken then
            goto p202
        end
        goto p253
        ::p134::
        tick(134)
        registers[40] = registers[18]
        goto p28
        ::p136::
        tick(136)
        registers[21] = upvalues[6]
        registers[22] = registers[19]
        registers[23] = registers[20]
        registers[24] = registers[2]
        if registers[24] then
            goto p446
        end
        goto p93
        ::p142::
        tick(142)
        registers[30] = registers[30] + 0.5;
        registers[(29)] = registers[(29)](registers[30])
        registers[30] = (0)
        registers[31] = (255)
        goto p417
        ::p147::
        tick(147)
        registers[30] = registers[40] + registers[41]
        goto p314
        ::p149::
        tick(149)
        registers[26] = registers[23]["text"]
        m, x = pack_returns(registers[24](unpack_range(26, registers, 25)))
        z = 0
        for f = 24, 25 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[26] = registers[24]
        if registers[26] then
            goto p232
        end
        goto p316
        ::p154::
        tick(154)
        registers[38] = registers[40]
        registers[40] = registers[39]
        if registers[40] then
            goto p28
        end
        goto p134
        ::p163::
        registers[37] = nil
        goto p196
        ::p174::
        registers[41] = (0)
        registers[42] = registers[28]
        registers[43] = (true)
        registers[(30)](unpack_range(43, registers, 31))
        if not (0 < registers[25]) then
            goto p546
        end
        goto p53
        ::p181::
        tick(181)
        registers[17] = registers[26] + registers[27]
        registers[26] = upvalues[2][151]
        registers[27] = registers[18]
        registers[28] = registers[25]
        if registers[28] then
            goto p487
        end
        goto p41
        ::p187::
        tick(187)
        registers[23] = registers[11]
        if registers[23] then
            goto p286
        end
        goto p411
        ::p190::
        registers[17]["color"] = registers[3]
        registers[18] = registers[6]
        registers[19] = (13);
        registers[(18)] = registers[(18)](registers[19])
        registers[17]["gap"] = registers[18]
        goto p35
        ::p196::
        registers[38] = upvalues[2][136]
        registers[39] = registers[37]
        registers[40] = registers[35]["text"]
        goto p100
        ::p200::
        registers[22] = (0)
        goto p187
        ::p202::
        registers[23] = registers[15][registers[22]]
        registers[24] = upvalues[2][136]
        registers[25] = registers[23]["flags"]
        if registers[25] then
            goto p149
        end
        goto p569
        ::p207::
        registers[(40)](unpack_range(49, registers, 41))
        registers[40] = registers[30] + registers[38]
        registers[41] = registers[35]["gap"]
        if registers[41] then
            goto p147
        end
        goto p227
        ::p212::
        tick(212)
        registers[15] = (217)
        registers[16] = (217)
        registers[17] = (217)
        registers[18] = (238)
        goto p249
        ::p227::
        registers[41] = (0)
        goto p147
        ::p229::
        registers[40] = (0)
        goto p154
        ::p232::
        tick(232)
        registers[26] = registers[17] + registers[26]
        registers[27] = registers[23]["gap"]
        if registers[27] then
            goto p181
        end
        goto p560
        ::p236::
        tick(236)
        registers[17] = (#registers[15])
        registers[17] = registers[17] + 1
        registers[18] = {
        }
        registers[19] = environment["string"]
        registers[19] = registers[19]["format"]
        registers[20] = "%02d:%02d:%02d"
        registers[21] = registers[9]
        goto p491
        ::p245::
        tick(245)
        registers[31] = registers[22]
        registers[(30)](registers[31])
        registers[30] = upvalues[2][129]
        goto p407
        ::p249::
        q = registers[(14)]
        q[1] = registers[15]
        q[2] = registers[16]
        q[3] = registers[17]
        q[4] = registers[18]
        registers[15] = registers[3]
        if registers[15] then
            goto p512
        end
        goto p322
        ::p253::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[19] = registers[6]
        registers[20] = (34)
        goto p308
        ::p257::
        tick(257)
        registers[17] = registers[17](registers[18], registers[19])
        if not registers[17] then
            goto p484
        end
        goto p236
        ::p279::
        tick(279)
        m, x = pack_returns(registers[9]())
        z = 0
        for f = 9, 11 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = upvalues[4]
        registers[13] = upvalues[2][32]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        registers[13] = new_frame(4)
        goto p345
        ::p286::
        tick(286);
        registers[19] = registers[19](unpack_range(23, registers, 20))
        registers[18]["text"] = registers[19]
        registers[18]["color"] = registers[13]
        registers[18]["gap"] = 0
        registers[15][registers[17]] = registers[18]
        goto p493
        ::p293::
        registers[27] = (registers[19] - registers[27])
        registers[25] = registers[25](registers[26], registers[27])
        registers[26] = registers[22] + registers[23]
        registers[27] = upvalues[2][151]
        registers[28] = (1)
        registers[29] = (registers[23] * 2)
        registers[29] = (registers[20] - registers[29])
        registers[27] = registers[27](registers[28], registers[29])
        goto p555
        ::p308::;
        registers[(19)] = registers[(19)](registers[20])
        registers[19] = registers[17] + registers[19]
        registers[20] = registers[6]
        registers[21] = (20);
        registers[(20)] = registers[(20)](registers[21])
        goto p136
        ::p314::
        tick(314)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[34] = v
            branch_taken = true
        end
        if branch_taken then
            goto p113
        end
        goto p33
        ::p316::
        registers[26] = (0)
        goto p232
        ::p320::
        tick(320)
        registers[30] = (110)
        goto p142
        ::p322::
        registers[15] = new_frame(4)
        registers[16] = (186)
        registers[17] = (255)
        registers[18] = (15)
        goto p121
        ::p328::
        tick(328)
        registers[38] = registers[28]
        registers[(30)](unpack_range(38, registers, 31))
        goto p546
        ::p331::
        tick(331)
        registers[17] = upvalues[5]
        registers[18] = registers[1]
        registers[19] = "Clock"
        goto p257
        ::p345::
        registers[14] = (242)
        registers[15] = (242)
        registers[16] = (242)
        registers[17] = (248)
        q = registers[(13)]
        q[1] = registers[14]
        q[2] = registers[15]
        q[3] = registers[16]
        q[4] = registers[17]
        registers[14] = new_frame(4)
        goto p212
        ::p366::
        tick(366);
        registers[17](registers[18], registers[19])
        goto p65
        ::p368::
        tick(368)
        registers[30] = upvalues[2][154]
        registers[31] = (registers[19] - registers[17])
        registers[31] = (registers[31] * 0.5)
        registers[31] = registers[31] + 0.5;
        registers[(30)] = registers[(30)](registers[31])
        registers[30] = registers[21] + registers[30]
        registers[31] = (1)
        registers[32] = (#registers[15])
        registers[33] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[33] + 0
        n = (registers[32] + 0)
        v = (registers[31] - U)
        goto p314
        goto p187
        ::p379::
        tick(379)
        registers[17] = upvalues[5]
        registers[18] = registers[1]
        registers[19] = "Ping"
        registers[17] = registers[17](registers[18], registers[19])
        if not registers[17] then
            goto p65
        end
        goto p551
        ::p385::
        registers[9] = (0)
        registers[10] = upvalues[2][154]
        registers[11] = upvalues[2][67];
        registers[11] = registers[11]()
        registers[11] = (registers[11] * 1000)
        registers[11] = registers[11] + 0.5
        m, x = pack_returns(registers[10](unpack_range(11, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = upvalues[2][96]
        goto p279
        ::p403::
        tick(403)
        registers[17] = registers[16]
        registers[18] = environment["string"]
        registers[18] = registers[18]["format"]
        goto p3
        ::p407::
        registers[31] = registers[21]
        registers[32] = registers[26]
        registers[33] = registers[24]
        goto p20
        ::p411::
        registers[23] = (0)
        goto p286
        ::p415::
        tick(415)
        registers[21] = (0)
        goto p88
        ::p417::;
        registers[28] = registers[28](unpack_range(31, registers, 29))
        a = D.f132
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[29] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[30] = registers[29]
        goto p245
        ::p427::
        tick(427)
        registers[41] = (0)
        registers[42] = (0)
        registers[43] = (true)
        goto p535
        ::p431::
        registers[34] = registers[27]
        registers[35] = (0)
        registers[36] = (0)
        registers[37] = (0)
        goto p328
        ::p436::
        tick(436)
        registers[26] = registers[24]
        registers[27] = upvalues[2][154]
        registers[28] = (registers[19] * 0.5)
        goto p71
        ::p446::
        registers[25] = registers[5]
        m, x = pack_returns(registers[21](unpack_range(25, registers, 22)))
        z = 0
        for f = 21, 22 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[23] = upvalues[2][151]
        registers[24] = (1)
        registers[25] = registers[6]
        registers[26] = (1)
        m, x = pack_returns(registers[25](unpack_range(26, registers, 26)))
        m = m + 25 - 1
        top = m
        z = 0
        for f = 25, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[23] = registers[23](unpack_range(top, registers, 24))
        registers[24] = upvalues[2][151]
        goto p564
        ::p463::
        tick(463)
        registers[26] = upvalues[2][154]
        registers[27] = (registers[19] * 0.08)
        registers[27] = registers[27] + 0.5
        m, x = pack_returns(registers[26](unpack_range(27, registers, 27)))
        m = m + 26 - 1
        top = m
        z = 0
        for f = 26, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[24] = registers[24](unpack_range(top, registers, 25))
        registers[25] = upvalues[2][162]
        goto p436
        ::p471::
        registers[42] = upvalues[2][154]
        registers[43] = (registers[20] - registers[39])
        registers[43] = (registers[43] * 0.5)
        registers[43] = registers[43] + 0.5
        goto p8
        ::p484::
        registers[17] = (#registers[15])
        if not (0 < registers[17]) then
            goto p493
        end
        goto p529
        ::p487::
        registers[26] = registers[26](registers[27], registers[28])
        registers[18] = registers[26]
        goto p124
        ::p491::
        if registers[21] then
            goto p88
        end
        goto p415
        ::p493::
        tick(493)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (1)
        registers[20] = (#registers[15])
        goto p119
        ::p498::
        registers[17] = registers[17](registers[18], registers[19])
        if not registers[17] then
            goto p379
        end
        goto p541
        ::p501::
        tick(501)
        registers[33] = registers[24]
        registers[34] = registers[27]
        registers[35] = (0)
        registers[36] = (0)
        registers[37] = (0)
        goto p525
        ::p512::
        registers[3] = registers[15]
        registers[15] = new_frame(2)
        registers[16] = {
        }
        registers[16]["text"] = "game"
        registers[16]["color"] = registers[13]
        goto p96
        ::p525::
        registers[38] = registers[28]
        registers[39] = (0)
        registers[40] = (0)
        goto p427
        ::p529::
        registers[17] = (#registers[15])
        registers[17] = registers[15][registers[17]]
        registers[17]["gap"] = 0
        goto p493
        ::p535::
        registers[(30)](unpack_range(43, registers, 31))
        registers[30] = registers[29]
        registers[31] = registers[22] + registers[20]
        registers[31] = (registers[31] - registers[23])
        registers[(30)](registers[31])
        goto p368
        ::p541::
        registers[17] = registers[16]
        registers[18] = registers[7]
        registers[19] = "FPS";
        registers[17](registers[18], registers[19])
        goto p379
        ::p546::
        registers[30] = upvalues[2][129]
        registers[31] = registers[21] + registers[24]
        registers[31] = registers[31] + registers[25]
        registers[32] = registers[26]
        goto p501
        ::p551::
        registers[17] = registers[16]
        registers[18] = registers[8]
        registers[19] = "PING"
        goto p366
        ::p555::
        registers[28] = upvalues[7]["clamp"]
        registers[29] = upvalues[2][154]
        registers[30] = registers[4]
        if registers[30] then
            goto p142
        end
        goto p320
        ::p560::
        registers[27] = (0)
        goto p181
        ::p562::
        if registers[12] == registers[0] then
            goto p331
        end
        goto p403
        ::p564::
        registers[25] = registers[6]
        registers[26] = (8);
        registers[(25)] = registers[(25)](registers[26])
        goto p463
        ::p569::
        registers[25] = nil
        goto p149
    end
end
