-- Recovered function f304; author names are unavailable.
F.f304 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z = nil, nil
        local branch_taken = nil
        local tick = new_tick("f304")
        tick(1)
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        branch_taken = false
        if registers[1] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p53
        end
        goto p52
        ::p6::
        tick(6)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p8::
        tick(8)
        registers[7] = new_frame(2)
        registers[8] = registers[4]
        registers[9] = registers[5]
        q = registers[(7)]
        q[1] = registers[8]
        q[2] = registers[9]
        registers[6][registers[3]] = registers[7]
        goto p64
        ::p52::
        do
            return 
        end
        ::p53::
        registers[1] = environment["ipairs"]
        registers[2] = upvalues[1]
        m, x = pack_returns(registers[2]())
        m = m + 2 - 1
        top = m
        z = 0
        for f = 2, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[1](unpack_range(top, registers, 2)))
        z = 0
        for f = 1, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(1)]
        n = registers[2]
        U = registers[3]
        goto p64
        ::p58::
        tick(58)
        registers[4] = environment["entity"]
        registers[4] = registers[4]["get_simtime"]
        registers[5] = registers[3]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        z = 0
        for f = 4, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = upvalues[2]["sim_store"]
        goto p8
        ::p64::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[2] = z;
            registers[3] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p58
        end
        goto p6
    end
end
