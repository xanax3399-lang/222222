-- Recovered function f436; author names are unavailable.
F.f436 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local branch_taken = nil
        local tick = new_tick("f436")
        tick(1)
        goto p45
        ::p33::
        tick(33)
        registers[2] = (1)
        do
            return registers[2]
        end
        ::p35::
        tick(35)
        branch_taken = false
        if registers[2] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p40
        end
        goto p33
        ::p40::
        registers[2] = upvalues[1][154]
        registers[3.0] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        goto p78
        ::p45::
        registers[1] = upvalues[0]["config"]
        registers[1] = registers[1]["list"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[2] = environment["type"]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        goto p35
        ::p78::
        registers[2] = registers[2] + 1
        do
            return registers[2]
        end
    end
end
