-- Recovered function f107; author names are unavailable.
F.f107 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f107")
        tick(1)
        goto p5
        ::p2::
        tick(2)
        registers[8] = (1)
        goto p13
        ::p5::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = upvalues[0][154]
        registers[7] = upvalues[1]["get_gradient_alpha"];
        registers[7] = registers[7]()
        registers[8] = registers[5]
        if registers[8] then
            goto p13
        end
        goto p2
        ::p13::
        registers[7] = registers[7] * registers[8]
        registers[7] = registers[7] + 0.5;
        registers[(6)] = registers[(6)](registers[7])
        registers[7] = upvalues[2]
        registers[8] = registers[1]
        registers[9] = registers[2]
        registers[10] = registers[3]
        registers[11] = registers[4]
        registers[12] = registers[6]
        registers[(7)](unpack_range(12, registers, 8))
        do
            return 
        end
    end
end
