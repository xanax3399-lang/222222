-- Recovered function f423; author names are unavailable.
F.f423 = function(function_metadata, upvalues)
    local operand_i, operand_k = function_metadata[2], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f423")
        tick(1)
        goto p30
        ::p16::
        tick(16)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p153
        ::p30::
        registers[1] = (1)
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p54
        ::p36::
        tick(36)
        registers[16] = upvalues[0]
        m, x = pack_returns(registers[16]())
        m = m + 16 - 1
        top = m
        z = 0
        for f = 16, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[15] = new_frame(1)
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        registers[17] = upvalues[0]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(15)]
        for f = 1, top - (15) do
            q[(0) + f] = registers[(15) + f]
        end
        registers[5][registers[14]] = registers[15]
        goto p157
        ::p47::
        tick(47)
        registers[15] = upvalues[1]
        a = registers
        z = 16
        q = upvalues
        q = q[2]
        a[z] = q;
        registers[16] = registers[16]()
        goto p210
        ::p54::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p153
        end
        goto p128
        ::p57::
        tick(57)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p123
        end
        goto p16
        ::p59::
        tick(59)
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        goto p110
        ::p66::
        tick(66)
        registers[14] = upvalues[2];
        registers[14] = registers[14]()
        if not registers[14] then
            goto p88
        end
        goto p119
        ::p88::
        tick(88)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[15] = registers[5][registers[15]]
        if registers[15] then
            goto p206
        end
        goto p47
        ::p95::
        tick(95)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        if not registers[15] then
            goto p167
        end
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        goto p167
        ::p104::
        tick(104)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        a = registers
        z = 6
        q = 1;
        a[z] = 1
        registers[7] = upvalues[0]
        goto p143
        ::p110::
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0]
        goto p231
        ::p115::
        tick(115)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p59
        end
        goto p104
        ::p117::
        tick(117)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p57
        ::p119::
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p88
        ::p123::
        registers[10] = (0)
        registers[11] = (255)
        registers[12] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p157
        goto p153
        ::p128::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[1]
        registers[2] = upvalues[2]
        goto p191
        ::p143::;
        registers[7] = registers[7]()
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p57
        registers[34] = operand_i
        registers[35] = operand_k
        registers[34][192] = 0
        registers[35][182] = 190
        a = (28)
        z = 35
        for f = a, z do
            q = registers
            m = f
            f = nil;
            q[m] = f
        end
        goto p191
        ::p153::
        registers[5] = {
        }
        registers[6] = (0)
        registers[7] = (255)
        goto p159
        ::p157::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p66
        end
        goto p117
        ::p159::
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p115
        ::p161::
        tick(161);
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p115
        ::p167::
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[3]
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        goto p36
        ::p191::;
        registers[2] = registers[2]()
        registers[3] = upvalues[0]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p195::
        tick(195)
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0]
        goto p161
        ::p206::
        tick(206)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p95
        ::p210::
        registers[17] = upvalues[2]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        goto p206
        ::p231::;
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        registers[10] = upvalues[1]
        goto p195
    end
end
