-- Recovered function f15; author names are unavailable.
F.f15 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local tick = new_tick("f15")
        tick(1)
        tick(3)
        do
            return 
        end
    end
end
