-- Recovered function f73; author names are unavailable.
F.f73 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local tick = new_tick("f73")
        tick(1)
        goto p38
        ::p35::
        tick(35)
        slot_2 = slot_2[slot_3]
        slot_1(slot_2)
        do
            return 
        end
        ::p38::
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["all"]
        slot_3 = upvalues[2]
        goto p35
    end
end
