-- Recovered function f312; author names are unavailable.
F.f312 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f312")
        tick(1)
        goto p46
        ::p32::
        tick(32)
        z = registers[1]
        registers[4] = z;
        registers[(3)] = z["get_float"];
        registers[(3)] = registers[(3)](registers[4])
        goto p60
        ::p36::
        tick(36)
        registers[3] = registers[2]
        goto p79
        ::p46::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[1] ~= registers[0] then
            goto p51
        end
        goto p57
        ::p51::
        tick(51)
        registers[3] = environment["tonumber"]
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["get_string"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] then
            goto p60
        end
        goto p32
        ::p57::
        registers[3] = registers[2]
        do
            return registers[3]
        end
        ::p60::
        if registers[3] then
            goto p79
        end
        goto p36
        ::p79::
        do
            return registers[3]
        end
    end
end
