-- Recovered function f399; author names are unavailable.
F.f399 = function(function_metadata, upvalues)
    local operand_g, code_metadata, operand_k = function_metadata[6], function_metadata[8], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f399")
        tick(1)
        goto p18
        ::p2::
        tick(2)
        registers[5] = upvalues[0][registers[4]]
        registers[6] = upvalues[1][registers[5]]
        if registers[6] == registers[0] then
            goto p44
        end
        goto p50
        ::p8::
        tick(8)
        registers[10] = code_metadata
        registers[16] = operand_k
        registers[17] = 411
        registers[17] = (registers[17] - 275)
        registers[17] = 7042 + registers[17]
        registers[17] = registers[17] + -7171
        registers[10][19] = registers[17]
        registers[16][42] = 17
        registers[9] = nil
        registers[10] = nil
        registers[11] = nil
        registers[12] = nil
        registers[13] = nil
        registers[14] = nil
        registers[15] = nil
        registers[16] = nil
        registers[17] = nil
        registers[18] = nil
        ::p18::
        tick(18)
        registers[1] = (1)
        registers[2] = upvalues[0]
        registers[2] = (#registers[2])
        a = registers
        z = 3;
        a[z] = 1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p44
        registers[26] = operand_k
        registers[24] = operand_g
        registers[24][4] = 6
        registers[24][46] = 0
        registers[26][58] = 41
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        goto p18
        ::p32::
        tick(32)
        registers[7] = registers[6]["raw"]
        registers[7]["hide_view_model_zoomed"] = true
        goto p44
        ::p35::
        tick(35)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[0]
        registers[1] = (#registers[1])
        registers[2] = (1)
        registers[3] = -1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p56
        goto p8
        ::p44::
        tick(44)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p2
        end
        goto p35
        ::p46::
        tick(46)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p48::
        tick(48)
        upvalues[0][registers[4]] = registers[0]
        goto p56
        ::p50::
        a = registers
        z = (7)
        q = registers
        q = q[6]
        q = q["raw"]
        a[z] = q
        if registers[7] == registers[0] then
            goto p44
        end
        goto p32
        ::p56::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p48
        end
        goto p46
    end
end
