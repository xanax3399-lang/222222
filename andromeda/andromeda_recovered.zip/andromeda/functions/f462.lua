-- Recovered function f462; author names are unavailable.
F.f462 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f462")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0][47]
        slot_3 = slot_1
        goto p71
        ::p45::
        tick(45)
        slot_2 = (0)
        goto p76
        ::p68::
        tick(68)
        slot_3 = (slot_3 == 1)
        do
            return slot_3
        end
        ::p71::
        slot_4 = "m_fFlags"
        slot_2 = slot_2(slot_3, slot_4)
        if slot_2 then
            goto p76
        end
        goto p45
        ::p76::
        slot_3 = environment["bit"]
        slot_3 = slot_3["band"]
        slot_4 = slot_2
        slot_5 = (1)
        slot_3 = slot_3(slot_4, slot_5)
        goto p68
    end
end
