-- Recovered function f342; author names are unavailable.
F.f342 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f342")
        tick(1)
        tick(3)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = slot_2["yaw_modifiers"]
        slot_4 = slot_3["builder_type"]
        goto p9
        ::p7::
        tick(7)
        do
            return 
        end
        ::p9::
        z = slot_4
        slot_5 = z;
        slot_4 = z["get"];
        slot_4 = slot_4(slot_5)
        branch_taken = false
        if slot_4 ~= "Default" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p14
        end
        goto p41
        ::p14::
        slot_4 = slot_1["yaw"]
        z = slot_1
        slot_6 = z;
        slot_5 = z["get_yaw_modifier_add"]
        slot_7 = slot_3
        slot_5 = slot_5(slot_6, slot_7)
        slot_4["add"] = slot_5
        goto p7
        ::p41::
        slot_4 = slot_1["yaw"]
        slot_4["add"] = 0
        do
            return 
        end
    end
end
