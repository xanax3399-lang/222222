-- Recovered function f216; author names are unavailable.
F.f216 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f216")
        tick(1)
        goto p4
        ::p2::
        tick(2)
        slot_2 = nil
        do
            return slot_2
        end
        ::p4::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1
        slot_4 = -90
        goto p17
        ::p9::
        tick(9)
        slot_2 = (90)
        do
            return slot_2
        end
        ::p11::
        tick(11)
        slot_2 = upvalues[0]
        slot_3 = slot_1
        slot_4 = (90)
        slot_2 = slot_2(slot_3, slot_4)
        if not slot_2 then
            goto p2
        end
        goto p9
        ::p17::
        slot_2 = slot_2(slot_3, slot_4)
        if not slot_2 then
            goto p11
        end
        slot_2 = -90
        do
            return slot_2
        end
    end
end
