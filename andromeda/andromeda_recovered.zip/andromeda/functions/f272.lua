-- Recovered function f272; author names are unavailable.
F.f272 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f272")
        tick(1)
        goto p10
        ::p2::
        tick(2)
        registers[6] = registers[3]
        registers[7] = registers[4]
        do
            return unpack_range(7, registers, (5))
        end
        ::p6::
        tick(6)
        registers[4] = (255)
        m, x = pack_returns(registers[2](unpack_range(4, registers, 3)))
        z = 0
        for f = 2, 4 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[2]
        goto p2
        ::p10::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["get_segment_color"]
        registers[3] = registers[1]
        goto p6
    end
end
