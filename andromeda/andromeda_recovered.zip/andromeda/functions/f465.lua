-- Recovered function f465; author names are unavailable.
F.f465 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local a = nil
        local tick = new_tick("f465")
        tick(1)
        goto p38
        ::p15::
        tick(15)
        if slot_2 then
            goto p52
        end
        slot_2 = (slot_1 == "bomb")
        goto p52
        ::p38::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = (slot_1 == "planted_bomb")
        if slot_2 then
            goto p15
        end
        slot_2 = (slot_1 == "bomb_planting")
        goto p15
        ::p52::
        do
            return slot_2
        end
    end
end
