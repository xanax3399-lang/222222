-- Recovered function f450; author names are unavailable.
F.f450 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f450")
        tick(1)
        goto p32
        ::p2::
        tick(2)
        slot_6 = slot_4 + slot_5
        slot_6 = (slot_6 * 0.5)
        slot_7 = (slot_5 - slot_4)
        slot_7 = (slot_7 * 0.5)
        slot_8 = upvalues[0][163]
        goto p51
        ::p8::
        tick(8)
        slot_4 = (0)
        goto p40
        ::p24::
        tick(24)
        do
            return slot_8
        end
        ::p32::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = slot_1
        if slot_4 then
            goto p40
        end
        goto p8
        ::p38::
        tick(38)
        slot_10 = (1)
        goto p56
        ::p40::
        slot_5 = slot_2
        if slot_5 then
            goto p2
        end
        slot_5 = slot_4
        goto p2
        ::p51::
        slot_9 = upvalues[0][30];
        slot_9 = slot_9()
        slot_10 = slot_3
        if slot_10 then
            goto p56
        end
        goto p38
        ::p56::
        slot_9 = slot_9 * slot_10;
        slot_8 = slot_8(slot_9)
        slot_8 = slot_8 * slot_7
        slot_8 = slot_6 + slot_8
        goto p24
    end
end
