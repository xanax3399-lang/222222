-- Recovered function f80; author names are unavailable.
F.f80 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f80")
        tick(1)
        goto p101
        ::p3::
        tick(3)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p17::
        tick(17)
        registers[9] = upvalues[0]
        registers[10] = {
        }
        registers[11] = upvalues[1]["CHECK_14_FAILED"]
        registers[10]["ban_num"] = registers[11]
        registers[10]["ban_info"] = "pcall [env][0x01]"
        goto p105
        ::p38::
        tick(38)
        registers[7] = environment["getmetatable"]
        registers[8] = registers[6];
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = environment["pcall"]
        a = D.f81
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[9] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[(8)] = registers[(8)](registers[9])
        goto p57
        ::p45::
        tick(45)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p78
        ::p46::
        tick(46)
        registers[5] = environment["pcall"]
        registers[6] = environment["getfenv"]
        registers[7] = registers[4]
        m, x = pack_returns(registers[5](unpack_range(7, registers, 6)))
        z = 0
        for f = 5, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p68
        ::p51::
        tick(51)
        do
            local f = (1)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        goto p78
        ::p57::
        if not registers[8] then
            goto p51
        end
        goto p17
        ::p68::
        if registers[5] then
            goto p38
        end
        goto p3
        ::p78::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p46
        end
        goto p3
        ::p101::
        registers[1] = (1)
        registers[2] = (10)
        registers[3] = (1)
        goto p45
        ::p105::
        registers[(9)](registers[10])
        goto p51
    end
end
