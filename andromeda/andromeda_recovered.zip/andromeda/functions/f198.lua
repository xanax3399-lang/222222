-- Recovered function f198; author names are unavailable.
F.f198 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local z = nil
        local tick = new_tick("f198")
        tick(1)
        goto p33
        ::p30::
        tick(30);
        slot_1 = slot_1(slot_2)
        slot_1 = (slot_1 == true)
        do
            return slot_1
        end
        ::p33::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["safe_point"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"]
        goto p30
    end
end
