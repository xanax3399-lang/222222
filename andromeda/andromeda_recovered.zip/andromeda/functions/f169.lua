-- Recovered function f169; author names are unavailable.
F.f169 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f169")
        tick(1)
        tick(12)
        slot_1 = upvalues[0]["clear_state"]
        slot_1()
        do
            return 
        end
    end
end
