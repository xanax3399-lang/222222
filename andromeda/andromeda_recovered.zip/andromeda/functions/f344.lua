-- Recovered function f344; author names are unavailable.
F.f344 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f344")
        tick(1)
        goto p230
        ::p2::
        tick(2)
        if registers[9] then
            goto p18
        end
        goto p163
        ::p4::
        tick(4)
        registers[5] = registers[1]["yaw"]
        registers[5]["type"] = "180"
        registers[5] = registers[1]["yaw"]
        registers[6] = registers[3]["global"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"]
        goto p206
        ::p10::
        tick(10)
        registers[11] = "Local view"
        goto p133
        ::p12::
        tick(12)
        registers[5]["base"] = registers[6]
        do
            return 
        end
        ::p15::
        tick(15)
        registers[6] = "Local view"
        goto p69
        ::p18::
        tick(18)
        registers[10] = registers[1]["yaw"]
        registers[10]["type"] = "180"
        registers[10] = registers[1]["yaw"]
        goto p46
        ::p23::
        tick(23)
        do
            return 
        end
        ::p30::
        tick(30)
        a = upvalues[0];
        registers[11] = a[2][a[1]]["manual"]
        registers[11] = (registers[11] ~= registers[0])
        if not registers[11] then
            goto p133
        end
        goto p10
        ::p35::
        tick(35)
        registers[5] = "At targets"
        goto p167
        ::p37::
        tick(37);
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = registers[7]
        if not registers[8] then
            goto p161
        end
        registers[8] = registers[5]
        goto p161
        ::p46::
        registers[11] = upvalues[1]["clamp"]
        registers[12] = upvalues[2]
        registers[13] = registers[5]
        registers[14] = registers[6]
        registers[15] = registers[9]
        a = upvalues[0];
        registers[16] = a[2][a[1]]["current"]
        goto p211
        ::p58::
        tick(58)
        if registers[4] ~= "180" then
            goto p145
        end
        goto p4
        ::p61::
        tick(61)
        registers[5] = registers[3]["left"]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get"];
        registers[(5)] = registers[(5)](registers[6])
        registers[6] = registers[3]["right"]
        z = registers[6]
        registers[7] = z;
        registers[(6)] = z["get"];
        registers[(6)] = registers[(6)](registers[7])
        z = registers[1]
        registers[8] = z;
        registers[(7)] = z["is_left_side"]
        goto p37
        ::p69::
        tick(69)
        if registers[6] then
            goto p12
        end
        goto p236
        ::p71::
        tick(71);
        registers[11] = registers[11](unpack_range(14, registers, 12))
        registers[10]["value"] = registers[11]
        registers[10] = registers[1]["yaw"]
        goto p30
        ::p100::
        tick(100)
        registers[4] = registers[3]["type"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"];
        registers[(4)] = registers[(4)](registers[5])
        branch_taken = false
        if registers[4] ~= "Solo" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p4
        end
        goto p58
        ::p133::
        if registers[11] then
            goto p143
        end
        goto p155
        ::p143::
        tick(143)
        registers[10]["base"] = registers[11]
        do
            return 
        end
        ::p145::
        branch_taken = false
        if registers[4] ~= "Double" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p61
        end
        goto p196
        ::p155::
        registers[11] = "At targets"
        goto p143
        ::p159::
        tick(159)
        registers[5] = "Local view"
        goto p175
        ::p161::
        if registers[8] then
            goto p227
        end
        goto p188
        ::p163::
        registers[9] = registers[3]["right_randomize"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p18
        ::p167::
        tick(167)
        registers[4]["base"] = registers[5]
        do
            return 
        end
        ::p171::
        tick(171);
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= "Hidden" then
            goto p100
        end
        goto p198
        ::p175::
        tick(175)
        if registers[5] then
            goto p167
        end
        goto p35
        ::p180::
        tick(180)
        registers[12] = registers[8] + registers[12]
        registers[13] = -180
        registers[14] = (180)
        goto p71
        ::p184::
        tick(184)
        registers[9] = registers[3]["left_randomize"]
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["get"];
        registers[(9)] = registers[(9)](registers[10])
        goto p2
        ::p188::
        registers[8] = registers[6]
        goto p227
        ::p196::
        if registers[4] ~= "L / R" then
            goto p23
        end
        goto p61
        ::p198::
        registers[4] = registers[1]["yaw"]
        registers[4]["type"] = "180"
        registers[4] = registers[1]["yaw"]
        registers[4]["value"] = 0
        registers[4] = registers[1]["yaw"]
        a = upvalues[0];
        registers[5] = a[2][a[1]]["manual"]
        registers[5] = (registers[5] ~= registers[0])
        goto p239
        ::p206::;
        registers[(6)] = registers[(6)](registers[7])
        registers[5]["value"] = registers[6]
        registers[5] = registers[1]["yaw"]
        a = upvalues[0];
        registers[6] = a[2][a[1]]["manual"]
        goto p255
        ::p211::
        registers[16] = upvalues[3][registers[16]]
        registers[17] = registers[7];
        registers[12] = registers[12](unpack_range(17, registers, 13))
        goto p180
        ::p227::
        registers[9] = registers[7]
        if not registers[9] then
            goto p2
        end
        goto p184
        ::p230::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = registers[2]["yaw"]
        registers[4] = registers[3]["builder_type"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get"]
        goto p171
        ::p236::
        registers[6] = "At targets"
        goto p12
        ::p239::
        if not registers[5] then
            goto p175
        end
        goto p159
        ::p255::
        registers[6] = (registers[6] ~= registers[0])
        if not registers[6] then
            goto p69
        end
        goto p15
    end
end
