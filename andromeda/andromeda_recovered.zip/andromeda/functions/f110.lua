-- Recovered function f110; author names are unavailable.
F.f110 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f110")
        tick(1)
        goto p27
        ::p3::
        tick(3)
        registers[8] = registers[4] / 4503599627370496
        registers[8] = registers[3] + registers[8]
        registers[7] = registers[7] * registers[8]
        goto p82
        ::p7::
        tick(7)
        registers[4] = upvalues[1]
        registers[5] = registers[2]
        a = registers
        z = 6;
        a[z] = 1
        goto p117
        ::p16::
        tick(16)
        registers[5] = (1)
        registers[3] = (0)
        goto p66
        ::p27::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (1)
        goto p7
        ::p40::
        tick(40)
        if registers[4] ~= 0 then
            goto p16
        end
        goto p146
        ::p47::
        tick(47);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        registers[6] = upvalues[1]
        a = registers
        z = 7
        q = registers
        q = q[2]
        a[z] = q
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        registers[6] = 1 ^ registers[6]
        registers[6] = -registers[6]
        goto p94
        ::p65::
        tick(65)
        do
            return registers[7]
        end
        ::p66::
        tick(66)
        registers[7] = (registers[5] - 1023)
        registers[7] = 2 ^ registers[7]
        registers[7] = registers[6] * registers[7]
        goto p3
        ::p82::
        do
            return registers[7]
        end
        ::p94::
        if registers[5] ~= 0 then
            goto p132
        end
        goto p40
        ::p96::
        tick(96)
        registers[7] = (registers[6] * 1)
        registers[7] = registers[7] / 0
        goto p144
        ::p99::
        tick(99)
        registers[7] = (registers[4] == 0)
        if not registers[7] then
            goto p144
        end
        goto p96
        ::p112::
        tick(112)
        registers[6] = registers[2]
        registers[7] = (21)
        registers[8] = (31)
        goto p47
        ::p117::
        registers[7] = (20);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[4] = (registers[4] * 4294967296)
        registers[4] = registers[4] + registers[1]
        registers[5] = upvalues[1]
        goto p112
        ::p132::
        if registers[5] ~= 2047 then
            goto p66
        end
        goto p99
        ::p144::
        if registers[7] then
            goto p65
        end
        goto p157
        ::p146::
        registers[7] = (registers[6] * 0)
        do
            return registers[7]
        end
        ::p157::
        registers[7] = (registers[6] * 0)
        registers[7] = registers[7] / 0
        goto p65
    end
end
