-- Recovered function f483; author names are unavailable.
F.f483 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f483")
        tick(1)
        goto p59
        ::p2::
        tick(2)
        registers[5] = upvalues[0]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_int"]
        registers[7] = registers[4]
        if not registers[7] then
            goto p97
        end
        goto p153
        ::p7::
        tick(7);
        registers[3](registers[4], registers[5])
        a = upvalues[2]
        a[2][a[1]] = (false)
        goto p126
        ::p16::
        tick(16)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["set_int"]
        registers[5] = upvalues[0]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["get_string"]
        goto p34
        ::p21::
        tick(21);
        registers[5](registers[6], registers[7])
        goto p93
        ::p32::
        tick(32)
        registers[7] = (1)
        goto p103
        ::p34::;
        registers[(5)] = registers[(5)](registers[6])
        registers[5] = (registers[5] == "1")
        if not registers[5] then
            goto p45
        end
        goto p81
        ::p38::
        tick(38)
        registers[4] = registers[1]["type"]
        registers[4] = (registers[4] == "knife")
        if not registers[3] then
            goto p68
        end
        goto p2
        ::p42::
        tick(42);
        registers[5](registers[6], registers[7])
        goto p93
        ::p45::
        tick(45)
        if registers[5] then
            goto p7
        end
        goto p133
        ::p59::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        if registers[2] ~= registers[0] then
            goto p63
        end
        goto p67
        ::p63::
        registers[2] = upvalues[1]["viewmodel_options"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"]
        registers[4] = "Opposite Knife"
        goto p99
        ::p67::
        do
            return 
        end
        ::p68::
        registers[5] = upvalues[0]
        z = registers[5]
        registers[6] = z;
        registers[(5)] = z["set_raw_int"]
        registers[7] = registers[4]
        if not registers[7] then
            goto p103
        end
        goto p32
        ::p73::
        tick(73)
        registers[3] = upvalues[0]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_string"];
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = (registers[3] == "1")
        goto p38
        ::p79::
        tick(79)
        registers[7] = (0)
        goto p21
        ::p81::
        registers[5] = (1)
        goto p45
        ::p93::
        a = upvalues[2]
        a[2][a[1]] = (true)
        goto p126
        ::p95::
        tick(95)
        if registers[1] == registers[0] then
            goto p135
        end
        goto p73
        ::p97::
        tick(97)
        if registers[7] then
            goto p42
        end
        goto p129
        ::p99::
        registers[2] = registers[2](registers[3], registers[4])
        if not registers[2] then
            goto p135
        end
        goto p95
        ::p103::
        if registers[7] then
            goto p21
        end
        goto p79
        ::p126::
        tick(126)
        do
            return 
        end
        ::p129::
        a = registers
        z = 7;
        a[z] = 1
        goto p42
        ::p133::
        registers[5] = (0)
        goto p7
        ::p135::
        a = upvalues[2];
        registers[3] = a[2][a[1]]
        if not registers[3] then
            goto p126
        end
        goto p16
        ::p153::
        registers[7] = (0)
        goto p97
    end
end
