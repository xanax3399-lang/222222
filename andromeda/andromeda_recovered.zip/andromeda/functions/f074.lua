-- Recovered function f74; author names are unavailable.
F.f74 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f74")
        tick(1)
        goto p14
        ::p2::
        tick(2)
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[4](unpack_range(top, registers, 5)))
        z = 0
        for f = 4, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[2] == registers[4]
        registers[7] = registers[3] == registers[5]
        registers[8] = registers[6]
        if not registers[8] then
            goto p65
        end
        goto p32
        ::p9::
        tick(9)
        registers[5] = environment["coroutine"]
        registers[5] = registers[5]["create"]
        registers[6] = registers[1]
        goto p2
        ::p14::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["pcall"]
        registers[3] = registers[1]
        m, x = pack_returns(registers[2](unpack_range(3, registers, 3)))
        z = 0
        for f = 2, 3 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = environment["coroutine"]
        registers[4] = registers[4]["resume"]
        goto p9
        ::p32::
        registers[8] = registers[7]
        ::p65::
        registers[9] = registers[2]
        registers[10] = registers[3]
        do
            return unpack_range(10, registers, (8))
        end
    end
end
