-- Recovered function f387; author names are unavailable.
F.f387 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f387")
        tick(1)
        goto p117
        ::p3::
        tick(3)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p54
        end
        goto p126
        ::p5::
        tick(5)
        registers[3] = (1)
        registers[4] = (#registers[2])
        registers[5] = (1)
        goto p45
        ::p18::
        tick(18)
        do
            return 
        end
        ::p19::
        tick(19)
        registers[8] = upvalues[2]
        registers[9] = registers[7]
        registers[10] = "m_vecOrigin"
        registers[8] = registers[8](registers[9], registers[10])
        registers[9] = upvalues[0]["predict_player_position"]
        goto p63
        ::p33::
        tick(33)
        registers[10] = upvalues[0]["shifted_players"]
        registers[10][registers[7]] = registers[8]
        registers[10] = upvalues[1][36]
        registers[11] = registers[7]
        registers[12] = "m_vecOrigin"
        registers[13] = registers[9]["x"]
        registers[14] = registers[9]["y"]
        registers[15] = registers[9]["z"]
        registers[(10)](unpack_range(15, registers, 11))
        goto p3
        ::p43::
        tick(43)
        if registers[8] == registers[0] then
            goto p3
        end
        goto p61
        ::p45::
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p3
        ::p46::
        tick(46)
        do
            return 
        end
        ::p48::
        tick(48)
        registers[8] = upvalues[1][42]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] then
            goto p3
        end
        goto p19
        ::p54::
        registers[7] = registers[2][registers[6]]
        registers[8] = upvalues[1][50]
        registers[9] = registers[7];
        registers[(8)] = registers[(8)](registers[9])
        if not registers[8] then
            goto p3
        end
        goto p48
        ::p61::
        if registers[9] == registers[8] then
            goto p3
        end
        goto p33
        ::p63::
        registers[10] = registers[7]
        registers[11] = registers[8]
        registers[9] = registers[9](registers[10], registers[11])
        if registers[9] == registers[0] then
            goto p3
        end
        goto p43
        ::p68::
        tick(68)
        registers[1] = upvalues[1][32];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p97
        end
        goto p121
        ::p93::
        tick(93);
        registers[1] = registers[1]()
        if not (registers[1] <= 0) then
            goto p68
        end
        goto p18
        ::p97::
        tick(97)
        do
            return 
        end
        ::p99::
        tick(99)
        registers[2] = upvalues[1][49]
        registers[3] = (true);
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] ~= registers[0] then
            goto p5
        end
        goto p46
        ::p117::
        registers[1] = upvalues[0]["restore_all"]
        registers[(1)]()
        registers[1] = upvalues[0]["get_ticks"]
        goto p93
        ::p121::
        registers[2] = upvalues[1][50]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] then
            goto p99
        end
        goto p97
        ::p126::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
    end
end
