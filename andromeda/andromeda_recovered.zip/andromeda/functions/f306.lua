-- Recovered function f306; author names are unavailable.
F.f306 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2 = nil, nil, nil
        local a = nil
        local tick = new_tick("f306")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        if slot_1 ~= slot_0 then
            goto p6
        end
        do
            return 
        end
        ::p6::
        slot_2 = "native_indicator_alpha:"..slot_1
        upvalues[0][slot_2] = (0)
        slot_2 = "native_indicator_slide:"..slot_1
        upvalues[0][slot_2] = (1)
        do
            return 
        end
    end
end
