-- Recovered function f292; author names are unavailable.
F.f292 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f292")
        tick(1)
        goto p113
        ::p10::
        tick(10);
        registers[(8)] = registers[(8)](registers[9])
        branch_taken = false
        if registers[8] ~= "number" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p220
        end
        goto p173
        ::p13::
        tick(13)
        registers[25] = environment["type"]
        registers[26] = registers[23];
        registers[(25)] = registers[(25)](registers[26])
        registers[25] = (registers[25] == "number")
        if not registers[25] then
            goto p38
        end
        goto p273
        ::p19::
        tick(19)
        registers[14] = upvalues[1]["freestand_cache"]
        registers[15] = {
        }
        registers[15]["tick"] = registers[2]
        registers[15]["side"] = registers[13]
        registers[14][registers[1]] = registers[15]
        registers[14] = registers[13]
        do
            return registers[14]
        end
        ::p26::
        tick(26)
        if registers[3] == registers[0] then
            goto p212
        end
        goto p47
        ::p35::
        tick(35)
        if registers[5] then
            goto p124
        end
        goto p80
        ::p38::
        tick(38)
        if registers[25] then
            goto p285
        end
        goto p256
        ::p42::
        tick(42)
        registers[30] = registers[22]
        registers[31] = registers[7];
        registers[24] = registers[24](unpack_range(31, registers, 25))
        goto p13
        ::p47::
        registers[4] = registers[3]["tick"]
        if registers[4] ~= registers[2] then
            goto p212
        end
        goto p176
        ::p52::
        tick(52)
        do
            return registers[9]
        end
        ::p61::
        tick(61)
        registers[22] = registers[6] + registers[22]
        registers[23] = upvalues[0][78]
        registers[24] = registers[4]
        registers[25] = registers[5]
        goto p235
        ::p67::
        tick(67)
        registers[11] = (0)
        registers[12] = (0)
        registers[13] = (30)
        registers[14] = (120)
        goto p122
        ::p72::
        tick(72)
        registers[19] = upvalues[0][148]
        registers[20] = registers[17];
        registers[(19)] = registers[(19)](registers[20])
        registers[19] = 256 * registers[19]
        registers[19] = registers[5] + registers[19]
        registers[20] = upvalues[0][163]
        registers[21] = registers[17]
        goto p230
        ::p80::
        registers[5] = (1)
        goto p124
        ::p85::
        tick(85)
        if registers[8] then
            goto p259
        end
        goto p161
        ::p87::
        tick(87)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p128
        end
        goto p251
        ::p89::
        tick(89)
        registers[9] = (registers[3] ~= registers[0])
        if not registers[9] then
            goto p166
        end
        goto p270
        ::p92::
        tick(92)
        registers[13] = -1
        goto p19
        ::p94::
        tick(94)
        registers[5] = upvalues[0][50]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if registers[5] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p225
        end
        goto p186
        ::p99::
        tick(99)
        registers[22] = registers[18];
        registers[(21)] = registers[(21)](registers[22])
        registers[21] = 256 * registers[21]
        registers[21] = registers[5] + registers[21]
        registers[22] = upvalues[0][163]
        goto p266
        ::p113::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][23];
        registers[2] = registers[2]()
        registers[3] = upvalues[1]["freestand_cache"]
        registers[3] = registers[3][registers[1]]
        goto p26
        ::p120::
        tick(120)
        registers[25] = (0)
        goto p125
        ::p122::
        registers[15] = (30)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p87
        ::p124::
        do
            return registers[5]
        end
        ::p125::
        tick(125)
        registers[12] = registers[12] + registers[25]
        goto p87
        ::p128::
        registers[17] = upvalues[0][171]
        registers[18] = (registers[10] - registers[16]);
        registers[(17)] = registers[(17)](registers[18])
        goto p275
        ::p161::
        registers[8] = (1)
        goto p259
        ::p163::
        tick(163)
        registers[25] = registers[24]
        goto p168
        ::p166::
        tick(166)
        if registers[9] then
            goto p52
        end
        goto p294
        ::p168::
        tick(168)
        if registers[25] then
            goto p125
        end
        goto p120
        ::p171::
        tick(171)
        registers[13] = (1)
        goto p178
        ::p173::
        registers[8] = (registers[3] ~= registers[0])
        if not registers[8] then
            goto p85
        end
        goto p292
        ::p176::
        registers[4] = registers[3]["side"]
        do
            return registers[4]
        end
        ::p178::
        tick(178)
        if registers[13] then
            goto p19
        end
        goto p92
        ::p180::
        tick(180)
        registers[30] = registers[7];
        registers[23] = registers[23](unpack_range(30, registers, 24))
        registers[24] = upvalues[0][78]
        registers[25] = registers[4]
        registers[26] = registers[5]
        goto p216
        ::p186::
        tick(186)
        registers[5] = (registers[3] ~= registers[0])
        if not registers[5] then
            goto p35
        end
        goto p240
        ::p212::
        registers[4] = upvalues[0][32];
        registers[4] = registers[4]()
        if registers[4] == registers[0] then
            goto p186
        end
        goto p94
        ::p216::
        registers[27] = registers[6]
        registers[28] = registers[7]
        registers[29] = registers[21]
        goto p42
        ::p220::
        registers[8] = upvalues[2]
        registers[9] = registers[1];
        registers[(8)] = registers[(8)](registers[9])
        if registers[8] ~= registers[0] then
            goto p242
        end
        goto p89
        ::p225::
        registers[5] = upvalues[0][91]
        m, x = pack_returns(registers[5]())
        z = 0
        for f = 5, 7 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = environment["type"]
        registers[9] = registers[5]
        goto p10
        ::p230::;
        registers[(20)] = registers[(20)](registers[21])
        registers[20] = 256 * registers[20]
        registers[20] = registers[6] + registers[20]
        registers[21] = upvalues[0][148]
        goto p99
        ::p235::
        registers[26] = registers[6]
        registers[27] = registers[7]
        registers[28] = registers[19]
        registers[29] = registers[20]
        goto p180
        ::p240::
        registers[5] = registers[3]["side"]
        goto p35
        ::p242::
        registers[9] = upvalues[3]
        registers[10] = registers[5]
        registers[11] = registers[6]
        registers[12] = registers[7];
        registers[9] = registers[9](unpack_range(12, registers, 10))
        registers[9] = (registers[8] - registers[9])
        z = registers[9]
        registers[10] = z;
        registers[(9)] = z["angles"]
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        z = 0
        for f = 9, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p67
        ::p251::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[13] = registers[11] < registers[12]
        if not registers[13] then
            goto p178
        end
        goto p171
        ::p256::
        registers[25] = (0)
        goto p285
        ::p259::
        do
            return registers[8]
        end
        ::p266::
        registers[23] = registers[18];
        registers[(22)] = registers[(22)](registers[23])
        registers[22] = 256 * registers[22]
        goto p61
        ::p270::
        registers[9] = registers[3]["side"]
        goto p166
        ::p273::
        registers[25] = registers[23]
        goto p38
        ::p275::
        registers[18] = upvalues[0][171]
        registers[19] = registers[10] + registers[16];
        registers[(18)] = registers[(18)](registers[19])
        goto p72
        ::p285::
        registers[11] = registers[11] + registers[25]
        registers[25] = environment["type"]
        registers[26] = registers[24];
        registers[(25)] = registers[(25)](registers[26])
        registers[25] = (registers[25] == "number")
        if not registers[25] then
            goto p168
        end
        goto p163
        ::p292::
        registers[8] = registers[3]["side"]
        goto p85
        ::p294::
        registers[9] = (1)
        goto p52
    end
end
