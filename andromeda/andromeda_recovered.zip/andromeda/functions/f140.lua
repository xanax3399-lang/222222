-- Recovered function f140; author names are unavailable.
F.f140 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f140")
        tick(1)
        goto p78
        ::p16::
        tick(16)
        if registers[2] ~= registers[0] then
            goto p64
        end
        goto p66
        ::p19::
        tick(19)
        upvalues[0][registers[1]] = registers[3]
        registers[6] = registers[3]
        registers[7] = registers[4]
        registers[8] = registers[5]
        do
            return unpack_range(8, registers, (6))
        end
        ::p24::
        tick(24)
        do
            return 
        end
        ::p28::
        tick(28)
        do
            return 
        end
        ::p29::
        tick(29)
        if registers[2] == registers[3] then
            goto p28
        end
        goto p19
        ::p46::
        tick(46)
        branch_taken = false
        if registers[4] ~= 3 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p24
        end
        goto p76
        ::p64::
        branch_taken = false
        if registers[4] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p24
        end
        goto p46
        ::p66::
        upvalues[0][registers[1]] = registers[3]
        do
            return 
        end
        ::p76::
        if registers[5] ~= registers[0] then
            goto p29
        end
        goto p24
        ::p78::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][registers[1]]
        z = registers[1]
        registers[4] = z;
        registers[(3)] = z["get"]
        m, x = pack_returns(registers[3](unpack_range(4, registers, 4)))
        z = 0
        for f = 3, 5 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p16
    end
end
