-- Recovered function f233; author names are unavailable.
F.f233 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f233")
        tick(1)
        goto p68
        ::p2::
        tick(2)
        slot_5 = nil
        do
            return slot_5
        end
        ::p4::
        tick(4)
        if slot_4 ~= 40 then
            goto p57
        end
        goto p8
        ::p6::
        tick(6)
        slot_3 = nil
        do
            return slot_3
        end
        ::p8::
        slot_5 = "Scout"
        do
            return slot_5
        end
        ::p10::
        tick(10)
        slot_5 = "Desert Eagle"
        do
            return slot_5
        end
        ::p33::
        tick(33)
        if slot_3 ~= "sniperrifle" then
            goto p2
        end
        goto p4
        ::p46::
        tick(46)
        slot_3 = slot_2["type"]
        slot_4 = slot_2["idx"]
        if slot_3 ~= "pistol" then
            goto p33
        end
        goto p80
        ::p50::
        tick(50)
        slot_5 = "Revolver R8"
        do
            return slot_5
        end
        ::p52::
        tick(52)
        slot_5 = "Auto Snipers"
        do
            return slot_5
        end
        ::p55::
        tick(55)
        slot_5 = "AWP"
        do
            return slot_5
        end
        ::p57::
        if slot_4 ~= 9 then
            goto p52
        end
        goto p55
        ::p68::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = upvalues[0]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        if slot_2 ~= slot_0 then
            goto p46
        end
        goto p6
        ::p76::
        tick(76)
        if slot_4 ~= 64 then
            goto p78
        end
        goto p50
        ::p78::
        slot_5 = "Pistols"
        do
            return slot_5
        end
        ::p80::
        if slot_4 ~= 1 then
            goto p76
        end
        goto p10
    end
end
