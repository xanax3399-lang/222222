-- Recovered function f430; author names are unavailable.
F.f430 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f430")
        tick(1)
        goto p89
        ::p6::
        tick(6)
        do
            return 
        end
        ::p35::
        tick(35);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["gsub"]
        registers[6] = "%-"
        registers[7] = "+";
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[3] = registers[4]
        registers[4] = (#registers[3])
        goto p58
        ::p45::
        tick(45)
        do
            return 
        end
        ::p46::
        tick(46)
        registers[5] = registers[2][registers[3]]
        if not registers[5] then
            goto p78
        end
        goto p6
        ::p58::
        registers[4] = registers[4] % 4
        branch_taken = false
        if registers[4] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p46
        end
        registers[5] = environment["string"]
        registers[5] = registers[5]["rep"]
        registers[6] = "="
        registers[7] = 4 - registers[4]
        registers[5] = registers[5](registers[6], registers[7])
        registers[3] = (registers[3]..registers[5])
        goto p46
        ::p78::
        registers[2][registers[3]] = true
        registers[5] = (#registers[1])
        registers[5] = registers[5] + 1
        registers[1][registers[5]] = registers[3]
        do
            return 
        end
        ::p89::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        goto p106
        ::p95::
        tick(95)
        z = registers[3]
        registers[5] = z;
        registers[(4)] = z["gsub"]
        registers[6] = "_"
        registers[7] = "/"
        goto p35
        ::p99::
        tick(99)
        registers[4] = (#registers[3])
        branch_taken = false
        if not (not (registers[4] < 16)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p95
        end
        goto p45
        ::p106::
        registers[3] = registers[4]
        if registers[3] == registers[0] then
            goto p45
        end
        goto p99
    end
end
