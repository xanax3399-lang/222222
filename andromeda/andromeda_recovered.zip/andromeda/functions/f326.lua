-- Recovered function f326; author names are unavailable.
F.f326 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4 = nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f326")
        tick(1)
        goto p30
        ::p4::
        tick(4)
        slot_2 = slot_1["write_revision"]
        slot_2 = slot_2 + 1
        slot_1["write_revision"] = slot_2
        goto p66
        ::p27::
        tick(27);
        slot_2 = slot_2(slot_3)
        branch_taken = false
        if slot_2 ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p4
        end
        goto p39
        ::p30::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1["configs_db"]
        goto p27
        ::p35::
        tick(35)
        slot_4 = slot_1["configs_db"];
        slot_2(slot_3, slot_4)
        slot_2 = (true)
        do
            return slot_2
        end
        ::p39::
        slot_2 = (false)
        do
            return slot_2
        end
        ::p41::
        tick(41)
        slot_3 = slot_1["write_revision"]
        slot_2["revision"] = slot_3
        slot_2 = slot_1["configs_db"]
        slot_3 = upvalues[0][30];
        slot_3 = slot_3()
        slot_2["saved_at"] = slot_3
        slot_2 = upvalues[0][122]
        slot_3 = slot_1["db"]
        goto p99
        ::p66::
        slot_2 = slot_1["configs_db"]
        slot_3 = slot_1["version"]
        slot_2["version"] = slot_3
        slot_2 = slot_1["configs_db"]
        goto p41
        ::p99::
        slot_4 = slot_1["configs_db"];
        slot_2(slot_3, slot_4)
        slot_2 = upvalues[0][122]
        slot_3 = slot_1["backup_db"]
        goto p35
    end
end
