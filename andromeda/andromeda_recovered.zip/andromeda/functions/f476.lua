-- Recovered function f476; author names are unavailable.
F.f476 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f476")
        tick(1)
        goto p5
        ::p2::
        tick(2)
        slot_1 = upvalues[1]
        slot_1()
        do
            return 
        end
        ::p5::
        slot_1 = upvalues[0]["is_quit"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p2
        end
        do
            return 
        end
    end
end
