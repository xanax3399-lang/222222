-- Recovered function f485; author names are unavailable.
F.f485 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f485")
        tick(1)
        goto p181
        ::p2::
        tick(2);
        registers[1](registers[2], registers[3])
        goto p49
        ::p4::
        tick(4);
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = (registers[3] == "1")
        if not registers[3] then
            goto p158
        end
        goto p256
        ::p15::
        tick(15)
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] then
            goto p234
        end
        goto p101
        ::p19::
        tick(19)
        registers[1] = upvalues[8]
        if registers[1] == registers[0] then
            goto p136
        end
        goto p300
        ::p24::
        tick(24)
        registers[3] = (68)
        goto p62
        ::p26::
        tick(26)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_y"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        goto p294
        ::p30::
        tick(30)
        if registers[3] then
            goto p229
        end
        goto p109
        ::p49::
        tick(49)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_y"]
        if registers[1] == registers[0] then
            goto p250
        end
        goto p26
        ::p53::
        tick(53)
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] then
            goto p161
        end
        goto p187
        ::p58::
        tick(58)
        registers[1] = upvalues[6]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = upvalues[4]
        goto p111
        ::p62::
        tick(62);
        registers[1](registers[2], registers[3])
        goto p323
        ::p64::
        tick(64)
        registers[1] = environment["cvar"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q["viewmodel_fov"]
        a[z] = q
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = environment["tonumber"]
        goto p308
        ::p95::
        tick(95)
        registers[1] = upvalues[3]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = upvalues[4]
        registers[4] = upvalues[3]
        registers[5] = (0)
        goto p272
        ::p101::
        registers[3] = environment["cvar"]
        registers[3] = registers[3]["viewmodel_offset_z"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_float"];
        registers[(3)] = registers[(3)](registers[4])
        goto p234
        ::p109::
        registers[3] = (0)
        goto p229
        ::p111::
        registers[4] = upvalues[6]
        registers[5] = (0)
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        goto p236
        ::p116::
        tick(116)
        registers[1] = upvalues[5]
        if registers[1] == registers[0] then
            goto p231
        end
        goto p194
        ::p125::
        tick(125)
        registers[3] = (0)
        goto p218
        ::p127::
        tick(127);
        registers[1](registers[2], registers[3])
        goto p204
        ::p136::
        tick(136)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_fov"]
        if registers[1] == registers[0] then
            goto p323
        end
        goto p64
        ::p141::
        tick(141)
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_x"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = environment["tonumber"]
        registers[4] = environment["cvar"]
        registers[4] = registers[4]["viewmodel_offset_x"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get_string"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] then
            goto p192
        end
        goto p282
        ::p158::
        tick(158)
        if registers[3] then
            goto p218
        end
        goto p125
        ::p161::
        tick(161)
        if registers[3] then
            goto p62
        end
        goto p24
        ::p176::
        tick(176)
        registers[3] = environment["cvar"]
        registers[3] = registers[3]["viewmodel_offset_y"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_float"];
        registers[(3)] = registers[(3)](registers[4])
        goto p30
        ::p181::
        registers[1] = upvalues[0]
        registers[(1)]()
        a = upvalues[1]
        a[2][a[1]] = (0)
        a = upvalues[2];
        registers[1] = a[2][a[1]]
        if not registers[1] then
            goto p241
        end
        goto p312
        ::p187::
        registers[3] = environment["cvar"]
        registers[3] = registers[3]["viewmodel_fov"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_float"];
        registers[(3)] = registers[(3)](registers[4])
        goto p161
        ::p192::
        tick(192)
        if registers[3] then
            goto p2
        end
        goto p254
        ::p194::
        registers[1] = upvalues[5]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = upvalues[4]
        goto p245
        ::p204::
        tick(204)
        do
            return 
        end
        ::p216::
        tick(216);
        registers[(3)] = registers[(3)](registers[4])
        goto p192
        ::p218::;
        registers[1](registers[2], registers[3])
        a = upvalues[7]
        a[2][a[1]] = (false)
        goto p136
        ::p221::
        tick(221)
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get_string"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[3] = registers[3](unpack_range(top, registers, 4))
        if registers[3] then
            goto p30
        end
        goto p176
        ::p226::
        tick(226)
        registers[3] = (0)
        goto p127
        ::p229::;
        registers[1](registers[2], registers[3])
        goto p250
        ::p231::
        tick(231)
        registers[1] = upvalues[6]
        if registers[1] == registers[0] then
            goto p236
        end
        goto p58
        ::p234::
        if registers[3] then
            goto p127
        end
        goto p226
        ::p236::
        a = upvalues[2]
        a[2][a[1]] = (false)
        ::p241::
        a = upvalues[7];
        registers[1] = a[2][a[1]]
        if not registers[1] then
            goto p136
        end
        goto p19
        ::p245::
        registers[4] = upvalues[5]
        registers[5] = (0)
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        goto p231
        ::p250::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_z"]
        if registers[1] == registers[0] then
            goto p204
        end
        goto p258
        ::p254::
        registers[3] = (0)
        goto p2
        ::p256::
        registers[3] = (1)
        goto p158
        ::p258::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_z"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = environment["tonumber"]
        registers[4] = environment["cvar"]
        registers[4] = registers[4]["viewmodel_offset_z"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get_string"]
        goto p15
        ::p272::
        m, x = pack_returns(registers[3](unpack_range(5, registers, 4)))
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[1](unpack_range(top, registers, 2))
        goto p116
        ::p282::
        a = registers
        z = (3)
        q = environment
        q = q["cvar"]
        a[z] = q
        registers[3] = registers[3]["viewmodel_offset_x"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_float"]
        goto p216
        ::p294::
        registers[3] = environment["tonumber"]
        registers[4] = environment["cvar"]
        registers[4] = registers[4]["viewmodel_offset_y"]
        goto p221
        ::p300::
        a = registers
        z = 1
        q = upvalues
        q = q[8]
        a[z] = q
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_int"]
        registers[3] = upvalues[8]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get_string"]
        goto p4
        ::p308::
        registers[4] = environment["cvar"]
        registers[4] = registers[4]["viewmodel_fov"]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["get_string"]
        goto p53
        ::p312::
        registers[1] = upvalues[3]
        if registers[1] == registers[0] then
            goto p116
        end
        goto p95
        ::p323::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["viewmodel_offset_x"]
        if registers[1] == registers[0] then
            goto p49
        end
        goto p141
    end
end
