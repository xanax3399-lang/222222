-- Recovered function f284; author names are unavailable.
F.f284 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f284")
        tick(1)
        goto p42
        ::p20::
        tick(20)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p25::
        tick(25)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_4 = v
            branch_taken = true
        end
        if branch_taken then
            goto p28
        end
        goto p20
        ::p28::
        slot_5 = upvalues[0]
        slot_6 = slot_4
        slot_5(slot_6)
        goto p25
        ::p42::
        slot_1 = (1)
        slot_2 = (64)
        slot_3 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_3 + 0
        n = (slot_2 + 0)
        v = (slot_1 - U)
        goto p25
        error("ANDROMEDA_INVALID_FALLTHROUGH: f284 pc=45", 0)
    end
end
