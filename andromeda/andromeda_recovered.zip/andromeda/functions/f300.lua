-- Recovered function f300; author names are unavailable.
F.f300 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f300")
        tick(1)
        goto p66
        ::p2::
        tick(2)
        registers[2] = upvalues[0]["miss_counter"]
        registers[2][registers[1]] = 1
        goto p117
        ::p6::
        tick(6)
        registers[2] = upvalues[0]["resolved"]
        registers[3] = {
        }
        registers[3]["angle"] = 0
        registers[3]["yaw"] = 0
        registers[2][registers[1]] = registers[3]
        goto p97
        ::p12::
        tick(12)
        registers[3]["stable_side"] = 1
        registers[3]["last_yaw_delta"] = 0
        registers[2][registers[1]] = registers[3]
        ::p16::
        tick(16)
        registers[2] = upvalues[0]["miss_counter"]
        registers[2] = registers[2][registers[1]]
        if registers[2] ~= registers[0] then
            goto p117
        end
        goto p2
        ::p52::
        tick(52)
        registers[2] = upvalues[0]["ent_store"]
        registers[3] = {
        }
        registers[2][registers[1]] = registers[3]
        goto p121
        ::p56::
        tick(56)
        registers[3]["stored_yaw_sp"] = registers[4]
        registers[4] = {
        }
        registers[3]["stored_eye_angles"] = registers[4]
        registers[3]["last_side"] = 1
        registers[3]["last_angle"] = 0
        registers[3]["jitter_ticks"] = 0
        registers[3]["positive_votes"] = 0
        registers[3]["negative_votes"] = 0
        goto p12
        ::p66::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["resolved"]
        registers[2] = registers[2][registers[1]]
        if registers[2] ~= registers[0] then
            goto p97
        end
        goto p6
        ::p97::
        registers[2] = upvalues[0]["records"]
        registers[2] = registers[2][registers[1]]
        if registers[2] ~= registers[0] then
            goto p16
        end
        goto p105
        ::p102::
        tick(102)
        registers[4] = upvalues[0]["ent_store"]
        registers[4] = registers[4][registers[1]]
        do
            return unpack_range(4, registers, (2))
        end
        ::p105::
        registers[2] = upvalues[0]["records"]
        registers[3] = {
        }
        registers[3]["n_yaw"] = registers[0]
        registers[4] = upvalues[1][23]
        goto p127
        ::p117::
        registers[2] = upvalues[0]["ent_store"]
        registers[2] = registers[2][registers[1]]
        if registers[2] ~= registers[0] then
            goto p121
        end
        goto p52
        ::p121::
        registers[2] = upvalues[0]["resolved"]
        registers[2] = registers[2][registers[1]]
        registers[3] = upvalues[0]["records"]
        registers[3] = registers[3][registers[1]]
        goto p102
        ::p127::;
        registers[4] = registers[4]()
        registers[3]["yaw_update_tick"] = registers[4]
        registers[4] = {
        }
        registers[3]["stored_yaw_angles"] = registers[4]
        registers[4] = {
        }
        goto p56
    end
end
