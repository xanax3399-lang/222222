-- Recovered function f310; author names are unavailable.
F.f310 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f310")
        tick(1)
        goto p23
        ::p19::
        tick(19)
        do
            return 
        end
        ::p23::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["r_aspectratio"]
        if registers[1] ~= registers[0] then
            goto p57
        end
        goto p83
        ::p27::
        tick(27)
        registers[1] = environment["cvar"]
        a = registers
        z = (1)
        q = registers
        q = q[1]
        q = q["r_aspectratio"]
        a[z] = q
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        goto p70
        ::p34::
        tick(34)
        registers[1] = upvalues[0]["aspect_ratio_value"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if not (49 < registers[1]) then
            goto p87
        end
        goto p27
        ::p57::
        registers[1] = upvalues[0]["aspect_ratio"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if not registers[1] then
            goto p87
        end
        goto p34
        ::p70::
        registers[3] = upvalues[0]["aspect_ratio_value"]
        z = registers[3]
        registers[4] = z;
        registers[(3)] = z["get"];
        registers[(3)] = registers[(3)](registers[4])
        goto p84
        ::p83::
        do
            return 
        end
        ::p84::
        registers[3] = (registers[3] * 0.01);
        registers[1](registers[2], registers[3])
        goto p19
        ::p87::
        registers[1] = environment["cvar"]
        registers[1] = registers[1]["r_aspectratio"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["set_float"]
        registers[3] = upvalues[1];
        registers[1](registers[2], registers[3])
        goto p19
    end
end
