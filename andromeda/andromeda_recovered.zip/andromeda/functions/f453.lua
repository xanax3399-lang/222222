-- Recovered function f453; author names are unavailable.
F.f453 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f453")
        tick(1)
        goto p67
        ::p2::
        tick(2)
        registers[11] = registers[10] * registers[9]
        registers[11] = (registers[6] - registers[11])
        registers[12] = upvalues[2]
        registers[13] = registers[11]
        goto p143
        ::p40::
        tick(40)
        registers[7] = upvalues[0][151]
        registers[8] = (0)
        registers[9] = registers[3]
        if registers[9] then
            goto p119
        end
        goto p65
        ::p45::
        tick(45)
        registers[10] = upvalues[0][154]
        registers[11] = registers[5];
        registers[(10)] = registers[(10)](registers[11])
        goto p2
        ::p49::
        tick(49)
        if registers[6] then
            goto p40
        end
        goto p102
        ::p65::
        registers[9] = (0)
        goto p119
        ::p67::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = upvalues[0][30];
        registers[5] = registers[5]()
        registers[5] = (registers[5] * 5)
        registers[6] = registers[1]
        goto p49
        ::p80::
        tick(80)
        registers[14] = (registers[14] * 0.001)
        registers[12] = registers[12](registers[13], registers[14])
        registers[11] = registers[12]
        registers[12] = registers[11]
        do
            return registers[12]
        end
        ::p102::
        registers[6] = (0)
        goto p40
        ::p105::
        tick(105)
        registers[10] = upvalues[0][161]
        registers[11] = registers[4]
        if registers[11] then
            goto p111
        end
        goto p140
        ::p111::
        tick(111)
        m, x = pack_returns(registers[10](unpack_range(11, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = registers[7] + registers[8]
        registers[9] = registers[9] / 2
        if registers[9] ~= 0 then
            goto p45
        end
        goto p135
        ::p119::
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[0][151]
        registers[9] = (0)
        goto p105
        ::p123::
        tick(123)
        registers[14] = (0)
        goto p80
        ::p135::
        registers[10] = upvalues[1]["normalize"]
        registers[11] = registers[6]
        registers[12] = -180
        registers[13] = (180)
        goto p142
        ::p140::
        registers[11] = (0)
        goto p111
        ::p142::
        do
            return registers[(10)](unpack_range(13, registers, 11))
        end
        ::p143::
        registers[14] = registers[2]
        if registers[14] then
            goto p80
        end
        goto p123
    end
end
