-- Recovered function f111; author names are unavailable.
F.f111 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f111")
        tick(1)
        goto p6
        ::p2::
        tick(2)
        registers[15] = upvalues[1]
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        goto p181
        ::p6::
        registers[1] = (1)
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        registers[3] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[3] + 0
        n = (registers[2] + 0)
        v = (registers[1] - U)
        goto p62
        ::p11::
        tick(11)
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        goto p55
        ::p32::
        tick(32)
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p157
        ::p40::
        tick(40)
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p78
        ::p44::
        tick(44)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        goto p83
        ::p53::
        tick(53)
        if registers[15] then
            goto p40
        end
        goto p2
        ::p55::
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        goto p32
        ::p59::
        tick(59)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p94
        ::p62::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[4] = v
            branch_taken = true
        end
        if branch_taken then
            goto p94
        end
        goto p204
        ::p64::
        tick(64)
        registers[14] = upvalues[0];
        registers[14] = registers[14]()
        goto p196
        ::p78::
        tick(78)
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        if not registers[15] then
            goto p83
        end
        goto p44
        ::p83::
        registers[5][registers[14]] = registers[15]
        registers[14] = upvalues[3]
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[16] = upvalues[0]
        goto p140
        ::p89::
        tick(89);
        registers[2] = registers[2]()
        registers[3] = upvalues[0]
        m, x = pack_returns(registers[3]())
        m = m + 3 - 1
        top = m
        z = 0
        for f = 3, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[1](unpack_range(top, registers, 2))
        end
        ::p94::
        registers[5] = {
        }
        registers[6] = (0)
        registers[7] = (255)
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p202
        registers[26] = (registers[26] - 440)
        registers[26] = 30061 + registers[26]
        registers[26] = registers[26] + -29713
        registers[19][83] = registers[26]
        registers[25][38] = 77
        registers[18] = nil
        registers[19] = nil
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        goto p78
        ::p140::
        m, x = pack_returns(registers[16]())
        m = m + 16 - 1
        top = m
        z = 0
        for f = 16, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[14] = registers[14](unpack_range(top, registers, 15))
        registers[15] = new_frame(1)
        goto p208
        ::p144::
        tick(144)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[13] = v
            branch_taken = true
        end
        if branch_taken then
            goto p188
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p222
        ::p157::
        registers[10] = upvalues[1]
        registers[11] = upvalues[0];
        registers[11] = registers[11]()
        registers[12] = upvalues[0]
        m, x = pack_returns(registers[12]())
        m = m + 12 - 1
        top = m
        z = 0
        for f = 12, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[10] = registers[10](unpack_range(top, registers, 11))
        registers[11] = upvalues[1]
        registers[12] = upvalues[0];
        registers[12] = registers[12]()
        registers[13] = upvalues[0]
        m, x = pack_returns(registers[13]())
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[11] = registers[11](unpack_range(top, registers, 12))
        registers[5][registers[10]] = registers[11]
        goto p202
        ::p181::
        registers[17] = upvalues[2]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[15](unpack_range(top, registers, 16))
        goto p40
        ::p188::
        registers[14] = upvalues[2];
        registers[14] = registers[14]()
        if not registers[14] then
            goto p196
        end
        goto p64
        ::p192::
        tick(192)
        registers[10] = (0)
        registers[11] = (255)
        registers[12] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[12] + 0
        n = (registers[11] + 0)
        v = (registers[10] - U)
        goto p144
        ::p196::
        registers[15] = upvalues[2];
        registers[15] = registers[15]()
        registers[15] = registers[5][registers[15]]
        goto p53
        ::p202::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p11
        end
        goto p216
        ::p204::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[1] = upvalues[1]
        registers[2] = upvalues[2]
        goto p89
        ::p208::
        registers[16] = upvalues[2];
        registers[16] = registers[16]()
        registers[17] = upvalues[0]
        m, x = pack_returns(registers[17]())
        m = m + 17 - 1
        top = m
        z = 0
        for f = 17, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(15)]
        for f = 1, top - (15) do
            q[(0) + f] = registers[(15) + f]
        end
        registers[5][registers[14]] = registers[15]
        goto p144
        ::p216::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[6] = (1)
        registers[7] = upvalues[0];
        registers[7] = registers[7]()
        registers[8] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[8] + 0
        n = (registers[7] + 0)
        v = (registers[6] - U)
        goto p222
        ::p222::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[9] = v
            branch_taken = true
        end
        if branch_taken then
            goto p192
        end
        goto p59
    end
end
