-- Recovered function f289; author names are unavailable.
F.f289 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f289")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (slot_2 - slot_1)
        slot_4 = upvalues[0][157]
        slot_5 = slot_3["y"]
        slot_6 = slot_3["x"]
        slot_5 = (slot_5 / slot_6)
        goto p44
        ::p15::
        tick(15)
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p30::
        tick(30)
        slot_5 = upvalues[1]
        slot_6 = slot_4 + 180
        slot_7 = (180)
        slot_5 = slot_5(slot_6, slot_7)
        slot_4 = slot_5
        goto p15
        ::p44::;
        slot_4 = slot_4(slot_5)
        slot_5 = upvalues[1]
        slot_6 = (slot_4 * 180)
        goto p93
        ::p60::
        tick(60)
        slot_5 = slot_5(slot_6, slot_7)
        slot_4 = slot_5
        slot_5 = slot_3["x"]
        branch_taken = false
        if not (not (0 <= slot_5)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p15
        end
        goto p30
        ::p93::
        slot_7 = environment["math"]
        slot_7 = slot_7["pi"]
        slot_6 = (slot_6 / slot_7)
        slot_7 = (180)
        goto p60
    end
end
