-- Recovered function f156; author names are unavailable.
F.f156 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local tick = new_tick("f156")
        tick(1)
        goto p7
        ::p4::
        tick(4)
        registers[(2)](unpack_range(5, registers, 3))
        if registers[1] then
            goto p21
        end
        goto p13
        ::p7::
        registers[1] = upvalues[0]["is_enabled"];
        registers[1] = registers[1]()
        if not registers[1] then
            goto p22
        end
        goto p24
        ::p11::
        tick(11)
        if registers[1] then
            goto p41
        end
        goto p39
        ::p13::
        registers[2] = upvalues[0]["restore_original"]
        registers[(2)]()
        goto p21
        ::p16::
        tick(16)
        upvalues[0]["active"] = registers[1]
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "setup_command"
        registers[4] = upvalues[0]["setup_command"]
        goto p29
        ::p21::
        do
            return 
        end
        ::p22::
        upvalues[0]["choked_commands"] = 0
        goto p36
        ::p24::
        registers[2] = upvalues[0]["capture_original"]
        registers[(2)]()
        registers[2] = upvalues[0]["sync"]
        registers[(2)]()
        goto p36
        ::p29::
        registers[5] = registers[1]
        registers[(2)](unpack_range(5, registers, 3))
        registers[2] = upvalues[1]["set_callback"]
        registers[3] = "paint"
        registers[4] = upvalues[0]["paint"]
        registers[5] = registers[1]
        goto p4
        ::p36::
        registers[2] = upvalues[0]["active"]
        if registers[2] ~= registers[1] then
            goto p16
        end
        goto p11
        ::p39::
        registers[2] = upvalues[0]["restore_original"]
        registers[(2)]()
        ::p41::
        do
            return 
        end
    end
end
