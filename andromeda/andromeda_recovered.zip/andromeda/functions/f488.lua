-- Recovered function f488; author names are unavailable.
F.f488 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local tick = new_tick("f488")
        tick(1)
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["viewmodel_offset_x"];
        slot_1 = slot_1(slot_2)
        if not slot_1 then
            goto p48
        end
        goto p51
        ::p48::
        slot_1 = upvalues[2]
        slot_1()
        do
            return 
        end
        ::p51::
        do
            return 
        end
    end
end
