-- Recovered function f318; author names are unavailable.
F.f318 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f318")
        tick(1)
        goto p80
        ::p2::
        tick(2)
        registers[14] = 255 * registers[14]
        registers[14] = registers[14] + 0.5;
        registers[(13)] = registers[(13)](registers[14])
        registers[14] = (0)
        goto p65
        ::p8::
        tick(8)
        registers[20] = 120 * registers[20];
        registers[(19)] = registers[(19)](registers[20])
        registers[20] = registers[7]
        goto p50
        ::p22::
        tick(22)
        registers[11] = upvalues[0]["get_planting_progress"];
        registers[11] = registers[11]()
        registers[12] = upvalues[2]["clamp"]
        registers[13] = upvalues[1][154]
        goto p166
        ::p39::
        tick(39)
        registers[9] = registers[5]
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[1][151]
        registers[9] = (3)
        registers[10] = upvalues[0]["px"]
        goto p132
        ::p46::
        tick(46)
        do
            return 
        end
        ::p48::
        tick(48)
        registers[20] = (1)
        goto p8
        ::p50::
        registers[21] = (0)
        registers[22] = (1)
        registers[23] = registers[8]
        registers[(13)](unpack_range(23, registers, 14))
        if not (0 < registers[11]) then
            goto p46
        end
        goto p61
        ::p57::
        tick(57)
        registers[16] = (0)
        registers[17] = (0)
        registers[18] = (0)
        goto p151
        ::p61::
        registers[13] = upvalues[1][127]
        registers[14] = registers[9]
        registers[15] = registers[10]
        goto p124
        ::p65::
        registers[15] = (255);
        registers[12] = registers[12](unpack_range(15, registers, 13))
        registers[13] = upvalues[1][127]
        registers[14] = registers[9]
        registers[15] = registers[10]
        goto p57
        ::p77::
        tick(77)
        m, x = pack_returns(registers[23](unpack_range(25, registers, 24)))
        m = m + 23 - 1
        top = m
        z = 0
        for f = 23, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[13](unpack_range(top, registers, 14))
        goto p46
        ::p80::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = a[6]
        registers[7] = upvalues[0]["px"]
        registers[8] = (8)
        goto p39
        ::p99::
        tick(99)
        registers[14] = (1)
        goto p2
        ::p118::
        tick(118)
        registers[23] = upvalues[1][151]
        registers[24] = (2)
        registers[25] = (registers[8] - 2)
        goto p77
        ::p124::
        registers[16] = (230)
        registers[17] = (230)
        registers[18] = (230)
        registers[19] = registers[12]
        registers[20] = (registers[7] - 1)
        registers[21] = (0)
        registers[22] = registers[11]
        goto p118
        ::p132::
        registers[11] = (4)
        registers[12] = registers[5]
        m, x = pack_returns(registers[10](unpack_range(12, registers, 11)))
        m = m + 10 - 1
        top = m
        z = 0
        for f = 10, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[8] = registers[8](unpack_range(top, registers, 9))
        registers[9] = registers[1] + registers[3]
        registers[10] = upvalues[0]["px"]
        goto p175
        ::p151::
        registers[19] = upvalues[1][154]
        registers[20] = registers[6]
        if registers[20] then
            goto p8
        end
        goto p48
        ::p162::
        tick(162)
        registers[11] = registers[11] + 0.5;
        registers[(10)] = registers[(10)](registers[11])
        registers[10] = registers[2] + registers[10]
        goto p22
        ::p166::
        registers[14] = registers[6]
        if registers[14] then
            goto p2
        end
        goto p99
        ::p175::
        registers[11] = (12)
        registers[12] = registers[5]
        registers[10] = registers[10](registers[11], registers[12])
        registers[9] = (registers[9] - registers[10])
        registers[10] = upvalues[1][154]
        registers[11] = (registers[4] * 0.5)
        goto p162
    end
end
