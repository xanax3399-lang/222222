-- Recovered function f407; author names are unavailable.
F.f407 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f407")
        tick(1)
        goto p201
        ::p2::
        tick(2)
        branch_taken = false
        if registers[3] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p116
        end
        registers[4] = registers[1]["yaw"]
        registers[5] = registers[1]["yaw"]
        registers[5] = registers[5]["add"]
        goto p289
        ::p8::
        tick(8)
        registers[4] = registers[4]["value"];
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        goto p197
        ::p13::
        tick(13)
        registers[4] = registers[2];
        registers[(3)] = registers[(3)](registers[4])
        if not registers[2] then
            goto p2
        end
        goto p70
        ::p24::
        tick(24);
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["edge_yaw"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["edge_yaw"]
        goto p292
        ::p64::
        tick(64)
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["yaw"]
        registers[4] = registers[4]["type"];
        registers[2](registers[3], registers[4])
        goto p144
        ::p70::
        registers[4] = registers[1]["yaw"]
        registers[5] = registers[1]["yaw"]
        registers[5] = registers[5]["add"]
        goto p277
        ::p74::
        tick(74)
        registers[2] = registers[2]["freestanding_body_yaw"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["body_yaw"]
        registers[4] = registers[4]["freestanding"];
        registers[2](registers[3], registers[4])
        goto p128
        ::p96::
        tick(96)
        registers[6] = upvalues[3]["normalize"]
        registers[7] = registers[1]["yaw"]
        registers[7] = registers[7]["value"]
        registers[8] = registers[1]["yaw"]
        registers[8] = registers[8]["add"]
        registers[7] = registers[7] + registers[8]
        registers[8] = registers[1]["yaw"]
        registers[8] = registers[8]["body"]
        registers[7] = registers[7] + registers[8]
        goto p210
        ::p116::
        tick(116)
        registers[4] = upvalues[0]["antiaim"]
        registers[4] = registers[4]["angles"]
        registers[4] = registers[4]["yaw"]
        registers[4] = registers[4][2]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["override"]
        goto p96
        ::p128::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["freestanding"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["freestanding"];
        registers[2](registers[3], registers[4])
        goto p185
        ::p135::
        tick(135)
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["yaw"]
        registers[4] = registers[4]["base"];
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[1];
        registers[2] = registers[2]()
        registers[3] = upvalues[2]
        goto p13
        ::p144::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["yaw_base"]
        goto p135
        ::p148::
        tick(148)
        if not registers[4] then
            goto p183
        end
        goto p285
        ::p151::
        tick(151)
        registers[4] = registers[4]["yaw_jitter"]
        registers[4] = registers[4][1]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["override"]
        goto p240
        ::p155::
        tick(155)
        registers[2] = registers[2]["hotkey"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["freestanding"]
        goto p148
        ::p159::
        tick(159)
        registers[4] = upvalues[3]["normalize"]
        registers[5] = registers[1]["body_yaw"]
        registers[5] = registers[5]["value"]
        goto p233
        ::p177::
        tick(177)
        registers[4] = new_frame(1)
        registers[5] = "On hotkey"
        q = registers[(4)]
        q[1] = registers[5]
        goto p24
        ::p183::
        tick(183)
        if registers[4] then
            goto p24
        end
        goto p177
        ::p185::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["freestanding"]
        goto p155
        ::p197::
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["yaw"]
        registers[2] = registers[2][1]
        goto p64
        ::p201::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["enabled"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = (true);
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        goto p265
        ::p210::
        registers[8] = -180
        registers[9] = (180)
        m, x = pack_returns(registers[6](unpack_range(9, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[4](unpack_range(top, registers, 5))
        registers[4] = upvalues[0]["antiaim"]
        registers[4] = registers[4]["angles"]
        goto p151
        ::p218::
        tick(218)
        registers[4] = registers[1]["pitch"]
        registers[4] = registers[4]["type"];
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        goto p270
        ::p224::
        tick(224)
        registers[2] = registers[2]["roll"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = (0);
        registers[2](registers[3], registers[4])
        do
            return 
        end
        ::p229::
        tick(229);
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        goto p280
        ::p233::
        registers[6] = -180
        registers[7] = (180)
        m, x = pack_returns(registers[4](unpack_range(7, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end;
        registers[2](unpack_range(top, registers, 3))
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        goto p74
        ::p240::
        registers[6] = "Off";
        registers[4](registers[5], registers[6])
        registers[4] = upvalues[0]["antiaim"]
        registers[4] = registers[4]["angles"]
        registers[4] = registers[4]["yaw_jitter"]
        registers[4] = registers[4][2]
        z = registers[4]
        registers[5] = z;
        registers[(4)] = z["override"]
        registers[6] = (0);
        registers[4](registers[5], registers[6])
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["body_yaw"]
        registers[2] = registers[2][1]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["body_yaw"]
        registers[4] = registers[4]["type"]
        goto p229
        ::p265::
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["pitch"]
        registers[2] = registers[2][1]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        goto p218
        ::p270::
        registers[2] = registers[2]["angles"]
        registers[2] = registers[2]["pitch"]
        registers[2] = registers[2][2]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        registers[4] = registers[1]["pitch"]
        goto p8
        ::p277::
        registers[5] = registers[5] + 180
        registers[4]["add"] = registers[5]
        goto p116
        ::p280::
        registers[2] = registers[2]["body_yaw"]
        registers[2.0] = registers[2][2]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["override"]
        goto p159
        ::p285::
        registers[4] = new_frame(1)
        registers[5] = "Always on"
        q = registers[(4)]
        q[1] = registers[5]
        goto p183
        ::p289::
        registers[5] = registers[5] + registers[3]
        registers[4]["add"] = registers[5]
        goto p116
        ::p292::;
        registers[2](registers[3], registers[4])
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["angles"]
        goto p224
    end
end
