-- Recovered function f84; author names are unavailable.
F.f84 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local tick = new_tick("f84")
        tick(1)
        a = {
            ...,
        }
        slot_1 = a[1]
        a = upvalues[0];
        slot_2 = a[2][a[1]]
        slot_2 = slot_2 + slot_1
        goto p27
        ::p13::
        tick(13)
        a = upvalues[0];
        slot_2 = a[2][a[1]]
        slot_2 = slot_2 % slot_1
        do
            return slot_2
        end
        ::p27::
        slot_3 = upvalues[1]
        slot_2 = slot_2 + slot_3
        a = upvalues[0]
        a[2][a[1]] = slot_2
        goto p13
    end
end
