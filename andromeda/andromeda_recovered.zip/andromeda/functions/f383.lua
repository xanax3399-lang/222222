-- Recovered function f383; author names are unavailable.
F.f383 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f383")
        tick(1)
        goto p32
        ::p10::
        tick(10)
        registers[2] = upvalues[0]["output_console"]
        registers[3] = registers[1]
        registers[(2)](registers[3])
        goto p80
        ::p24::
        tick(24)
        registers[(4)](registers[5])
        goto p35
        ::p26::
        tick(26)
        registers[4] = (1)
        registers[5] = {
        }
        registers[5]["segments"] = registers[1]
        goto p75
        ::p30::
        tick(30)
        do
            return 
        end
        ::p32::
        a = {
            ...,
        }
        registers[1] = a[1]
        if registers[1] ~= registers[0] then
            goto p10
        end
        goto p30
        ::p35::
        tick(35)
        registers[2] = upvalues[0]["items"]
        registers[2] = (#registers[2])
        registers[3] = upvalues[0]["max_items"]
        if not (registers[3] < registers[2]) then
            goto p50
        end
        goto p70
        ::p50::
        do
            return 
        end
        ::p70::
        registers[4] = environment["table"]
        registers[4] = registers[4]["remove"]
        registers[5] = upvalues[0]["items"]
        goto p24
        ::p75::
        registers[6] = upvalues[1][30];
        registers[6] = registers[6]()
        registers[5]["time"] = registers[6]
        registers[(2)](unpack_range(5, registers, 3))
        goto p35
        ::p80::
        registers[2] = environment["table"]
        registers[2] = registers[2]["insert"]
        registers[3.0] = upvalues[0]["items"]
        goto p26
    end
end
