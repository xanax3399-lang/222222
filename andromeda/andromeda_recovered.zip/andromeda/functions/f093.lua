-- Recovered function f93; author names are unavailable.
F.f93 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f93")
        tick(1)
        goto p59
        ::p34::
        tick(34)
        registers[3] = upvalues[2]
        a = registers
        z = 4
        q = registers
        q = q[1]
        a[z] = q;
        registers[(3)] = registers[(3)](registers[4])
        registers[2] = (registers[2]..registers[3])
        do
            return registers[2]
        end
        ::p54::
        tick(54)
        registers[4] = (1899447441);
        registers[1] = registers[1](unpack_range(4, registers, 2))
        a = upvalues[1];
        registers[2] = a[2][a[1]]
        goto p34
        ::p59::
        registers[1] = upvalues[0]
        registers[2] = (770255983)
        registers[3] = (275423344)
        goto p54
    end
end
