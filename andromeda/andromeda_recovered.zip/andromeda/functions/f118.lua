-- Recovered function f118; author names are unavailable.
F.f118 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f118")
        tick(1)
        goto p101
        ::p3::
        tick(3)
        slot_5 = slot_1 % slot_5
        slot_5 = (slot_5 >= slot_4)
        if not slot_5 then
            goto p104
        end
        goto p72
        ::p26::
        tick(26)
        slot_5 = (0)
        goto p44
        ::p40::
        tick(40)
        slot_6 = (slot_2 - 1)
        slot_5 = (slot_5 - slot_6)
        slot_5 = slot_5 + 1
        goto p78
        ::p44::
        tick(44)
        do
            return slot_5
        end
        ::p66::
        tick(66)
        slot_4 = (slot_2 - 1)
        slot_4 = 2 ^ slot_4
        slot_5 = slot_4 + slot_4
        goto p3
        ::p72::
        slot_5 = (1)
        goto p104
        ::p78::
        slot_5 = 2 ^ slot_5
        slot_4 = slot_4 % slot_5
        slot_5 = slot_4 % 1
        goto p111
        ::p101::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        if not slot_3 then
            goto p66
        end
        goto p106
        ::p104::
        if slot_5 then
            goto p44
        end
        goto p26
        ::p106::
        slot_4 = (slot_2 - 1)
        slot_4 = 2 ^ slot_4
        slot_4 = (slot_1 / slot_4)
        slot_5 = (slot_3 - 1)
        goto p40
        ::p111::
        slot_5 = (slot_4 - slot_5)
        do
            return slot_5
        end
    end
end
