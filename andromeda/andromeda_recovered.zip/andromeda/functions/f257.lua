-- Recovered function f257; author names are unavailable.
F.f257 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f257")
        tick(1)
        goto p62
        ::p21::
        tick(21)
        do
            return 
        end
        ::p23::
        tick(23)
        slot_3[2] = slot_4
        slot_5 = slot_1["configs_db"]
        slot_5 = slot_5["menu_list"]
        slot_6 = slot_3[1]
        slot_5[slot_2] = slot_6
        z = slot_1
        slot_6 = z;
        slot_5 = z["write_db"];
        slot_5 = slot_5(slot_6)
        if not slot_5 then
            goto p42
        end
        goto p50
        ::p32::
        tick(32)
        slot_4 = upvalues[0][86]
        slot_5 = "play resource/warning.wav"
        slot_4(slot_5)
        do
            return 
        end
        ::p37::
        tick(37)
        slot_4 = environment["type"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        branch_taken = false
        if slot_4 ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p57
        end
        goto p32
        ::p42::
        slot_5 = upvalues[0][86]
        slot_6 = "play resource/warning.wav"
        slot_5(slot_6)
        goto p21
        ::p46::
        tick(46)
        slot_5 = upvalues[0][86]
        slot_6 = "play resource/warning.wav"
        slot_5(slot_6)
        do
            return 
        end
        ::p50::
        slot_5 = upvalues[0][86]
        slot_6 = "play ui\\beepclear"
        slot_5(slot_6)
        goto p21
        ::p57::
        z = slot_1
        slot_5 = z;
        slot_4 = z["build_encoded_payload"];
        slot_4 = slot_4(slot_5)
        if slot_4 ~= slot_0 then
            goto p23
        end
        goto p46
        ::p62::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = slot_1["configs_db"]
        slot_3 = slot_3["cfg_list"]
        slot_3 = slot_3[slot_2]
        goto p37
    end
end
