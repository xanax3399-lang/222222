-- Recovered function f102; author names are unavailable.
F.f102 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f102")
        tick(1)
        goto p96
        ::p5::
        tick(5)
        branch_taken = false
        if registers[9] ~= 1 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p148
        end
        goto p17
        ::p15::
        tick(15)
        if registers[11] == registers[0] then
            goto p104
        end
        goto p106
        ::p17::
        if registers[9] ~= 2 then
            goto p74
        end
        goto p148
        ::p27::
        tick(27);
        registers[7] = registers[7](unpack_range(10, registers, 8))
        registers[8] = environment["pairs"]
        registers[9] = upvalues[1]["layers"]
        m, x = pack_returns(registers[8](unpack_range(9, registers, 9)))
        z = 0
        for f = 8, 10 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p65
        ::p33::
        tick(33);
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[10]["weight"] = registers[13]
        goto p104
        ::p42::
        tick(42)
        registers[13] = upvalues[2]["lerp"]
        registers[14] = registers[11]["weight"]
        registers[15] = registers[12]["weight"]
        registers[16] = registers[7]
        goto p33
        ::p47::
        tick(47)
        registers[8] = upvalues[2]["lerp"]
        registers[9] = registers[4]["duck_amount"]
        registers[10] = registers[5]["duck_amount"]
        registers[11] = registers[7]
        goto p57
        ::p54::
        tick(54)
        do
            return 
        end
        ::p57::;
        registers[8] = registers[8](unpack_range(11, registers, 9))
        upvalues[1]["last_duck_amount"] = registers[8]
        registers[8] = registers[4]["weapon"]
        upvalues[1]["last_weapon"] = registers[8]
        do
            return 
        end
        ::p65::
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(8)]
        n = registers[9]
        U = registers[10]
        goto p104
        ::p66::
        tick(66)
        registers[4] = (#registers[3])
        registers[4] = (registers[4] - 1)
        registers[4] = registers[3][registers[4]]
        registers[5] = (#registers[3])
        registers[5] = registers[3][registers[5]]
        if registers[4] == registers[0] then
            goto p54
        end
        goto p124
        ::p74::
        tick(74)
        registers[13] = upvalues[2]["lerp"]
        registers[14] = registers[11]["cycle"]
        registers[15] = registers[12]["cycle"]
        registers[16] = registers[7];
        registers[13] = registers[13](unpack_range(16, registers, 14))
        registers[10]["cycle"] = registers[13]
        goto p42
        ::p96::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = upvalues[0]
        registers[4] = registers[1]
        registers[5] = "Smooth"
        registers[3] = registers[3](registers[4], registers[5])
        if registers[3] then
            goto p115
        end
        goto p191
        ::p104::
        tick(104)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[9] = z;
            registers[10] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p198
        end
        goto p142
        ::p106::
        tick(106)
        if registers[12] == registers[0] then
            goto p104
        end
        goto p5
        ::p108::
        tick(108)
        registers[6] = registers[5]["time"]
        registers[7] = registers[4]["time"]
        registers[6] = (registers[6] - registers[7])
        if not (registers[6] <= 0) then
            goto p162
        end
        goto p114
        ::p113::
        tick(113)
        do
            return 
        end
        ::p114::
        do
            return 
        end
        ::p115::
        registers[3] = upvalues[1]["server_anim_states"]
        registers[4] = (#registers[3])
        branch_taken = false
        if not (not (registers[4] < 2)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p66
        end
        goto p113
        ::p119::
        tick(119)
        registers[13] = registers[12]["cycle"]
        registers[10]["cycle"] = registers[13]
        registers[13] = registers[12]["weight"]
        registers[10]["weight"] = registers[13]
        goto p104
        ::p124::
        if registers[5] ~= registers[0] then
            goto p108
        end
        goto p54
        ::p136::
        tick(136)
        registers[9] = registers[4]["time"]
        registers[8] = (registers[8] - registers[9])
        registers[8] = (registers[8] / registers[6])
        registers[9] = (0)
        registers[10] = (1)
        goto p27
        ::p142::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[8] = upvalues[2]["lerp"]
        registers[9] = registers[4]["velocity"]
        registers[10] = registers[5]["velocity"]
        goto p211
        ::p148::
        registers[13] = registers[4]["weapon"]
        registers[14] = registers[5]["weapon"]
        if registers[13] == registers[14] then
            goto p74
        end
        goto p119
        ::p162::
        registers[7] = upvalues[2]["clamp"]
        registers[8] = upvalues[3][30];
        registers[8] = registers[8]()
        goto p136
        ::p178::
        tick(178)
        registers[11] = registers[4]["layers"]
        registers[11] = registers[11][registers[9]]
        registers[12] = registers[5]["layers"]
        registers[12] = registers[12][registers[9]]
        if registers[10] == registers[0] then
            goto p104
        end
        goto p15
        ::p191::
        do
            return 
        end
        ::p198::
        z = registers[2]
        registers[11] = z;
        registers[(10)] = z["get_anim_overlay"]
        registers[12] = registers[9]
        registers[10] = registers[10](registers[11], registers[12])
        goto p178
        ::p211::
        registers[11] = registers[7];
        registers[8] = registers[8](unpack_range(11, registers, 9))
        upvalues[1]["last_velocity"] = registers[8]
        goto p47
    end
end
