-- Recovered function f78; author names are unavailable.
F.f78 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f78")
        tick(1)
        goto p62
        ::p3::
        tick(3)
        registers[14] = registers[2][registers[6]]
        registers[14] = registers[14]["str"]
        registers[(13)](registers[14])
        goto p87
        ::p8::
        tick(8)
        registers[13] = registers[2][registers[6]]
        registers[13] = registers[13]["threshold"]
        branch_taken = false
        if not (registers[13] < registers[12]) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p56
        end
        goto p38
        ::p25::
        tick(25)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p99
        end
        goto p165
        ::p34::
        tick(34)
        registers[3]["threshold"] = 0.01
        registers[3]["char"] = "T"
        registers[4] = {
        }
        goto p139
        ::p38::
        branch_taken = false
        if not (not (registers[12] < 0)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p214
        end
        goto p56
        ::p41::
        tick(41)
        registers[9] = " - "..registers[9]
        registers[8] = (registers[8]..registers[9])
        registers[3] = (registers[3]..registers[8])
        goto p235
        ::p46::
        tick(46)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p25
        goto p62
        ::p56::
        tick(56)
        registers[13] = registers[2][registers[6]]
        registers[14] = registers[2][registers[6]]
        registers[14] = registers[14]["count"]
        registers[14] = registers[14] + 1
        registers[13]["count"] = registers[14]
        goto p214
        ::p62::
        registers[1] = environment["load"]
        registers[2] = new_frame(2)
        registers[3] = {
        }
        registers[4] = environment["tostring"]
        registers[3]["func"] = registers[4]
        registers[3]["str"] = ""
        registers[3]["count"] = 0
        goto p34
        ::p70::
        tick(70)
        registers[12] = "restart"
        registers[(11)](registers[12])
        a = D.f79
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[11] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end;
        registers[11] = registers[11]()
        registers[12] = environment["collectgarbage"]
        registers[13] = "count";
        registers[(12)] = registers[(12)](registers[13])
        registers[13] = registers[2][registers[6]]
        registers[13] = registers[13]["func"]
        goto p3
        ::p80::
        tick(80)
        registers[11] = registers[2][registers[6]]
        registers[12] = registers[2][registers[6]]
        registers[12] = registers[12]["str"]
        goto p155
        ::p85::
        tick(85)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[7] = v
            branch_taken = true
        end
        if branch_taken then
            goto p196
        end
        goto p149
        ::p87::
        registers[13] = environment["collectgarbage"]
        registers[14] = "count";
        registers[(13)] = registers[(13)](registers[14])
        registers[12] = (registers[13] - registers[12])
        if registers[11] then
            goto p56
        end
        goto p8
        ::p99::
        registers[7] = environment["pcall"]
        registers[8] = environment["jit"]
        registers[8] = registers[8]["on"]
        registers[9] = registers[2][registers[6]]
        registers[9] = registers[9]["func"];
        registers[7](registers[8], registers[9])
        registers[7] = (1)
        registers[8] = (111)
        goto p212
        ::p132::
        tick(132)
        registers[4]["threshold"] = 0.15
        registers[4]["char"] = "L"
        q = registers[(2)]
        q[1] = registers[3]
        q[2] = registers[4]
        registers[3] = (1)
        registers[4] = (#registers[2])
        registers[5] = (1)
        goto p46
        ::p139::
        registers[4]["func"] = registers[1]
        registers[4]["str"] = ""
        registers[4]["count"] = 0
        goto p132
        ::p149::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[4] = upvalues[0]
        registers[5] = {
        }
        registers[6] = upvalues[1]["CHECK_13_FAILED"]
        registers[5]["ban_num"] = registers[6]
        goto p200
        ::p155::
        registers[12] = registers[12].."\000"
        registers[11]["str"] = registers[12]
        registers[11] = environment["collectgarbage"]
        goto p70
        ::p165::
        tick(165)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[3] = registers[2][1]
        registers[3] = registers[3]["count"]
        if 32 <= registers[3] then
            goto p188
        end
        registers[4] = registers[2][2]
        registers[4] = registers[4]["count"]
        branch_taken = false
        if not (not (32 <= registers[4])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p195
        end
        ::p188::
        registers[3] = ""
        registers[4] = (1)
        registers[5] = (#registers[2])
        registers[6] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[6] + 0
        n = (registers[5] + 0)
        v = (registers[4] - U)
        goto p85
        goto p165
        ::p195::
        tick(195)
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p196::
        registers[8] = registers[2][registers[7]]
        registers[8] = registers[8]["char"]
        registers[9] = environment["tostring"]
        goto p229
        ::p200::
        registers[6] = registers[3].."][0x01]"
        registers[6] = " ["..registers[6]
        registers[6] = "[module] invalid"..registers[6]
        registers[5]["ban_info"] = registers[6]
        registers[(4)](registers[5])
        goto p195
        ::p212::
        registers[9] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[9] + 0
        n = (registers[8] + 0)
        v = (registers[7] - U)
        goto p214
        ::p214::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[10] = v
            branch_taken = true
        end
        if branch_taken then
            goto p80
        end
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p25
        ::p226::
        tick(226)
        registers[3] = registers[3]..", "
        goto p85
        ::p229::
        registers[10] = registers[2][registers[7]]
        registers[10] = registers[10]["count"];
        registers[(9)] = registers[(9)](registers[10])
        goto p41
        ::p235::
        registers[8] = (#registers[2])
        if not (registers[7] < registers[8]) then
            goto p85
        end
        goto p226
    end
end
