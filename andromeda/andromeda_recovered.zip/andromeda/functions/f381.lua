-- Recovered function f381; author names are unavailable.
F.f381 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f381")
        tick(1)
        tick(25)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = environment["string"]
        registers[2] = registers[2]["format"]
        registers[3] = "%02X%02X%02X%02X"
        goto p43
        ::p36::
        tick(36)
        registers[7] = registers[1]["a"]
        do
            return registers[(2)](unpack_range(7, registers, 3))
        end
        ::p43::
        registers[4] = registers[1]["r"]
        registers[5] = registers[1]["g"]
        registers[6] = registers[1]["b"]
        goto p36
    end
end
