-- Recovered function f99; author names are unavailable.
F.f99 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f99")
        tick(1)
        goto p23
        ::p8::
        tick(8)
        registers[4] = (0)
        goto p29
        ::p10::
        tick(10)
        registers[7] = upvalues[0]["lerp"]
        registers[8] = registers[1]["g"]
        registers[9] = registers[2]["g"]
        goto p88
        ::p14::
        tick(14)
        registers[9] = upvalues[0]["lerp"]
        a = registers
        z = (10)
        q = registers
        q = q[1]
        q = q["a"]
        a[z] = q
        registers[11] = registers[2]["a"]
        goto p143
        ::p23::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = environment["type"]
        registers[5] = registers[3];
        registers[(4)] = registers[(4)](registers[5])
        if registers[4] ~= "boolean" then
            goto p109
        end
        goto p101
        ::p29::
        tick(29)
        registers[3] = registers[4]
        goto p109
        ::p88::
        registers[10] = registers[3]
        m, x = pack_returns(registers[7](unpack_range(10, registers, 8)))
        m = m + 7 - 1
        top = m
        z = 0
        for f = 7, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[7] = upvalues[0]["round"]
        registers[8] = upvalues[0]["lerp"]
        a = registers
        z = (9)
        q = registers
        q = q[1]
        q = q["b"]
        a[z] = q
        registers[10] = registers[2]["b"]
        goto p117
        ::p99::
        tick(99)
        registers[4] = (1)
        goto p114
        ::p101::
        registers[4] = registers[3]
        if not registers[4] then
            goto p114
        end
        goto p99
        ::p104::
        tick(104)
        registers[7] = (1);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[3] = registers[4]
        registers[4] = upvalues[1]["new"]
        goto p122
        ::p109::
        registers[4] = upvalues[0]["clamp"]
        registers[5] = registers[3]
        registers[6] = (0)
        goto p104
        ::p114::
        if registers[4] then
            goto p29
        end
        goto p8
        ::p117::
        registers[11] = registers[3]
        m, x = pack_returns(registers[8](unpack_range(11, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[7] = registers[7](unpack_range(top, registers, 8))
        registers[8] = upvalues[0]["round"]
        goto p14
        ::p122::
        registers[5] = upvalues[0]["round"]
        registers[6] = upvalues[0]["lerp"]
        registers[7] = registers[1]["r"]
        registers[8] = registers[2]["r"]
        registers[9] = registers[3]
        m, x = pack_returns(registers[6](unpack_range(9, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[6] = upvalues[0]["round"]
        goto p10
        ::p143::
        registers[12] = registers[3]
        m, x = pack_returns(registers[9](unpack_range(12, registers, 10)))
        m = m + 9 - 1
        top = m
        z = 0
        for f = 9, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        m, x = pack_returns(registers[8](unpack_range(top, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        do
            return registers[4](unpack_range(top, registers, 5))
        end
    end
end
