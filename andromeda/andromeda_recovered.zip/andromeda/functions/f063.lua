-- Recovered function f63; author names are unavailable.
F.f63 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local n, v, R = nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f63")
        tick(1)
        goto p40
        ::p2::
        tick(2)
        slot_3 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_3 + 0
        n = (slot_2 + 0)
        v = (slot_1 - U)
        goto p47
        ::p4::
        tick(4)
        a = upvalues[1]
        a[2][a[1]] = slot_5
        goto p47
        ::p26::
        tick(26)
        a = upvalues[1];
        slot_5 = a[2][a[1]]
        slot_6 = upvalues[0][slot_4];
        slot_6 = slot_6()
        slot_5 = slot_5 + slot_6
        goto p4
        ::p31::
        tick(31)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        a = upvalues[2]
        a[2][a[1]] = (true)
        do
            return 
        end
        ::p40::
        slot_1 = (1)
        slot_2 = upvalues[0]
        slot_2 = (#slot_2)
        goto p2
        ::p47::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_4 = v
            branch_taken = true
        end
        if branch_taken then
            goto p26
        end
        goto p31
    end
end
