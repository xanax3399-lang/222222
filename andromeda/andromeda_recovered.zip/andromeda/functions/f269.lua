-- Recovered function f269; author names are unavailable.
F.f269 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f269")
        tick(1)
        goto p53
        ::p3::
        tick(3)
        registers[8] = environment["tostring"]
        registers[9] = registers[6];
        registers[(8)] = registers[(8)](registers[9])
        goto p90
        ::p21::
        tick(21)
        registers[5] = environment["pairs"]
        registers[6] = registers[3]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        z = 0
        for f = 5, 7 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(5)]
        n = registers[6]
        U = registers[7]
        goto p88
        ::p25::
        tick(25)
        do
            return 
        end
        ::p26::
        tick(26)
        if registers[8] then
            goto p90
        end
        goto p3
        ::p28::
        tick(28)
        registers[8] = registers[2]
        if not registers[8] then
            goto p26
        end
        goto p38
        ::p32::
        tick(32)
        registers[5] = upvalues[0]
        registers[6] = registers[3];
        registers[(5)] = registers[(5)](registers[6])
        if not registers[5] then
            goto p103
        end
        goto p101
        ::p38::
        registers[8] = environment["tostring"]
        registers[9] = registers[6];
        registers[(8)] = registers[(8)](registers[9])
        registers[8] = "."..registers[8]
        registers[8] = (registers[2]..registers[8])
        goto p26
        ::p44::
        tick(44)
        registers[4][registers[2]] = registers[3]
        do
            return 
        end
        ::p52::
        tick(52)
        do
            return 
        end
        ::p53::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        if registers[3] ~= registers[0] then
            goto p32
        end
        goto p52
        ::p57::
        tick(57)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p84::
        tick(84)
        registers[13] = registers[4]
        registers[(9)](unpack_range(13, registers, 10))
        ::p88::
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[6] = z;
            registers[7] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p28
        end
        goto p57
        ::p90::
        z = registers[1]
        registers[10] = z;
        registers[(9)] = z["add_handles"]
        registers[11] = registers[8]
        registers[12] = registers[7]
        goto p84
        ::p95::
        tick(95)
        do
            return 
        end
        ::p101::
        if registers[2] ~= "visuals.ragebot.hitchance.weapon" then
            goto p44
        end
        goto p25
        ::p103::
        registers[5] = environment["type"]
        registers[6] = registers[3];
        registers[(5)] = registers[(5)](registers[6])
        branch_taken = false
        if registers[5] ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p21
        end
        goto p95
    end
end
