-- Recovered function f113; author names are unavailable.
F.f113 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f113")
        tick(1)
        goto p65
        ::p7::
        tick(7)
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        a = registers
        z = 5
        q = registers
        q = q[4]
        m = registers
        x = 4
        m = m[x]
        q = q + m
        a[z] = q
        goto p31
        ::p25::
        tick(25)
        registers[5] = (0)
        goto p93
        ::p29::
        tick(29)
        registers[5] = (1)
        goto p101
        ::p31::
        registers[5] = registers[1] % registers[5]
        registers[5] = (registers[5] >= registers[4])
        if not registers[5] then
            goto p101
        end
        goto p29
        ::p65::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        if not registers[3] then
            goto p7
        end
        registers[4] = (registers[2] - 1)
        registers[4] = 2 ^ registers[4]
        registers[4] = (registers[1] / registers[4])
        registers[5] = (registers[3] - 1)
        registers[6] = (registers[2] - 1)
        registers[5] = (registers[5] - registers[6])
        registers[5] = registers[5] + 1
        registers[5] = 2 ^ registers[5]
        goto p94
        ::p93::
        tick(93)
        do
            return registers[5]
        end
        ::p94::
        registers[4] = registers[4] % registers[5]
        registers[5] = registers[4] % 1
        registers[5] = (registers[4] - registers[5])
        do
            return registers[5]
        end
        ::p101::
        if registers[5] then
            goto p93
        end
        goto p25
    end
end
