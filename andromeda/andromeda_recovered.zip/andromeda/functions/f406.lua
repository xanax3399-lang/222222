-- Recovered function f406; author names are unavailable.
F.f406 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3, slot_4, slot_5 = nil, nil, nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f406")
        tick(1)
        tick(2)
        slot_1 = upvalues[0]["skip_native_cleanup"];
        slot_1 = slot_1()
        if not slot_1 then
            goto p11
        end
        goto p57
        ::p11::
        slot_1 = upvalues[1]["visuals"]
        if slot_1 == slot_0 then
            goto p82
        end
        goto p62
        ::p24::
        tick(24)
        slot_4 = upvalues[1]["visuals"]
        slot_4 = slot_4["stubs"]
        slot_4 = slot_4["damage_indicator"]
        z = slot_4
        slot_5 = z;
        slot_4 = z["get"];
        slot_4 = slot_4(slot_5)
        if slot_4 then
            goto p83
        end
        goto p82
        ::p31::
        tick(31)
        do
            return 
        end
        ::p57::
        do
            return 
        end
        ::p59::
        tick(59)
        if slot_2 then
            goto p71
        end
        goto p31
        ::p62::
        slot_2 = upvalues[1]["visuals"]
        slot_2 = slot_2["stubs"]
        if slot_2 == slot_0 then
            goto p82
        end
        slot_3 = upvalues[1]["visuals"]
        slot_3 = slot_3["stubs"]
        slot_3 = slot_3["damage_indicator"]
        if slot_3 == slot_0 then
            goto p82
        end
        goto p24
        ::p71::
        slot_2 = upvalues[3]
        slot_2()
        do
            return 
        end
        ::p82::
        do
            return 
        end
        ::p83::
        slot_1 = upvalues[2][32];
        slot_1 = slot_1()
        if slot_1 == slot_0 then
            goto p31
        end
        slot_2 = upvalues[2][50]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        goto p59
    end
end
