-- Recovered function f341; author names are unavailable.
F.f341 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f341")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0];
        registers[2] = registers[2]()
        if registers[2] ~= true then
            goto p46
        end
        goto p49
        ::p13::
        tick(13)
        registers[3] = upvalues[2]["wraith"]
        registers[3] = registers[3]["flags"]
        registers[3] = registers[3][registers[1]]
        goto p54
        ::p36::
        tick(36)
        registers[3] = upvalues[3][33]
        registers[4] = registers[1];
        registers[(3)] = registers[(3)](registers[4])
        goto p152
        ::p46::
        tick(46)
        do
            return 
        end
        ::p49::
        registers[3] = upvalues[1]
        registers[4] = "Flags";
        registers[(3)] = registers[(3)](registers[4])
        branch_taken = false
        if registers[3] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p87
        end
        goto p46
        ::p54::
        registers[4] = (registers[3] ~= registers[0])
        registers[5] = registers[3]
        do
            return unpack_range(5, registers, (4))
        end
        ::p64::
        tick(64)
        registers[3] = upvalues[2]["wraith"]
        registers[3] = registers[3]["flags"]
        registers[3] = registers[3][registers[1]]
        registers[4] = upvalues[4]
        goto p123
        ::p84::
        tick(84)
        registers[4] = "MEDA"
        goto p142
        ::p87::
        registers[2] = upvalues[2]["resolved"]
        registers[2] = registers[2][registers[1]]
        if registers[2] == registers[0] then
            goto p64
        end
        goto p36
        ::p117::
        tick(117)
        registers[3] = upvalues[4];
        registers[3] = registers[3]()
        if registers[3] ~= "Auto" then
            goto p136
        end
        goto p13
        ::p121::
        tick(121)
        if registers[3] == registers[0] then
            goto p135
        end
        goto p149
        ::p123::;
        registers[4] = registers[4]()
        if registers[4] ~= "Auto" then
            goto p135
        end
        goto p121
        ::p132::
        tick(132)
        if registers[4] then
            goto p142
        end
        goto p84
        ::p135::
        do
            return 
        end
        ::p136::
        registers[3] = (true)
        registers[4] = registers[2]["jitter"]
        if not registers[4] then
            goto p132
        end
        registers[4] = "MEDA[J]"
        goto p132
        ::p142::
        do
            return unpack_range(4, registers, (3))
        end
        ::p149::
        registers[4] = (true)
        registers[5] = registers[3]
        do
            return unpack_range(5, registers, (4))
        end
        ::p152::
        branch_taken = false
        if registers[3] ~= true then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p117
        end
        goto p64
    end
end
