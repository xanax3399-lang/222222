-- Recovered function f4; author names are unavailable.
F.f4 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6 = nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f4")
        tick(1)
        goto p47
        ::p12::
        tick(12)
        slot_4 = slot_4 % slot_5
        slot_5 = slot_4 % 1
        slot_5 = (slot_4 - slot_5)
        do
            return slot_5
        end
        ::p36::
        tick(36)
        if slot_5 then
            goto p58
        end
        slot_5 = (0)
        goto p58
        ::p47::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        if not slot_3 then
            goto p54
        end
        goto p70
        ::p54::
        slot_4 = (slot_2 - 1)
        slot_4 = 2 ^ slot_4
        slot_5 = slot_4 + slot_4
        goto p66
        ::p58::
        do
            return slot_5
        end
        ::p59::
        tick(59)
        slot_6 = (slot_2 - 1)
        slot_5 = (slot_5 - slot_6)
        slot_5 = slot_5 + 1
        slot_5 = 2 ^ slot_5
        goto p12
        ::p66::
        slot_5 = slot_1 % slot_5
        slot_5 = (slot_5 >= slot_4)
        if not slot_5 then
            goto p36
        end
        goto p75
        ::p70::
        slot_4 = (slot_2 - 1)
        slot_4 = 2 ^ slot_4
        slot_4 = (slot_1 / slot_4)
        slot_5 = (slot_3 - 1)
        goto p59
        ::p75::
        slot_5 = (1)
        goto p36
    end
end
