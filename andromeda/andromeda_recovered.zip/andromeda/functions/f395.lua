-- Recovered function f395; author names are unavailable.
F.f395 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local environment = andromeda_environment
        local z, a = nil, nil
        local tick = new_tick("f395")
        tick(1)
        goto p4
        ::p2::
        tick(2)
        if slot_4 then
            goto p20
        end
        goto p8
        ::p4::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = environment["tostring"]
        slot_4 = slot_2
        goto p2
        ::p8::
        slot_4 = ""
        goto p20
        ::p10::
        tick(10)
        z = slot_4
        slot_6 = z;
        slot_5 = z["match"]
        slot_7 = "^([AB])"
        slot_5 = slot_5(slot_6, slot_7)
        goto p27
        ::p14::
        tick(14)
        slot_6 = "B"
        goto p18
        ::p16::
        tick(16)
        slot_5 = slot_3
        do
            return slot_5
        end
        ::p18::
        tick(18)
        slot_6 = slot_6.." - Planting"
        do
            return slot_6
        end
        ::p20::;
        slot_3 = slot_3(slot_4)
        slot_4 = environment["string"]
        slot_4 = slot_4["upper"]
        slot_5 = slot_3;
        slot_4 = slot_4(slot_5)
        if slot_1 ~= "bomb_planting" then
            goto p16
        end
        goto p10
        ::p27::
        slot_6 = slot_5
        if slot_6 then
            goto p18
        end
        goto p14
    end
end
