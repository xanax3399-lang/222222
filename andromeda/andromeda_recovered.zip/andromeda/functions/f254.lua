-- Recovered function f254; author names are unavailable.
F.f254 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f254")
        tick(1)
        goto p47
        ::p3::
        tick(3)
        slot_2 = upvalues[1][154]
        a = upvalues[3];
        slot_3 = a[2][a[1]]
        slot_3 = slot_3 + 0.5
        do
            return slot_2(slot_3)
        end
        ::p8::
        tick(8)
        slot_2 = (slot_1 - slot_2)
        branch_taken = false
        if not (not (1.5 <= slot_2)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p3
        end
        a = upvalues[0];
        slot_2 = a[2][a[1]]
        a = upvalues[2];
        slot_3 = a[2][a[1]]
        slot_3 = (slot_1 - slot_3)
        slot_2 = (slot_2 / slot_3)
        goto p31
        ::p27::
        tick(27)
        slot_1 = upvalues[1][30];
        slot_1 = slot_1()
        a = upvalues[2];
        slot_2 = a[2][a[1]]
        goto p8
        ::p31::
        a = upvalues[3]
        a[2][a[1]] = slot_2
        a = upvalues[0]
        a[2][a[1]] = (0)
        a = upvalues[2]
        a[2][a[1]] = slot_1
        goto p3
        ::p47::
        a = upvalues[0];
        slot_1 = a[2][a[1]]
        slot_1 = slot_1 + 1
        a = upvalues[0]
        a[2][a[1]] = slot_1
        goto p27
    end
end
