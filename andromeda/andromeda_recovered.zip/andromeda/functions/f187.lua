-- Recovered function f187; author names are unavailable.
F.f187 = function(function_metadata, upvalues)
    local operand_i, operand_k = function_metadata[2], function_metadata[11]
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f187")
        tick(1)
        goto p102
        ::p2::
        tick(2)
        registers[12] = registers[11]
        if not registers[12] then
            goto p107
        end
        goto p157
        ::p5::
        tick(5)
        registers[12] = (0)
        goto p136
        ::p7::
        tick(7)
        registers[11] = (registers[10] == "Spin")
        goto p145
        ::p21::
        tick(21)
        if not registers[1] then
            goto p153
        end
        goto p88
        ::p25::
        tick(25)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        goto p110
        ::p39::
        tick(39)
        if registers[11] then
            goto p145
        end
        goto p7
        ::p41::
        tick(41);
        registers[(2)] = registers[(2)](registers[3])
        registers[3] = (1)
        registers[4] = upvalues[2]
        registers[4] = (#registers[4])
        registers[5] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[5] + 0
        n = (registers[4] + 0)
        v = (registers[3] - U)
        goto p110
        registers[26] = operand_i
        registers[27] = operand_k
        registers[26][137] = 0
        registers[27][24] = 135
        registers[20] = nil
        registers[21] = nil
        registers[22] = nil
        registers[23] = nil
        registers[24] = nil
        registers[25] = nil
        registers[26] = nil
        registers[27] = nil
        goto p136
        ::p65::
        tick(65)
        registers[7] = upvalues[2][registers[6]]
        a = registers
        z = (8)
        q = registers
        q = q[7]
        q = q["modifiers"]
        a[z] = q
        registers[9] = registers[8]["custom"]
        goto p116
        ::p73::
        tick(73);
        registers[17](registers[18], registers[19])
        goto p122
        ::p77::
        tick(77)
        if not registers[11] then
            goto p79
        end
        goto p124
        ::p79::
        tick(79)
        if not registers[11] then
            goto p145
        end
        goto p92
        ::p81::
        tick(81)
        registers[14] = (10)
        a = registers
        z = 15;
        a[z] = 1
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[15] + 0
        n = (registers[14] + 0)
        v = (registers[13] - U)
        goto p122
        ::p85::
        tick(85)
        registers[11] = registers[7]["state_name"]
        registers[11] = registers[2] == registers[11]
        goto p77
        ::p88::
        registers[1] = upvalues[1];
        registers[1] = registers[1]()
        goto p153
        ::p92::
        registers[11] = (registers[10] == "Center")
        if registers[11] then
            goto p39
        end
        goto p166
        ::p95::
        tick(95)
        registers[19] = (registers[16] <= registers[12])
        goto p73
        ::p97::
        tick(97)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        do
            return 
        end
        ::p100::
        tick(100)
        registers[11] = (registers[11] == "Default")
        goto p79
        ::p102::
        registers[1] = upvalues[0]["switch"]
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        registers[1] = (registers[1] == "Anti-Aim")
        goto p21
        ::p107::
        tick(107)
        if registers[12] then
            goto p136
        end
        goto p5
        ::p110::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[6] = v
            branch_taken = true
        end
        if branch_taken then
            goto p65
        end
        goto p97
        ::p112::
        tick(112)
        registers[19] = registers[11]
        if not registers[19] then
            goto p73
        end
        goto p95
        ::p116::
        registers[10] = registers[8]["type"]
        z = registers[10]
        registers[11] = z;
        registers[(10)] = z["get"];
        registers[(10)] = registers[(10)](registers[11])
        registers[11] = registers[1]
        if not registers[11] then
            goto p77
        end
        goto p85
        ::p122::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[16] = v
            branch_taken = true
        end
        if branch_taken then
            goto p140
        end
        goto p25
        ::p124::
        registers[11] = registers[8]["builder_type"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        goto p100
        ::p136::
        registers[13] = upvalues[3][151]
        registers[14] = (0)
        registers[15] = upvalues[3][162]
        goto p168
        ::p140::
        registers[17] = registers[9]["slots"]
        registers[17] = registers[17][registers[16]]
        z = registers[17]
        registers[18] = z;
        registers[(17)] = z["set_visible"]
        goto p112
        ::p145::
        if not registers[11] then
            goto p2
        end
        registers[11] = registers[8]["values"]
        z = registers[11]
        registers[12] = z;
        registers[(11)] = z["get"];
        registers[(11)] = registers[(11)](registers[12])
        registers[11] = (registers[11] == "Custom")
        goto p2
        ::p153::
        registers[2] = upvalues[0]["antiaim"]
        registers[2] = registers[2]["conditions"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"]
        goto p41
        ::p157::
        registers[12] = upvalues[3][154]
        a = registers
        z = (13)
        q = registers
        q = q[9]
        q = q["count"]
        a[z] = q
        z = registers[13]
        registers[14] = z;
        registers[(13)] = z["get"]
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        m = m + 13 - 1
        top = m
        z = 0
        for f = 13, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[12] = registers[12](unpack_range(top, registers, 13))
        goto p107
        ::p166::
        registers[11] = (registers[10] == "Random")
        goto p39
        ::p168::
        registers[16] = (10)
        a = registers
        z = 17
        q = registers
        q = q[12]
        a[z] = q
        m, x = pack_returns(registers[15](unpack_range(17, registers, 16)))
        m = m + 15 - 1
        top = m
        z = 0
        for f = 15, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[13] = registers[13](unpack_range(top, registers, 14))
        registers[12] = registers[13]
        registers[13] = (1)
        goto p81
    end
end
