-- Recovered function f378; author names are unavailable.
F.f378 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f378")
        tick(1)
        goto p129
        ::p4::
        tick(4)
        registers[4] = registers[3]
        a = upvalues[2];
        registers[5] = a[2][a[1]]
        if registers[5] ~= registers[2] then
            goto p153
        end
        goto p150
        ::p8::
        tick(8)
        a = upvalues[3]
        a[2][a[1]] = registers[4]
        registers[5] = upvalues[4]["set_callback"]
        registers[6] = "setup_command"
        goto p135
        ::p33::
        tick(33)
        a = upvalues[6]
        a[2][a[1]] = registers[3]
        if registers[3] then
            goto p121
        end
        goto p96
        ::p37::
        tick(37)
        registers[7] = upvalues[5]["pre_render"]
        registers[8] = registers[2]
        registers[(5)](unpack_range(8, registers, 6))
        registers[5] = upvalues[4]["set_callback"]
        registers[6] = "setup_command"
        goto p109
        ::p84::
        tick(84)
        registers[5] = upvalues[5]["reset"]
        registers[(5)]()
        ::p86::
        tick(86)
        do
            return 
        end
        ::p87::
        tick(87)
        registers[3] = registers[3](registers[4], registers[5])
        goto p4
        ::p90::
        tick(90)
        registers[2] = registers[1]["enabled"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        registers[2] = (registers[2] == true)
        goto p118
        ::p96::
        registers[5] = {
        }
        upvalues[7]["server_anim_states"] = registers[5]
        goto p121
        ::p105::
        tick(105)
        registers[2] = registers[1]["enabled"]
        registers[2] = (registers[2] ~= registers[0])
        goto p126
        ::p109::
        registers[7] = upvalues[5]["setup_command"]
        registers[8] = registers[4]
        registers[(5)](unpack_range(8, registers, 6))
        goto p147
        ::p114::
        tick(114)
        registers[3] = upvalues[1]
        registers[4] = registers[1]
        registers[5] = "Smooth"
        goto p87
        ::p118::
        tick(118)
        registers[3] = registers[2]
        if not registers[3] then
            goto p4
        end
        goto p114
        ::p121::
        tick(121)
        if registers[2] then
            goto p149
        end
        goto p141
        ::p126::
        tick(126)
        if not registers[2] then
            goto p118
        end
        goto p90
        ::p129::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        registers[2] = (registers[1] ~= registers[0])
        if not registers[2] then
            goto p126
        end
        goto p105
        ::p135::
        registers[7] = upvalues[5]["setup_command"]
        registers[8] = registers[4]
        registers[(5)](unpack_range(8, registers, 6))
        goto p144
        ::p141::
        registers[5] = upvalues[5]["reset"]
        registers[(5)]()
        goto p149
        ::p144::
        tick(144)
        a = upvalues[6];
        registers[5] = a[2][a[1]]
        if registers[5] == registers[3] then
            goto p121
        end
        goto p33
        ::p147::
        if registers[2] then
            goto p86
        end
        goto p84
        ::p149::
        do
            return 
        end
        ::p150::
        a = upvalues[3];
        registers[5] = a[2][a[1]]
        if registers[5] == registers[4] then
            goto p144
        end
        goto p8
        ::p153::
        a = upvalues[2]
        a[2][a[1]] = registers[2]
        a = upvalues[6]
        a[2][a[1]] = registers[3]
        a = upvalues[3]
        a[2][a[1]] = registers[4]
        registers[5] = upvalues[4]["set_callback"]
        registers[6] = "pre_render"
        goto p37
    end
end
