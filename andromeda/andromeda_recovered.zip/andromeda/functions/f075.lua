-- Recovered function f75; author names are unavailable.
F.f75 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local tick = new_tick("f75")
        tick(1)
        tick(22)
        slot_1 = upvalues[0]
        slot_2 = upvalues[1]["all"]
        slot_3 = upvalues[2]
        slot_2 = slot_2[slot_3]
        slot_3 = {
        };
        slot_1(slot_2, slot_3)
        do
            return 
        end
    end
end
