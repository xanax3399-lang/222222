-- Recovered function f13; author names are unavailable.
F.f13 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local T, _, z = 0, nil, nil
        local tick = new_tick("f13")
        tick(1)
        _, Q = pack_returns(...)
        z = (_ - T - 1)
        if z < 0 then
            z = -1
        end
        q = 0
        for T = 2, 2 + z, 1 do
            registers[T] = Q[W + q]
            q = q + 1
        end
        top = (2 + z)
        do
            return unpack_range(top, registers, 2)
        end
    end
end
