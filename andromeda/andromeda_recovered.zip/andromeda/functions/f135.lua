-- Recovered function f135; author names are unavailable.
F.f135 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f135")
        tick(1)
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0][32];
        registers[2] = registers[2]()
        if registers[2] then
            goto p120
        end
        goto p110
        ::p9::
        tick(9)
        a = upvalues[4]
        a[2][a[1]] = registers[0]
        goto p55
        ::p13::
        tick(13)
        a = upvalues[3]
        a[2][a[1]] = (0)
        goto p100
        ::p15::
        tick(15)
        a = upvalues[3];
        registers[6] = a[2][a[1]]
        if not (registers[3] < registers[6]) then
            goto p104
        end
        goto p33
        ::p19::
        tick(19)
        if registers[6] ~= registers[7] then
            goto p55
        end
        goto p9
        ::p33::
        registers[6] = upvalues[0][162]
        registers[7] = (14)
        registers[8] = upvalues[0][151]
        registers[9] = (0)
        goto p152
        ::p55::
        do
            return 
        end
        ::p71::
        tick(71)
        a = upvalues[3]
        a[2][a[1]] = registers[3]
        goto p104
        ::p80::
        tick(80)
        registers[4] = registers[2]
        registers[5] = "m_nTickBase"
        registers[3] = registers[3](registers[4], registers[5])
        a = upvalues[2];
        registers[4] = a[2][a[1]]["exploits"]
        registers[4] = registers[4]["defensive"]
        goto p157
        ::p100::
        tick(100)
        registers[5] = (0)
        a = upvalues[3];
        registers[6] = a[2][a[1]]
        if not (registers[6] < registers[3]) then
            goto p15
        end
        goto p71
        ::p104::
        tick(104)
        registers[4]["left"] = registers[5]
        registers[6] = upvalues[0][151]
        registers[7] = registers[4]["max"]
        registers[8] = registers[5]
        registers[6] = registers[6](registers[7], registers[8])
        goto p127
        ::p110::
        do
            return 
        end
        ::p120::
        registers[3] = upvalues[0][47]
        registers[4] = registers[2]
        registers[5] = "m_fFlags"
        registers[3] = registers[3](registers[4], registers[5])
        a = upvalues[1]
        a[2][a[1]] = registers[3]
        registers[3] = upvalues[0][47]
        goto p80
        ::p127::
        registers[4]["max"] = registers[6]
        registers[6] = registers[1]["command_number"]
        a = upvalues[4];
        registers[7] = a[2][a[1]]
        goto p19
        ::p139::
        tick(139)
        m, x = pack_returns(registers[8](unpack_range(10, registers, 9)))
        m = m + 8 - 1
        top = m
        z = 0
        for f = 8, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[6] = registers[6](unpack_range(top, registers, 7))
        registers[5] = registers[6]
        goto p104
        ::p152::
        a = upvalues[3];
        registers[10] = a[2][a[1]]
        registers[10] = (registers[10] - registers[3])
        registers[10] = (registers[10] - 1)
        goto p139
        ::p157::
        registers[5] = upvalues[0][161]
        a = upvalues[3];
        registers[6] = a[2][a[1]]
        registers[6] = (registers[3] - registers[6]);
        registers[(5)] = registers[(5)](registers[6])
        if not (64 < registers[5]) then
            goto p100
        end
        goto p13
    end
end
