-- Recovered function f454; author names are unavailable.
F.f454 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7, slot_8, slot_9, slot_10, slot_11, slot_12, slot_13, slot_14, slot_15 = nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f454")
        tick(1)
        goto p88
        ::p7::
        tick(7)
        slot_11 = upvalues[1]["random_int"]
        slot_12 = (0)
        slot_13 = (1)
        slot_11 = slot_11(slot_12, slot_13)
        goto p166
        ::p12::
        tick(12)
        slot_12 = upvalues[1]["random_int"]
        slot_13 = slot_7
        slot_14 = slot_8
        goto p181
        ::p29::
        tick(29)
        slot_1["target_pitch"] = slot_11
        slot_1["start_time"] = slot_6
        goto p62
        ::p32::
        tick(32)
        slot_12 = -1
        goto p102
        ::p34::
        tick(34)
        slot_8 = (0)
        ::p35::
        tick(35)
        slot_9 = slot_4
        if slot_9 then
            goto p162
        end
        goto p72
        ::p40::
        tick(40)
        slot_11 = -1
        goto p211
        ::p42::
        tick(42)
        slot_11 = (1)
        goto p66
        ::p45::
        tick(45)
        slot_12 = upvalues[0][162]
        slot_13 = (slot_11 / slot_10)
        slot_14 = (1)
        slot_12 = slot_12(slot_13, slot_14)
        slot_13 = slot_1["base_pitch"]
        slot_14 = slot_1["target_pitch"]
        slot_15 = slot_1["base_pitch"]
        goto p84
        ::p62::
        tick(62)
        slot_11 = slot_1["start_time"]
        slot_11 = (slot_6 - slot_11)
        branch_taken = false
        if not (not (slot_10 <= slot_11)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p45
        end
        goto p12
        ::p66::
        tick(66)
        slot_11 = slot_11 / 10
        slot_12 = (0.01)
        slot_10 = slot_10(slot_11, slot_12)
        slot_11 = slot_1["initialized"]
        goto p171
        ::p72::
        slot_9 = (0)
        goto p162
        ::p84::
        slot_14 = (slot_14 - slot_15)
        slot_14 = slot_14 * slot_12
        slot_13 = slot_13 + slot_14
        do
            return slot_13
        end
        ::p88::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = a[3]
        slot_4 = a[4]
        slot_5 = a[5]
        slot_6 = upvalues[0][30];
        slot_6 = slot_6()
        slot_7 = slot_3
        if slot_7 then
            goto p94
        end
        goto p119
        ::p94::
        tick(94)
        slot_8 = slot_2
        if slot_8 then
            goto p35
        end
        goto p34
        ::p97::
        tick(97)
        slot_14 = (1)
        slot_12 = slot_12(slot_13, slot_14)
        slot_12 = (slot_12 == 0)
        if not slot_12 then
            goto p102
        end
        goto p32
        ::p102::
        if slot_12 then
            goto p158
        end
        goto p209
        ::p111::
        tick(111)
        slot_11 = (1)
        goto p151
        ::p113::
        tick(113)
        slot_13 = slot_9 * slot_13
        slot_12 = slot_12 + slot_13
        slot_1["target_pitch"] = slot_12
        slot_1["start_time"] = slot_6
        goto p122
        ::p119::
        slot_7 = (0)
        goto p94
        ::p122::
        slot_11 = (0)
        goto p45
        ::p144::
        tick(144)
        slot_1["initialized"] = true
        slot_11 = upvalues[1]["random_int"]
        slot_12 = slot_7
        slot_13 = slot_8
        slot_11 = slot_11(slot_12, slot_13)
        slot_1["base_pitch"] = slot_11
        goto p7
        ::p151::
        tick(151)
        slot_1["spin_dir"] = slot_11
        slot_11 = slot_1["base_pitch"]
        slot_12 = slot_1["spin_dir"]
        slot_12 = slot_9 * slot_12
        slot_11 = slot_11 + slot_12
        goto p29
        ::p158::
        tick(158)
        slot_1["spin_dir"] = slot_12
        slot_12 = slot_1["base_pitch"]
        slot_13 = slot_1["spin_dir"]
        goto p113
        ::p162::
        slot_10 = upvalues[0][151]
        slot_11 = slot_5
        if slot_11 then
            goto p66
        end
        goto p42
        ::p166::
        slot_11 = (slot_11 == 0)
        if not slot_11 then
            goto p211
        end
        goto p40
        ::p171::
        if slot_11 then
            goto p62
        end
        goto p144
        ::p181::
        slot_12 = slot_12(slot_13, slot_14)
        slot_1["base_pitch"] = slot_12
        slot_12 = upvalues[1]["random_int"]
        slot_13 = (0)
        goto p97
        ::p209::
        slot_12 = (1)
        goto p158
        ::p211::
        if slot_11 then
            goto p151
        end
        goto p111
    end
end
