-- Recovered function f249; author names are unavailable.
F.f249 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f249")
        tick(1)
        goto p96
        ::p2::
        tick(2)
        registers[7] = registers[2][2]
        goto p117
        ::p4::
        tick(4)
        registers[9] = registers[3][4]
        if registers[9] then
            goto p101
        end
        goto p94
        ::p9::
        tick(9)
        registers[3] = {
        }
        z = registers[1]
        registers[5] = z;
        registers[(4)] = z["get"]
        m, x = pack_returns(registers[4](unpack_range(5, registers, 5)))
        m = m + 4 - 1
        top = m
        z = 0
        for f = 4, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        q = registers[(3)]
        for f = 1, top - (3) do
            q[(0) + f] = registers[(3) + f]
        end
        registers[4] = registers[3][1]
        registers[5] = environment["type"]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        if registers[5] ~= "table" then
            goto p87
        end
        goto p109
        ::p19::
        tick(19)
        registers[5] = new_frame(4)
        registers[6] = registers[4][1]
        if registers[6] then
            goto p120
        end
        goto p181
        ::p23::
        tick(23)
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        do
            return registers[5]
        end
        ::p51::
        tick(51)
        registers[9] = registers[2][4]
        goto p73
        ::p53::
        tick(53)
        registers[9] = registers[4][4]
        if registers[9] then
            goto p73
        end
        goto p51
        ::p73::
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        do
            return registers[5]
        end
        ::p75::
        tick(75)
        registers[3] = registers[2]
        do
            return registers[3]
        end
        ::p87::
        tick(87)
        registers[5] = environment["type"]
        registers[6] = registers[4];
        registers[(5)] = registers[(5)](registers[6])
        goto p185
        ::p91::
        tick(91)
        registers[7] = registers[4]["g"]
        if registers[7] then
            goto p189
        end
        goto p164
        ::p94::
        registers[9] = registers[2][4]
        goto p101
        ::p96::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        if registers[1] ~= registers[0] then
            goto p9
        end
        goto p75
        ::p101::
        q = registers[(5)]
        q[1] = registers[6]
        q[2] = registers[7]
        q[3] = registers[8]
        q[4] = registers[9]
        do
            return registers[5]
        end
        ::p104::
        tick(104)
        registers[9] = registers[2][4]
        goto p23
        ::p106::
        tick(106)
        registers[5] = registers[2]
        do
            return registers[5]
        end
        ::p109::
        registers[5] = registers[4]["r"]
        if registers[5] == registers[0] then
            goto p143
        end
        goto p128
        ::p113::
        tick(113)
        registers[8] = registers[3][3]
        if registers[8] then
            goto p4
        end
        goto p136
        ::p117::
        tick(117)
        registers[8] = registers[4][3]
        if registers[8] then
            goto p53
        end
        goto p187
        ::p120::
        tick(120)
        registers[7] = registers[4][2]
        if registers[7] then
            goto p117
        end
        goto p2
        ::p124::
        tick(124)
        registers[6] = registers[2][1]
        goto p91
        ::p128::
        registers[5] = new_frame(4)
        registers[6] = registers[4]["r"]
        if registers[6] then
            goto p91
        end
        goto p124
        ::p132::
        tick(132)
        registers[6] = registers[2][1]
        goto p167
        ::p134::
        tick(134)
        registers[8] = registers[2][3]
        goto p170
        ::p136::
        registers[8] = registers[2][3]
        goto p4
        ::p143::
        registers[5] = registers[4][1]
        if registers[5] == registers[0] then
            goto p87
        end
        goto p19
        ::p146::
        tick(146)
        registers[5] = new_frame(4)
        registers[6] = registers[4]
        if registers[6] then
            goto p167
        end
        goto p132
        ::p164::
        registers[7] = registers[2][2]
        goto p189
        ::p167::
        registers[7] = registers[3][2]
        if registers[7] then
            goto p113
        end
        goto p183
        ::p170::
        tick(170)
        registers[9] = registers[4]["a"]
        if registers[9] then
            goto p23
        end
        goto p104
        ::p181::
        registers[6] = registers[2][1]
        goto p120
        ::p183::
        registers[7] = registers[2][2]
        goto p113
        ::p185::
        if registers[5] ~= "number" then
            goto p106
        end
        goto p146
        ::p187::
        registers[8] = registers[2][3]
        goto p53
        ::p189::
        registers[8] = registers[4]["b"]
        if registers[8] then
            goto p170
        end
        goto p134
    end
end
