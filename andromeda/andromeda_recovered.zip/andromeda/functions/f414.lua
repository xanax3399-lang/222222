-- Recovered function f414; author names are unavailable.
F.f414 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f414")
        tick(1)
        goto p40
        ::p23::
        tick(23);
        registers[(3)] = registers[(3)](registers[4])
        registers[3] = "native_indicator_alpha:"..registers[3]
        registers[4] = (1)
        registers[5] = (10)
        registers[6] = (0.01)
        registers[7] = "ease_out"
        do
            return registers[(2)](unpack_range(7, registers, 3))
        end
        ::p30::
        tick(30)
        registers[4] = ""
        goto p23
        ::p40::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = upvalues[0]
        registers[3] = environment["tostring"]
        registers[4] = registers[1]
        if registers[4] then
            goto p23
        end
        goto p30
    end
end
