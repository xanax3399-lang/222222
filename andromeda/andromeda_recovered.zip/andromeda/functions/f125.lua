-- Recovered function f125; author names are unavailable.
F.f125 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local tick = new_tick("f125")
        tick(1)
        goto p40
        ::p10::
        tick(10)
        registers[9] = (230)
        registers[10] = registers[5] + 45
        registers[8] = registers[8](registers[9], registers[10])
        registers[9] = upvalues[0][129]
        goto p181
        ::p16::
        tick(16)
        registers[12] = registers[6]
        registers[13] = (1)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        goto p140
        ::p28::
        tick(28)
        registers[8] = (0)
        registers[9] = (registers[6] * 2)
        registers[9] = (registers[3] - registers[9])
        registers[7] = registers[7](registers[8], registers[9])
        registers[8] = upvalues[0][162]
        goto p10
        ::p36::
        tick(36)
        registers[11] = registers[2]
        registers[12] = registers[6]
        registers[13] = registers[4]
        goto p51
        ::p40::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = upvalues[0][162]
        registers[7] = upvalues[0][154]
        goto p116
        ::p44::
        tick(44)
        registers[13] = (1)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        registers[17] = registers[8]
        registers[(9)](unpack_range(17, registers, 10))
        goto p171
        ::p51::
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        goto p152
        ::p92::
        tick(92)
        registers[(9)](unpack_range(22, registers, 10))
        if not (0 < registers[7]) then
            goto p171
        end
        goto p257
        ::p95::
        tick(95)
        registers[16] = (0)
        registers[17] = registers[8]
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = (0)
        registers[22] = (true)
        registers[(9)](unpack_range(22, registers, 10))
        do
            return 
        end
        ::p105::
        tick(105)
        registers[16] = (0)
        registers[17] = registers[8]
        registers[(9)](unpack_range(17, registers, 10))
        registers[9] = upvalues[0][128]
        goto p223
        ::p110::
        tick(110)
        registers[9] = upvalues[0][129]
        registers[10] = registers[1] + registers[6]
        registers[10] = registers[10] + registers[7]
        goto p36
        ::p116::
        registers[8] = (registers[3] * 0.28)
        registers[8] = registers[8] + 0.5;
        registers[(7)] = registers[(7)](registers[8])
        registers[8] = (42)
        registers[6] = registers[6](registers[7], registers[8])
        registers[7] = upvalues[0][151]
        goto p28
        ::p132::
        tick(132)
        registers[(9)](unpack_range(22, registers, 10))
        if not (0 < registers[7]) then
            goto p110
        end
        goto p236
        ::p140::
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = registers[8]
        goto p175
        ::p146::
        tick(146)
        registers[17] = registers[8]
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = (0)
        goto p206
        ::p152::
        registers[17] = registers[5]
        registers[18] = (0)
        registers[19] = (0)
        goto p192
        ::p156::
        tick(156)
        registers[11] = registers[2] + registers[4]
        registers[11] = (registers[11] - 1)
        registers[12] = registers[6]
        registers[13] = (1)
        registers[14] = (0)
        registers[15] = (0)
        goto p95
        ::p171::
        registers[9] = upvalues[0][129]
        registers[10] = registers[1] + registers[6]
        registers[10] = registers[10] + registers[7]
        goto p264
        ::p175::
        registers[22] = (true)
        registers[(9)](unpack_range(22, registers, 10))
        registers[9] = upvalues[0][129]
        registers[10] = registers[1] + registers[6]
        registers[10] = registers[10] + registers[7]
        goto p156
        ::p181::
        registers[10] = registers[1]
        registers[11] = registers[2]
        registers[12] = registers[6]
        registers[13] = registers[4]
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        goto p202
        ::p192::
        registers[20] = (0)
        registers[21] = (0)
        registers[22] = (true)
        registers[(9)](unpack_range(22, registers, 10))
        registers[9] = upvalues[0][129]
        registers[10] = registers[1]
        registers[11] = registers[2]
        registers[12] = registers[6]
        registers[13] = (1)
        goto p213
        ::p202::
        registers[20] = (0)
        registers[21] = registers[5]
        registers[22] = (true)
        goto p132
        ::p206::
        registers[22] = (true)
        registers[(9)](unpack_range(22, registers, 10))
        registers[9] = upvalues[0][129]
        registers[10] = registers[1]
        registers[11] = registers[2] + registers[4]
        registers[11] = (registers[11] - 1)
        goto p16
        ::p213::
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        registers[17] = (0)
        registers[18] = (0)
        registers[19] = (0)
        registers[20] = (0)
        registers[21] = registers[8]
        registers[22] = (true)
        goto p92
        ::p223::
        registers[10] = registers[1] + registers[6]
        registers[11] = registers[2] + registers[4]
        registers[11] = (registers[11] - 1)
        registers[12] = registers[7]
        goto p44
        ::p236::
        registers[9] = upvalues[0][128]
        registers[10] = registers[1] + registers[6]
        registers[11] = registers[2]
        goto p268
        ::p248::
        tick(248)
        registers[13] = (1)
        registers[14] = (0)
        registers[15] = (0)
        goto p105
        ::p253::
        tick(253)
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        goto p146
        ::p257::
        registers[9] = upvalues[0][128]
        registers[10] = registers[1] + registers[6]
        registers[11] = registers[2]
        registers[12] = registers[7]
        goto p248
        ::p264::
        registers[11] = registers[2]
        registers[12] = registers[6]
        registers[13] = (1)
        goto p253
        ::p268::
        registers[12] = registers[7]
        registers[13] = registers[4]
        registers[14] = (0)
        registers[15] = (0)
        registers[16] = (0)
        registers[17] = registers[5]
        registers[(9)](unpack_range(17, registers, 10))
        goto p110
    end
end
