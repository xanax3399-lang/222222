-- Recovered function f65; author names are unavailable.
F.f65 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, S, z, a = nil, nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f65")
        tick(1)
        goto p50
        ::p2::
        tick(2)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[7] = {
        }
        registers[8] = environment["tostring"]
        registers[9] = environment["_G"]
        registers[9] = registers[9]["tostring"]
        registers[10] = registers[7]
        registers[8] = registers[8](registers[9], registers[10])
        goto p91
        ::p34::
        tick(34)
        registers[8] = upvalues[1]
        registers[9] = {
        }
        registers[10] = upvalues[2]["CHECK_12_FAILED"]
        goto p240
        ::p38::
        tick(38)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[10] = v
            branch_taken = true
        end
        if branch_taken then
            goto p313
        end
        goto p2
        ::p50::
        a = D.f66
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[1] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[2] = "\181\155?M\230\022R5\219-\197\223\216<\221I\2395n\141,\2191\226";
        registers[(1)] = registers[(1)](registers[2])
        registers[2] = environment["tostring"]
        registers[3] = environment["jit"]
        registers[3] = registers[3]["flush"]
        registers[4] = environment["setfenv"]
        goto p211
        ::p58::
        tick(58)
        registers[11] = upvalues[1]
        registers[12] = {
        }
        registers[13] = upvalues[2]["CHECK_12_FAILED"]
        goto p222
        ::p68::
        tick(68)
        branch_taken = false
        if registers[11] ~= "function" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p126
        end
        goto p58
        ::p73::
        tick(73)
        registers[8] = environment["tostring"]
        registers[9] = environment["_G"]
        registers[9] = registers[9]["tostring"]
        registers[10] = {
        }
        registers[8] = registers[8](registers[9], registers[10])
        if registers[8] ~= "function: NULL" then
            goto p159
        end
        goto p239
        ::p84::
        tick(84)
        do
            local f = (7)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        goto p288
        ::p86::
        tick(86)
        if registers[15] then
            goto p142
        end
        goto p330
        ::p91::
        if registers[8] == registers[1] then
            goto p73
        end
        goto p34
        ::p112::
        tick(112)
        registers[8] = (#registers[8])
        registers[9] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[9] + 0
        n = (registers[8] + 0)
        v = (registers[7] - U)
        goto p126
        goto p153
        ::p117::
        tick(117)
        registers[8] = upvalues[1]
        registers[9] = {
        }
        registers[10] = upvalues[2]["CHECK_12_FAILED"]
        registers[9]["ban_num"] = registers[10]
        registers[9]["ban_info"] = "tostring [S-TS][0x01]"
        registers[(8)](registers[9])
        goto p244
        ::p126::
        tick(126)
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[10] = v
            branch_taken = true
        end
        if branch_taken then
            goto p318
        end
        goto p153
        ::p142::
        registers[17] = upvalues[1]
        registers[18] = {
        }
        registers[19] = upvalues[2]["CHECK_12_FAILED"]
        registers[18]["ban_num"] = registers[19]
        goto p206
        ::p147::
        tick(147)
        if registers[8] ~= registers[1] then
            goto p183
        end
        goto p226
        ::p149::
        tick(149)
        registers[8] = registers[8](registers[9], registers[10])
        branch_taken = false
        if registers[8] ~= "function: NULL" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p244
        end
        goto p117
        ::p153::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[7] = (1)
        registers[8] = upvalues[0]["all"]
        registers[8] = (#registers[8])
        goto p220
        ::p159::
        registers[8] = environment["_G"]
        registers[9] = "tostring"
        a = D.f72
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[10] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[8][registers[9]] = registers[10]
        registers[8] = registers[2]
        registers[9] = environment["_G"]
        registers[9] = registers[9]["tostring"]
        registers[10] = {
        }
        goto p149
        ::p168::
        tick(168)
        registers[11] = registers[6]
        a = D.f73
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        m, x = pack_returns(registers[11](unpack_range(12, registers, 12)))
        z = 0
        for f = 11, 12 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p299
        ::p183::
        registers[8] = environment["_G"]
        registers[8]["tostring"] = registers[2]
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p193::
        tick(193)
        registers[(17)](registers[18])
        goto p84
        ::p196::
        tick(196)
        registers[15] = registers[14]
        goto p296
        ::p206::
        registers[19] = upvalues[0]["all_str"]
        registers[19] = registers[19][registers[10]]
        registers[19] = registers[19].." [JS][0x01]"
        registers[18]["ban_info"] = registers[19]
        goto p193
        ::p211::
        registers[5] = environment["type"]
        a = D.f74
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[6] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[7] = (1)
        registers[8] = upvalues[0]["all"]
        goto p112
        ::p216::
        tick(216)
        registers[13] = registers[13].." [TY][0x01]"
        registers[12]["ban_info"] = registers[13]
        registers[(11)](registers[12])
        goto p126
        ::p220::
        registers[9] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[9] + 0
        n = (registers[8] + 0)
        v = (registers[7] - U)
        goto p288
        ::p222::
        registers[12]["ban_num"] = registers[13]
        registers[13] = upvalues[0]["all_str"]
        registers[13] = registers[13][registers[10]]
        goto p216
        ::p226::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p227::
        tick(227)
        registers[19] = registers[19].." [JS][0x01]"
        registers[18]["ban_info"] = registers[19]
        registers[(17)](registers[18])
        goto p84
        ::p239::
        do
            if N then
                for f, F, u in next, N do
                    if not (f >= 1) then

                    else
                        F[2] = F
                        F[3] = registers[f];
                        F[1] = 3
                        N[f] = nil
                    end
                end
            end
            return 
        end
        ::p240::
        registers[9]["ban_num"] = registers[10]
        registers[9]["ban_info"] = "tostring [TS][0x01]"
        registers[(8)](registers[9])
        goto p73
        ::p244::
        registers[8] = registers[2]
        registers[9] = environment["_G"]
        registers[9] = registers[9]["tostring"]
        registers[10] = {
        }
        registers[8] = registers[8](registers[9], registers[10])
        goto p147
        ::p256::
        tick(256)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[7] = (1)
        registers[8] = upvalues[0]["lua"]
        registers[8] = (#registers[8])
        registers[9] = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = registers[9] + 0
        n = (registers[8] + 0)
        v = (registers[7] - U)
        goto p38
        goto p288
        ::p281::
        tick(281)
        registers[17] = upvalues[1]
        registers[18] = {
        }
        registers[19] = upvalues[2]["CHECK_12_FAILED"]
        registers[18]["ban_num"] = registers[19]
        registers[19] = upvalues[0]["all_str"]
        registers[19] = registers[19][registers[10]]
        goto p227
        ::p288::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            registers[10] = v
            branch_taken = true
        end
        if branch_taken then
            goto p168
        end
        goto p256
        ::p296::
        tick(296)
        registers[16] = not registers[11]
        if registers[16] then
            goto p86
        end
        goto p311
        ::p299::
        registers[13] = registers[6]
        a = D.f75
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[14] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        m, x = pack_returns(registers[13](unpack_range(14, registers, 14)))
        z = 0
        for f = 13, 14 do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[15] = registers[12]
        if registers[15] then
            goto p296
        end
        goto p196
        ::p311::
        registers[16] = not registers[13]
        goto p86
        ::p313::
        registers[11] = environment["pcall"]
        a = D.f76
        z = a[4]
        q = (#z)
        m = q > 0 and {
        }
        x = make_function(a, m);
        setfenv(x, environment);
        registers[12] = x
        if m then
            for f = 1, q do
                a = z[f]
                x = a[2]
                S = a[1]
                if x == 0 then
                    if not N then
                        N = {
                        }
                    end
                    H = N[S]
                    if not H then
                        H = ({
                            [2] = registers,
                            [1] = S,
                        });
                        N[S] = H
                    end
                    m[f - 1] = H
                else
                    if x ~= 1 then
                        m[f - 1] = upvalues[S]
                    else
                        m[f - 1] = registers[S]
                    end
                end
            end
        end
        registers[(11)](registers[12])
        do
            local f = (7)
            if not N then

            else
                for F, u, c in next, N do
                    if F >= f then
                        u[2] = u
                        u[3] = registers[F]
                        u[1] = (3)
                        N[F] = nil
                    end
                end
            end
        end
        goto p38
        ::p318::
        registers[11] = registers[5]
        registers[12] = upvalues[0]["all"]
        registers[12] = registers[12][registers[10]];
        registers[(11)] = registers[(11)](registers[12])
        goto p68
        ::p330::
        if not registers[16] then
            goto p84
        end
        goto p281
    end
end
