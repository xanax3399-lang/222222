-- Recovered function f267; author names are unavailable.
F.f267 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z = nil
        local tick = new_tick("f267")
        tick(1)
        goto p30
        ::p2::
        tick(2)
        registers[2] = upvalues[1]["misc"]
        registers[2] = registers[2]["usercmd"]
        z = registers[2]
        registers[3] = z;
        registers[(2)] = z["get"];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] == registers[0] then
            goto p175
        end
        goto p121
        ::p21::
        tick(21)
        registers[1] = upvalues[1]["antiaim"]
        registers[1] = registers[1]["fakelag"]
        registers[1] = registers[1]["on"]
        goto p26
        ::p25::
        tick(25)
        do
            return 
        end
        ::p26::
        z = registers[1]
        registers[2] = z;
        registers[(1)] = z["get"];
        registers[(1)] = registers[(1)](registers[2])
        if registers[1] then
            goto p35
        end
        goto p124
        ::p30::
        tick(30)
        registers[1] = upvalues[0]["is_enabled"];
        registers[1] = registers[1]()
        if registers[1] then
            goto p21
        end
        goto p182
        ::p35::
        registers[1] = upvalues[2][32];
        registers[1] = registers[1]()
        if registers[1] == registers[0] then
            goto p25
        end
        goto p184
        ::p39::
        tick(39)
        registers[12] = registers[5]
        registers[13] = registers[6]
        registers[14] = (255)
        registers[15] = (9)
        goto p73
        ::p56::
        tick(56)
        registers[4] = 255 - registers[4]
        registers[5] = registers[3] / 1.62
        registers[5] = (registers[5] * 3.42105263158)
        registers[6] = registers[3] / 1.62
        registers[6] = (registers[6] * 0.22807017543)
        registers[7] = upvalues[2][138]
        registers[8] = registers[4]
        registers[9] = registers[5]
        registers[10] = registers[6]
        registers[11] = (255)
        registers[12] = "PEEK"
        goto p161
        ::p68::
        tick(68)
        registers[8] = upvalues[2][127]
        registers[9] = (90)
        registers[10] = registers[7] + 19
        registers[11] = (0)
        goto p176
        ::p73::
        registers[16] = (0)
        registers[17] = registers[3] / 100
        registers[18] = (4)
        registers[(8)](unpack_range(18, registers, 9))
        do
            return 
        end
        ::p102::
        tick(102)
        do
            return 
        end
        ::p121::
        if registers[2] ~= 0 then
            goto p136
        end
        goto p175
        ::p124::
        do
            return 
        end
        ::p136::
        registers[3] = upvalues[0]["choked_commands"]
        registers[3] = (registers[3] * 100)
        registers[3] = (registers[3] / registers[2])
        registers[4] = registers[3] / 1.62
        registers[4] = (registers[4] * 2.29824561404)
        goto p56
        ::p142::
        tick(142)
        registers[17] = (1)
        registers[18] = (5)
        registers[(8)](unpack_range(18, registers, 9))
        registers[8] = upvalues[2][127]
        registers[9] = (90)
        registers[10] = registers[7] + 19
        registers[11] = registers[4]
        goto p39
        ::p161::;
        registers[7] = registers[7](unpack_range(12, registers, 8))
        if registers[7] ~= registers[0] then
            goto p68
        end
        goto p102
        ::p175::
        do
            return 
        end
        ::p176::
        registers[12] = (0)
        registers[13] = (0)
        registers[14] = (150)
        registers[15] = (10)
        registers[16] = (0)
        goto p142
        ::p182::
        do
            return 
        end
        ::p184::
        registers[2] = upvalues[2][50]
        registers[3] = registers[1];
        registers[(2)] = registers[(2)](registers[3])
        if registers[2] then
            goto p2
        end
        goto p25
    end
end
