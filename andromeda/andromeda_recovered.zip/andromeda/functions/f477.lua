-- Recovered function f477; author names are unavailable.
F.f477 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2 = nil, nil, nil
        local z = nil
        local tick = new_tick("f477")
        tick(1)
        goto p17
        ::p4::
        tick(4)
        if not slot_1 then
            goto p39
        end
        goto p49
        ::p7::
        tick(7)
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["enemy_resolver"]
        slot_1 = (slot_1 ~= slot_0)
        goto p4
        ::p17::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p4
        end
        goto p7
        ::p39::
        tick(39)
        do
            return slot_1
        end
        ::p49::
        slot_1 = upvalues[0]["ragebot"]
        slot_1 = slot_1["enemy_resolver"]
        z = slot_1
        slot_2 = z;
        slot_1 = z["get"];
        slot_1 = slot_1(slot_2)
        slot_1 = (slot_1 == true)
        goto p39
    end
end
