-- Recovered function f183; author names are unavailable.
F.f183 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f183")
        tick(1)
        goto p137
        ::p3::
        tick(3)
        if slot_2 ~= "Onetap" then
            goto p5
        end
        goto p38
        ::p5::
        if slot_2 ~= "TeamSkeet" then
            goto p8
        end
        goto p135
        ::p8::
        if slot_2 ~= "TeamSkeet Velocity" then
            goto p53
        end
        goto p76
        ::p10::
        tick(10)
        slot_2 = "First"
        do
            return slot_2
        end
        ::p12::
        tick(12)
        if slot_2 ~= 6 then
            goto p125
        end
        goto p31
        ::p14::
        tick(14)
        slot_3 = "First"
        goto p101
        ::p26::
        tick(26)
        slot_3 = slot_2
        if slot_3 then
            goto p101
        end
        goto p14
        ::p29::
        tick(29)
        slot_3 = "Fourth"
        do
            return slot_3
        end
        ::p31::
        slot_3 = "CS2"
        do
            return slot_3
        end
        ::p33::
        tick(33)
        if not slot_1 then
            goto p79
        end
        goto p91
        ::p35::
        tick(35)
        slot_3 = "CS2"
        do
            return slot_3
        end
        ::p38::
        slot_3 = "Second"
        do
            return slot_3
        end
        ::p40::
        tick(40)
        slot_3 = "Second"
        do
            return slot_3
        end
        ::p42::
        tick(42)
        if slot_2 ~= "Invictus" then
            goto p3
        end
        goto p133
        ::p53::
        if slot_2 ~= "Fifth" then
            goto p140
        end
        goto p57
        ::p55::
        tick(55)
        slot_3 = "Fifth"
        do
            return slot_3
        end
        ::p57::
        slot_3 = "Fifth"
        do
            return slot_3
        end
        ::p60::
        tick(60)
        z = slot_1
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        if slot_2 ~= 1 then
            goto p104
        end
        slot_3 = "First"
        do
            return slot_3
        end
        ::p73::
        tick(73)
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["stubs"]
        goto p33
        ::p76::
        slot_3 = "Fourth"
        do
            return slot_3
        end
        ::p79::
        tick(79)
        if slot_1 then
            goto p102
        end
        slot_1 = nil
        goto p102
        ::p84::
        tick(84)
        if slot_2 ~= 5 then
            goto p12
        end
        goto p55
        ::p86::
        tick(86)
        slot_3 = "First"
        do
            return slot_3
        end
        ::p91::
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["stubs"]
        slot_1 = slot_1["manual_arrows_style"]
        goto p79
        ::p98::
        tick(98)
        if slot_2 ~= 4 then
            goto p84
        end
        goto p29
        ::p101::
        do
            return slot_3
        end
        ::p102::
        if slot_1 ~= slot_0 then
            goto p60
        end
        goto p10
        ::p104::
        if slot_2 ~= 2 then
            goto p142
        end
        goto p40
        ::p123::
        tick(123)
        slot_3 = "Third"
        do
            return slot_3
        end
        ::p125::
        if slot_2 ~= "Triangle" then
            goto p42
        end
        goto p86
        ::p133::
        slot_3 = "First"
        do
            return slot_3
        end
        ::p135::
        slot_3 = "Third"
        do
            return slot_3
        end
        ::p137::
        slot_1 = upvalues[0]["visuals"]
        if not slot_1 then
            goto p33
        end
        goto p73
        ::p140::
        if slot_2 ~= "CS2" then
            goto p26
        end
        goto p35
        ::p142::
        if slot_2 ~= 3 then
            goto p98
        end
        goto p123
    end
end
