-- Recovered function f435; author names are unavailable.
F.f435 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local environment, n, v, R = andromeda_environment, nil, nil, nil
        local U, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f435")
        tick(1)
        goto p17
        ::p13::
        tick(13)
        slot_7 = slot_1[slot_6]
        slot_2[slot_6] = slot_7
        goto p37
        ::p17::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["type"]
        slot_3 = slot_1;
        slot_2 = slot_2(slot_3)
        goto p39
        ::p32::
        tick(32)
        slot_2 = {
        }
        slot_3 = (1)
        slot_4 = (#slot_1)
        slot_5 = (1)
        R = {
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        }
        U = slot_5 + 0
        n = (slot_4 + 0)
        v = (slot_3 - U)
        goto p37
        ::p37::
        branch_taken = false
        a = false
        v = v + U
        if U <= 0 then
            a = (v >= n)
        else
            a = (v <= n)
        end
        if a then
            slot_6 = v
            branch_taken = true
        end
        if branch_taken then
            goto p13
        end
        goto p41
        ::p39::
        branch_taken = false
        if slot_2 ~= "table" then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p32
        end
        goto p45
        ::p41::
        tick(41)
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        slot_3 = slot_2
        do
            return slot_3
        end
        ::p45::
        slot_2 = {
        }
        do
            return slot_2
        end
    end
end
