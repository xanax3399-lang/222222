-- Recovered function f90; author names are unavailable.
F.f90 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3 = nil, nil, nil
        local environment = andromeda_environment
        local a = nil
        local tick = new_tick("f90")
        tick(1)
        goto p5
        ::p2::
        tick(2)
        slot_3 = (slot_1 * 69)
        slot_3 = slot_3 % 1337
        do
            return slot_2(slot_3)
        end
        ::p5::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = environment["math"]
        slot_2 = slot_2["floor"]
        goto p2
    end
end
