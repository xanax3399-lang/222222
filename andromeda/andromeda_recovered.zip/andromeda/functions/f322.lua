-- Recovered function f322; author names are unavailable.
F.f322 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local branch_taken = nil
        local tick = new_tick("f322")
        tick(1)
        goto p44
        ::p2::
        tick(2)
        registers[9] = 1 - registers[9]
        registers[10] = (registers[2] - registers[6])
        registers[10] = registers[10] * registers[9]
        registers[8] = registers[6] + registers[10]
        goto p48
        ::p12::
        tick(12)
        registers[6] = registers[3]
        if registers[6] then
            goto p122
        end
        goto p191
        ::p15::
        tick(15)
        registers[9] = (registers[2] - registers[6])
        registers[9] = registers[9] * registers[7]
        registers[9] = registers[9] * registers[7]
        goto p155
        ::p19::
        tick(19)
        if registers[9] then
            goto p113
        end
        goto p63
        ::p21::
        tick(21)
        registers[4] = registers[6]
        registers[6] = registers[5]
        if registers[6] then
            goto p169
        end
        goto p99
        ::p26::
        tick(26)
        upvalues[0][registers[1]] = registers[8]
        goto p187
        ::p35::
        tick(35)
        if registers[5] ~= "ease_in" then
            goto p79
        end
        goto p163
        ::p44::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = upvalues[0][registers[1]]
        if registers[6] ~= registers[0] then
            goto p12
        end
        goto p185
        ::p48::
        tick(48)
        registers[9] = upvalues[1][161]
        registers[10] = (registers[2] - registers[8]);
        registers[(9)] = registers[(9)](registers[10])
        branch_taken = false
        if not (not (registers[9] <= registers[4])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p26
        end
        goto p59
        ::p53::
        tick(53)
        if registers[5] ~= "ease_in_out" then
            goto p118
        end
        goto p182
        ::p55::
        tick(55)
        registers[9] = 1 - registers[7]
        registers[10] = 1 - registers[7]
        registers[9] = registers[9] * registers[10]
        goto p2
        ::p59::
        upvalues[0][registers[1]] = registers[2]
        goto p187
        ::p63::
        registers[9] = upvalues[1][160]
        registers[10] = -2 * registers[7]
        a = registers
        z = (10)
        q = registers
        m = 10
        q = q[m]
        m = 2
        q = (q + m);
        a[z] = q
        registers[11] = (2)
        registers[9] = registers[9](registers[10], registers[11])
        goto p193
        ::p79::
        if registers[5] ~= "ease_out" then
            goto p53
        end
        goto p55
        ::p99::
        registers[6] = "linear"
        goto p169
        ::p101::
        tick(101)
        registers[9] = 2 * registers[7]
        registers[9] = registers[9] * registers[7]
        goto p19
        ::p113::
        tick(113)
        registers[10] = (registers[2] - registers[6])
        registers[10] = registers[10] * registers[9]
        registers[8] = registers[6] + registers[10]
        goto p48
        ::p118::
        registers[9] = (registers[2] - registers[6])
        registers[9] = registers[9] * registers[7]
        registers[8] = registers[6] + registers[9]
        goto p48
        ::p122::
        tick(122)
        registers[3] = registers[6]
        registers[6] = registers[4]
        if registers[6] then
            goto p21
        end
        registers[6] = (0.005)
        goto p21
        ::p136::
        tick(136)
        registers[9] = (registers[2] - registers[6])
        registers[9] = registers[9] * registers[7]
        a = registers
        z = 8
        q = registers
        q = q[6]
        m = registers
        x = 9
        m = m[x]
        q = q + m
        a[z] = q
        goto p48
        ::p155::
        registers[10] = 2 * registers[7]
        registers[10] = 3 - registers[10]
        registers[9] = registers[9] * registers[10]
        a = registers
        z = 8
        q = registers
        q = q[6]
        m = registers
        x = 9
        m = m[x]
        q = q + m
        a[z] = q
        goto p48
        ::p163::
        registers[9] = (registers[2] - registers[6])
        registers[9] = registers[9] * registers[7]
        registers[9] = registers[9] * registers[7]
        registers[8] = registers[6] + registers[9]
        goto p48
        ::p169::
        registers[5] = registers[6]
        a = registers
        z = 6
        q = upvalues
        m = (0)
        q = q[m]
        m = registers
        m = m[1]
        q = q[m]
        a[z] = q
        registers[7] = upvalues[1][19];
        registers[7] = registers[7]()
        registers[7] = registers[7] * registers[3]
        registers[8] = nil
        if registers[5] ~= "linear" then
            goto p189
        end
        goto p136
        ::p182::
        registers[9] = (registers[7] < 0.5)
        if not registers[9] then
            goto p19
        end
        goto p101
        ::p185::
        upvalues[0][registers[1]] = registers[2]
        goto p12
        ::p187::
        registers[9] = upvalues[0][registers[1]]
        do
            return registers[9]
        end
        ::p189::
        if registers[5] ~= "smooth" then
            goto p35
        end
        goto p15
        ::p191::
        registers[6] = (8)
        goto p122
        ::p193::
        registers[9] = registers[9] / 2
        registers[9] = 1 - registers[9]
        goto p113
    end
end
