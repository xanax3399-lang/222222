-- Recovered function f18; author names are unavailable.
F.f18 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2 = nil, nil
        local environment = andromeda_environment
        local tick = new_tick("f18")
        tick(1)
        slot_1 = upvalues[0]
        slot_2 = environment["config"]
        slot_2 = slot_2["export"];
        slot_2 = slot_2()
        slot_2 = (#slot_2)
        do
            return slot_1(slot_2)
        end
    end
end
