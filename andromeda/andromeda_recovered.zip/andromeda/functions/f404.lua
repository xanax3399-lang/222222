-- Recovered function f404; author names are unavailable.
F.f404 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_0, slot_1, slot_2, slot_3 = nil, nil, nil, nil
        local z = nil
        local tick = new_tick("f404")
        tick(1)
        slot_1 = upvalues[0]["visuals"]
        slot_1 = (slot_1 ~= slot_0)
        if not slot_1 then
            goto p40
        end
        slot_1 = upvalues[0]["visuals"]
        slot_1 = slot_1["stubs"]
        goto p40
        ::p10::
        tick(10)
        slot_2 = (slot_1 ~= slot_0)
        if not slot_2 then
            goto p60
        end
        slot_2 = slot_1["native_indicators"]
        slot_2 = (slot_2 ~= slot_0)
        goto p60
        ::p15::
        tick(15)
        slot_2 = slot_1["native_indicators"]
        z = slot_2
        slot_3 = z;
        slot_2 = z["get"];
        slot_2 = slot_2(slot_3)
        slot_2 = (slot_2 == true)
        ::p29::
        tick(29)
        do
            return slot_2
        end
        ::p40::
        if slot_1 then
            goto p10
        end
        slot_1 = nil
        goto p10
        ::p60::
        if not slot_2 then
            goto p29
        end
        goto p15
    end
end
