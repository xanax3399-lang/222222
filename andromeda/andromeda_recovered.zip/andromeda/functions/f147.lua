-- Recovered function f147; author names are unavailable.
F.f147 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f147")
        tick(1)
        goto p39
        ::p14::
        tick(14)
        registers[12] = registers[5]["y"]
        registers[13] = registers[5]["z"];
        registers[6] = registers[6](unpack_range(13, registers, 7))
        registers[7] = (registers[6] == 1)
        do
            return registers[7]
        end
        ::p32::
        tick(32)
        registers[7] = registers[2]
        registers[8] = registers[4]["x"]
        registers[9] = registers[4]["y"]
        registers[10] = registers[4]["z"]
        registers[11] = registers[5]["x"]
        goto p14
        ::p39::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]
        registers[5] = upvalues[1][46]
        registers[6] = registers[2]
        m, x = pack_returns(registers[5](unpack_range(6, registers, 6)))
        m = m + 5 - 1
        top = m
        z = 0
        for f = 5, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[4] = registers[4](unpack_range(top, registers, 5))
        registers[5] = upvalues[0]
        registers[6] = upvalues[1][46]
        registers[7] = registers[3]
        m, x = pack_returns(registers[6](unpack_range(7, registers, 7)))
        m = m + 6 - 1
        top = m
        z = 0
        for f = 6, m do
            z = (z + 1);
            registers[f] = x[z]
        end
        registers[5] = registers[5](unpack_range(top, registers, 6))
        registers[6] = upvalues[1][78]
        goto p32
    end
end
