-- Recovered function f48; author names are unavailable.
F.f48 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1, slot_2, slot_3, slot_4, slot_5, slot_6, slot_7 = nil, nil, nil, nil, nil, nil, nil
        local a = nil
        local tick = new_tick("f48")
        tick(1)
        goto p23
        ::p2::
        tick(2)
        if not (slot_1 < slot_2) then
            goto p42
        end
        goto p29
        ::p17::
        tick(17)
        if not (0 < slot_1) then
            goto p2
        end
        goto p27
        ::p19::
        tick(19)
        slot_6 = (slot_1 - slot_5)
        slot_1 = slot_6 / 2
        slot_3 = (slot_3 * 2)
        goto p42
        ::p23::
        a = {
            ...,
        }
        slot_1 = a[1]
        slot_2 = a[2]
        slot_3 = (1)
        slot_4 = (0)
        goto p17
        ::p27::
        if not (0 < slot_2) then
            goto p2
        end
        goto p67
        ::p29::
        slot_1 = slot_2
        goto p42
        ::p33::
        tick(33)
        slot_4 = slot_4 + slot_3
        goto p19
        ::p35::
        tick(35)
        slot_4 = slot_4 + slot_3
        goto p74
        ::p38::
        tick(38)
        slot_5 = slot_1 % 2
        if not (0 < slot_5) then
            goto p19
        end
        goto p33
        ::p42::
        if not (0 < slot_1) then
            goto p72
        end
        goto p38
        ::p67::
        slot_5 = slot_1 % 2
        slot_6 = slot_2 % 2
        if slot_5 == slot_6 then
            goto p74
        end
        goto p35
        ::p72::
        slot_5 = slot_4
        do
            return slot_5
        end
        ::p74::
        slot_7 = (slot_1 - slot_5)
        slot_1 = slot_7 / 2
        slot_7 = (slot_2 - slot_6)
        slot_2 = slot_7 / 2
        slot_3 = (slot_3 * 2)
        goto p17
    end
end
