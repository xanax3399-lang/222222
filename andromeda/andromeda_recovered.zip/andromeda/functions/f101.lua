-- Recovered function f101; author names are unavailable.
F.f101 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local U, z, a = nil, nil, nil
        local branch_taken = nil
        local tick = new_tick("f101")
        tick(1)
        goto p62
        ::p29::
        tick(29)
        registers[9] = (0)
        goto p242
        ::p31::
        tick(31)
        registers[8]["velocity"] = registers[7]
        registers[9] = upvalues[1][47]
        registers[10] = registers[2]
        registers[11] = "m_flDuckAmount"
        goto p101
        ::p37::
        tick(37)
        registers[7] = (0)
        goto p107
        ::p40::
        tick(40)
        do
            return 
        end
        ::p41::
        tick(41)
        do
            return 
        end
        ::p43::
        tick(43)
        branch_taken = false
        z, q = v(n, U)
        if not z then

        else
            registers[10] = z;
            registers[11] = q
            branch_taken = true
            U = z
        end
        if branch_taken then
            goto p138
        end
        goto p119
        ::p45::
        tick(45)
        registers[6] = registers[2]
        registers[7] = "m_vecVelocity"
        m, x = pack_returns(registers[5](unpack_range(7, registers, 6)))
        z = 0
        for f = 5, 6 do
            z = (z + 1);
            registers[f] = x[z]
        end
        goto p160
        ::p49::
        tick(49)
        if not (60 < registers[9]) then
            goto p41
        end
        goto p150
        ::p52::
        tick(52)
        if not registers[7] then
            goto p154
        end
        goto p79
        ::p62::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = upvalues[0]
        registers[5] = registers[1]
        registers[6] = "Smooth"
        registers[4] = registers[4](registers[5], registers[6])
        if registers[4] then
            goto p94
        end
        goto p40
        ::p79::
        registers[7] = registers[5]
        goto p154
        ::p94::
        registers[4] = upvalues[1][23];
        registers[4] = registers[4]()
        registers[5] = upvalues[1][47]
        goto p45
        ::p98::
        tick(98)
        registers[11] = (1);
        registers[9](registers[10], registers[11])
        goto p41
        ::p101::
        registers[9] = registers[9](registers[10], registers[11])
        if registers[9] then
            goto p242
        end
        goto p29
        ::p105::
        tick(105)
        registers[7] = (0)
        goto p193
        ::p107::
        tick(107)
        registers[8] = {
        }
        registers[9] = {
        }
        registers[8]["layers"] = registers[9]
        registers[8]["tick"] = registers[4]
        registers[9] = upvalues[1][30]
        goto p226
        ::p119::
        v = R[3]
        n = R[2]
        U = R[5]
        R = R[1]
        registers[9] = upvalues[2]["server_anim_states"]
        registers[10] = upvalues[2]["server_anim_states"]
        registers[10] = (#registers[10])
        registers[10] = registers[10] + 1
        registers[9][registers[10]] = registers[8]
        registers[9] = upvalues[2]["server_anim_states"]
        registers[9] = (#registers[9])
        goto p49
        ::p129::
        tick(129)
        registers[8]["weapon"] = registers[9]
        registers[9] = environment["pairs"]
        registers[10] = upvalues[2]["layers"]
        m, x = pack_returns(registers[9](unpack_range(10, registers, 10)))
        z = 0
        for f = 9, 11 do
            z = (z + 1);
            registers[f] = x[z]
        end
        R = ({
            [1] = R,
            [3] = v,
            [5] = U,
            [2] = n,
        })
        v = registers[(9)]
        n = registers[10]
        U = registers[11]
        goto p43
        goto p31
        ::p135::
        tick(135)
        registers[7] = registers[6]
        goto p213
        ::p138::
        z = registers[3]
        registers[12] = z;
        registers[(11)] = z["get_anim_overlay"]
        registers[13] = registers[10]
        registers[11] = registers[11](registers[12], registers[13])
        goto p202
        ::p142::
        tick(142)
        registers[12] = registers[8]["layers"]
        registers[13] = {
        }
        registers[14] = registers[11]["cycle"]
        goto p156
        ::p146::
        tick(146)
        registers[10] = registers[10](registers[11], registers[12])
        if registers[10] then
            goto p219
        end
        goto p224
        ::p150::
        registers[9] = environment["table"]
        registers[9] = registers[9]["remove"]
        registers[10] = upvalues[2]["server_anim_states"]
        goto p98
        ::p154::
        if registers[7] then
            goto p193
        end
        goto p105
        ::p156::
        registers[13]["cycle"] = registers[14]
        registers[14] = registers[11]["weight"]
        registers[13]["weight"] = registers[14]
        goto p171
        ::p160::
        registers[7] = environment["type"]
        registers[8] = registers[5];
        registers[(7)] = registers[(7)](registers[8])
        registers[7] = (registers[7] == "number")
        goto p52
        ::p171::
        registers[12][registers[10]] = registers[13]
        goto p43
        ::p193::
        registers[5] = registers[7]
        registers[7] = environment["type"]
        registers[8] = registers[6];
        registers[(7)] = registers[(7)](registers[8])
        registers[7] = (registers[7] == "number")
        if not registers[7] then
            goto p213
        end
        goto p135
        ::p200::
        tick(200)
        registers[7] = (0)
        goto p209
        ::p202::
        if registers[11] == registers[0] then
            goto p43
        end
        goto p142
        ::p204::
        tick(204)
        registers[9] = registers[6] * registers[6]
        registers[8] = registers[8] + registers[9];
        registers[(7)] = registers[(7)](registers[8])
        branch_taken = false
        if not (not (registers[7] < 0.1)) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p107
        end
        goto p37
        ::p209::
        tick(209)
        registers[6] = registers[7]
        registers[7] = upvalues[1][155]
        registers[8] = registers[5] * registers[5]
        goto p204
        ::p213::
        if registers[7] then
            goto p209
        end
        goto p200
        ::p215::
        tick(215)
        registers[10] = upvalues[1][47]
        registers[11] = registers[2]
        registers[12] = "m_fFlags"
        goto p146
        ::p219::
        tick(219)
        registers[11] = (1)
        registers[9] = registers[9](registers[10], registers[11])
        registers[9] = (registers[9] == 1)
        registers[8]["on_ground"] = registers[9]
        goto p31
        ::p224::
        registers[10] = (0)
        goto p219
        ::p226::;
        registers[9] = registers[9]()
        registers[8]["time"] = registers[9]
        registers[9] = upvalues[1][47]
        registers[10] = registers[2]
        registers[11] = "m_bDucking"
        registers[9] = registers[9](registers[10], registers[11])
        registers[9] = (registers[9] == 1)
        registers[8]["ducking"] = registers[9]
        registers[9] = environment["bit"]
        registers[9] = registers[9]["band"]
        goto p215
        ::p242::
        registers[8]["duck_amount"] = registers[9]
        registers[9] = upvalues[1][37]
        registers[10] = registers[2];
        registers[(9)] = registers[(9)](registers[10])
        goto p129
    end
end
