-- Recovered function f480; author names are unavailable.
F.f480 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local slot_1 = nil
        local tick = new_tick("f480")
        tick(1)
        slot_1 = {
        }
        slot_1["Antiaim"] = true
        slot_1["Visuals"] = true
        do
            return slot_1
        end
    end
end
