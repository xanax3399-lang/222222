-- Recovered function f51; author names are unavailable.
F.f51 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local z, a = nil, nil
        local tick = new_tick("f51")
        tick(1)
        goto p104
        ::p2::
        tick(2)
        do
            return registers[7]
        end
        ::p17::
        tick(17)
        if registers[5] ~= 2047 then
            goto p96
        end
        goto p51
        ::p19::
        tick(19)
        registers[7] = (20);
        registers[4] = registers[4](unpack_range(7, registers, 5))
        registers[4] = (registers[4] * 4294967296)
        registers[4] = registers[4] + registers[1]
        registers[5] = upvalues[1]
        registers[6] = registers[2]
        goto p137
        ::p26::
        tick(26)
        registers[8] = registers[3] + registers[8]
        registers[7] = registers[7] * registers[8]
        do
            return registers[7]
        end
        ::p51::
        registers[7] = (registers[4] == 0)
        if not registers[7] then
            goto p92
        end
        goto p79
        ::p71::
        tick(71)
        registers[6] = 1 ^ registers[6]
        registers[6] = -registers[6]
        if registers[5] ~= 0 then
            goto p17
        end
        goto p122
        ::p75::
        tick(75)
        registers[7] = (registers[6] * 0)
        registers[7] = registers[7] / 0
        goto p2
        ::p79::
        registers[7] = (registers[6] * 1)
        registers[7] = registers[7] / 0
        ::p92::
        if registers[7] then
            goto p2
        end
        goto p75
        ::p94::
        tick(94)
        registers[7] = (registers[6] * 0)
        do
            return registers[7]
        end
        ::p96::
        tick(96)
        registers[7] = (registers[5] - 1023)
        registers[7] = 2 ^ registers[7]
        registers[7] = registers[6] * registers[7]
        registers[8] = registers[4] / 4503599627370496
        goto p26
        ::p104::
        registers[1] = upvalues[0];
        registers[1] = registers[1]()
        a = registers
        z = 2
        q = upvalues
        q = q[0]
        a[z] = q;
        registers[2] = registers[2]()
        goto p132
        ::p122::
        if registers[4] ~= 0 then
            goto p124
        end
        goto p94
        ::p124::
        registers[5] = (1)
        registers[3] = (0)
        goto p96
        ::p127::
        tick(127)
        registers[6] = upvalues[1]
        registers[7] = registers[2]
        registers[8] = (32)
        registers[6] = registers[6](registers[7], registers[8])
        goto p71
        ::p132::
        registers[3] = (1)
        registers[4] = upvalues[1]
        registers[5] = registers[2]
        registers[6] = (1)
        goto p19
        ::p137::
        registers[7] = (21)
        registers[8] = (31);
        registers[5] = registers[5](unpack_range(8, registers, 6))
        goto p127
    end
end
