-- Recovered function f229; author names are unavailable.
F.f229 = function(function_metadata, upvalues)
    local frame_size = function_metadata[7]
    return function(...)
        if startup_blocked then
            return 
        end
        local registers, top, environment, W, n, m, x, N, H, v, R, Q, q = new_frame(frame_size), 1, andromeda_environment, 1
        local a = nil
        local branch_taken = nil
        local tick = new_tick("f229")
        tick(1)
        goto p93
        ::p8::
        tick(8)
        registers[8] = registers[2]
        goto p37
        ::p28::
        tick(28)
        registers[6] = (1)
        goto p100
        ::p31::
        tick(31)
        registers[9] = (0)
        goto p115
        ::p33::
        tick(33)
        a = upvalues[0];
        registers[8] = a[2][a[1]]["packets"]
        registers[9] = registers[1]["last_flick_at"]
        registers[8] = (registers[8] - registers[9])
        goto p86
        ::p37::
        tick(37)
        if registers[8] then
            goto p39
        end
        goto p139
        ::p39::
        tick(39)
        registers[9] = registers[8]
        if registers[9] then
            goto p115
        end
        goto p31
        ::p51::
        tick(51)
        registers[9] = -1
        goto p134
        ::p65::
        tick(65)
        registers[7] = (0)
        goto p33
        ::p82::
        tick(82)
        registers[8] = registers[1]["flicker"]
        if not registers[8] then
            goto p37
        end
        goto p8
        ::p86::
        branch_taken = false
        if not (not (registers[6] <= registers[8])) then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p82
        end
        goto p103
        ::p88::
        tick(88)
        if registers[9] then
            goto p134
        end
        goto p51
        ::p93::
        a = {
            ...,
        }
        registers[1] = a[1]
        registers[2] = a[2]
        registers[3] = a[3]
        registers[4] = a[4]
        registers[5] = a[5]
        registers[6] = registers[4]
        if registers[6] then
            goto p100
        end
        goto p28
        ::p100::
        registers[7] = registers[5]
        if registers[7] then
            goto p33
        end
        goto p65
        ::p103::
        registers[8] = registers[1]["flicker"]
        registers[8] = not registers[8]
        registers[1]["flicker"] = registers[8]
        a = upvalues[0];
        registers[8] = a[2][a[1]]["packets"]
        registers[1]["last_flick_at"] = registers[8]
        goto p82
        ::p109::
        tick(109)
        registers[9] = registers[8] > 0
        if not registers[9] then
            goto p88
        end
        goto p124
        ::p112::
        tick(112)
        registers[9] = registers[9] * registers[10]
        registers[8] = registers[8] + registers[9]
        goto p121
        ::p115::
        registers[8] = registers[9]
        branch_taken = false
        if registers[7] ~= 0 then

        else
            branch_taken = true
        end
        if branch_taken then
            goto p121
        end
        goto p109
        ::p121::
        registers[9] = registers[8]
        registers[10] = registers[1]["flicker"]
        do
            return unpack_range(10, registers, (9))
        end
        ::p124::
        registers[9] = (1)
        goto p88
        ::p134::
        registers[10] = upvalues[1]["random_int"]
        registers[11] = (0)
        registers[12] = registers[7]
        registers[10] = registers[10](registers[11], registers[12])
        goto p112
        ::p139::
        registers[8] = registers[3]
        goto p39
    end
end
