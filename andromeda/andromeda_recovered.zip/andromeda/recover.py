"""Conservative source-to-source recovery of the supplied expanded Lua program.

Never runs the application. Keeps mutable frames/capture cells and startup guards.
"""
from pathlib import Path
import collections, contextlib, copy, io, json, math, re, sys, time
from concurrent.futures import ProcessPoolExecutor
from luaparser import ast
from luaparser import astnodes as n
from luaparser.printers import LuaOutputVisitor

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'reference/andromeda_supplied.lua'
SCRATCH = set('top environment W n m x N H v R Q q T U _ S z a branch_taken'.split())

def children(node):
    if not isinstance(node, n.Node): return
    for key, value in vars(node).items():
        if key.startswith('_') or key in ('comments', 'wrapped'): continue
        if isinstance(value, n.Node): yield key, value
        elif isinstance(value, list):
            for i,item in enumerate(value):
                if isinstance(item,n.Node): yield (key,i), item

def walk(node):
    yield node
    for _,child in children(node): yield from walk(child)

def literal(node):
    if isinstance(node,n.Number): return ('number', node.n)
    if isinstance(node,n.TrueExpr): return ('boolean',True)
    if isinstance(node,n.FalseExpr): return ('boolean',False)
    if isinstance(node,n.Nil): return ('nil',None)
    if isinstance(node,n.String): return ('string',node.raw_literal)
    return None

def node_for(value):
    if value is None: return n.Nil()
    if value is True: return n.TrueExpr()
    if value is False: return n.FalseExpr()
    return n.Number(value)

def truth(lit): return lit[0] != 'nil' and not (lit[0]=='boolean' and not lit[1])

def expression(node, known):
    if not isinstance(node,n.Node): return node
    if isinstance(node,n.Name) and node.id in known: return copy.deepcopy(known[node.id])
    if isinstance(node,(n.AnonymousFunction,n.Function,n.LocalFunction)): return node
    for key,child in list(children(node)):
        # Dot field identifiers are keys, not variable reads.
        if isinstance(node,n.Index) and key=='idx' and node.notation==n.IndexNotation.DOT: continue
        changed=expression(child,known)
        if isinstance(key,tuple): getattr(node,key[0])[key[1]]=changed
        else: setattr(node,key,changed)
    if isinstance(node,n.UMinusOp):
        value=literal(node.operand)
        if value and value[0]=='number': return node_for(-value[1])
    if isinstance(node,n.ULNotOp):
        value=literal(node.operand)
        if value: return node_for(not truth(value))
    if isinstance(node,n.BinaryOp):
        a,b=literal(node.left),literal(node.right)
        if isinstance(node,(n.AndLoOp,n.OrLoOp)) and a:
            if isinstance(node,n.AndLoOp): return node.right if truth(a) else node.left
            return node.left if truth(a) else node.right
        if a and b:
            av,bv=a[1],b[1]
            if isinstance(node,(n.EqToOp,n.NotEqToOp)):
                # Different spellings can denote the same Lua byte string.
                if a[0]==b[0]=='string' and av!=bv: return node
                result=a[0]==b[0] and av==bv
                return node_for(not result if isinstance(node,n.NotEqToOp) else result)
            if a[0]==b[0]=='number' and abs(av)<1e9 and abs(bv)<1e9:
                operations={n.AddOp:lambda:av+bv,n.SubOp:lambda:av-bv,n.MultOp:lambda:av*bv,
                            n.FloatDivOp:lambda:av/bv,n.ModOp:lambda:av%bv,
                            n.LessThanOp:lambda:av<bv,n.LessOrEqThanOp:lambda:av<=bv,
                            n.GreaterThanOp:lambda:av>bv,n.GreaterOrEqThanOp:lambda:av>=bv}
                action=operations.get(type(node))
                if action:
                    try:
                        result=action()
                        if isinstance(result,bool) or (math.isfinite(result) and abs(result)<1e9): return node_for(result)
                    except (ZeroDivisionError,OverflowError): pass
    return node

def assignments(node):
    return {t.id for x in walk(node) if isinstance(x,n.Assign) for t in x.targets if isinstance(t,n.Name)}

def simplify(block, known=None):
    known={} if known is None else dict(known)
    output=[]
    local_names=set()
    for stmt in block.body:
        if isinstance(stmt,n.Assign):
            values=[expression(v,known) for v in stmt.values]
            targets=[]
            for target in stmt.targets:
                targets.append(expression(target,known) if not isinstance(target,n.Name) else target)
            stmt.values,stmt.targets=values,targets
            for i,target in enumerate(targets):
                if not isinstance(target,n.Name): continue
                if isinstance(stmt,n.LocalAssign): local_names.add(target.id)
                known.pop(target.id,None)
                # Restrict propagation to interpreter scratch, never frame cells/captures.
                if target.id in SCRATCH and i<len(values) and literal(values[i]) is not None:
                    known[target.id]=copy.deepcopy(values[i])
            output.append(stmt)
        elif isinstance(stmt,n.Do):
            old=dict(known)
            stmt.body,known,declared=simplify(stmt.body,known)
            for name in declared:
                known.pop(name,None)
                if name in old: known[name]=old[name]
            # Removing one redundant do layer does not change the contained scope.
            if len(stmt.body.body)==1 and isinstance(stmt.body.body[0],n.Do): stmt=stmt.body.body[0]
            if stmt.body.body: output.append(stmt)
        elif isinstance(stmt,n.If):
            stmt.test=expression(stmt.test,known)
            value=literal(stmt.test)
            if value is not None:
                chosen=stmt.body if truth(value) else stmt.orelse
                if isinstance(chosen,n.ElseIf):
                    chosen=n.Block([n.If(chosen.test,chosen.body,chosen.orelse)])
                if isinstance(chosen,n.Block):
                    old=dict(known); chosen,known,declared=simplify(chosen,known)
                    for name in declared:
                        known.pop(name,None)
                        if name in old: known[name]=old[name]
                    if chosen.body: output.append(n.Do(chosen))
            else:
                stmt.body,_,_=simplify(stmt.body,known)
                if isinstance(stmt.orelse,n.Block): stmt.orelse,_,_=simplify(stmt.orelse,known)
                elif isinstance(stmt.orelse,n.ElseIf):
                    tmp,_,_=simplify(n.Block([n.If(stmt.orelse.test,stmt.orelse.body,stmt.orelse.orelse)]),known)
                    stmt.orelse=n.Block(tmp.body)
                for name in assignments(stmt): known.pop(name,None)
                output.append(stmt)
        elif isinstance(stmt,n.Fornum):
            stmt.start=expression(stmt.start,known);stmt.stop=expression(stmt.stop,known)
            if stmt.step: stmt.step=expression(stmt.step,known)
            start,stop=literal(stmt.start),literal(stmt.stop)
            step=literal(stmt.step) if stmt.step else ('number',1)
            unsafe=any(isinstance(x,(n.AnonymousFunction,n.LocalFunction,n.Break,n.Goto,n.Label)) for x in walk(stmt.body))
            if (start and stop and step and start[0]==stop[0]==step[0]=='number'
                and step[1]!=0 and abs(stop[1]-start[1])<=32 and not unsafe
                and stmt.target.id not in assignments(stmt.body)
                and all(float(x[1]).is_integer() for x in (start,stop,step))):
                old=dict(known)
                for value in range(int(start[1]),int(stop[1])+(1 if step[1]>0 else -1),int(step[1])):
                    iteration=dict(known);iteration[stmt.target.id]=n.Number(value)
                    piece,known,_=simplify(copy.deepcopy(stmt.body),iteration)
                    if piece.body: output.append(n.Do(piece))
                known.pop(stmt.target.id,None)
                if stmt.target.id in old: known[stmt.target.id]=old[stmt.target.id]
                continue
            loop_known=dict(known)
            for name in assignments(stmt): loop_known.pop(name,None);known.pop(name,None)
            loop_known.pop(stmt.target.id,None)
            stmt.body,_,_=simplify(stmt.body,loop_known)
            output.append(stmt)
        elif isinstance(stmt,(n.Forin,n.While,n.Repeat)):
            for name in assignments(stmt): known.pop(name,None)
            stmt=expression(stmt,known)
            output.append(stmt)
        else:
            output.append(expression(stmt,known))
    return n.Block(output),known,local_names

def uses_defs(stmt):
    if isinstance(stmt,(n.Goto,n.Label,n.SemiColon)): return set(),set()
    if isinstance(stmt,n.Assign):
        uses={x.id for v in stmt.values for x in walk(v) if isinstance(x,n.Name)}
        defs=set()
        for target in stmt.targets:
            if isinstance(target,n.Name): defs.add(target.id)
            else: uses.update(x.id for x in walk(target) if isinstance(x,n.Name))
        return uses,defs
    if isinstance(stmt,n.Do):
        uses,defs=set(),set()
        for sub in stmt.body.body:
            u,d=uses_defs(sub);uses.update(u-defs);defs.update(d)
        return uses,defs
    def names(node):
        if isinstance(node,(n.Goto,n.Label)): return set()
        if isinstance(node,n.Name): return {node.id}
        return set().union(*(names(child) for _,child in children(node)))
    return names(stmt),set()

def pure(node):
    # Indexing, calls and arithmetic can have side effects/errors: keep them.
    return literal(node) is not None or isinstance(node,n.Name)

def dce(block, live):
    out=[]
    for stmt in reversed(block.body):
        if isinstance(stmt,n.Do):
            stmt.body,live=dce(stmt.body,live)
            if stmt.body.body: out.append(stmt)
            continue
        u,d=uses_defs(stmt)
        if (type(stmt) is n.Assign and d and d<=SCRATCH and not(d&live)
                and len(d)==len(stmt.targets) and all(pure(v) for v in stmt.values)):
            continue
        live=(live-d)|u
        out.append(stmt)
    return n.Block(list(reversed(out))),live

def ends_return(stmt):
    if isinstance(stmt,n.Return): return True
    if isinstance(stmt,n.Do) and stmt.body.body: return ends_return(stmt.body.body[-1])
    return False

def short_branch(body):
    # false flag -> conditional true flag -> conditional jump becomes a direct branch.
    def flatten(stmt):
        while isinstance(stmt,n.Do) and len(stmt.body.body)==1: stmt=stmt.body.body[0]
        return stmt
    for i in range(len(body)-2):
        a,b,c=map(flatten,body[i:i+3])
        if (type(a) is n.Assign and len(a.targets)==1 and isinstance(a.targets[0],n.Name)
            and a.targets[0].id=='branch_taken' and isinstance(a.values[0],n.FalseExpr)
            and isinstance(b,n.If) and not b.orelse and len(b.body.body)==1
            and isinstance(c,n.If) and isinstance(c.test,n.Name) and c.test.id=='branch_taken'):
            set_true=flatten(b.body.body[0])
            if (type(set_true) is n.Assign and isinstance(set_true.targets[0],n.Name)
                and set_true.targets[0].id=='branch_taken' and isinstance(set_true.values[0],n.TrueExpr)):
                c.test=b.test
                return short_branch(body[:i]+[c]+body[i+3:])
    return body

class RawLuaVisitor(LuaOutputVisitor):
    def do_visit(self,node):
        # luaparser decodes decimal escapes using Python/octal rules. Preserve
        # original literal tokens instead of re-emitting its decoded String.s.
        if isinstance(node,n.String): return node.raw_literal
        if isinstance(node,n.Field) and node.between_brackets and isinstance(node.key,n.Number) and node.key.first_token is None:
            # {...} and {f()} expand all final results; {[1]=...} does not.
            return self.do_visit(node.value)
        return super().do_visit(node)

def render(tree):
    for node in walk(tree):
        if isinstance(node,(n.Name,n.Index)): node.wrapped=False
    text=RawLuaVisitor(indent_size=4).do_visit(tree)
    lines=[]
    for line in text.splitlines():
        if line.strip()==';':
            if lines and not (lines[-1].strip() in ('do','else') or lines[-1].strip().endswith(' then')):
                lines[-1]+=';'
        else: lines.append(line)
    return '\n'.join(lines)

def prune_declarations(block):
    used=set()
    def collect(node):
        if isinstance(node,n.LocalAssign):
            for value in node.values: collect(value)
        else:
            if isinstance(node,n.Name): used.add(node.id)
            for _,child in children(node): collect(child)
    collect(block)
    result=[]
    for stmt in block.body:
        if isinstance(stmt,n.LocalAssign) and all(literal(v) is not None or isinstance(v,n.Name) for v in stmt.values):
            keep=[i for i,t in enumerate(stmt.targets) if t.id in used]
            if not keep: continue
            stmt.targets=[stmt.targets[i] for i in keep]
            stmt.values=[stmt.values[i] if i<len(stmt.values) else n.Nil() for i in keep]
        result.append(stmt)
    return n.Block(result)

def flatten_scopes(block):
    result=[]
    for stmt in block.body:
        if isinstance(stmt,n.Do):
            stmt.body=flatten_scopes(stmt.body)
            # Keep scopes with local declarations and returns (Lua's return rule).
            if not any(isinstance(x,(n.LocalAssign,n.LocalFunction,n.Return)) for x in stmt.body.body):
                result.extend(stmt.body.body);continue
        result.append(stmt)
    return n.Block(result)

def scalarize(inner):
    slots=set()
    def check(node,parent=None,key=None):
        if isinstance(node,n.Name) and node.id=='registers':
            if not (isinstance(parent,n.Index) and key=='value' and isinstance(parent.idx,n.Number)):
                return False
            slots.add(parent.idx.n)
        return all(check(child,node,key) for key,child in children(node))
    # Ignore the initial frame declaration while looking for frame escapes.
    declaration=next((x for x in inner.body.body if isinstance(x,n.LocalAssign)
                      and any(isinstance(t,n.Name) and t.id=='registers' for t in x.targets)),None)
    if declaration is None: return 0
    others=n.Block([x for x in inner.body.body if x is not declaration])
    if not check(others) or len(slots)>100: return 0
    if not all(isinstance(i,int) and i>=0 for i in slots): return 0
    def change(node):
        if isinstance(node,n.Index) and isinstance(node.value,n.Name) and node.value.id=='registers':
            return n.Name('slot_'+str(int(node.idx.n)))
        for key,child in list(children(node)):
            value=change(child)
            if isinstance(key,tuple): getattr(node,key[0])[key[1]]=value
            else: setattr(node,key,value)
        return node
    inner.body=change(inner.body)
    pos=next(i for i,t in enumerate(declaration.targets) if t.id=='registers')
    declaration.targets.pop(pos)
    if pos<len(declaration.values): declaration.values.pop(pos)
    if slots:
        at=inner.body.body.index(declaration)
        inner.body.body.insert(at,n.LocalAssign([n.Name('slot_'+str(i)) for i in sorted(slots)],[]))
    return len(slots)

def flatten_chunks(inner):
    body=inner.body.body
    chunks=[];head=[];entry=None
    for stmt in body:
        if isinstance(stmt,n.LocalAssign) and any(t.id=='entry_pc' for t in stmt.targets):
            entry=stmt.values[0].n
            continue
        if isinstance(stmt,n.LocalAssign) and any(t.id=='chunks' for t in stmt.targets): continue
        if (isinstance(stmt,n.Assign) and len(stmt.targets)==1 and isinstance(stmt.targets[0],n.Index)
            and isinstance(stmt.targets[0].value,n.Name) and stmt.targets[0].value.id=='chunks'):
            assert isinstance(stmt.values[0],n.AnonymousFunction)
            statements=stmt.values[0].body.body
            first=next(i for i,x in enumerate(statements) if isinstance(x,n.Label))
            chunks.extend(statements[first:])
        elif isinstance(stmt,n.While):
            assert chunks
        else: head.append(stmt)
    assert len(chunks)>1000 and entry is not None
    def transfers(node):
        if isinstance(node,n.Do):
            st=[x for x in node.body.body if not isinstance(x,n.SemiColon)]
            if (len(st)==3 and isinstance(st[0],n.Assign) and isinstance(st[1],n.Assign)
                and isinstance(st[2],n.Return) and st[0].targets[0].id=='entry_pc'
                and st[1].targets[0].id=='current_chunk'):
                assert isinstance(st[2].values[0],n.FalseExpr)
                return n.Goto(n.Name('p'+str(st[0].values[0].n)))
        if isinstance(node,n.Return) and node.values and isinstance(node.values[0],n.TrueExpr):
            assert len(node.values)==1
            return n.Return([])
        for key,child in list(children(node)):
            value=transfers(child)
            if isinstance(key,tuple): getattr(node,key[0])[key[1]]=value
            else: setattr(node,key,value)
        return node
    inner.body=n.Block(head+[n.Goto(n.Name('p'+str(entry)))]+[transfers(x) for x in chunks])
    assert not any(isinstance(x,n.Name) and x.id in ('entry_pc','current_chunk','chunks') for x in walk(inner.body))

def process(task):
    fid,source,*options=task
    chunk_mode='chunk' in options
    start=time.monotonic()
    with contextlib.redirect_stdout(io.StringIO()): tree=ast.parse(source)
    for node in walk(tree):
        if isinstance(node,n.String):
            raw=source[node.first_token.start:node.last_token.stop+1].strip()
            while raw.startswith('(') and raw.endswith(')'): raw=raw[1:-1].strip()
            assert raw.startswith(('"',"'",'[')),(fid,raw[:60])
            node.raw_literal=raw
    factory=tree.body.body[0].values[0]
    returned=factory.body.body[-1]
    if not isinstance(returned,n.Return) or not isinstance(returned.values[0],n.AnonymousFunction):
        raise ValueError((fid,'unknown factory layout'))
    inner=returned.values[0]
    if fid==96 and not chunk_mode: flatten_chunks(inner)
    labels=[i for i,s in enumerate(inner.body.body) if isinstance(s,n.Label)]
    if not labels:
        rendered=render(tree)
        return fid,rendered,{'seconds':round(time.monotonic()-start,3),'blocks':0}
    head=inner.body.body[:labels[0]]
    body_writes=assignments(n.Block(inner.body.body[labels[0]:]))
    # Without a closure-cell allocation the open-capture table stays nil.
    stable={'N':n.Nil()} if 'N' not in body_writes and not chunk_mode else {}
    blocks=collections.OrderedDict()
    for a,b in zip(labels,labels[1:]+[len(inner.body.body)]):
        label=inner.body.body[a].id
        name=label.id if isinstance(label,n.Name) else label
        block=n.Block(inner.body.body[a+1:b])
        # Operate on individual instruction scopes with conservative scratch facts.
        block,_,_=simplify(block,stable)
        block.body=short_branch(block.body)
        blocks[name]=block
    names=list(blocks)
    successors={}
    for i,(name,block) in enumerate(blocks.items()):
        targets={g.label.id for g in walk(block) if isinstance(g,n.Goto)}
        if block.body and not isinstance(block.body[-1],n.Goto) and not ends_return(block.body[-1]) and i+1<len(names):
            targets.add(names[i+1])
        successors[name]=targets
    # Fixed-point liveness: no cross-branch expression substitution.
    live_in={name:set() for name in blocks}; live_out={name:set() for name in blocks}
    summaries={}
    for name,block in blocks.items():
        u,d=set(),set()
        for stmt in block.body:
            su,sd=uses_defs(stmt);u.update(su-d);d.update(sd)
        summaries[name]=(u,d)
    changed=True
    while changed:
        changed=False
        for name in reversed(names):
            out=set().union(*(live_in[t] for t in successors[name] if t in live_in))
            if chunk_mode and (not successors[name] or any(isinstance(x,n.Return) for x in walk(blocks[name]))):
                out.update(SCRATCH | {'registers','upvalues','entry_pc','current_chunk','arguments','argument_count','chunks'})
            u,d=summaries[name]; incoming=u|(out-d)
            if incoming!=live_in[name] or out!=live_out[name]: changed=True
            live_in[name],live_out[name]=incoming,out
    for name,block in blocks.items(): blocks[name],_=dce(block,live_out[name])
    # Only remove jumps to the physically next block. Do not speculate about loops.
    for i,name in enumerate(names[:-1]):
        body=blocks[name].body
        if body and isinstance(body[-1],n.Goto) and body[-1].label.id==names[i+1]: body.pop()
    if head and isinstance(head[-1],n.Goto) and head[-1].label.id==names[0]: head.pop()
    referenced={g.label.id for b in blocks.values() for g in walk(b) if isinstance(g,n.Goto)}
    referenced.update(g.label.id for b in head for g in walk(b) if isinstance(g,n.Goto))
    joined=list(head)
    for name,block in blocks.items():
        if name in referenced: joined.append(n.Label(n.Name(name)))
        joined.extend(block.body)
    inner.body=flatten_scopes(n.Block(joined))
    slots=scalarize(inner)
    for i,stmt in enumerate(inner.body.body):
        if isinstance(stmt,n.LocalFunction) and stmt.name.id=='tick':
            fid_string=next(x for x in walk(stmt) if isinstance(x,n.String) and x.raw_literal in ('"f'+str(fid)+'"',"'f"+str(fid)+"'"))
            inner.body.body[i]=n.LocalAssign([n.Name('tick')],[n.Call(n.Name('new_tick'),[copy.deepcopy(fid_string)])])
    inner.body=prune_declarations(inner.body)
    # The operand aliases are unused in the expanded code; keep metadata actually read.
    alias=factory.body.body[0]
    if isinstance(alias,n.LocalAssign) and len(alias.targets)==7:
        used={x.id for x in walk(inner) if isinstance(x,n.Name)}
        keep=[(t,v) for t,v in zip(alias.targets,alias.values) if t.id in used]
        if keep: alias.targets,alias.values=map(list,zip(*keep))
        else: factory.body.body.pop(0)
    rendered=render(tree)
    return fid,rendered,{'seconds':round(time.monotonic()-start,3),'blocks':len(blocks),
                         'bytes_before':len(source.encode()),'bytes_after':len(rendered.encode()),'scalar_slots':slots}

def main():
    source=INPUT.read_text()
    matches=list(re.finditer(r'^F\.f(\d+)=function\(function_metadata,upvalues\)',source,re.M))
    assert len(matches)==564
    end=source.index('-- Recovered arithmetic XOR helpers.')
    prefix=source[:matches[0].start()]
    prefix+='''
-- Shared implementation of the original per-call startup checkpoints.
local function new_tick(function_id)
    local instructions_left = startup_instruction_limit
    return function(pc)
        current_function, current_pc = function_id, pc
        if startup_active then
            instructions_left = instructions_left - 1
            if instructions_left <= 0 then
                error("ANDROMEDA_STARTUP_LIMIT: " .. function_id .. " pc=" .. pc, 0)
            end
            startup_poll_remaining = startup_poll_remaining - 1
            if startup_poll_remaining <= 0 then
                startup_poll_remaining = startup_poll_interval
                check_startup_clock()
            end
        end
    end
end

'''
    suffix=source[end:]
    tasks=[]
    for i,match in enumerate(matches):
        stop=matches[i+1].start() if i+1<len(matches) else end
        text=source[match.start():stop]
        # Remove only a trailing annotation for the following function.
        text=re.sub(r'\n-- Function f\d+;[^\n]*\n\s*$','\n',text)
        tasks.append((int(match[1]),text))
    out=ROOT/'functions';out.mkdir(exist_ok=True)
    results={}; stats={}
    # Each function is independent; two workers keep parser memory bounded.
    with ProcessPoolExecutor(max_workers=2) as pool:
        for fid,text,info in pool.map(process,tasks):
            results[fid]=text;stats[str(fid)]=info
            (out/f'f{fid:03}.lua').write_text(f'-- Recovered function f{fid}; author names are unavailable.\n'+text+'\n')
            if fid%20==0 or fid in (1,2,96):
                print(f'f{fid}: {info}',flush=True)
    merged=prefix+'\n'.join(f'-- Recovered function f{i}\n'+results[i] for i in range(1,565))+'\n'+suffix
    (ROOT/'andromeda_source.lua').write_text(merged)
    (ROOT/'recovery_stats.json').write_text(json.dumps(stats,indent=2)+'\n')
    print('DONE',len(source.encode()),len(merged.encode()),flush=True)

if __name__=='__main__': main()
