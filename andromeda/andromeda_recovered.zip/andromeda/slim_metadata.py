"""Remove unused instruction-operand arrays from executable source.

Original arrays remain in the supplied reference and an extracted metadata file.
"""
from pathlib import Path
import re,json
import validate

ROOT=Path(__file__).resolve().parent
original=validate.INPUT.read_text()
lua,module=validate.runtime(original)

def literal(value, depth=0):
    kind=lua.eval(b'type')(value)
    if kind==b'nil':return 'nil'
    if kind==b'boolean':return 'true' if value else 'false'
    if kind==b'number':
        return str(int(value)) if float(value).is_integer() else repr(value)
    if kind==b'string':
        return '"'+''.join(chr(x) if 32<=x<127 and x not in (34,92) else '\\%03d'%x for x in value)+'"'
    assert kind==b'table' and depth<10,(kind,depth)
    return '{'+','.join('['+literal(k,depth+1)+']='+literal(v,depth+1) for k,v in sorted(value.items(),key=lambda kv:str(kv[0])))+'}'

current=(ROOT/'andromeda_source.lua').read_text()
needed=set()
matches=list(re.finditer(r'^F\.f(\d+)\s*=\s*function',current,re.M))
for i,m in enumerate(matches):
    end=matches[i+1].start() if i+1<len(matches) else current.index('-- Recovered arithmetic XOR helpers.')
    if re.search(r'function_metadata\[8\]',current[m.start():end]):needed.add(int(m[1]))
assert len(matches)==564
records=[]
for i in range(1,565):
    proto=module[b'D'][f'f{i}'.encode()]
    records.append('D.f%d={id="f%d",[4]=%s,[7]=%s,[9]=%s}' % (i,i,literal(proto[4]),literal(proto[7]),literal(proto[9])))
for i in sorted(needed):records.append(f'D.f{i}[8]={literal(module[b'D'][f"f{i}".encode()][8])}')
metadata='\n'.join(records)+'\n\n'
before=original.index('D.f1={')
after=original.index('\n\nmake_function=function')
(ROOT/'prototype_metadata_reference.lua').write_text('-- Original operand/constant arrays; reference data, not an application.\nlocal D={}\n'+original[before:after]+'\nreturn D\n')
for name in ['andromeda_source.lua','andromeda_flat_source.lua']:
    path=ROOT/name; text=path.read_text()
    start=text.index('D.f1={'); end=text.index('\n\nmake_function=function')
    text=text[:start]+metadata+text[end:]
    path.write_text(text)
print('Replaced unused metadata arrays; retained instruction guard metadata for',sorted(needed))
