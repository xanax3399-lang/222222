from pathlib import Path
import hashlib, json, re, sys, time
from lupa.luajit21 import LuaRuntime

ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'reference/andromeda_supplied.lua'

TRUSTED='''
jit.off()
local native_load, native_setfenv = loadstring, setfenv
local actual_bit = require('bit')
local function stub(...) return 1,2,3,4,5 end
local allowed_names={'assert','error','ipairs','next','pairs','pcall','select','tonumber','tostring','type','unpack','xpcall','setmetatable','getmetatable','rawget','rawset','rawequal','collectgarbage','newproxy'}
function load_definitions(source)
    local env={_SCRIPT_NAME='andromeda',_VERSION=_VERSION}
    for _,name in ipairs(allowed_names) do env[name]=_G[name] end
    for _,name in ipairs({'string','math','table','coroutine'}) do
        local library={}; for k,v in pairs(_G[name]) do library[k]=v end
        env[name]=library
    end
    env.math.random=function(a,b) return a or 0.5 end
    env.collectgarbage=function(mode) if mode=='count' then return 100 else return 0 end end
    env.bit=actual_bit
    env.getfenv=function() return env end
    env.setfenv=native_setfenv
    env.require=function(name)
        if name=='bit' then return actual_bit end
        error('FIXTURE_MODULE_UNAVAILABLE: '..tostring(name),0)
    end
    env._G=env
    local f,why=native_load(source)
    assert(f,why)
    native_setfenv(f,env)
    return f()
end
local function fingerprint(value,seen,depth)
    local kind=type(value)
    if kind=='number' then
        if value~=value then return 'number:nan' end
        return 'number:'..string.format('%.17g',value)
    end
    if kind=='string' then return 'string:'..string.format('%q',value) end
    if kind=='function' then return 'function' end
    if kind~='table' then return kind..':'..tostring(value) end
    if depth>5 then return 'table:depth-limit' end
    if seen[value] then return 'table:cycle' end
    seen[value]=true
    local rows={}
    for k,v in next,value do
        rows[#rows+1]=fingerprint(k,seen,depth+1)..'='..fingerprint(v,seen,depth+1)
        if #rows>1000 then return 'table:size-limit' end
    end
    table.sort(rows);seen[value]=nil
    return 'table:{'..table.concat(rows,'|')..'}'
end
function trial(lib,id,scenario)
    local captures={}
    for i=0,31 do
        if scenario==1 then captures[i]=1
        elseif scenario==2 then captures[i]=stub
        elseif scenario==3 then captures[i]={[1]=3,[2]={},[3]=1}
        else captures[i]=0 end
    end
    local fn=lib.make(lib.D['f'..id],captures)
    local args
    if scenario==1 then args={1,2,3,4,5,6,7,8}
    elseif scenario==2 then args={'abc','def','ghi','jkl',1,2,3,4}
    elseif scenario==3 then args={{1,2,3},{1,2,3},1,2,3,4,5,6}
    elseif scenario==4 then args={0,0,0,0,0,0,0,0}
    else args={} end
    local budget=0
    debug.sethook(function()
        budget=budget+1000
        if budget>200000 then error('FIXTURE_BUDGET',0) end
    end,'',1000)
    local result={pcall(function()
        local function pack(...) return select('#',...),{...} end
        return pack(fn(unpack(args,1,8)))
    end)}
    debug.sethook()
    if not result[1] then
        local why=tostring(result[2]):gsub('%[string "[^"%]]*"%]:%d+: ','')
        return false,why
    end
    local count,values=result[2],result[3]
    local out={}
    for i=1,count do out[i]=fingerprint(values[i],{},0) end
    return true,tostring(count)..':'..table.concat(out,';')
end
function invoke(lib,id,...)
    local budget=0
    debug.sethook(function() budget=budget+1000; if budget>5000000 then error('FIXTURE_BUDGET',0) end end,'',1000)
    local result={pcall(function() return lib.make(lib.D['f'..id],nil)(...) end)}
    debug.sethook()
    if not result[1] then return false,tostring(result[2]) end
    return true,result[2]
end
'''.replace("function invoke(lib,id,...)\n", "function invoke(lib,id,...)\n    local args={...}\n").replace("lib.make(lib.D['f'..id],nil)(...) end)","lib.make(lib.D['f'..id],nil)(unpack(args)) end)")

def definitions(source):
    before=source.split('local arguments, argument_count = {...}, select("#", ...)',1)[0]
    assert before!=source
    return before+'\nstartup_active=false\nreturn {D=D,F=F,make=make_function}\n'

def runtime(source, fast_xor=True):
    lua=LuaRuntime(max_memory=768*1024*1024,encoding=None)
    lua.execute(TRUSTED.encode())
    if not fast_xor:
        source=source[:source.index('-- Recovered arithmetic XOR helpers.')]+ '\nlocal arguments, argument_count = {...}, select("#", ...)\n'
    module=lua.globals().load_definitions(definitions(source).encode())
    return lua,module

def main():
    original=INPUT.read_text(); generated=(ROOT/'andromeda_source.lua').read_text()
    report={'input_sha256':hashlib.sha256(INPUT.read_bytes()).hexdigest(),
            'output_sha256':hashlib.sha256((ROOT/'andromeda_source.lua').read_bytes()).hexdigest()}
    for label,source in [('input',original),('output',generated)]:
        compiler=LuaRuntime().eval('function(s) local f,e=loadstring(s); return f~=nil,e end')
        ok,error=compiler(source);assert ok,(label,error)
    report['luajit_compilation']='input and output passed'
    compiler=LuaRuntime().eval('function(s) local f,e=loadstring(s); return f~=nil,e end')
    fragments=sorted((ROOT/'functions').glob('f[0-9][0-9][0-9].lua'))
    assert len(fragments)==564
    for path in fragments:
        ok,why=compiler(path.read_text());assert ok,(path.name,why)
    from lupa.lua54 import LuaRuntime as Lua54
    ok,why=Lua54().eval('function(s) local f,e=load(s); return f~=nil,e end')((ROOT/'andromeda_flat_source.lua').read_text())
    assert ok,why
    ok,why=compiler((ROOT/'prototype_metadata_reference.lua').read_text());assert ok,why
    report['individual_factory_fragments_compiled']=len(fragments)
    report['flat_source_lua54_compilation']='passed'
    report['flat_source_luajit_compilation']='unsupported: control structure too long'
    a,ma=runtime(original); b,mb=runtime(generated)
    successes=[]; errors=[]; mismatches=[]; error_differences=[]; nondeterministic=[]; structure_only=[]
    for fid in range(1,565):
        for scenario in range(1,6):
            ra=a.globals().trial(ma,fid,scenario);rb=b.globals().trial(mb,fid,scenario)
            if ra[0] and rb[0] and ra[1]!=rb[1]:
                repeats=[a.globals().trial(ma,fid,scenario) for _ in range(2)]
                if any(r[0] and r[1]!=ra[1] for r in repeats):
                    nondeterministic.append([fid,scenario,repr(ra[1]),*[repr(r[1]) for r in repeats]])
                    continue
            if ra[0] and rb[0]:
                if ra[1]!=rb[1]: mismatches.append([fid,scenario,repr(ra[1]),repr(rb[1])])
                else:
                    successes.append([fid,scenario])
                    if b'function' in ra[1] or b'depth-limit' in ra[1] or b'size-limit' in ra[1]: structure_only.append([fid,scenario])
            elif ra[0]!=rb[0]: mismatches.append([fid,scenario,repr(ra),repr(rb)])
            else:
                errors.append([fid,scenario])
                if ra[1]!=rb[1]: error_differences.append([fid,scenario,repr(ra[1]),repr(rb[1])])
        if fid%100==0: print('Compared',fid,'functions;',len(successes),'matching completed trials;',len(mismatches),'mismatches',flush=True)
    report.update({'functions_instantiated':564,'completed_matching_trials':len(successes),
                   'value_comparison_trials':len(successes)-len(structure_only),
                   'returned_function_structure_only_trials':len(structure_only),
                   'completed_matching_function_ids':sorted(set(f for f,_ in successes)),
                   'both_errored_trials_not_validation':len(errors),'mismatches':mismatches,
                   'error_message_differences':error_differences,
                   'nondeterministic_trials_not_validation':nondeterministic})
    # Known arithmetic helper: validate the unsigned XOR fast path on representative inputs.
    xor_cases=[(0,0),(1,2),(255,170),(65535,12345),(2**31,2**32-1),(2**32-1,2**32-1)]
    xor_count=0
    for fid in [3,48,112,117,419]:
        for left,right in xor_cases:
            for lua,lib in [(a,ma),(b,mb)]:
                ok,value=lua.globals().invoke(lib,fid,left,right)
                assert ok and value==left^right,(fid,left,right,ok,value)
            xor_count+=1
    report['unsigned_xor_vectors']=xor_count
    # Bypass the unchanged fast wrapper to validate rewritten arithmetic bodies too.
    raw_a,raw_ma=runtime(original,False);raw_b,raw_mb=runtime(generated,False)
    for fid in [3,48,112,117,419]:
        for left,right in xor_cases:
            for lua,lib in [(raw_a,raw_ma),(raw_b,raw_mb)]:
                ok,value=lua.globals().invoke(lib,fid,left,right)
                assert ok and value==left^right,(fid,left,right,ok,value)
    report['arithmetic_xor_body_vectors']=xor_count
    import hmac
    crypto_vectors=0; reference_hashes={}; standard_failures=[]; standard_passes=0
    for label,lua,lib in [('input',a,ma),('output',b,mb)]:
        ok,crypto=lua.globals().invoke(lib,29);assert ok
        bounded=lua.eval(b'''function(fn,...)
            local args={...};local count=select('#',...)
            debug.sethook(function() error('FIXTURE_BUDGET',0) end,'',5000000)
            local ok,value=pcall(function() return fn(unpack(args,1,count)) end)
            debug.sethook();return ok,value
        end''')
        for msg in [b'',b'abc',b'a'*55,b'a'*56,b'a'*64,b'a'*65,bytes(range(256))]:
            for method,expected in [(b'sha256',hashlib.sha256(msg).hexdigest().encode()),
                                    (b'sha256_binary',hashlib.sha256(msg).digest())]:
                ok,value=bounded(crypto[method],msg);assert ok,(label,method,len(msg),value)
                key=(method,len(msg))
                if label=='input': reference_hashes[key]=value
                else: assert value==reference_hashes[key],(method,len(msg),'recovery changed digest')
                if value==expected:standard_passes+=1
                else:standard_failures.append({'version':label,'method':method.decode(),'input_length':len(msg),
                                               'matches_supplied_input':label=='output' and value==reference_hashes[key]})
                crypto_vectors+=1
        for key,msg in [(b'key',b'message'),(b'',b'abc'),(b'key'*40,b'payload')]:
            ok,value=bounded(crypto[b'hmac_sha256'],key,msg)
            assert ok and value==hmac.new(key,msg,hashlib.sha256).hexdigest().encode(),(label,ok,value)
    report['sha256_reconstruction_vectors']=crypto_vectors//2
    report['sha256_standard_passes']=standard_passes
    report['sha256_standard_failures_inherited_from_input']=standard_failures
    report['hmac_standard_vectors_input_and_output']=6
    (ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('completed_matching_function_ids','error_message_differences','nondeterministic_trials_not_validation')},indent=2))
    assert not mismatches, 'Semantic mismatches found; inspect validation.json'

if __name__=='__main__': main()
