"""Translate decoded PSU primitive operations to a standard Lua 5.1 chunk."""
from pathlib import Path
import re,json,struct,collections
R=Path(__file__).resolve().parent
g=json.loads((R/'graph.json').read_text());objects=g['objects']
def table(v):return dict(objects[v['ref']]['items'])
protos=[]
def visit(ref):
 p=table(ref);p['_ref']=ref['ref'];protos.append(p)
 for _,c in sorted(table(p[2]).items()):visit(c)
visit(table(g['root'])['proto'])
ops=json.loads((R/'opcodes.json').read_text())
def clean(v):
 v=re.sub(r'\s*;\s*',';',v)
 v=re.sub(r'(?:local [A-Za-z](?: , [A-Za-z])*;)+','',v)
 return v.strip('; ')
parts={int(k):[clean(p)for p in re.split(r'A = A \+ 1;\s*e = C \[ A \];?',re.sub(r'\s*;\s*',';',v))]for k,v in ops.items()}
report=[];compiled={};nups=collections.defaultdict(int)
OP='MOVE LOADK LOADBOOL LOADNIL GETUPVAL GETGLOBAL GETTABLE SETGLOBAL SETUPVAL SETTABLE NEWTABLE SELF ADD SUB MUL DIV MOD POW UNM NOT LEN CONCAT JMP EQ LT LE TEST TESTSET CALL TAILCALL RETURN FORLOOP FORPREP TFORLOOP SETLIST CLOSE CLOSURE VARARG'.split()
def atom(raw):
 if isinstance(raw,dict)and'bytes'in raw:return bytes.fromhex(raw['bytes'])
 if isinstance(raw,str):return raw.encode()
 return raw
class Build:
 def __init__(self,p,fid):self.p=p;self.fid=fid;self.code=table(p[1]);self.nodes={};self.constants=[];self.priority=set();self.maxreg=max(p[3]+2,2);self.pending=[1];self.childrefs=table(p[2]);self.children=[]
 def reg(self,x):assert isinstance(x,int)and x>=0,(self.fid,x);self.maxreg=max(self.maxreg,x+1);return x
 def k(self,x):
  x=atom(x)
  for i,v in enumerate(self.constants):
   if type(x)==type(v)and x==v:return i
  self.constants.append(x);return len(self.constants)-1
 def rk(self,x,const=False):
  if not const:return self.reg(x)
  i=self.k(x);self.priority.add(i);return 256+i
 def compile(self):
  while self.pending:
   pc=self.pending.pop()
   if pc in self.nodes:continue
   assert pc in self.code,('invalid target',self.fid,pc)
   ins=table(self.code[pc]);opcode=ins[1]
   ps=parts[opcode]
   for offset,text in enumerate(ps):
    current=pc+offset
    if current in self.nodes:raise AssertionError(('overlapping macro',self.fid,current))
    fields=table(self.code[current]);a,b,c=fields.get(2),fields.get(3),fields.get(4)
    out=[];targets=[];terminal=False;extra=0
    def emit(op,A=0,B=0,C=0):out.append([op,A,B,C])
    def jump(target):emit('JMP',0,target);targets.append(target)
    def call(ret):
     match=re.search(r'l \[ ([A-Za-z]) \] \( (.*?) \)',text)
     if 'M ( l ,'in text:
      arg=0 if re.search(r'M \( l , [A-Za-z] \+ 1 , Q \)',text)else b-a+1
     elif re.search(r'l \[ [A-Za-z] \] \( l \[ [A-Za-z] \+ 1 \] \)',text):arg=2
     else:arg=1
     emit('CALL',self.reg(a),arg,ret)
     if arg>0:self.reg(a+arg-1)
    # Branches carry absolute VM positions; the interpreter increments afterwards.
    if text=='A = e [ 3 ]':jump(b+1);terminal=True
    elif text.startswith('if '):
     m=re.match(r'if \( (.*?) (==|~=|<=|<) (.*?) \) then A = (.*?);else A = (.*?);end$',text)
     if m:
      lhs,cmp,rhs,yes,no=m.groups()
      lb=self.rk(a,lhs=='e [ 2 ]');rc=self.rk(c,rhs=='e [ 4 ]')
      emit({'==':'EQ','~=':'EQ','<':'LT','<=':'LE'}[cmp],1 if cmp=='~='else 0,lb,rc)
      # EQ/LT/LE A=0 skips the following instruction when the predicate is true.
      false=current+2 if no=='A + 1'else b+1
      true=current+2 if yes=='A + 1'else b+1
      jump(false);jump(true)
     else:
      m=re.match(r'if (not )?l \[ e \[ 2 \] \] then A = A \+ 1;else A = e \[ 3 \];end$',text)
      assert m,('unknown conditional',text)
      emit('TEST',self.reg(a),0,1 if m[1]else 0);jump(b+1);jump(current+2)
     terminal=True
    elif 'for M = 1 , e [ 4 ] do A = A + 1;'in text:
     child=self.childrefs[b];nups[child['ref']]=max(nups[child['ref']],c)
     emit('CLOSURE',self.reg(a),b)
     for index in range(1,c+1):
      cap=table(self.code[current+index]);emit('MOVE'if cap[1]==208 else 'GETUPVAL',0,cap[3],0)
      if cap[1]==208:self.reg(cap[3])
     extra=c
    elif 'o ( E [ e [ 3 ] ] , nil , L )'in text:emit('CLOSURE',self.reg(a),b)
    elif 'for A = 0 , # e do' in text:emit('CLOSE',self.reg(a))
    elif 'local n = l [ C + 2 ];local B = l [ C ] + n' in text:
     emit('FORLOOP',self.reg(a),b+1);self.reg(a+3);targets.append(b+1)
    elif 'l [ B + 3 ] ='in text or 'l [ C + 3 ] ='in text:
     # Match this prep with the closing loop having the same counter base.
     loops=[]
     for q,ref in self.code.items():
      f=table(ref)
      if f.get(2)==a and 'local n = l [ C + 2 ];local B = l [ C ] + n'in parts[f[1]][-1]:loops.append(q)
     matches=[q for q in loops if q>current and table(self.code[q]).get(3)==current]
     assert len(matches)==1,('loop matching',self.fid,current,a,loops,matches)
     emit('FORPREP',self.reg(a),matches[0]);targets.append(matches[0]);self.reg(a+3)
    elif 'local C = C [ 1 ] if C then'in text:
     emit('TFORLOOP',self.reg(a),0,c);self.reg(a+c+2);jump(b+1);jump(current+2);terminal=True
    elif re.search(r'l \[ e \[ 4 \] \];if (?:not )?[A-Za-z] then',text):
     emit('TESTSET',self.reg(a),self.reg(c),1 if ';if not 'in text else 0);jump(b+1);jump(current+2);terminal=True
    elif 'do return'in text:
     if 'l ['in text and '( 'in text and not text.startswith('do return l [ e [ 2 ] ] end')and'M ( l , B , 'not in text and'M ( l , e , 'not in text and'M ( l , A , 'not in text and', l ['not in text:
      if text.startswith('do return l [ e [ 2 ] ] ( )'):emit('TAILCALL',self.reg(a),1)
      else:
       call(0);out[-1][0]='TAILCALL'
      emit('RETURN',a,0)
     elif text=='do return end':emit('RETURN',0,1)
     elif text=='do return l [ e [ 2 ] ] end':emit('RETURN',self.reg(a),2)
     elif ', l ['in text:emit('RETURN',self.reg(a),3);self.reg(a+1)
     elif re.search(r'M \( l , [A-Za-z] , Q \)',text):emit('RETURN',self.reg(a),0)
     else:emit('RETURN',self.reg(a),b+2);self.reg(a+b)
     terminal=True
    elif ' .. l [ e ]'in text:emit('CONCAT',self.reg(a),self.reg(b),self.reg(c))
    elif 'D ('in text and 'for e ='in text:emit('SETLIST',self.reg(a),0 if ' , Q do'in text else b-a,1)
    elif 'l [ e ] = nil'in text:emit('LOADNIL',self.reg(a),self.reg(b))
    elif text == 'l [ e [ 2 ] ] ( )':emit('CALL',self.reg(a),1,1)
    elif text.startswith('l [ e [ 2 ] ] ='):
     value=text[len('l [ e [ 2 ] ] = '):]
     if value=='e [ 3 ]':emit('LOADK',self.reg(a),self.k(b))
     elif value=='{ }':emit('NEWTABLE',self.reg(a))
     elif value=='( e [ 3 ] ~= 0 )':emit('LOADBOOL',self.reg(a),int(b!=0))
     elif value=='( e [ 3 ] ~= 0 );A = A + 1':emit('LOADBOOL',self.reg(a),int(b!=0));jump(current+2);terminal=True
     elif value=='n [ e [ 3 ] ]':emit('GETUPVAL',self.reg(a),b)
     elif value=='L [ e [ 3 ] ]':emit('GETGLOBAL',self.reg(a),self.k(b))
     elif value=='l [ e [ 3 ] ]':emit('MOVE',self.reg(a),self.reg(b))
     elif value=='# l [ e [ 3 ] ]':emit('LEN',self.reg(a),self.reg(b))
     elif value=='- l [ e [ 3 ] ]':emit('UNM',self.reg(a),self.reg(b))
     elif value=='( not l [ e [ 3 ] ] )':emit('NOT',self.reg(a),self.reg(b))
     elif re.fullmatch(r'l \[ e \[ 3 \] \] \[ (?:l \[ )?e \[ 4 \](?: \])? \]',value):emit('GETTABLE',self.reg(a),self.reg(b),self.rk(c,'l [ e [ 4 ] ]'not in value))
     else:
      m=re.fullmatch(r'(l \[ e \[ 3 \] \]|e \[ 3 \]) ([+*/%^\-]) (l \[ e \[ 4 \] \]|e \[ 4 \])',value)
      assert m,('unknown assignment',self.fid,current,text)
      emit({'+':'ADD','-':'SUB','*':'MUL','/':'DIV','%':'MOD','^':'POW'}[m[2]],self.reg(a),self.rk(b,m[1]=='e [ 3 ]'),self.rk(c,m[3]=='e [ 4 ]'))
    elif text=='n [ e [ 3 ] ] = l [ e [ 2 ] ]':emit('SETUPVAL',self.reg(a),b)
    elif text=='L [ e [ 3 ] ] = l [ e [ 2 ] ]':emit('SETGLOBAL',self.reg(a),self.k(b))
    elif text.startswith('l [ e [ 2 ] ] ['):
     emit('SETTABLE',self.reg(a),self.rk(b,'[ l [ e [ 3 ] ] ]'not in text),self.rk(c,text.endswith('= e [ 4 ]')))
    elif re.search(r'l \[ [A-Za-z] \+ 1 \] = [A-Za-z];l \[ [A-Za-z] \] = [A-Za-z] \[ e \[ 4 \] \]',text):emit('SELF',self.reg(a),self.reg(b),self.rk(c,True));self.reg(a+1)
    elif re.search(r'l \[ [A-Za-z] \] \(',text):
     if ' = R ('in text or re.search(r'\w , \w = R \(',text):ret=0
     elif '{ l ['in text:ret=c-a+2
     elif re.search(r'l \[ [A-Za-z] \] = l \[ [A-Za-z] \] \(',text):ret=2
     else:ret=1
     call(ret)
     if ret>1:self.reg(a+ret-2)
    else:raise AssertionError(('unhandled',self.fid,current,text))
    nxt=current+extra+1
    if not terminal:targets.append(nxt)
    self.nodes[current]={'ops':out,'next':None if terminal else nxt,'template':text,'fields':fields}
    self.pending+=targets
    if extra:
     assert len(ps)==1;break
    if terminal:break
  # Thread unconditional trampolines and use the standard test+jump layout.
  def resolved(pc):
   seen=set()
   while pc in self.nodes and len(self.nodes[pc]['ops'])==1 and self.nodes[pc]['ops'][0][0]=='JMP':
    if pc in seen:return pc
    seen.add(pc);pc=self.nodes[pc]['ops'][0][2]
   return pc
  aliases={pc:resolved(pc)for pc in self.nodes}
  self.nodes={pc:node for pc,node in self.nodes.items()if aliases[pc]==pc}
  ordered=sorted(self.nodes)
  for idx,pc in enumerate(ordered):
   node=self.nodes[pc]
   for ins in node['ops']:
    if ins[0]in ['JMP','FORLOOP','FORPREP']:ins[2]=aliases.get(ins[2],ins[2])
   if node['next']is not None:node['next']=aliases.get(node['next'],node['next'])
   nextpc=ordered[idx+1]if idx+1<len(ordered)else None
   seq=node['ops']
   if len(seq)==3 and seq[0][0]in ['EQ','LT','LE','TEST','TESTSET','TFORLOOP']and seq[1][0]==seq[2][0]=='JMP':
    if seq[2][2]==nextpc:seq.pop();node['next']=nextpc
    elif seq[1][2]==nextpc and seq[0][0]in ['EQ','LT','LE','TEST']:
     if seq[0][0]=='TEST':seq[0][3]=1-seq[0][3]
     else:seq[0][1]=1-seq[0][1]
     seq[1]=seq[2];seq.pop();node['next']=nextpc
  native=[];positions={}
  for pc in ordered:
   positions[pc]=len(native);node=self.nodes[pc];native+=node['ops']
   if node['next']is not None and node['next']!=(ordered[ordered.index(pc)+1]if ordered.index(pc)+1<len(ordered)else None):native.append(['JMP',0,node['next'],0])
  for pc,node in self.nodes.items():
   for op in node['ops']:
    if op[0]in ['JMP','FORLOOP','FORPREP']:
     assert op[2]in positions,('missing native target',self.fid,op,sorted(positions))
  if not native or native[-1][:3]!=['RETURN',0,1]:native.append(['RETURN',0,1,0])
  array_lengths={}
  for ins in native:
   if ins[0]=='NEWTABLE':array_lengths[ins[1]]=0
   elif ins[0]=='SETLIST':
    previous=array_lengths.get(ins[1],0)
    assert previous%50==0,('nonstandard append offset',self.fid,previous)
    ins[3]=previous//50+1
    array_lengths[ins[1]]=previous+ins[2]
  self.native=native;self.positions=positions
  assert len(self.priority)<=256,('RK priority overflow',self.fid,len(self.priority))
  order=sorted(self.priority)+[i for i in range(len(self.constants))if i not in self.priority];remap={old:new for new,old in enumerate(order)}
  self.constants=[self.constants[i]for i in order]
  for ins in native:
   if ins[0]in ['LOADK','GETGLOBAL','SETGLOBAL']:ins[2]=remap[ins[2]]
   slots=[3]if ins[0]in ['GETTABLE','SELF']else [2,3]if ins[0]in ['SETTABLE','ADD','SUB','MUL','DIV','MOD','POW','EQ','LT','LE']else []
   for k in slots:
    if ins[k]>=256:ins[k]=256+remap[ins[k]-256]
  report.append({'function':self.fid,'vm_entries':len(self.nodes),'native_instructions':len(native),'constants':len(self.constants),'stack':self.maxreg})
  return self
builders=[]
for fid,p in enumerate(protos):
 b=Build(p,fid);builders.append(b);b.compile()
print('Translated',len(builders),'functions')
(R/'lift_report.json').write_text(json.dumps(report,indent=2)+'\n')

def u32(n):return struct.pack('<I',n)
def string(value):
 if value is None:return struct.pack('<Q',0)
 if isinstance(value,str):value=value.encode()
 return struct.pack('<Q',len(value)+1)+value+b'\0'
def chunk(b):
 data=string('@sigma_dec14_recovered')+u32(0)+u32(0)
 assert b.maxreg<=250,('stack too big',b.fid,b.maxreg)
 data+=bytes([nups[b.p['_ref']],b.p[3],2,b.maxreg])
 encoded=[]
 for pc,ins in enumerate(b.native):
  op,a,bb,c=(ins+[0]*4)[:4];num=OP.index(op)
  if op in ['JMP','FORLOOP','FORPREP']:
   bb=b.positions[bb]-pc-1+131071
   assert 0<=bb<262144
   word=num+(a<<6)+(bb<<14)
  elif op in ['LOADK','GETGLOBAL','SETGLOBAL','CLOSURE']:word=num+(a<<6)+(bb<<14)
  else:
   assert 0<=a<256 and 0<=bb<512 and 0<=c<512,('encode',b.fid,ins)
   word=num+(a<<6)+(c<<14)+(bb<<23)
  encoded.append(u32(word))
 data+=u32(len(encoded))+b''.join(encoded)+u32(len(b.constants))
 for k in b.constants:
  if k is None:data+=b'\x00'
  elif isinstance(k,bool):data+=b'\x01'+bytes([int(k)])
  elif isinstance(k,(int,float)):data+=b'\x03'+struct.pack('<d',k)
  elif isinstance(k,bytes):data+=b'\x04'+string(k)
  else:raise ValueError(k)
 children=[next(x for x in builders if x.p['_ref']==ref['ref'])for _,ref in sorted(b.childrefs.items())]
 data+=u32(len(children))+b''.join(chunk(c)for c in children)
 data+=u32(0)+u32(0)+u32(0)
 return data
(R/'recovered.luac').write_bytes(b'\x1bLua\x51\x00\x01\x04\x08\x04\x08\x00'+chunk(builders[0]))
