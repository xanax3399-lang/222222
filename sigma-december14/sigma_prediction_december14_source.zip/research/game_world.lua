
 trace={}
 local function encode(value)
  if type(value)=='function'then return '<function>'end
  if type(value)=='table'then local copy={};for k,v in pairs(value)do copy[k]=encode(v)end;return copy end
  return value
 end
 for _,module in ipairs({'ui','client','renderer','database','plist'})do
  for name,fn in pairs(_G[module])do
   if type(fn)=='function'then
    _G[module][name]=function(...)
     trace[#trace+1]={module=module,name=name,args=encode({...})}
     return fn(...)
    end
   end
  end
 end
 client.trace_bullet=function()return 0,0 end
 client.scale_damage=function(player,hitgroup,damage)return damage end
 fixture_world=false
entity.get_local_player=function()return fixture_world and 1 or nil end
entity.is_alive=function()return fixture_world end
entity.get_players=function()return {2}end
entity.get_all=function()return {}end
entity.get_player_resource=function()return 65 end
entity.hitbox_position=function(id)return id*20,0,64 end
entity.get_prop=function(id,name,index)
 if name=='m_vecOrigin'then return id*20,0,0 end
 if name=='m_vecVelocity'then return 0,0,0 end
 if name=='m_flPoseParameter'then return 0.5 end
 if name=='m_iTeamNum'then return id==1 and 3 or 2 end
 if name=='m_fFlags'then return 1 end
 if name=='m_iPing'then return 40 end
 return 0
end
client.userid_to_entindex=function(id)return id end
client.trace_line=function()return 1,0 end
client.trace_bullet=function()return 0,0 end
 client.scale_damage=function(player,hitgroup,damage)return damage end
client.eye_position=function()return 20,0,64 end
client.camera_angles=function()return 0,0 end
 entity.hitbox_position=function(id)return id*20,0,64 end
 entity.get_player_resource=function()return 65 end
 client.camera_angles=function()return 0,0 end
 entity.hitbox_position=function(id)return id*20,0,64 end
 entity.get_player_resource=function()return 65 end
 globals.curtime=function()return 120 end
 panorama.loadstring=function()return function()return '76561198000000000'end end
 