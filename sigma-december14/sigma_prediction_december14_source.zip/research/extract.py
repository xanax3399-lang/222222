from pathlib import Path
import sys,json,hashlib
from vm_sandbox import BOOTSTRAP,dump_graph
from lupa.luajit21 import LuaRuntime
R=Path(__file__).resolve().parent
raw=(R/'original.lua').read_bytes();assert hashlib.sha256(raw).hexdigest()=='532275963ef3828dfe569f9956f3a73b3fed332caaa75fe9973166c68a38e149';source=raw[raw.index(b'return(function(S,e,Q,'):]
old=b'return o(S(),{},O())(...)';assert source.count(old)==1
source=source.replace(old,b'return {proto=S(),vm=o,env=O()}')
lua=LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
bootstrap=BOOTSTRAP.replace(b'safe.bit=bitlib',b'safe.bit=bitlib;safe.client={}')
result=lua.execute(bootstrap)(source)
graph=dump_graph(lua,result)
(R/'graph.json').write_text(json.dumps(graph,ensure_ascii=True))
strings=[]
def walk(p):
 for _,i in p[1].items():
  for _,v in i.items():
   if isinstance(v,bytes):strings.append(v)
 for _,c in p[2].items():walk(c)
walk(result[b'proto'])
strings=sorted(set(strings),key=len,reverse=True)
for i,s in enumerate(strings[:20]):
 print(i,len(s),repr(s[:180]))
 (R/('string_%d.bin'%i)).write_bytes(s)
