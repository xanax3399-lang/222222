from pathlib import Path
import subprocess,sys,os
R=Path(__file__).resolve().parent
steps=['extract.py','normalize_sigma.py','opcode_map.py','lift_bytecode.py','JAVA','structure_source.py','prepare_editable.py','polish_editable.py','build_source.py','verify_source.py','verify_helpers.py']
for step in steps:
 env=os.environ.copy()
 if step=='verify_source.py':env.update(DEC14_SOURCE='sigma_prediction_december14_source.lua',DEC14_FULL_SOURCE='1')
 if step=='verify_helpers.py':env['DEC14_HELPER_SOURCE']='final.helper_instrumented.lua'
 if step=='JAVA':
  with (R/'recovered.raw.lua').open('w')as output:
   result=subprocess.run(['java','-jar',str(R/'unluac-recovery.jar'),str(R/'recovered.luac')],cwd=R,stdout=output,stderr=subprocess.PIPE,text=True)
  if result.returncode:raise SystemExit(result.stderr)
 else:
  with (R/(step+'.log')).open('w')as log:result=subprocess.run([sys.executable,str(R/step)],cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:raise SystemExit('Failed '+step+'; see '+step+'.log')
 print('Passed:',step,flush=True)
