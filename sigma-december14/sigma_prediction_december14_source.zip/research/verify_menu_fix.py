from pathlib import Path
import os,json,hashlib
R=Path(__file__).resolve().parent
os.environ['DEC14_SOURCE']='sigma_prediction_december14_source.lua';os.environ['DEC14_FULL_SOURCE']='1'
import verify_source as V
from lupa import lua51,luajit21
source=(R/'sigma_prediction_december14_source.lua').read_bytes()
for m in [lua51,luajit21]:
 l=m.LuaRuntime(encoding=None);assert l.eval(b'function(s)local f,e=loadstring(s);return f~=nil,e end')(source)==(True,None)
base=V.SETUP
report={'source_sha256':hashlib.sha256(source).hexdigest(),'syntax':['Lua 5.1','LuaJIT 2.1'],'scenarios':{},'gameplay_tested':False}
for kind in ['checkbox','multiselect']:
 V.SETUP=base+('''
local reference=ui.reference
ui.reference=function(tab,group,name)
 if name=='Fake yaw limit'or name=='sv_maxusrcmdprocessticks'then error('not found')end
 if tab:lower()=='rage'and group:lower()=='other'and(name=='Double tap'or name=='Force body aim')then error('not found')end
 local a,b=reference(tab,group,name)
 if name=='Freestanding'then local c=sigma_controls()[a];c.kind='%s';if c.kind=='checkbox'then c.value=false else c.value={}end end
 return a,b
end
local set=ui.set
ui.set=function(id,value,...)
 local c=assert(sigma_controls()[id])
 if c.name=='Freestanding'and c.kind=='checkbox'then assert(type(value)=='boolean','boolean expected, got '..type(value))end
 return set(id,value,...)
end
'''%kind).encode()
 result=V.run(True);failures=[r for r in result['outcomes'].values()if not r['ok']]
 assert not failures,(kind,failures)
 assert any(r['module']=='client'and r['name']=='log'and 'Fake yaw limit'in r['args'].get(1,'')for r in result['trace'].values())
 report['scenarios'][kind]={'startup':result['stats'],'callbacks':len(result['outcomes']),'failures':failures,'optional_warning_seen':True}
(R/'menu_fix_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Missing old controls, relocated DT/BAIM, Freestanding types passed')
