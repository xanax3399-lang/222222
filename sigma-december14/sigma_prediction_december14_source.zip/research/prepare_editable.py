from pathlib import Path
import sys,re,io,contextlib,json,copy
from luaparser import ast,astnodes as N
import source_ast as H
R=Path(__file__).resolve().parent
raw=(R/'recovered.structured.lua').read_text();preserved={}
def protect(m):
 value=m[0]
 if '\\'not in value and all(ord(c)<128 for c in value):return value
 marker='__DEC14_TEXT_%d__'%len(preserved);preserved[marker]=value;return marker
with contextlib.redirect_stdout(io.StringIO()):tree=ast.parse(re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',protect,raw))
function_count=0
names={1:'vector_constructor',2:'vector_equal',3:'vector_negate',4:'vector_add',5:'vector_subtract',6:'vector_multiply',7:'vector_divide',8:'vector_to_string',9:'vector_unpack',10:'vector_clone',11:'vector_length_2d_squared',12:'vector_length_squared',13:'vector_length_2d',14:'vector_length',15:'vector_dot',16:'vector_cross',17:'vector_distance',18:'vector_squared_distance',19:'vector_normalize_in_place',20:'vector_normalize',21:'vector_normalized',22:'clamp',23:'number_is_finite',24:'vector_angles',25:'vector_yaw',26:'vector_angle_forward',27:'vector_angle_right',28:'vector_field_of_view',29:'extract_bits_native',30:'extract_bits_fallback',31:'base64_make_encoder',32:'base64_make_decoder',33:'base64_encode',34:'base64_decode',35:'set_native_ui_visible',36:'contains_value',37:'head_coordinates',38:'normalize_yaw',39:'yaw_between_points',40:'signed_coordinate_delta',41:'target_info',42:'signed_line_distance',43:'target_record_info',44:'pose_desync_side',45:'update_shot_history',46:'angles_to_direction',47:'classify_movement',48:'vector_yaw',49:'scale_factor',50:'draw_circle_indicator',51:'estimate_damage_at_offsets',52:'select_nearest_player',53:'is_valid_player',54:'update_target_anti_aim',55:'reset_player_state',56:'handle_use_key',57:'update_manual_and_freestanding',58:'point_on_circle',59:'draw_indicator_triangle',60:'reset_clan_tag',61:'apply_body_yaw',62:'on_bullet_impact',63:'on_player_hurt',64:'on_player_spawn',65:'set_clan_tag_frame',66:'clear_clan_tag',67:'schedule_clan_tag',68:'draw_indicators',69:'update_ui_visibility',70:'register_events_if_whitelisted',71:'draw_whitelist_warning',72:'request_whitelist',73:'handle_whitelist_response',74:'draw_branding'}
index=[]
def rewrite(node):
 global function_count
 if isinstance(node,(N.Function,N.LocalFunction,N.AnonymousFunction)):
  function_count+=1;fid=function_count
  node._recovered_id=fid
  index.append({'function':fid,'inferred_name':names[fid],'parameters':[a.id for a in node.args if isinstance(a,N.Name)]})
 for field,i,child in list(H.children(node)):
  new=rewrite(child)
  if i is None:setattr(node,field,new)
  else:getattr(node,field)[i]=new
 if isinstance(node,N.Forin):
  node.body.body.insert(0,N.If(test=N.ULNotOp(operand=copy.deepcopy(node.targets[0])),body=N.Block([N.Break()]),orelse=None))
 if isinstance(node,N.Function):
  fn=N.AnonymousFunction(args=node.args,body=node.body);fn._recovered_id=node._recovered_id
  return N.Assign(targets=[node.name],values=[fn])
 if isinstance(node,N.ElseIf):return N.If(test=node.test,body=node.body,orelse=node.orelse)
 if isinstance(node,N.If)and isinstance(node.orelse,N.If):node.orelse=N.Block([node.orelse])
 return node
rewrite(tree);assert function_count==74,function_count
# Root bindings have inferred role names. Some slots are reused temporarily
# before their final role; they remain assignments to preserve capture timing.
root_names={0:'http_module',1:'vector_module',2:'get_value_type',3:'set_metatable',4:'to_string',5:'math_pi',6:'math_min',7:'math_max',8:'math_degrees',9:'math_radians',10:'math_square_root',11:'math_sine',12:'math_cosine',13:'math_arctangent',14:'math_arccosine',15:'math_remainder',16:'vector_metatable',17:'base64_module',18:'extract_bits',19:'base64_encoder',20:'base64_decoder',21:'string_char',22:'table_concat'}
api=['bit_band','camera_angles','eye_position','key_state','scale_damage','screen_size','set_event_callback','trace_bullet','trace_line','userid_to_entindex','get_all_entities','get_classname','get_local_player','get_player_resource','get_players','get_prop','hitbox_position','is_alive','is_dormant','is_enemy','curtime','tickcount','tickinterval','math_abs','math_atan','math_atan2','math_cos','math_deg','math_rad','math_sin','math_sqrt','draw_gradient','draw_line','draw_text','draw_triangle','table_remove','ui_get','ui_new_color_picker','ui_new_hotkey','ui_new_label','ui_new_multiselect','ui_reference','ui_set','ui_set_callback','ui_set_visible','type_alias','ui_new_slider','native_controls','set_native_ui_visible','script_controls','anti_aim_state','player_records','contains_value','head_coordinates','normalize_yaw','yaw_between_points','signed_coordinate_delta','target_info','signed_line_distance','target_record_info','pose_desync_side','update_shot_history','angles_to_direction','classify_movement','vector_yaw','scale_factor','draw_circle_indicator','estimate_damage_at_offsets','select_nearest_player','is_valid_player']
root_names.update({i+23:n for i,n in enumerate(api)})
root_names.update({95:'update_target_anti_aim',96:'reset_player_state',97:'handle_use_key',99:'update_manual_and_freestanding',100:'point_on_circle',101:'draw_indicator_triangle',102:'reset_clan_tag',103:'apply_body_yaw',104:'on_bullet_impact',105:'on_player_hurt',106:'on_player_spawn',112:'clear_clan_tag',113:'draw_indicators',114:'update_ui_visibility',115:'whitelisted',116:'panorama_api',117:'register_events_if_whitelisted',118:'request_whitelist',119:'fake_yaw_limit',120:'screen_dimensions',121:'screen_center',122:'draw_branding'})
# Field names after DOT are never variable bindings.
def rename(node):
 if isinstance(node,N.Name):
  m=re.fullmatch(r'L(\d+)_1',node.id)
  if m and int(m[1])in root_names:node.id=root_names[int(m[1])]
 for field,_,c in H.children(node):
  if isinstance(node,N.Index)and field=='idx'and node.notation==N.IndexNotation.DOT:continue
  rename(c)
# Give the only closed-over temporary scope distinct identifiers.
def isolate_closed_scope(node):
 if isinstance(node,N.Block)and any(isinstance(v,N.LocalAssign)and [t.id for t in v.targets]==['L19_1','L20_1','L21_1']for v in node.body):
  mapping={'L19_1':'captured_bit_lshift','L20_1':'captured_bit_rshift','L21_1':'captured_bit_band'}
  def scoped(n):
   if isinstance(n,N.Name)and n.id in mapping:n.id=mapping[n.id]
   for field,_,c in H.children(n):
    if isinstance(n,N.Index)and field=='idx'and n.notation==N.IndexNotation.DOT:continue
    scoped(c)
  scoped(node)
 for _,_,child in H.children(node):isolate_closed_scope(child)
isolate_closed_scope(tree)
# Eliminate a temporary holding a function immediately exported to a field.
def direct_exports(block):
 out=[];i=0
 while i<len(block.body):
  prev=block.body[i];nxt=block.body[i+1]if i+1<len(block.body)else None
  if isinstance(prev,N.Assign)and len(prev.targets)==len(prev.values)==1 and isinstance(prev.targets[0],N.Name)and isinstance(prev.values[0],N.AnonymousFunction)and isinstance(nxt,N.Assign)and len(nxt.targets)==len(nxt.values)==1 and isinstance(nxt.values[0],N.Name)and nxt.values[0].id==prev.targets[0].id:
   temp=prev.targets[0].id;safe=False
   for later in block.body[i+2:]:
    if isinstance(later,(N.Assign,N.LocalAssign))and any(isinstance(t,N.Name)and t.id==temp for t in later.targets):
     reads=set().union(*(H.references(v)for v in later.values))if later.values else set()
     safe=temp not in reads;break
    if temp in H.references(later):break
   if safe and temp not in H.free_names(prev.values[0]):
    nxt.values=prev.values;out.append(nxt);i+=2;continue
  out.append(prev);i+=1
 block.body=out
direct_exports(tree.body)
rename(tree)
main=N.LocalFunction(name=N.Name('main'),args=[N.Varargs()],body=tree.body)
tree.body=N.Block([main,N.Return(values=[N.Call(func=N.Name('main'),args=[N.Varargs()])])])
def preserve_lists(node):
 if isinstance(node,N.Field)and isinstance(node.key,N.Number)and node._first_token is not None and node._first_token.text!='[':
  node.key=N.Name('__DEC14_LIST__');node.between_brackets=True
 for _,_,c in H.children(node):preserve_lists(c)
preserve_lists(tree)
def output(tree,name):
 with contextlib.redirect_stdout(io.StringIO()):s=ast.to_lua_source(tree)
 s=re.sub(r'\[__DEC14_LIST__\]\s*=\s*','',s)
 s=re.sub(r'\b__DEC14_TEXT_\d+__\b',lambda m:preserved[m[0]],s)
 (R/name).write_text(s+'\n')
output(tree,'recovered.lexical.lua')
# Test-only instrumentation captures actual compiled function bodies.
def instrument(node):
 for field,i,child in list(H.children(node)):
  new=instrument(child)
  if i is None:setattr(node,field,new)
  else:getattr(node,field)[i]=new
 if isinstance(node,N.AnonymousFunction)and hasattr(node,'_recovered_id'):
  return N.Call(func=N.Name('__capture_function'),args=[N.Number(node._recovered_id),node])
 return node
instrument(tree);output(tree,'recovered.test_instrumented.lua')
(R/'function_index.json').write_text(json.dumps([{'function':0,'inferred_name':'main'}]+index,indent=2)+'\n')
print('Prepared 75 lexical function bodies')
