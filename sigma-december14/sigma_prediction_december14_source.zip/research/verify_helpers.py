from pathlib import Path
import contextlib,io,json,random,math,os
from lupa.luajit21 import LuaRuntime,lua_type
import verify_source as V
R=Path(__file__).resolve().parent
INVOKE=b'''function(fn,args)
 local function pack(...)return {n=select('#',...),...}end
 local ok,result=pcall(function()return pack(fn(unpack(args,1,args.n)))end)
 if not ok then return {ok=false,error=tostring(result)}end
 return {ok=true,values=result}
end'''
def setup(recovered):
 lua=LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
 wrapper=b'''local captured={};local old_factory=o;o=function(proto,up,env)local fn=old_factory(proto,up,env);captured[proto]=fn;return fn end;return {proto=S(),vm=o,env=O(),captured=captured}'''
 src=V.X.source.replace(b'return {proto=S(),vm=o,env=O()}',wrapper)
 assert src!=V.X.source
 result=lua.execute(V.X.bootstrap)(src)
 lua.execute(V.fixture);lua.execute(V.WORLD);lua.execute(V.SETUP);lua.execute(V.prefix)
 if recovered:
  lua.execute(b'''helper_functions={};__capture_function=function(id,fn)helper_functions[id]=fn;return fn end''')
  lua.execute((R/os.environ.get('DEC14_HELPER_SOURCE','recovered.test_instrumented.lua')).read_bytes());funcs=lua.globals().helper_functions
 else:
  result[b'vm'](result[b'proto'],lua.table(),result[b'env'])()
  ps=[]
  def visit(p):
   ps.append(p)
   for _,child in sorted(p[2].items()):visit(child)
  visit(result[b'proto']);funcs=lua.table_from({i:result[b'captured'][p]for i,p in enumerate(ps)})
 lua.execute(b'function pack_args(...)return {n=select("#",...),...}end')
 return lua,funcs
cases=[]
def add(fid,*args):cases.append((fid,','.join(args)))
for vals in [('nil','nil','nil'),('false','"x"','nil'),('1','2','3'),('-4','0','1.5')]:add(1,*vals)
for i in range(20):
 rand=random.Random(i);a,b,c,d,e,f=[rand.uniform(-100,100)for _ in range(6)]
 v='Vector3(%r,%r,%r)'%(a,b,c);w='Vector3(%r,%r,%r)'%(d,e,f)
 for fid in [2,4,5,6,7,15,16,17,18]:add(fid,v,w)
 for fid in [3,8,9,10,11,12,13,14,19,20,21,24,25,26,27]:add(fid,v)
 for fid in [4,5,6,7]:add(fid,v,'2');add(fid,'2',v)
 add(22,repr(a),'-10','10')
 add(39,repr(a),repr(b),repr(c),repr(d))
 for flat in ['true','false']:add(40,'{%r,%r,%r}'%(a,b,c),'{%r,%r,%r}'%(d,e,f),flat)
 add(46,repr(a),repr(b));add(48,repr(a),repr(b));add(58,repr(a),repr(b),repr(c),repr(d))
for value in ['0','1','-1','math.huge','-math.huge','0/0','"str"']:add(23,value)
for fid in [29,30]:
 for value in [0,1,127,1024,123456]:add(fid,str(value),'3','5')
for fid in [31,32]:add(fid,'nil','nil','nil');add(fid,'"-"','"_"','"="')
for text in ['""','"a"','"ab"','"abc"','"abcdef"','"\\000\\255hi"']:add(33,text)
for text in ['""','"YQ=="','"YWI="','"YWJj"','"YWJjZGVm"']:add(34,text)
for angle in [-1080,-181,-180,0,179,180,181,360,1080]+[random.Random(i).uniform(-1e5,1e5)for i in range(80)]:add(38,repr(angle))
for a,b in [(0,0),(1,0),(0,1),(-1,0),(3,4)]:add(48,str(a),str(b))
for value in [0,1,64]:add(53,str(value))
results=[];available=[]
for recovered in [False,True]:
 lua,funcs=setup(recovered);invoke=lua.eval(INVOKE);values=[];missing=set()
 for fid,args in cases:
  fn=funcs[fid]
  if fn is None:values.append(None);missing.add(fid);continue
  args=lua.eval(('pack_args('+args+')').encode());values.append(V.plain(invoke(fn,args)))
 results.append(values);available.append(missing)
assert available[0]==available[1],available
for i,(a,b)in enumerate(zip(*results)):
 if a and b and not a['ok']and not b['ok']:a={'ok':False};b={'ok':False}
 if a!=b:
  (R/'helper_diff.json').write_text(json.dumps({'case':cases[i],'vm':a,'source':b},indent=2))
  raise AssertionError(('Helper differs',i,cases[i],a,b))
verified=sum(v is not None for v in results[0]);errors=sum(v is not None and not v['ok']for v in results[0])
report={'cases_compared':verified,'matching_error_outcomes':errors,'function_ids_tested':sorted({fid for fid,_ in cases if fid not in available[0]}),'inactive_function_ids':sorted(available[0]),'matched_original_vm':True,'gameplay_tested':False}
(R/'helper_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Matched',verified,'helper cases;',errors,'matching errors')
