from pathlib import Path
import json,sys,contextlib,io,ast,os,re,math
from lupa.luajit21 import LuaRuntime,lua_type
R=Path(__file__).resolve().parent
with contextlib.redirect_stdout(io.StringIO()):import extract as X
fixture=(R/'gamesense_fixture.lua').read_bytes()
# Reuse the controlled game-world fixture, never live engine/native APIs.
WORLD=(R/'game_world.lua').read_bytes()
prefix=(R/'original.lua').read_bytes().split(b'return(function(S,e,Q,',1)[0]
SOURCE=os.environ.get('DEC14_SOURCE','recovered.structured.lua')
SETUP=b'''
__dec14_pack_results=function(...)return {n=select('#',...),...}end

require=function(name)
 if name=='gamesense/http'then return mock_http end
 if name=='vector'then return vector end
 if name=='ffi'then return ffi end
 if name=='gamesense/images'then return mock_images end
 error('Unsupported require: '..name)
end
renderer.indicator=function()end
entity.is_enemy=function(id)return id==2 end
entity.get_player_weapon=function()return 66 end
'''
def plain(x):
 if isinstance(x,float)and math.isnan(x):return "<nan>"
 if lua_type(x)=='table':return {k.decode(errors='backslashreplace')if isinstance(k,bytes)else k:plain(v)for k,v in x.items()}
 if isinstance(x,bytes):return x.decode(errors='backslashreplace')
 return x
EXERCISE=b'''
local outcomes={}
local function invoke(label,fn,data)
 local ok,why=pcall(fn,data)
 outcomes[#outcomes+1]={label=label,ok=ok,error=not ok and tostring(why)or nil}
end
local controls=sigma_controls()
for _,c in pairs(controls)do
 if c.name=='Fake yaw limit'then c.kind='slider';c.value=60 end
 if c.name=='Limit'then c.kind='slider';c.value=14 end
end
fixture_world=true
for variant=1,3 do
 for id,c in pairs(controls)do
  if c.callback then
   c.value=variant==1 and {}or variant==2 and {'Manual AA','Freestanding','Edge yaw','Keybind indicator','Name indicator','AA indicator','Custom Legit AA'}or c.options
   invoke('ui:'..variant..':'..c.name,c.callback,id)
  end
  if c.kind=='checkbox'then c.value=variant==3 end
 end
 local count=#events
 for index=1,count do
  local e=events[index]
  local data={userid=1,attacker=2,weapon='ssg08',hitgroup=1,target=2,x=40,y=0,z=64,chokedcommands=variant-1,in_jump=0,in_use=0,command_number=64+variant}
  if e[1]=='paint'or e[1]=='paint_ui'or e[1]=='shutdown'then data=nil end
  invoke('event:'..variant..':'..index..':'..e[1],e[2],data)
 end
end
return outcomes
'''
def run(recovered):
 lua=LuaRuntime(encoding=None,register_eval=False,register_builtins=False)
 result=lua.execute(X.bootstrap)(X.source)
 lua.execute(fixture);lua.execute(WORLD);lua.execute(SETUP)
 if not recovered or not os.environ.get('DEC14_FULL_SOURCE'):lua.execute(prefix)
 if recovered:lua.execute((R/SOURCE).read_bytes())
 else:result[b'vm'](result[b'proto'],lua.table(),result[b'env'])()
 stats=lua.eval(b'fixture_stats')();startup=plain(lua.globals().trace)
 outcomes=plain(lua.execute(EXERCISE));trace=plain(lua.globals().trace)
 return {'stats':stats,'startup':startup,'outcomes':outcomes,'trace':trace}
if __name__=='__main__':
 values=[run(False),run(True)]
 for v in values:
  for row in v['outcomes'].values():
   if row.get('error'):row['error']=re.sub(r'^.*?:\d+: ','',row['error'])
 print([(v['stats'],len(v['trace']),len(v['outcomes']))for v in values])
 if values[0]!=values[1]:
  (R/'source_diff.json').write_text(json.dumps(values,ensure_ascii=False,indent=2))
  raise AssertionError('Source and VM differ; see source_diff.json')
 failures=[r for r in values[0]['outcomes'].values()if not r['ok']]
 report={'matched':True,'startup_stats':values[0]['stats'],'host_calls':len(values[0]['trace']),'callback_cases':len(values[0]['outcomes']),'fixture_failures':failures,'gameplay_tested':False}
 (R/'source_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print('Matched original VM')
