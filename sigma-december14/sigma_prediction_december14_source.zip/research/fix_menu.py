from pathlib import Path
import re
R=Path(__file__).resolve().parent
p=R/'sigma_prediction_december14_source.lua';s=p.read_text();(R/'before_menu_fix.lua').write_text(s)
for key in ['enabled','maxprocticks','fakeduck','player_list','reset_all','apply_all','load_cfg','fl_limit']:
 assert len(re.findall(r'native_controls\.'+key+r'\b',s))==1,key
 s,n=re.subn(r'(?m)^    native_controls\.'+key+r' = .*\n','',s);assert n==1
helper='''-- Resolve known legacy menu paths without changing the global GameSense API.
local function compatible_reference(tab, container, name)
    local results = __dec14_pack_results(pcall(ui.reference, tab, container, name))
    if results[1] then return unpack(results, 2, results.n) end
    if not tostring(results[2]):find('not found', 1, true) then error(results[2], 2) end
    if tab:lower() == 'rage' and container:lower() == 'other' and (name == 'Double tap' or name == 'Force body aim') then
        return ui.reference(tab, 'Aimbot', name)
    end
    if name == 'Fake yaw limit' then
        client.log('[sigma dec14] Fake yaw limit is unavailable; its visibility and limit writes are skipped.')
        return nil
    end
    error(results[2], 2)
end

'''
s=s.replace('local function main(...)',helper+'local function main(...)',1)
s=s.replace('ui_reference = ui.reference','ui_reference = compatible_reference',1)
s=s.replace('''    ui_set = ui.set''','''    ui_set = function(handle, value, ...)
        if native_controls and native_controls.freestand and handle == native_controls.freestand[1] and type(ui.get(handle)) == 'boolean' and type(value) == 'string' then
            return ui.set(handle, value == 'Default', ...)
        end
        return ui.set(handle, value, ...)
    end''',1)
s=s.replace('("anti-aimbot angles")','("Anti-aimbot angles")').replace('("pitch")','("Pitch")')
# The seven writes immediately following this known optional handle read.
pat=r'(?m)^(\s*)(\w+) = native_controls\.fakeyawlimit\n\s*ui_set\(\2, ([^\n]+)\)'
s,n=re.subn(pat,lambda m:m[1]+m[2]+' = native_controls.fakeyawlimit\n'+m[1]+'if '+m[2]+' ~= nil then ui_set('+m[2]+', '+m[3]+') end',s);assert n==7,n
pat=r'(?m)^(\s*)(\w+) = native_controls\.fakeyawlimit\n\s*ui_set_visible\(\2, ([^\n]+)\)'
s,n=re.subn(pat,lambda m:m[1]+m[2]+' = native_controls.fakeyawlimit\n'+m[1]+'if '+m[2]+' ~= nil then ui_set_visible('+m[2]+', '+m[3]+') end',s);assert n==1,n
s,n=re.subn(r'(?m)^    fake_yaw_limit = \(ui\.reference\).*\n','',s);assert n==1
needle='        value_3_2 = #argument_0_2'
assert s.count(needle)==1;s=s.replace(needle,"        if type_alias(argument_0_2) ~= 'table' then return argument_0_2 == argument_1_2 end\n"+needle)
needle='                    value_16_2 = contains_value(value_17_2, ("Default"))'
assert s.count(needle)==1;s=s.replace(needle,'''                    local freestanding_state = ui_get(value_17_2)
                    if type_alias(freestanding_state) == 'boolean' then
                        value_16_2 = freestanding_state
                    else
                        value_16_2 = contains_value(freestanding_state, 'Default')
                    end''')
(R/'sigma_prediction_december14_source.lua').write_text(s)
