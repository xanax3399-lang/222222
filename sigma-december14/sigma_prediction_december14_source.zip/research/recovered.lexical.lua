local function main(...)
    local http_module, vector_module, get_value_type, set_metatable, to_string, math_pi, math_min, math_max, math_degrees, math_radians, math_square_root, math_sine, math_cosine, math_arctangent, math_arccosine, math_remainder, vector_metatable, base64_module, extract_bits, base64_encoder, base64_decoder, string_char, table_concat, bit_band, camera_angles, eye_position, key_state, scale_damage, screen_size, set_event_callback, trace_bullet, trace_line, userid_to_entindex, get_all_entities, get_classname, get_local_player, get_player_resource, get_players, get_prop, hitbox_position, is_alive, is_dormant, is_enemy, curtime, tickcount, tickinterval, math_abs, math_atan, math_atan2, math_cos, math_deg, math_rad, math_sin, math_sqrt, draw_gradient, draw_line, draw_text, draw_triangle, table_remove, ui_get, ui_new_color_picker, ui_new_hotkey, ui_new_label, ui_new_multiselect, ui_reference, ui_set, ui_set_callback, ui_set_visible, type_alias, ui_new_slider, native_controls, set_native_ui_visible, script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1
    http_module = require
    vector_module = "gamesense/http"
    http_module = http_module(vector_module)
    vector_module = require
    get_value_type = "vector"
    vector_module = vector_module(get_value_type)
    get_value_type = type
    set_metatable = setmetatable
    to_string = tostring
    math_pi = math
    math_pi = math_pi.pi
    math_min = math
    math_min = math_min.min
    math_max = math
    math_max = math_max.max
    math_degrees = math
    math_degrees = math_degrees.deg
    math_radians = math
    math_radians = math_radians.rad
    math_square_root = math
    math_square_root = math_square_root.sqrt
    math_sine = math
    math_sine = math_sine.sin
    math_cosine = math
    math_cosine = math_cosine.cos
    math_arctangent = math
    math_arctangent = math_arctangent.atan
    math_arccosine = math
    math_arccosine = math_arccosine.acos
    math_remainder = math
    math_remainder = math_remainder.fmod
    vector_metatable = {
    }
    vector_metatable.__index = vector_metatable
    Vector3 = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2
        L3_2 = get_value_type
        L4_2 = A0_2
        L3_2 = L3_2(L4_2)
        if L3_2 ~= "number" then
            A0_2 = 0
        end
        L3_2 = get_value_type
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L3_2 ~= "number" then
            A1_2 = 0
        end
        L3_2 = get_value_type
        L4_2 = A2_2
        L3_2 = L3_2(L4_2)
        if L3_2 ~= "number" then
            A2_2 = 0
        end
        if not A0_2 then
            A0_2 = 0
        end
        if not A1_2 then
            A1_2 = 0
        end
        if not A2_2 then
            A2_2 = 0
        end
        L3_2 = set_metatable
        L4_2 = {
        }
        L4_2.x = A0_2
        L4_2.y = A1_2
        L4_2.z = A2_2
        L5_2 = vector_metatable
        return L3_2(L4_2, L5_2)
    end
    vector_metatable.__eq = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        L2_2 = A0_2.x
        L3_2 = A1_2.x
        if L2_2 == L3_2 then
            L2_2 = A0_2.y
            L3_2 = A1_2.y
            if L2_2 == L3_2 then
                L2_2 = A0_2.z
                L3_2 = A1_2.z
                if L2_2 == L3_2 then
                    L2_2 = true
                else
                    L2_2 = false
                end
            else
                L2_2 = false
            end
        else
            L2_2 = false
        end
        return L2_2
    end
    vector_metatable.__unm = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2
        L1_2 = Vector3
        L2_2 = A0_2.x
        L2_2 = -L2_2
        L3_2 = A0_2.y
        L3_2 = -L3_2
        L4_2 = A0_2.z
        L4_2 = -L4_2
        return L1_2(L2_2, L3_2, L4_2)
    end
    vector_metatable.__add = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type
        L3_2 = A0_2
        L2_2 = L2_2(L3_2)
        L3_2 = get_value_type
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 + L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 + L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 + L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L5_2 = L5_2 + A1_2
            L6_2 = A0_2.y
            L6_2 = L6_2 + A1_2
            L7_2 = A0_2.z
            L7_2 = L7_2 + A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 + L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 + L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 + L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__sub = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type
        L3_2 = A0_2
        L2_2 = L2_2(L3_2)
        L3_2 = get_value_type
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 - L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 - L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 - L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L5_2 = L5_2 - A1_2
            L6_2 = A0_2.y
            L6_2 = L6_2 - A1_2
            L7_2 = A0_2.z
            L7_2 = L7_2 - A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 - L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 - L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 - L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__mul = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type
        L3_2 = A0_2
        L2_2 = L2_2(L3_2)
        L3_2 = get_value_type
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 * L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 * L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 * L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L5_2 = L5_2 * A1_2
            L6_2 = A0_2.y
            L6_2 = L6_2 * A1_2
            L7_2 = A0_2.z
            L7_2 = L7_2 * A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 * L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 * L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 * L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__div = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type
        L3_2 = A0_2
        L2_2 = L2_2(L3_2)
        L3_2 = get_value_type
        L4_2 = A1_2
        L3_2 = L3_2(L4_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 / L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 / L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 / L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L5_2 = L5_2 / A1_2
            L6_2 = A0_2.y
            L6_2 = L6_2 / A1_2
            L7_2 = A0_2.z
            L7_2 = L7_2 / A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 / L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 / L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 / L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__tostring = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
        L1_2 = "( "
        L2_2 = A0_2.x
        L3_2 = ", "
        L4_2 = A0_2.y
        L5_2 = ", "
        L6_2 = A0_2.z
        L7_2 = " )"
        L1_2 = L1_2..L2_2..L3_2..L4_2..L5_2..L6_2..L7_2
        return L1_2
    end
    vector_metatable.clear = function(A0_2, ...)
        local L1_2, L2_2
        A0_2.x = 0
        A0_2.y = 0
        A0_2.z = 0
    end
    vector_metatable.unpack = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.y
        L3_2 = A0_2.z
        return L1_2, L2_2, L3_2
    end
    vector_metatable.length_2d_sqr = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.x
        L1_2 = L1_2 * L2_2
        L2_2 = A0_2.y
        L3_2 = A0_2.y
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        return L1_2
    end
    vector_metatable.length_sqr = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.x
        L1_2 = L1_2 * L2_2
        L2_2 = A0_2.y
        L3_2 = A0_2.y
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        L2_2 = A0_2.z
        L3_2 = A0_2.z
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        return L1_2
    end
    vector_metatable.length_2d = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = math_square_root
        L3_2 = A0_2
        L2_2 = A0_2.length_2d_sqr
        local returned_13_0 = __dec14_pack_results(L2_2(L3_2))
        L2_2, L3_2 = unpack(returned_13_0, 1, returned_13_0.n)
        return L1_2(unpack(returned_13_0, 1, returned_13_0.n))
    end
    vector_metatable.length = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = math_square_root
        L3_2 = A0_2
        L2_2 = A0_2.length_sqr
        local returned_14_1 = __dec14_pack_results(L2_2(L3_2))
        L2_2, L3_2 = unpack(returned_14_1, 1, returned_14_1.n)
        return L1_2(unpack(returned_14_1, 1, returned_14_1.n))
    end
    vector_metatable.dot = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2
        L2_2 = A0_2.x
        L3_2 = A1_2.x
        L2_2 = L2_2 * L3_2
        L3_2 = A0_2.y
        L4_2 = A1_2.y
        L3_2 = L3_2 * L4_2
        L2_2 = L2_2 + L3_2
        L3_2 = A0_2.z
        L4_2 = A1_2.z
        L3_2 = L3_2 * L4_2
        L2_2 = L2_2 + L3_2
        return L2_2
    end
    vector_metatable.cross = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
        L2_2 = Vector3
        L3_2 = A0_2.y
        L4_2 = A1_2.z
        L3_2 = L3_2 * L4_2
        L4_2 = A0_2.z
        L5_2 = A1_2.y
        L4_2 = L4_2 * L5_2
        L3_2 = L3_2 - L4_2
        L4_2 = A0_2.z
        L5_2 = A1_2.x
        L4_2 = L4_2 * L5_2
        L5_2 = A0_2.x
        L6_2 = A1_2.z
        L5_2 = L5_2 * L6_2
        L4_2 = L4_2 - L5_2
        L5_2 = A0_2.x
        L6_2 = A1_2.y
        L5_2 = L5_2 * L6_2
        L6_2 = A0_2.y
        L7_2 = A1_2.x
        L6_2 = L6_2 * L7_2
        L5_2 = L5_2 - L6_2
        return L2_2(L3_2, L4_2, L5_2)
    end
    vector_metatable.dist_to = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        L2_2 = A1_2 - A0_2
        L3_2 = L2_2
        L2_2 = L2_2.length
        return L2_2(L3_2)
    end
    vector_metatable.is_zero = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        if not A1_2 then
            A1_2 = 0.001
        end
        L2_2 = A0_2.x
        if A1_2 > L2_2 then
            L2_2 = A0_2.x
            L3_2 = -A1_2
            if L2_2 > L3_2 then
                L2_2 = A0_2.y
                if A1_2 > L2_2 then
                    L2_2 = A0_2.y
                    L3_2 = -A1_2
                    if L2_2 > L3_2 then
                        L2_2 = A0_2.z
                        if A1_2 > L2_2 then
                            L2_2 = A0_2.z
                            L3_2 = -A1_2
                            if L2_2 > L3_2 then
                                L2_2 = true
                                return L2_2
                            end
                        end
                    end
                end
            end
        end
        L2_2 = false
        return L2_2
    end
    vector_metatable.normalize = function(A0_2, ...)
        local L1_2, L2_2
        L2_2 = A0_2
        L1_2 = A0_2.length
        L1_2 = L1_2(L2_2)
        if L1_2 <= 0 then
            L2_2 = 0
            return L2_2
        end
        L2_2 = A0_2.x
        L2_2 = L2_2 / L1_2
        A0_2.x = L2_2
        L2_2 = A0_2.y
        L2_2 = L2_2 / L1_2
        A0_2.y = L2_2
        L2_2 = A0_2.z
        L2_2 = L2_2 / L1_2
        A0_2.z = L2_2
        return L1_2
    end
    vector_metatable.normalize_no_len = function(A0_2, ...)
        local L1_2, L2_2
        L2_2 = A0_2
        L1_2 = A0_2.length
        L1_2 = L1_2(L2_2)
        if L1_2 <= 0 then
            return 
        end
        L2_2 = A0_2.x
        L2_2 = L2_2 / L1_2
        A0_2.x = L2_2
        L2_2 = A0_2.y
        L2_2 = L2_2 / L1_2
        A0_2.y = L2_2
        L2_2 = A0_2.z
        L2_2 = L2_2 / L1_2
        A0_2.z = L2_2
    end
    vector_metatable.normalized = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2
        L2_2 = A0_2
        L1_2 = A0_2.length
        L1_2 = L1_2(L2_2)
        if L1_2 <= 0 then
            L2_2 = Vector3
            return L2_2()
        end
        L2_2 = Vector3
        L3_2 = A0_2.x
        L3_2 = L3_2 / L1_2
        L4_2 = A0_2.y
        L4_2 = L4_2 / L1_2
        L5_2 = A0_2.z
        L5_2 = L5_2 / L1_2
        return L2_2(L3_2, L4_2, L5_2)
    end
    clamp = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2
        if A0_2 < A1_2 then
            return A1_2
        end
        if A2_2 < A0_2 then
            return A2_2
        end
        return A0_2
    end
    normalize_angle = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
        L3_2 = to_string
        L4_2 = A0_2
        L3_2 = L3_2(L4_2)
        L2_2 = L3_2
        if L2_2 == "nan" or L2_2 == "inf" then
            L3_2 = 0
            return L3_2
        end
        if -180 <= A0_2 and A0_2 <= 180 then
            return A0_2
        end
        L3_2 = math_remainder
        L4_2 = math_remainder
        L5_2 = A0_2 + 360
        L6_2 = 360
        L4_2 = L4_2(L5_2, L6_2)
        L5_2 = 360
        L3_2 = L3_2(L4_2, L5_2)
        L1_2 = L3_2
        if 180 < L1_2 then
            L1_2 = L1_2 - 360
        end
        return L1_2
    end
    vector_to_angle = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
        L5_2 = A0_2
        L4_2 = A0_2.length
        L4_2 = L4_2(L5_2)
        L1_2 = L4_2
        if 0 < L1_2 then
            L4_2 = math_degrees
            L5_2 = math_arctangent
            L6_2 = A0_2.z
            L6_2 = -L6_2
            L7_2 = L1_2
            local returned_24_2 = __dec14_pack_results(L5_2(L6_2, L7_2))
            L5_2, L6_2, L7_2 = unpack(returned_24_2, 1, returned_24_2.n)
            L4_2 = L4_2(unpack(returned_24_2, 1, returned_24_2.n))
            L2_2 = L4_2
            L4_2 = math_degrees
            L5_2 = math_arctangent
            L6_2 = A0_2.y
            L7_2 = A0_2.x
            local returned_24_3 = __dec14_pack_results(L5_2(L6_2, L7_2))
            L5_2, L6_2, L7_2 = unpack(returned_24_3, 1, returned_24_3.n)
            L4_2 = L4_2(unpack(returned_24_3, 1, returned_24_3.n))
            L3_2 = L4_2
        else
            L4_2 = A0_2.x
            if 0 < L4_2 then
                L2_2 = 270
            else
                L2_2 = 90
            end
            L3_2 = 0
        end
        L4_2 = Vector3
        L5_2 = L2_2
        L6_2 = L3_2
        L7_2 = 0
        return L4_2(L5_2, L6_2, L7_2)
    end
    angle_forward = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L1_2 = math_sine
        L2_2 = math_radians
        L3_2 = A0_2.x
        local returned_25_4 = __dec14_pack_results(L2_2(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_4, 1, returned_25_4.n)
        L1_2 = L1_2(unpack(returned_25_4, 1, returned_25_4.n))
        L2_2 = math_cosine
        L3_2 = math_radians
        L4_2 = A0_2.x
        local returned_25_5 = __dec14_pack_results(L3_2(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_5, 1, returned_25_5.n)
        L2_2 = L2_2(unpack(returned_25_5, 1, returned_25_5.n))
        L3_2 = math_sine
        L4_2 = math_radians
        L5_2 = A0_2.y
        local returned_25_6 = __dec14_pack_results(L4_2(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_6, 1, returned_25_6.n)
        L3_2 = L3_2(unpack(returned_25_6, 1, returned_25_6.n))
        L4_2 = math_cosine
        L5_2 = math_radians
        L6_2 = A0_2.y
        local returned_25_7 = __dec14_pack_results(L5_2(L6_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_7, 1, returned_25_7.n)
        L4_2 = L4_2(unpack(returned_25_7, 1, returned_25_7.n))
        L5_2 = Vector3
        L6_2 = L2_2 * L4_2
        L7_2 = L2_2 * L3_2
        L8_2 = -L1_2
        return L5_2(L6_2, L7_2, L8_2)
    end
    angle_right = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L1_2 = math_sine
        L2_2 = math_radians
        L3_2 = A0_2.x
        local returned_26_8 = __dec14_pack_results(L2_2(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_8, 1, returned_26_8.n)
        L1_2 = L1_2(unpack(returned_26_8, 1, returned_26_8.n))
        L2_2 = math_cosine
        L3_2 = math_radians
        L4_2 = A0_2.x
        local returned_26_9 = __dec14_pack_results(L3_2(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_9, 1, returned_26_9.n)
        L2_2 = L2_2(unpack(returned_26_9, 1, returned_26_9.n))
        L3_2 = math_sine
        L4_2 = math_radians
        L5_2 = A0_2.y
        local returned_26_10 = __dec14_pack_results(L4_2(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_10, 1, returned_26_10.n)
        L3_2 = L3_2(unpack(returned_26_10, 1, returned_26_10.n))
        L4_2 = math_cosine
        L5_2 = math_radians
        L6_2 = A0_2.y
        local returned_26_11 = __dec14_pack_results(L5_2(L6_2))
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_11, 1, returned_26_11.n)
        L4_2 = L4_2(unpack(returned_26_11, 1, returned_26_11.n))
        L5_2 = math_sine
        L6_2 = math_radians
        L7_2 = A0_2.z
        local returned_26_12 = __dec14_pack_results(L6_2(L7_2))
        L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_12, 1, returned_26_12.n)
        L5_2 = L5_2(unpack(returned_26_12, 1, returned_26_12.n))
        L6_2 = math_cosine
        L7_2 = math_radians
        L8_2 = A0_2.z
        local returned_26_13 = __dec14_pack_results(L7_2(L8_2))
        L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_13, 1, returned_26_13.n)
        L6_2 = L6_2(unpack(returned_26_13, 1, returned_26_13.n))
        L7_2 = Vector3
        L8_2 = -1 * L5_2
        L8_2 = L8_2 * L1_2
        L8_2 = L8_2 * L4_2
        L9_2 = -1 * L6_2
        L10_2 = -L3_2
        L9_2 = L9_2 * L10_2
        L8_2 = L8_2 + L9_2
        L9_2 = -1 * L5_2
        L9_2 = L9_2 * L1_2
        L9_2 = L9_2 * L3_2
        L10_2 = -1 * L6_2
        L10_2 = L10_2 * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = -1 * L5_2
        L10_2 = L10_2 * L2_2
        return L7_2(L8_2, L9_2, L10_2)
    end
    angle_up = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L1_2 = math_sine
        L2_2 = math_radians
        L3_2 = A0_2.x
        local returned_27_14 = __dec14_pack_results(L2_2(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_14, 1, returned_27_14.n)
        L1_2 = L1_2(unpack(returned_27_14, 1, returned_27_14.n))
        L2_2 = math_cosine
        L3_2 = math_radians
        L4_2 = A0_2.x
        local returned_27_15 = __dec14_pack_results(L3_2(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_15, 1, returned_27_15.n)
        L2_2 = L2_2(unpack(returned_27_15, 1, returned_27_15.n))
        L3_2 = math_sine
        L4_2 = math_radians
        L5_2 = A0_2.y
        local returned_27_16 = __dec14_pack_results(L4_2(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_16, 1, returned_27_16.n)
        L3_2 = L3_2(unpack(returned_27_16, 1, returned_27_16.n))
        L4_2 = math_cosine
        L5_2 = math_radians
        L6_2 = A0_2.y
        local returned_27_17 = __dec14_pack_results(L5_2(L6_2))
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_17, 1, returned_27_17.n)
        L4_2 = L4_2(unpack(returned_27_17, 1, returned_27_17.n))
        L5_2 = math_sine
        L6_2 = math_radians
        L7_2 = A0_2.z
        local returned_27_18 = __dec14_pack_results(L6_2(L7_2))
        L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_18, 1, returned_27_18.n)
        L5_2 = L5_2(unpack(returned_27_18, 1, returned_27_18.n))
        L6_2 = math_cosine
        L7_2 = math_radians
        L8_2 = A0_2.z
        local returned_27_19 = __dec14_pack_results(L7_2(L8_2))
        L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_19, 1, returned_27_19.n)
        L6_2 = L6_2(unpack(returned_27_19, 1, returned_27_19.n))
        L7_2 = Vector3
        L8_2 = L6_2 * L1_2
        L8_2 = L8_2 * L4_2
        L9_2 = -L5_2
        L10_2 = -L3_2
        L9_2 = L9_2 * L10_2
        L8_2 = L8_2 + L9_2
        L9_2 = L6_2 * L1_2
        L9_2 = L9_2 * L3_2
        L10_2 = -L5_2
        L10_2 = L10_2 * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = L6_2 * L2_2
        return L7_2(L8_2, L9_2, L10_2)
    end
    get_FOV = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L7_2 = angle_forward
        L8_2 = A0_2
        L7_2 = L7_2(L8_2)
        L4_2 = L7_2
        L7_2 = A2_2 - A1_2
        L8_2 = L7_2
        L7_2 = L7_2.normalized
        L7_2 = L7_2(L8_2)
        L5_2 = L7_2
        L7_2 = math_arccosine
        L9_2 = L4_2
        L8_2 = L4_2.dot
        L10_2 = L5_2
        L8_2 = L8_2(L9_2, L10_2)
        L10_2 = L5_2
        L9_2 = L5_2.length
        L9_2 = L9_2(L10_2)
        L8_2 = L8_2 / L9_2
        L7_2 = L7_2(L8_2)
        L6_2 = L7_2
        L7_2 = math_max
        L8_2 = 0
        L9_2 = math_degrees
        L10_2 = L6_2
        local returned_28_20 = __dec14_pack_results(L9_2(L10_2))
        L9_2, L10_2 = unpack(returned_28_20, 1, returned_28_20.n)
        return L7_2(L8_2, unpack(returned_28_20, 1, returned_28_20.n))
    end
    base64_module = {
    }
    extract_bits = _G
    extract_bits = extract_bits.bit32
    if extract_bits then
        extract_bits = _G
        extract_bits = extract_bits.bit32
        extract_bits = extract_bits.extract
    end
    if not extract_bits then
        base64_encoder = _G
        base64_encoder = base64_encoder.bit
        if base64_encoder then
            local captured_bit_lshift, captured_bit_rshift, captured_bit_band
            captured_bit_lshift = _G
            captured_bit_lshift = captured_bit_lshift.bit
            captured_bit_lshift = captured_bit_lshift.lshift
            captured_bit_rshift = _G
            captured_bit_rshift = captured_bit_rshift.bit
            captured_bit_rshift = captured_bit_rshift.rshift
            captured_bit_band = _G
            captured_bit_band = captured_bit_band.bit
            captured_bit_band = captured_bit_band.band
            extract_bits = function(A0_2, A1_2, A2_2, ...)
                local L3_2, L4_2, L5_2, L6_2, L7_2
                L3_2 = captured_bit_band
                L4_2 = captured_bit_rshift
                L5_2 = A0_2
                L6_2 = A1_2
                L4_2 = L4_2(L5_2, L6_2)
                L5_2 = captured_bit_lshift
                L6_2 = 1
                L7_2 = A2_2
                L5_2 = L5_2(L6_2, L7_2)
                L5_2 = L5_2 - 1
                return L3_2(L4_2, L5_2)
            end
        else
            base64_encoder = _G
            base64_encoder = base64_encoder._VERSION
            if base64_encoder == "Lua 5.1" then
                extract_bits = function(A0_2, A1_2, A2_2, ...)
                    local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
                    L3_2 = 0
                    L4_2 = 2 ^ A1_2
                    L5_2 = 0
                    L6_2 = A2_2 - 1
                    L7_2 = 1
                    for L8_2 = L5_2, L6_2, L7_2 do
                        L9_2 = L4_2 + L4_2
                        L10_2 = A0_2 % L9_2
                        if L4_2 <= L10_2 then
                            L10_2 = 2 ^ L8_2
                            L3_2 = L3_2 + L10_2
                        end
                        L4_2 = L9_2
                    end
                    return L3_2
                end
            else
                base64_encoder = load
                base64_decoder = "return function( v, from, width ) return ( v >> from ) & ((1 << width) - 1) end"
                base64_encoder = base64_encoder(base64_decoder)
                base64_encoder = base64_encoder()
                extract_bits = base64_encoder
            end
        end
    end
    base64_module.makeencoder = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2, L34_2, L35_2, L36_2, L37_2, L38_2, L39_2, L40_2, L41_2, L42_2, L43_2, L44_2, L45_2, L46_2, L47_2, L48_2, L49_2, L50_2, L51_2, L52_2, L53_2, L54_2, L55_2
        L3_2 = {
        }
        L4_2 = pairs
        L5_2 = {
        }
        L5_2[0] = "A"
        L6_2 = "B"
        L7_2 = "C"
        L8_2 = "D"
        L9_2 = "E"
        L10_2 = "F"
        L11_2 = "G"
        L12_2 = "H"
        L13_2 = "I"
        L14_2 = "J"
        L15_2 = "K"
        L16_2 = "L"
        L17_2 = "M"
        L18_2 = "N"
        L19_2 = "O"
        L20_2 = "P"
        L21_2 = "Q"
        L22_2 = "R"
        L23_2 = "S"
        L24_2 = "T"
        L25_2 = "U"
        L26_2 = "V"
        L27_2 = "W"
        L28_2 = "X"
        L29_2 = "Y"
        L30_2 = "Z"
        L31_2 = "a"
        L32_2 = "b"
        L33_2 = "c"
        L34_2 = "d"
        L35_2 = "e"
        L36_2 = "f"
        L37_2 = "g"
        L38_2 = "h"
        L39_2 = "i"
        L40_2 = "j"
        L41_2 = "k"
        L42_2 = "l"
        L43_2 = "m"
        L44_2 = "n"
        L45_2 = "o"
        L46_2 = "p"
        L47_2 = "q"
        L48_2 = "r"
        L49_2 = "s"
        L50_2 = "t"
        L51_2 = "u"
        L52_2 = "v"
        L53_2 = "w"
        L54_2 = "x"
        L55_2 = "y"
        L5_2[1] = L6_2
        L5_2[2] = L7_2
        L5_2[3] = L8_2
        L5_2[4] = L9_2
        L5_2[5] = L10_2
        L5_2[6] = L11_2
        L5_2[7] = L12_2
        L5_2[8] = L13_2
        L5_2[9] = L14_2
        L5_2[10] = L15_2
        L5_2[11] = L16_2
        L5_2[12] = L17_2
        L5_2[13] = L18_2
        L5_2[14] = L19_2
        L5_2[15] = L20_2
        L5_2[16] = L21_2
        L5_2[17] = L22_2
        L5_2[18] = L23_2
        L5_2[19] = L24_2
        L5_2[20] = L25_2
        L5_2[21] = L26_2
        L5_2[22] = L27_2
        L5_2[23] = L28_2
        L5_2[24] = L29_2
        L5_2[25] = L30_2
        L5_2[26] = L31_2
        L5_2[27] = L32_2
        L5_2[28] = L33_2
        L5_2[29] = L34_2
        L5_2[30] = L35_2
        L5_2[31] = L36_2
        L5_2[32] = L37_2
        L5_2[33] = L38_2
        L5_2[34] = L39_2
        L5_2[35] = L40_2
        L5_2[36] = L41_2
        L5_2[37] = L42_2
        L5_2[38] = L43_2
        L5_2[39] = L44_2
        L5_2[40] = L45_2
        L5_2[41] = L46_2
        L5_2[42] = L47_2
        L5_2[43] = L48_2
        L5_2[44] = L49_2
        L5_2[45] = L50_2
        L5_2[46] = L51_2
        L5_2[47] = L52_2
        L5_2[48] = L53_2
        L5_2[49] = L54_2
        L5_2[50] = L55_2
        L6_2 = "z"
        L7_2 = "0"
        L8_2 = "1"
        L9_2 = "2"
        L10_2 = "3"
        L11_2 = "4"
        L12_2 = "5"
        L13_2 = "6"
        L14_2 = "7"
        L15_2 = "8"
        L16_2 = "9"
        L17_2 = A0_2 or L17_2
        if not A0_2 then
            L17_2 = "+"
        end
        L18_2 = A1_2 or L18_2
        if not A1_2 then
            L18_2 = "/"
        end
        L19_2 = A2_2 or L19_2
        if not A2_2 then
            L19_2 = "="
        end
        L5_2[51] = L6_2
        L5_2[52] = L7_2
        L5_2[53] = L8_2
        L5_2[54] = L9_2
        L5_2[55] = L10_2
        L5_2[56] = L11_2
        L5_2[57] = L12_2
        L5_2[58] = L13_2
        L5_2[59] = L14_2
        L5_2[60] = L15_2
        L5_2[61] = L16_2
        L5_2[62] = L17_2
        L5_2[63] = L18_2
        L5_2[64] = L19_2
        L4_2, L5_2, L6_2 = L4_2(L5_2)
        for L7_2, L8_2 in L4_2, L5_2, L6_2 do
            if not L7_2 then
                break
            end
            L10_2 = L8_2
            L9_2 = L8_2.byte
            L9_2 = L9_2(L10_2)
            L3_2[L7_2] = L9_2
        end
        return L3_2
    end
    base64_module.makedecoder = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L3_2 = {
        }
        L4_2 = pairs
        L5_2 = base64_module
        L5_2 = L5_2.makeencoder
        L6_2 = A0_2
        L7_2 = A1_2
        L8_2 = A2_2
        local returned_32_21 = __dec14_pack_results(L5_2(L6_2, L7_2, L8_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_32_21, 1, returned_32_21.n)
        L4_2, L5_2, L6_2 = L4_2(unpack(returned_32_21, 1, returned_32_21.n))
        for L7_2, L8_2 in L4_2, L5_2, L6_2 do
            if not L7_2 then
                break
            end
            L3_2[L8_2] = L7_2
        end
        return L3_2
    end
    base64_encoder = base64_module.makeencoder
    base64_encoder = base64_encoder()
    base64_decoder = base64_module.makedecoder
    base64_decoder = base64_decoder()
    string_char = string
    string_char = string_char.char
    table_concat = table
    table_concat = table_concat.concat
    base64_module.encode = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
        if not A1_2 then
            A1_2 = base64_encoder
        end
        L3_2 = {
        }
        L4_2 = 1
        L5_2 = #A0_2
        L6_2 = L5_2 % 3
        L7_2 = {
        }
        L8_2 = 1
        L9_2 = L5_2 - L6_2
        L10_2 = 3
        for L11_2 = L8_2, L9_2, L10_2 do
            L13_2 = A0_2
            L12_2 = A0_2.byte
            L14_2 = L11_2
            L15_2 = L11_2 + 2
            L12_2, L13_2, L14_2 = L12_2(L13_2, L14_2, L15_2)
            L15_2 = L12_2 * 65536
            L16_2 = L13_2 * 256
            L15_2 = L15_2 + L16_2
            L15_2 = L15_2 + L14_2
            L16_2 = nil
            if A2_2 then
                L16_2 = L7_2[L15_2]
                if not L16_2 then
                    L17_2 = string_char
                    L18_2 = extract_bits
                    L19_2 = L15_2
                    L20_2 = 18
                    L21_2 = 6
                    L18_2 = L18_2(L19_2, L20_2, L21_2)
                    L18_2 = A1_2[L18_2]
                    L19_2 = extract_bits
                    L20_2 = L15_2
                    L21_2 = 12
                    L22_2 = 6
                    L19_2 = L19_2(L20_2, L21_2, L22_2)
                    L19_2 = A1_2[L19_2]
                    L20_2 = extract_bits
                    L21_2 = L15_2
                    L22_2 = 6
                    L23_2 = 6
                    L20_2 = L20_2(L21_2, L22_2, L23_2)
                    L20_2 = A1_2[L20_2]
                    L21_2 = extract_bits
                    L22_2 = L15_2
                    L23_2 = 0
                    L24_2 = 6
                    L21_2 = L21_2(L22_2, L23_2, L24_2)
                    L21_2 = A1_2[L21_2]
                    L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
                    L16_2 = L17_2
                    L7_2[L15_2] = L16_2
                end
            else
                L17_2 = string_char
                L18_2 = extract_bits
                L19_2 = L15_2
                L20_2 = 18
                L21_2 = 6
                L18_2 = L18_2(L19_2, L20_2, L21_2)
                L18_2 = A1_2[L18_2]
                L19_2 = extract_bits
                L20_2 = L15_2
                L21_2 = 12
                L22_2 = 6
                L19_2 = L19_2(L20_2, L21_2, L22_2)
                L19_2 = A1_2[L19_2]
                L20_2 = extract_bits
                L21_2 = L15_2
                L22_2 = 6
                L23_2 = 6
                L20_2 = L20_2(L21_2, L22_2, L23_2)
                L20_2 = A1_2[L20_2]
                L21_2 = extract_bits
                L22_2 = L15_2
                L23_2 = 0
                L24_2 = 6
                L21_2 = L21_2(L22_2, L23_2, L24_2)
                L21_2 = A1_2[L21_2]
                L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
                L16_2 = L17_2
            end
            L3_2[L4_2] = L16_2
            L4_2 = L4_2 + 1
        end
        if L6_2 == 2 then
            L9_2 = A0_2
            L8_2 = A0_2.byte
            L10_2 = L5_2 - 1
            L11_2 = L5_2
            L8_2, L9_2 = L8_2(L9_2, L10_2, L11_2)
            L10_2 = L8_2 * 65536
            L11_2 = L9_2 * 256
            L10_2 = L10_2 + L11_2
            L11_2 = string_char
            L12_2 = extract_bits
            L13_2 = L10_2
            L14_2 = 18
            L15_2 = 6
            L12_2 = L12_2(L13_2, L14_2, L15_2)
            L12_2 = A1_2[L12_2]
            L13_2 = extract_bits
            L14_2 = L10_2
            L15_2 = 12
            L16_2 = 6
            L13_2 = L13_2(L14_2, L15_2, L16_2)
            L13_2 = A1_2[L13_2]
            L14_2 = extract_bits
            L15_2 = L10_2
            L16_2 = 6
            L17_2 = 6
            L14_2 = L14_2(L15_2, L16_2, L17_2)
            L14_2 = A1_2[L14_2]
            L15_2 = A1_2[64]
            L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
            L3_2[L4_2] = L11_2
        else
            if L6_2 == 1 then
                L9_2 = A0_2
                L8_2 = A0_2.byte
                L10_2 = L5_2
                L8_2 = L8_2(L9_2, L10_2)
                L8_2 = L8_2 * 65536
                L9_2 = string_char
                L10_2 = extract_bits
                L11_2 = L8_2
                L12_2 = 18
                L13_2 = 6
                L10_2 = L10_2(L11_2, L12_2, L13_2)
                L10_2 = A1_2[L10_2]
                L11_2 = extract_bits
                L12_2 = L8_2
                L13_2 = 12
                L14_2 = 6
                L11_2 = L11_2(L12_2, L13_2, L14_2)
                L11_2 = A1_2[L11_2]
                L12_2 = A1_2[64]
                L13_2 = A1_2[64]
                L9_2 = L9_2(L10_2, L11_2, L12_2, L13_2)
                L3_2[L4_2] = L9_2
            end
        end
        L8_2 = table_concat
        L9_2 = L3_2
        return L8_2(L9_2)
    end
    base64_module.decode = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2
        if not A1_2 then
            A1_2 = base64_decoder
        end
        L3_2 = "[^%w%+%/%=]"
        if A1_2 then
            L4_2 = nil
            L5_2 = nil
            L6_2 = pairs
            L7_2 = A1_2
            L6_2, L7_2, L8_2 = L6_2(L7_2)
            for L9_2, L10_2 in L6_2, L7_2, L8_2 do
                if not L9_2 then
                    break
                end
                if L10_2 == 62 then
                    L4_2 = L9_2
                else
                    if L10_2 == 63 then
                        L5_2 = L9_2
                    end
                end
            end
            L6_2 = "[^%%w%%%s%%%s%%=]"
            L7_2 = L6_2
            L6_2 = L6_2.format
            L8_2 = string_char
            L9_2 = L4_2
            L8_2 = L8_2(L9_2)
            L9_2 = string_char
            L10_2 = L5_2
            local returned_34_22 = __dec14_pack_results(L9_2(L10_2))
            L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_22, 1, returned_34_22.n)
            L6_2 = L6_2(L7_2, L8_2, unpack(returned_34_22, 1, returned_34_22.n))
            L3_2 = L6_2
        end
        L5_2 = A0_2
        L4_2 = A0_2.gsub
        L6_2 = L3_2
        L7_2 = ""
        L4_2 = L4_2(L5_2, L6_2, L7_2)
        A0_2 = L4_2
        L4_2 = A2_2 or L4_2
        if A2_2 then
            L4_2 = {
            }
        end
        L5_2 = {
        }
        L6_2 = 1
        L7_2 = #A0_2
        L9_2 = A0_2
        L8_2 = A0_2.sub
        L10_2 = -2
        L8_2 = L8_2(L9_2, L10_2)
        if L8_2 == "==" then
            L8_2 = 2
            if not (L8_2) then
                L9_2 = A0_2
                L8_2 = A0_2.sub
                L10_2 = -1
                L8_2 = L8_2(L9_2, L10_2)
                if L8_2 == "=" then
                    L8_2 = 1
                    if not (L8_2) then
                        L8_2 = 0
                    end
                else
                    L8_2 = 0
                end
            end
        else
            L9_2 = A0_2
            L8_2 = A0_2.sub
            L10_2 = -1
            L8_2 = L8_2(L9_2, L10_2)
            if L8_2 == "=" then
                L8_2 = 1
                if not (L8_2) then
                    L8_2 = 0
                end
            else
                L8_2 = 0
            end
        end
        L9_2 = 1
        if 0 < L8_2 then
            L10_2 = L7_2 - 4
            if not (L10_2) then
                L10_2 = L7_2
            end
        else
            L10_2 = L7_2
        end
        L11_2 = 4
        for L12_2 = L9_2, L10_2, L11_2 do
            L14_2 = A0_2
            L13_2 = A0_2.byte
            L15_2 = L12_2
            L16_2 = L12_2 + 3
            L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2, L15_2, L16_2)
            L17_2 = nil
            if A2_2 then
                L18_2 = L13_2 * 16777216
                L19_2 = L14_2 * 65536
                L18_2 = L18_2 + L19_2
                L19_2 = L15_2 * 256
                L18_2 = L18_2 + L19_2
                L18_2 = L18_2 + L16_2
                L17_2 = L4_2[L18_2]
                if not L17_2 then
                    L19_2 = A1_2[L13_2]
                    L19_2 = L19_2 * 262144
                    L20_2 = A1_2[L14_2]
                    L20_2 = L20_2 * 4096
                    L19_2 = L19_2 + L20_2
                    L20_2 = A1_2[L15_2]
                    L20_2 = L20_2 * 64
                    L19_2 = L19_2 + L20_2
                    L20_2 = A1_2[L16_2]
                    L19_2 = L19_2 + L20_2
                    L20_2 = string_char
                    L21_2 = extract_bits
                    L22_2 = L19_2
                    L23_2 = 16
                    L24_2 = 8
                    L21_2 = L21_2(L22_2, L23_2, L24_2)
                    L22_2 = extract_bits
                    L23_2 = L19_2
                    L24_2 = 8
                    L25_2 = 8
                    L22_2 = L22_2(L23_2, L24_2, L25_2)
                    L23_2 = extract_bits
                    L24_2 = L19_2
                    L25_2 = 0
                    L26_2 = 8
                    local returned_34_23 = __dec14_pack_results(L23_2(L24_2, L25_2, L26_2))
                    L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_23, 1, returned_34_23.n)
                    L20_2 = L20_2(L21_2, L22_2, unpack(returned_34_23, 1, returned_34_23.n))
                    L17_2 = L20_2
                    L4_2[L18_2] = L17_2
                end
            else
                L18_2 = A1_2[L13_2]
                L18_2 = L18_2 * 262144
                L19_2 = A1_2[L14_2]
                L19_2 = L19_2 * 4096
                L18_2 = L18_2 + L19_2
                L19_2 = A1_2[L15_2]
                L19_2 = L19_2 * 64
                L18_2 = L18_2 + L19_2
                L19_2 = A1_2[L16_2]
                L18_2 = L18_2 + L19_2
                L19_2 = string_char
                L20_2 = extract_bits
                L21_2 = L18_2
                L22_2 = 16
                L23_2 = 8
                L20_2 = L20_2(L21_2, L22_2, L23_2)
                L21_2 = extract_bits
                L22_2 = L18_2
                L23_2 = 8
                L24_2 = 8
                L21_2 = L21_2(L22_2, L23_2, L24_2)
                L22_2 = extract_bits
                L23_2 = L18_2
                L24_2 = 0
                L25_2 = 8
                local returned_34_24 = __dec14_pack_results(L22_2(L23_2, L24_2, L25_2))
                L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_24, 1, returned_34_24.n)
                L19_2 = L19_2(L20_2, L21_2, unpack(returned_34_24, 1, returned_34_24.n))
                L17_2 = L19_2
            end
            L5_2[L6_2] = L17_2
            L6_2 = L6_2 + 1
        end
        if L8_2 == 1 then
            L10_2 = A0_2
            L9_2 = A0_2.byte
            L11_2 = L7_2 - 3
            L12_2 = L7_2 - 1
            L9_2, L10_2, L11_2 = L9_2(L10_2, L11_2, L12_2)
            L12_2 = A1_2[L9_2]
            L12_2 = L12_2 * 262144
            L13_2 = A1_2[L10_2]
            L13_2 = L13_2 * 4096
            L12_2 = L12_2 + L13_2
            L13_2 = A1_2[L11_2]
            L13_2 = L13_2 * 64
            L12_2 = L12_2 + L13_2
            L13_2 = string_char
            L14_2 = extract_bits
            L15_2 = L12_2
            L16_2 = 16
            L17_2 = 8
            L14_2 = L14_2(L15_2, L16_2, L17_2)
            L15_2 = extract_bits
            L16_2 = L12_2
            L17_2 = 8
            L18_2 = 8
            local returned_34_25 = __dec14_pack_results(L15_2(L16_2, L17_2, L18_2))
            L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_25, 1, returned_34_25.n)
            L13_2 = L13_2(L14_2, unpack(returned_34_25, 1, returned_34_25.n))
            L5_2[L6_2] = L13_2
        else
            if L8_2 == 2 then
                L10_2 = A0_2
                L9_2 = A0_2.byte
                L11_2 = L7_2 - 3
                L12_2 = L7_2 - 2
                L9_2, L10_2 = L9_2(L10_2, L11_2, L12_2)
                L11_2 = A1_2[L9_2]
                L11_2 = L11_2 * 262144
                L12_2 = A1_2[L10_2]
                L12_2 = L12_2 * 4096
                L11_2 = L11_2 + L12_2
                L12_2 = string_char
                L13_2 = extract_bits
                L14_2 = L11_2
                L15_2 = 16
                L16_2 = 8
                local returned_34_26 = __dec14_pack_results(L13_2(L14_2, L15_2, L16_2))
                L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_26, 1, returned_34_26.n)
                L12_2 = L12_2(unpack(returned_34_26, 1, returned_34_26.n))
                L5_2[L6_2] = L12_2
            end
        end
        L9_2 = table_concat
        L10_2 = L5_2
        return L9_2(L10_2)
    end
    bit_band = bit
    bit_band = bit_band.band
    camera_angles = client
    camera_angles = camera_angles.camera_angles
    eye_position = client
    eye_position = eye_position.eye_position
    key_state = client
    key_state = key_state.key_state
    scale_damage = client
    scale_damage = scale_damage.scale_damage
    screen_size = client
    screen_size = screen_size.screen_size
    set_event_callback = client
    set_event_callback = set_event_callback.set_event_callback
    trace_bullet = client
    trace_bullet = trace_bullet.trace_bullet
    trace_line = client
    trace_line = trace_line.trace_line
    userid_to_entindex = client
    userid_to_entindex = userid_to_entindex.userid_to_entindex
    get_all_entities = entity
    get_all_entities = get_all_entities.get_all
    get_classname = entity
    get_classname = get_classname.get_classname
    get_local_player = entity
    get_local_player = get_local_player.get_local_player
    get_player_resource = entity
    get_player_resource = get_player_resource.get_player_resource
    get_players = entity
    get_players = get_players.get_players
    get_prop = entity
    get_prop = get_prop.get_prop
    hitbox_position = entity
    hitbox_position = hitbox_position.hitbox_position
    is_alive = entity
    is_alive = is_alive.is_alive
    is_dormant = entity
    is_dormant = is_dormant.is_dormant
    is_enemy = entity
    is_enemy = is_enemy.is_enemy
    curtime = globals
    curtime = curtime.curtime
    tickcount = globals
    tickcount = tickcount.tickcount
    tickinterval = globals
    tickinterval = tickinterval.tickinterval
    math_abs = math
    math_abs = math_abs.abs
    math_atan = math
    math_atan = math_atan.atan
    math_atan2 = math
    math_atan2 = math_atan2.atan2
    math_cos = math
    math_cos = math_cos.cos
    math_deg = math
    math_deg = math_deg.deg
    math_rad = math
    math_rad = math_rad.rad
    math_sin = math
    math_sin = math_sin.sin
    math_sqrt = math
    math_sqrt = math_sqrt.sqrt
    draw_gradient = renderer
    draw_gradient = draw_gradient.gradient
    draw_line = renderer
    draw_line = draw_line.line
    draw_text = renderer
    draw_text = draw_text.text
    draw_triangle = renderer
    draw_triangle = draw_triangle.triangle
    table_remove = table
    table_remove = table_remove.remove
    ui_get = ui
    ui_get = ui_get.get
    ui_new_color_picker = ui
    ui_new_color_picker = ui_new_color_picker.new_color_picker
    ui_new_hotkey = ui
    ui_new_hotkey = ui_new_hotkey.new_hotkey
    ui_new_label = ui
    ui_new_label = ui_new_label.new_label
    ui_new_multiselect = ui
    ui_new_multiselect = ui_new_multiselect.new_multiselect
    ui_reference = ui
    ui_reference = ui_reference.reference
    ui_set = ui
    ui_set = ui_set.set
    ui_set_callback = ui
    ui_set_callback = ui_set_callback.set_callback
    ui_set_visible = ui
    ui_set_visible = ui_set_visible.set_visible
    type_alias = get_value_type
    ui_new_slider = ui
    ui_new_slider = ui_new_slider.new_slider
    native_controls = {
    }
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "Anti-aimbot angles"
    player_records = "Enabled"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.enabled = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "Anti-aimbot angles"
    player_records = "pitch"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.pitch = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "Anti-aimbot angles"
    player_records = "Yaw base"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.yawbase = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "anti-aimbot angles"
    player_records = "Fake yaw limit"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.fakeyawlimit = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "anti-aimbot angles"
    player_records = "Freestanding body yaw"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.fsbodyyaw = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "Anti-aimbot angles"
    player_records = "Edge yaw"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.edgeyaw = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "MISC"
    anti_aim_state = "Settings"
    player_records = "sv_maxusrcmdprocessticks"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.maxprocticks = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "RAGE"
    anti_aim_state = "Other"
    player_records = "Duck peek assist"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.fakeduck = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "RAGE"
    anti_aim_state = "Aimbot"
    player_records = "Force safe point"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.safepoint = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "RAGE"
    anti_aim_state = "Other"
    player_records = "Force body aim"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.forcebaim = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "PLAYERS"
    anti_aim_state = "Players"
    player_records = "Player list"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.player_list = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "PLAYERS"
    anti_aim_state = "Players"
    player_records = "Reset all"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.reset_all = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "PLAYERS"
    anti_aim_state = "Adjustments"
    player_records = "Apply to all"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.apply_all = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "Config"
    anti_aim_state = "Presets"
    player_records = "Load"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.load_cfg = set_native_ui_visible
    set_native_ui_visible = ui_reference
    script_controls = "AA"
    anti_aim_state = "Fake lag"
    player_records = "Limit"
    set_native_ui_visible = set_native_ui_visible(script_controls, anti_aim_state, player_records)
    native_controls.fl_limit = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Anti-aimbot angles"
    contains_value = "Yaw"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.yaw = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "RAGE"
    player_records = "Other"
    contains_value = "Quick peek assist"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.quickpeek = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Anti-aimbot angles"
    contains_value = "Yaw jitter"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.yawjitter = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Anti-aimbot angles"
    contains_value = "Body yaw"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.bodyyaw = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Anti-aimbot angles"
    contains_value = "Freestanding"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.freestand = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Other"
    contains_value = "On shot anti-aim"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.os = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Other"
    contains_value = "Slow motion"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.slow = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "RAGE"
    player_records = "Other"
    contains_value = "Double tap"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.dt = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls = ui_reference
    anti_aim_state = "AA"
    player_records = "Fake lag"
    contains_value = "Enabled"
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = script_controls(anti_aim_state, player_records, contains_value)
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.fakelag = set_native_ui_visible
    set_native_ui_visible = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        if A0_2 == nil then
            A0_2 = true
        end
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.pitch
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.yawbase
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.yaw
        L2_2 = L2_2[1]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.yaw
        L2_2 = L2_2[2]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.yawjitter
        L2_2 = L2_2[1]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.yawjitter
        L2_2 = L2_2[2]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.bodyyaw
        L2_2 = L2_2[1]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.bodyyaw
        L2_2 = L2_2[2]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.fakeyawlimit
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.fsbodyyaw
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.edgeyaw
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.freestand
        L2_2 = L2_2[1]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
        L1_2 = ui_set_visible
        L2_2 = native_controls
        L2_2 = L2_2.freestand
        L2_2 = L2_2[2]
        L3_2 = A0_2
        L1_2(L2_2, L3_2)
    end
    script_controls = set_native_ui_visible
    anti_aim_state = false
    script_controls(anti_aim_state)
    script_controls = {
    }
    anti_aim_state = {
    }
    anti_aim_state.Standing = "Reversed Freestanding"
    anti_aim_state.Moving = "Reversed Freestanding"
    anti_aim_state["Slow walk"] = "Reversed Freestanding"
    anti_aim_state["In air"] = "Reversed Freestanding"
    anti_aim_state["On E"] = "Freestanding"
    anti_aim_state.Crouched = "Reversed  Freestanding"
    anti_aim_state["Standing 2"] = "Reversed Freestanding"
    script_controls.b = anti_aim_state
    script_controls["Detect missed angle"] = false
    script_controls["Anti-resolver on X shot"] = "-"
    script_controls["Anti-resolver shot amount"] = 0
    anti_aim_state = ui_new_label
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "----------------------------------------------------"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.w = anti_aim_state
    anti_aim_state = ui_new_label
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "+                 LIVE [Dec. 14, 2021]"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.ww = anti_aim_state
    anti_aim_state = ui_new_label
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "----------------------------------------------------"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.www = anti_aim_state
    anti_aim_state = ui_new_multiselect
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Anti-aim settings"
    normalize_yaw = {
    }
    yaw_between_points = "Manual AA"
    signed_coordinate_delta = "Custom Legit AA"
    target_info = "Jitter when not networked"
    signed_line_distance = "Freestanding"
    target_record_info = "Edge yaw"
    pose_desync_side = "Keybind indicator"
    update_shot_history = "Name indicator"
    angles_to_direction = "Status Indicator"
    classify_movement = "Legacy arrows"
    vector_yaw = "Legacy OG Circle"
    scale_factor = "Adaptive clantag"
    normalize_yaw[1] = yaw_between_points
    normalize_yaw[2] = signed_coordinate_delta
    normalize_yaw[3] = target_info
    normalize_yaw[4] = signed_line_distance
    normalize_yaw[5] = target_record_info
    normalize_yaw[6] = pose_desync_side
    normalize_yaw[7] = update_shot_history
    normalize_yaw[8] = angles_to_direction
    normalize_yaw[9] = classify_movement
    normalize_yaw[10] = vector_yaw
    normalize_yaw[11] = scale_factor
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates, normalize_yaw)
    script_controls.s = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-Aimbot angles"
    head_coordinates = "Legit AA on key"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.la = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Manual left\010Manual Prediction"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.ml = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Manual right\010Manual Prediction"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.mr = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Manual forwards\010Manual Prediction"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.mf = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Freestanding\010Manual Prediction"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.fs = anti_aim_state
    anti_aim_state = ui_new_hotkey
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Edye yaw\010Manual Prediction"
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates)
    script_controls.ey = anti_aim_state
    anti_aim_state = ui_new_multiselect
    player_records = "AA"
    contains_value = "Anti-aimbot angles"
    head_coordinates = "Keybinds"
    normalize_yaw = {
    }
    yaw_between_points = "Double tap"
    signed_coordinate_delta = "Onshot Anti-Aim"
    target_info = "Force body aim"
    signed_line_distance = "Force safe point"
    target_record_info = "Quick peek"
    pose_desync_side = "Edge yaw"
    update_shot_history = "Freestanding"
    normalize_yaw[1] = yaw_between_points
    normalize_yaw[2] = signed_coordinate_delta
    normalize_yaw[3] = target_info
    normalize_yaw[4] = signed_line_distance
    normalize_yaw[5] = target_record_info
    normalize_yaw[6] = pose_desync_side
    normalize_yaw[7] = update_shot_history
    anti_aim_state = anti_aim_state(player_records, contains_value, head_coordinates, normalize_yaw)
    script_controls.k = anti_aim_state
    anti_aim_state = {
    }
    player_records = ui_new_label
    contains_value = "AA"
    head_coordinates = "Anti-aimbot angles"
    normalize_yaw = "Main color"
    player_records = player_records(contains_value, head_coordinates, normalize_yaw)
    contains_value = ui_new_color_picker
    head_coordinates = "AA"
    normalize_yaw = "Anti-aimbot angles"
    yaw_between_points = "Main colorpicker"
    contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = contains_value(head_coordinates, normalize_yaw, yaw_between_points)
    anti_aim_state[1] = player_records
    anti_aim_state[2] = contains_value
    anti_aim_state[3] = head_coordinates
    anti_aim_state[4] = normalize_yaw
    anti_aim_state[5] = yaw_between_points
    anti_aim_state[6] = signed_coordinate_delta
    anti_aim_state[7] = target_info
    anti_aim_state[8] = signed_line_distance
    anti_aim_state[9] = target_record_info
    anti_aim_state[10] = pose_desync_side
    anti_aim_state[11] = update_shot_history
    anti_aim_state[12] = angles_to_direction
    anti_aim_state[13] = classify_movement
    anti_aim_state[14] = vector_yaw
    anti_aim_state[15] = scale_factor
    anti_aim_state[16] = draw_circle_indicator
    anti_aim_state[17] = estimate_damage_at_offsets
    anti_aim_state[18] = select_nearest_player
    anti_aim_state[19] = is_valid_player
    anti_aim_state[20] = L93_1
    anti_aim_state[21] = L94_1
    anti_aim_state[22] = update_target_anti_aim
    anti_aim_state[23] = reset_player_state
    anti_aim_state[24] = handle_use_key
    anti_aim_state[25] = L98_1
    anti_aim_state[26] = update_manual_and_freestanding
    anti_aim_state[27] = point_on_circle
    anti_aim_state[28] = draw_indicator_triangle
    anti_aim_state[29] = reset_clan_tag
    anti_aim_state[30] = apply_body_yaw
    anti_aim_state[31] = on_bullet_impact
    anti_aim_state[32] = on_player_hurt
    anti_aim_state[33] = on_player_spawn
    anti_aim_state[34] = L107_1
    anti_aim_state[35] = L108_1
    anti_aim_state[36] = L109_1
    anti_aim_state[37] = L110_1
    anti_aim_state[38] = L111_1
    anti_aim_state[39] = clear_clan_tag
    anti_aim_state[40] = draw_indicators
    anti_aim_state[41] = update_ui_visibility
    anti_aim_state[42] = whitelisted
    anti_aim_state[43] = panorama_api
    anti_aim_state[44] = register_events_if_whitelisted
    anti_aim_state[45] = request_whitelist
    anti_aim_state[46] = fake_yaw_limit
    anti_aim_state[47] = screen_dimensions
    anti_aim_state[48] = screen_center
    anti_aim_state[49] = draw_branding
    anti_aim_state[50] = L123_1
    anti_aim_state[51] = L124_1
    anti_aim_state[52] = L125_1
    anti_aim_state[53] = L126_1
    anti_aim_state[54] = L127_1
    anti_aim_state[55] = L128_1
    anti_aim_state[56] = L129_1
    anti_aim_state[57] = L130_1
    anti_aim_state[58] = L131_1
    anti_aim_state[59] = L132_1
    anti_aim_state[60] = L133_1
    anti_aim_state[61] = L134_1
    anti_aim_state[62] = L135_1
    script_controls.clr = anti_aim_state
    anti_aim_state = {
    }
    player_records = ui_new_label
    contains_value = "AA"
    head_coordinates = "Anti-aimbot angles"
    normalize_yaw = "Accent color"
    player_records = player_records(contains_value, head_coordinates, normalize_yaw)
    contains_value = ui_new_color_picker
    head_coordinates = "AA"
    normalize_yaw = "Anti-aimbot angles"
    yaw_between_points = "Accent colorpicker"
    contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = contains_value(head_coordinates, normalize_yaw, yaw_between_points)
    anti_aim_state[1] = player_records
    anti_aim_state[2] = contains_value
    anti_aim_state[3] = head_coordinates
    anti_aim_state[4] = normalize_yaw
    anti_aim_state[5] = yaw_between_points
    anti_aim_state[6] = signed_coordinate_delta
    anti_aim_state[7] = target_info
    anti_aim_state[8] = signed_line_distance
    anti_aim_state[9] = target_record_info
    anti_aim_state[10] = pose_desync_side
    anti_aim_state[11] = update_shot_history
    anti_aim_state[12] = angles_to_direction
    anti_aim_state[13] = classify_movement
    anti_aim_state[14] = vector_yaw
    anti_aim_state[15] = scale_factor
    anti_aim_state[16] = draw_circle_indicator
    anti_aim_state[17] = estimate_damage_at_offsets
    anti_aim_state[18] = select_nearest_player
    anti_aim_state[19] = is_valid_player
    anti_aim_state[20] = L93_1
    anti_aim_state[21] = L94_1
    anti_aim_state[22] = update_target_anti_aim
    anti_aim_state[23] = reset_player_state
    anti_aim_state[24] = handle_use_key
    anti_aim_state[25] = L98_1
    anti_aim_state[26] = update_manual_and_freestanding
    anti_aim_state[27] = point_on_circle
    anti_aim_state[28] = draw_indicator_triangle
    anti_aim_state[29] = reset_clan_tag
    anti_aim_state[30] = apply_body_yaw
    anti_aim_state[31] = on_bullet_impact
    anti_aim_state[32] = on_player_hurt
    anti_aim_state[33] = on_player_spawn
    anti_aim_state[34] = L107_1
    anti_aim_state[35] = L108_1
    anti_aim_state[36] = L109_1
    anti_aim_state[37] = L110_1
    anti_aim_state[38] = L111_1
    anti_aim_state[39] = clear_clan_tag
    anti_aim_state[40] = draw_indicators
    anti_aim_state[41] = update_ui_visibility
    anti_aim_state[42] = whitelisted
    anti_aim_state[43] = panorama_api
    anti_aim_state[44] = register_events_if_whitelisted
    anti_aim_state[45] = request_whitelist
    anti_aim_state[46] = fake_yaw_limit
    anti_aim_state[47] = screen_dimensions
    anti_aim_state[48] = screen_center
    anti_aim_state[49] = draw_branding
    anti_aim_state[50] = L123_1
    anti_aim_state[51] = L124_1
    anti_aim_state[52] = L125_1
    anti_aim_state[53] = L126_1
    anti_aim_state[54] = L127_1
    anti_aim_state[55] = L128_1
    anti_aim_state[56] = L129_1
    anti_aim_state[57] = L130_1
    anti_aim_state[58] = L131_1
    anti_aim_state[59] = L132_1
    anti_aim_state[60] = L133_1
    anti_aim_state[61] = L134_1
    anti_aim_state[62] = L135_1
    script_controls.clr2 = anti_aim_state
    anti_aim_state = {
    }
    anti_aim_state.aa = 1
    player_records = {
    }
    contains_value = "Standing"
    head_coordinates = "Moving"
    normalize_yaw = "Slow walk"
    yaw_between_points = "In air"
    signed_coordinate_delta = "On E"
    target_info = "Crouched"
    signed_line_distance = "Standing 2"
    player_records[1] = contains_value
    player_records[2] = head_coordinates
    player_records[3] = normalize_yaw
    player_records[4] = yaw_between_points
    player_records[5] = signed_coordinate_delta
    player_records[6] = target_info
    player_records[7] = signed_line_distance
    anti_aim_state.s_i = player_records
    player_records = {
    }
    contains_value = 0
    head_coordinates = 0
    normalize_yaw = 0
    player_records[1] = contains_value
    player_records[2] = head_coordinates
    player_records[3] = normalize_yaw
    anti_aim_state.l_s = player_records
    player_records = {
    }
    anti_aim_state.rec = player_records
    anti_aim_state.desync = 0
    anti_aim_state.holding_e = false
    anti_aim_state.target = 0
    player_records = {
    }
    player_records.manual = 0
    player_records.fs = false
    player_records.edge = false
    player_records.time = 0
    anti_aim_state.dir = player_records
    player_records = {
    }
    player_records.manual = 0
    player_records.fs = false
    player_records.edge = false
    player_records.time = 0
    anti_aim_state.stored_dir = player_records
    anti_aim_state.old_dsy = true
    player_records = {
    }
    contains_value = "CWorld"
    head_coordinates = "CCSPlayer"
    normalize_yaw = "CFuncBrush"
    player_records[1] = contains_value
    player_records[2] = head_coordinates
    player_records[3] = normalize_yaw
    anti_aim_state.classnames = player_records
    player_records = {
    }
    contains_value = "knife"
    head_coordinates = "hegrenade"
    normalize_yaw = "inferno"
    yaw_between_points = "flashbang"
    signed_coordinate_delta = "decoy"
    target_info = "smokegrenade"
    signed_line_distance = "taser"
    player_records[1] = contains_value
    player_records[2] = head_coordinates
    player_records[3] = normalize_yaw
    player_records[4] = yaw_between_points
    player_records[5] = signed_coordinate_delta
    player_records[6] = target_info
    player_records[7] = signed_line_distance
    anti_aim_state.nonweapons = player_records
    player_records = {
    }
    contains_value = 1
    head_coordinates = 64
    normalize_yaw = 1
    for yaw_between_points = contains_value, head_coordinates, normalize_yaw do
        signed_coordinate_delta = {
        }
        target_info = {
        }
        signed_coordinate_delta.s = target_info
        target_info = {
        }
        signed_coordinate_delta.h = target_info
        signed_coordinate_delta.m = 0
        target_info = 0
        signed_coordinate_delta.r = target_info
        target_info = "d"
        signed_line_distance = 0
        signed_coordinate_delta[target_info] = signed_line_distance
        target_info = "l"
        signed_line_distance = 0
        signed_coordinate_delta[target_info] = signed_line_distance
        player_records[yaw_between_points] = signed_coordinate_delta
    end
    contains_value = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2
        if A0_2 == nil then
            L2_2 = false
            return L2_2
        end
        L2_2 = type_alias
        L3_2 = A0_2
        L2_2 = L2_2(L3_2)
        if L2_2 == "number" then
            L2_2 = ui_get
            L3_2 = A0_2
            L2_2 = L2_2(L3_2)
            A0_2 = L2_2
        end
        L2_2 = 0
        L3_2 = #A0_2
        L4_2 = 1
        for L5_2 = L2_2, L3_2, L4_2 do
            L6_2 = A0_2[L5_2]
            if L6_2 == A1_2 then
                L6_2 = true
                return L6_2
            end
        end
        L2_2 = false
        return L2_2
    end
    head_coordinates = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L1_2 = hitbox_position
        L2_2 = A0_2
        L3_2 = 0
        L1_2, L2_2, L3_2 = L1_2(L2_2, L3_2)
        L4_2 = get_prop
        L5_2 = A0_2
        L6_2 = "m_vecOrigin"
        L4_2, L5_2, L6_2 = L4_2(L5_2, L6_2)
        L7_2 = L4_2
        L8_2 = L5_2
        L9_2 = L3_2
        return L7_2, L8_2, L9_2
    end
    normalize_yaw = function(A0_2, ...)
        local L1_2, L2_2
        while 180 < A0_2 do
            A0_2 = A0_2 - 360
        end
        while A0_2 < -180 do
            A0_2 = A0_2 + 360
        end
        return A0_2
    end
    yaw_between_points = function(A0_2, A1_2, A2_2, A3_2, ...)
        local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L4_2 = A1_2 - A3_2
        L5_2 = A0_2 - A2_2
        L6_2 = math_atan
        L7_2 = L4_2 / L5_2
        L6_2 = L6_2(L7_2)
        L7_2 = normalize_yaw
        L8_2 = L6_2 * 180
        L9_2 = math
        L9_2 = L9_2.pi
        L8_2 = L8_2 / L9_2
        L7_2 = L7_2(L8_2)
        L6_2 = L7_2
        if 0 <= L5_2 then
            L7_2 = normalize_yaw
            L8_2 = L6_2 + 180
            L7_2 = L7_2(L8_2)
            L6_2 = L7_2
        end
        return L6_2
    end
    signed_coordinate_delta = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2
        if A2_2 == nil then
            A2_2 = false
        end
        if A2_2 then
            L3_2 = {
            }
            L4_2 = A1_2[1]
            L5_2 = A1_2[2]
            L6_2 = A0_2[3]
            L3_2[1] = L4_2
            L3_2[2] = L5_2
            L3_2[3] = L6_2
            A1_2 = L3_2
        end
        L3_2 = A0_2[1]
        L4_2 = A1_2[1]
        L3_2 = L3_2 - L4_2
        L4_2 = A0_2[2]
        L5_2 = A1_2[2]
        L4_2 = L4_2 - L5_2
        L3_2 = L3_2 + L4_2
        L4_2 = A0_2[3]
        L5_2 = A1_2[3]
        L4_2 = L4_2 - L5_2
        L3_2 = L3_2 + L4_2
        if L3_2 < 0 then
            L3_2 = L3_2 * 0.75
        end
        return L3_2
    end
    target_info = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
        L2_2 = head_coordinates
        L3_2 = A0_2
        L2_2, L3_2, L4_2 = L2_2(L3_2)
        L5_2 = head_coordinates
        L6_2 = get_local_player
        local returned_41_27 = __dec14_pack_results(L6_2())
        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = unpack(returned_41_27, 1, returned_41_27.n)
        L5_2, L6_2, L7_2 = L5_2(unpack(returned_41_27, 1, returned_41_27.n))
        L8_2 = {
        }
        L9_2 = L5_2
        L10_2 = L6_2
        L11_2 = L7_2
        L8_2[1] = L9_2
        L8_2[2] = L10_2
        L8_2[3] = L11_2
        L9_2 = {
        }
        L10_2 = L2_2
        L11_2 = L3_2
        L12_2 = L4_2
        L9_2[1] = L10_2
        L9_2[2] = L11_2
        L9_2[3] = L12_2
        L10_2 = {
        }
        L11_2 = A1_2.x
        L12_2 = A1_2.y
        L13_2 = A1_2.z
        L10_2[1] = L11_2
        L10_2[2] = L12_2
        L10_2[3] = L13_2
        L11_2 = {
        }
        L12_2 = L10_2[1]
        L13_2 = L9_2[1]
        L12_2 = L12_2 - L13_2
        L13_2 = L10_2[2]
        L14_2 = L9_2[2]
        L13_2 = L13_2 - L14_2
        L14_2 = L10_2[3]
        L15_2 = L9_2[3]
        L14_2 = L14_2 - L15_2
        L11_2[1] = L12_2
        L11_2[2] = L13_2
        L11_2[3] = L14_2
        L12_2 = math_sqrt
        L13_2 = L11_2[1]
        L13_2 = L13_2 ^ 2
        L14_2 = L11_2[2]
        L14_2 = L14_2 ^ 2
        L13_2 = L13_2 + L14_2
        L14_2 = L11_2[3]
        L14_2 = L14_2 ^ 2
        L13_2 = L13_2 + L14_2
        L12_2 = L12_2(L13_2)
        L13_2 = {
        }
        L14_2 = L11_2[1]
        L14_2 = L14_2 / L12_2
        L15_2 = L11_2[2]
        L15_2 = L15_2 / L12_2
        L16_2 = L11_2[3]
        L16_2 = L16_2 / L12_2
        L13_2[1] = L14_2
        L13_2[2] = L15_2
        L13_2[3] = L16_2
        L14_2 = {
        }
        L15_2 = L8_2[1]
        L16_2 = L9_2[1]
        L15_2 = L15_2 - L16_2
        L16_2 = L8_2[2]
        L17_2 = L9_2[2]
        L16_2 = L16_2 - L17_2
        L17_2 = L8_2[3]
        L18_2 = L9_2[3]
        L17_2 = L17_2 - L18_2
        L14_2[1] = L15_2
        L14_2[2] = L16_2
        L14_2[3] = L17_2
        L15_2 = L13_2[1]
        L16_2 = L14_2[1]
        L15_2 = L15_2 * L16_2
        L16_2 = L13_2[2]
        L17_2 = L14_2[2]
        L16_2 = L16_2 * L17_2
        L15_2 = L15_2 + L16_2
        L16_2 = L13_2[3]
        L17_2 = L14_2[3]
        L16_2 = L16_2 * L17_2
        L15_2 = L15_2 + L16_2
        L16_2 = anti_aim_state
        L17_2 = {
        }
        L18_2 = L9_2[1]
        L19_2 = L13_2[1]
        L19_2 = L15_2 * L19_2
        L18_2 = L18_2 + L19_2
        L19_2 = L9_2[2]
        L20_2 = L13_2[2]
        L20_2 = L15_2 * L20_2
        L19_2 = L19_2 + L20_2
        L20_2 = L9_2[3]
        L21_2 = L13_2[3]
        L21_2 = L15_2 * L21_2
        L20_2 = L20_2 + L21_2
        L17_2[1] = L18_2
        L17_2[2] = L19_2
        L17_2[3] = L20_2
        L16_2.ls = L17_2
        L16_2 = signed_coordinate_delta
        L17_2 = anti_aim_state
        L17_2 = L17_2.ls
        L18_2 = L8_2
        L19_2 = true
        return L16_2(L17_2, L18_2, L19_2)
    end
    signed_line_distance = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
        L3_2 = head_coordinates
        L4_2 = A0_2
        L3_2, L4_2, L5_2 = L3_2(L4_2)
        L6_2 = head_coordinates
        L7_2 = A1_2
        L6_2, L7_2, L8_2 = L6_2(L7_2)
        L9_2 = A2_2.y
        L9_2 = L9_2 - L4_2
        L9_2 = L9_2 * L6_2
        L10_2 = A2_2.x
        L10_2 = L10_2 - L3_2
        L10_2 = L10_2 * L7_2
        L9_2 = L9_2 - L10_2
        L10_2 = A2_2.x
        L10_2 = L10_2 * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = A2_2.y
        L10_2 = L10_2 * L3_2
        L9_2 = L9_2 - L10_2
        L10_2 = math_sqrt
        L11_2 = A2_2.y
        L11_2 = L11_2 - L4_2
        L11_2 = L11_2 ^ 2
        L12_2 = A2_2.x
        L12_2 = L12_2 - L3_2
        L12_2 = L12_2 ^ 2
        L11_2 = L11_2 + L12_2
        L10_2 = L10_2(L11_2)
        L9_2 = L9_2 / L10_2
        return L9_2
    end
    target_record_info = function(A0_2, A1_2, A2_2, A3_2, A4_2, ...)
        local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
        L5_2 = {
        }
        L6_2 = head_coordinates
        L7_2 = A3_2
        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = L6_2(L7_2)
        L5_2[1] = L6_2
        L5_2[2] = L7_2
        L5_2[3] = L8_2
        L5_2[4] = L9_2
        L5_2[5] = L10_2
        L5_2[6] = L11_2
        L5_2[7] = L12_2
        L5_2[8] = L13_2
        L6_2 = {
        }
        L7_2 = get_prop
        L8_2 = A3_2
        L9_2 = "m_vecOrigin"
        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = L7_2(L8_2, L9_2)
        L6_2[1] = L7_2
        L6_2[2] = L8_2
        L6_2[3] = L9_2
        L6_2[4] = L10_2
        L6_2[5] = L11_2
        L6_2[6] = L12_2
        L6_2[7] = L13_2
        L7_2 = A1_2[3]
        L8_2 = L5_2[3]
        L8_2 = L8_2 + 10
        if not (L7_2 > L8_2) then
            L7_2 = A1_2[3]
            L8_2 = L6_2[3]
            if not (L7_2 < L8_2) then
                L7_2 = math_abs
                L8_2 = signed_line_distance
                L9_2 = A2_2
                L10_2 = A3_2
                L11_2 = A4_2
                local returned_43_28 = __dec14_pack_results(L8_2(L9_2, L10_2, L11_2))
                L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = unpack(returned_43_28, 1, returned_43_28.n)
                L7_2 = L7_2(unpack(returned_43_28, 1, returned_43_28.n))
                if 300 < L7_2 then
                    L7_2 = false
                    return L7_2
                else
                    L7_2 = math_abs
                    L8_2 = A0_2
                    L7_2 = L7_2(L8_2)
                    if L7_2 < 30 then
                        L7_2 = true
                        return L7_2
                    else
                        L7_2 = get_prop
                        L8_2 = get_player_resource
                        L8_2 = L8_2()
                        L9_2 = "m_iPing"
                        L10_2 = A2_2
                        L7_2 = L7_2(L8_2, L9_2, L10_2)
                        L8_2 = tickinterval
                        L8_2 = L8_2()
                        L8_2 = L7_2 * L8_2
                        L8_2 = 14 - L8_2
                        L9_2 = anti_aim_state
                        L9_2 = L9_2.rec
                        L9_2 = #L9_2
                        if L8_2 <= L9_2 then
                            L9_2 = anti_aim_state
                            L9_2 = L9_2.rec
                            L9_2 = L9_2[L8_2]
                            if L9_2 == nil then
                                L10_2 = false
                                return L10_2
                            else
                                L10_2 = signed_coordinate_delta
                                L11_2 = L9_2
                                L12_2 = L5_2
                                L13_2 = true
                                L10_2 = L10_2(L11_2, L12_2, L13_2)
                                if A0_2 < 0 and A0_2 > L10_2 or A0_2 < L10_2 then
                                    L11_2 = math_abs
                                    L12_2 = A0_2
                                    L11_2 = L11_2(L12_2)
                                    L12_2 = math_abs
                                    L13_2 = L10_2
                                    L12_2 = L12_2(L13_2)
                                    if L11_2 < L12_2 then
                                        L11_2 = true
                                    else
                                        L11_2 = math_abs
                                        L12_2 = A0_2
                                        L11_2 = L11_2(L12_2)
                                        L12_2 = math_abs
                                        L13_2 = L10_2
                                        L12_2 = L12_2(L13_2)
                                        if not (L11_2 > L12_2) then
                                            L11_2 = false
                                        else
                                            L11_2 = true
                                        end
                                    end
                                else
                                    L11_2 = math_abs
                                    L12_2 = A0_2
                                    L11_2 = L11_2(L12_2)
                                    L12_2 = math_abs
                                    L13_2 = L10_2
                                    L12_2 = L12_2(L13_2)
                                    if not (L11_2 > L12_2) then
                                        L11_2 = false
                                    else
                                        L11_2 = true
                                    end
                                end
                                return L11_2
                            end
                        else
                            L9_2 = false
                            return L9_2
                        end
                    end
                end
            else
                L7_2 = false
                do
                    return L7_2
                end
            end
        else
            L7_2 = false
            do
                return L7_2
            end
        end
    end
    pose_desync_side = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2
        L1_2 = anti_aim_state
        L1_2 = L1_2.desync
        if L1_2 == 0 then
            L1_2 = 0
            return L1_2
        else
            L1_2 = get_prop
            L2_2 = A0_2
            L3_2 = "m_flPoseParameter"
            L4_2 = 11
            L1_2 = L1_2(L2_2, L3_2, L4_2)
            L1_2 = L1_2 * 120
            L1_2 = L1_2 - 60
            if L1_2 < 0 then
                L2_2 = anti_aim_state
                L2_2 = L2_2.desync
                if not (L2_2) then
                    L2_2 = anti_aim_state
                    L2_2 = L2_2.desync
                    L2_2 = -L2_2
                end
            else
                L2_2 = anti_aim_state
                L2_2 = L2_2.desync
                L2_2 = -L2_2
            end
            return L2_2
        end
    end
    update_shot_history = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L1_2 = 1
        L2_2 = 64
        L3_2 = 1
        for L4_2 = L1_2, L2_2, L3_2 do
            L5_2 = player_records
            L5_2 = L5_2[L4_2]
            L5_2 = L5_2.r
            L6_2 = player_records
            L6_2 = L6_2[L4_2]
            L6_2 = L6_2.s
            L6_2 = #L6_2
            if L5_2 < L6_2 then
                L5_2 = player_records
                L5_2 = L5_2[L4_2]
                L5_2 = L5_2.h
                L5_2 = #L5_2
                if 0 < L5_2 then
                    L5_2 = player_records
                    L5_2 = L5_2[L4_2]
                    L5_2 = L5_2.s
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    L6_2 = L6_2.s
                    L6_2 = #L6_2
                    L5_2 = L5_2[L6_2]
                    L5_2 = L5_2.t
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    L6_2 = L6_2.h
                    L7_2 = player_records
                    L7_2 = L7_2[L4_2]
                    L7_2 = L7_2.h
                    L7_2 = #L7_2
                    L6_2 = L6_2[L7_2]
                    L6_2 = L6_2.t
                    if L5_2 == L6_2 then
                        L5_2 = true
                    else
                        L5_2 = false
                    end
                else
                    L5_2 = false
                end
                if L5_2 then
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    L6_2 = L6_2.h
                    L7_2 = player_records
                    L7_2 = L7_2[L4_2]
                    L7_2 = L7_2.h
                    L7_2 = #L7_2
                    L6_2 = L6_2[L7_2]
                    L6_2 = L6_2.v
                    if not (L6_2 ~= A0_2) then
                        L6_2 = player_records
                        L6_2 = L6_2[L4_2]
                        if L5_2 then
                            L7_2 = player_records
                            L7_2 = L7_2[L4_2]
                            L7_2 = L7_2.h
                            L8_2 = player_records
                            L8_2 = L8_2[L4_2]
                            L8_2 = L8_2.h
                            L8_2 = #L8_2
                            L7_2 = L7_2[L8_2]
                            L7_2 = L7_2.h
                            if L7_2 == 1 then
                                L7_2 = pose_desync_side
                                L8_2 = A0_2
                                L7_2 = L7_2(L8_2)
                                if not (L7_2) then
                                    L7_2 = 0
                                end
                            else
                                L7_2 = 0
                            end
                        else
                            L7_2 = 0
                        end
                        L6_2.l = L7_2
                        if not L5_2 then
                            L6_2 = player_records
                            L6_2 = L6_2[L4_2]
                            L6_2 = L6_2.m
                            L7_2 = script_controls
                            L7_2 = L7_2["Anti-resolver shot amount"]
                            if L6_2 < L7_2 then
                                L6_2 = player_records
                                L6_2 = L6_2[L4_2]
                                L7_2 = player_records
                                L7_2 = L7_2[L4_2]
                                L7_2 = L7_2.m
                                L7_2 = L7_2 + 1
                                L6_2.m = L7_2
                            end
                        else
                            L6_2 = player_records
                            L6_2 = L6_2[L4_2]
                            L6_2.m = 0
                        end
                        if L5_2 then
                            L6_2 = player_records
                            L6_2 = L6_2[L4_2]
                            L6_2 = L6_2.s
                            L7_2 = player_records
                            L7_2 = L7_2[L4_2]
                            L7_2 = L7_2.s
                            L7_2 = #L7_2
                            L6_2 = L6_2[L7_2]
                            L7_2 = pose_desync_side
                            L8_2 = A0_2
                            L7_2 = L7_2(L8_2)
                            L6_2.d = L7_2
                        end
                        L6_2 = player_records
                        L6_2 = L6_2[L4_2]
                        L7_2 = player_records
                        L7_2 = L7_2[L4_2]
                        L7_2 = L7_2.s
                        L8_2 = player_records
                        L8_2 = L8_2[L4_2]
                        L8_2 = L8_2.s
                        L8_2 = #L8_2
                        L7_2 = L7_2[L8_2]
                        L7_2 = L7_2.d
                        L6_2.d = L7_2
                        L6_2 = anti_aim_state
                        L6_2.target = L4_2
                    end
                else
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    if L5_2 then
                        L7_2 = player_records
                        L7_2 = L7_2[L4_2]
                        L7_2 = L7_2.h
                        L8_2 = player_records
                        L8_2 = L8_2[L4_2]
                        L8_2 = L8_2.h
                        L8_2 = #L8_2
                        L7_2 = L7_2[L8_2]
                        L7_2 = L7_2.h
                        if L7_2 == 1 then
                            L7_2 = pose_desync_side
                            L8_2 = A0_2
                            L7_2 = L7_2(L8_2)
                            if not (L7_2) then
                                L7_2 = 0
                            end
                        else
                            L7_2 = 0
                        end
                    else
                        L7_2 = 0
                    end
                    L6_2.l = L7_2
                    if not L5_2 then
                        L6_2 = player_records
                        L6_2 = L6_2[L4_2]
                        L6_2 = L6_2.m
                        L7_2 = script_controls
                        L7_2 = L7_2["Anti-resolver shot amount"]
                        if L6_2 < L7_2 then
                            L6_2 = player_records
                            L6_2 = L6_2[L4_2]
                            L7_2 = player_records
                            L7_2 = L7_2[L4_2]
                            L7_2 = L7_2.m
                            L7_2 = L7_2 + 1
                            L6_2.m = L7_2
                        end
                    else
                        L6_2 = player_records
                        L6_2 = L6_2[L4_2]
                        L6_2.m = 0
                    end
                    if L5_2 then
                        L6_2 = player_records
                        L6_2 = L6_2[L4_2]
                        L6_2 = L6_2.s
                        L7_2 = player_records
                        L7_2 = L7_2[L4_2]
                        L7_2 = L7_2.s
                        L7_2 = #L7_2
                        L6_2 = L6_2[L7_2]
                        L7_2 = pose_desync_side
                        L8_2 = A0_2
                        L7_2 = L7_2(L8_2)
                        L6_2.d = L7_2
                    end
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    L7_2 = player_records
                    L7_2 = L7_2[L4_2]
                    L7_2 = L7_2.s
                    L8_2 = player_records
                    L8_2 = L8_2[L4_2]
                    L8_2 = L8_2.s
                    L8_2 = #L8_2
                    L7_2 = L7_2[L8_2]
                    L7_2 = L7_2.d
                    L6_2.d = L7_2
                    L6_2 = anti_aim_state
                    L6_2.target = L4_2
                end
                L6_2 = player_records
                L6_2 = L6_2[L4_2]
                L7_2 = player_records
                L7_2 = L7_2[L4_2]
                L7_2 = L7_2.s
                L7_2 = #L7_2
                L6_2.r = L7_2
            else
                L5_2 = player_records
                L5_2 = L5_2[L4_2]
                L5_2 = L5_2.r
                L6_2 = player_records
                L6_2 = L6_2[L4_2]
                L6_2 = L6_2.s
                L6_2 = #L6_2
                if L5_2 > L6_2 then
                    L5_2 = player_records
                    L5_2 = L5_2[L4_2]
                    L6_2 = player_records
                    L6_2 = L6_2[L4_2]
                    L6_2 = L6_2.s
                    L6_2 = #L6_2
                    L5_2.r = L6_2
                end
            end
        end
    end
    angles_to_direction = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = math_sin
        L3_2 = math_rad
        L4_2 = A1_2
        local returned_46_29 = __dec14_pack_results(L3_2(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_29, 1, returned_46_29.n)
        L2_2 = L2_2(unpack(returned_46_29, 1, returned_46_29.n))
        L3_2 = math_cos
        L4_2 = math_rad
        L5_2 = A1_2
        local returned_46_30 = __dec14_pack_results(L4_2(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_30, 1, returned_46_30.n)
        L3_2 = L3_2(unpack(returned_46_30, 1, returned_46_30.n))
        L4_2 = math_sin
        L5_2 = math_rad
        L6_2 = A0_2
        local returned_46_31 = __dec14_pack_results(L5_2(L6_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_31, 1, returned_46_31.n)
        L4_2 = L4_2(unpack(returned_46_31, 1, returned_46_31.n))
        L5_2 = math_cos
        L6_2 = math_rad
        L7_2 = A0_2
        local returned_46_32 = __dec14_pack_results(L6_2(L7_2))
        L6_2, L7_2, L8_2 = unpack(returned_46_32, 1, returned_46_32.n)
        L5_2 = L5_2(unpack(returned_46_32, 1, returned_46_32.n))
        L6_2 = L5_2 * L3_2
        L7_2 = L5_2 * L2_2
        L8_2 = -L4_2
        return L6_2, L7_2, L8_2
    end
    classify_movement = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
        L2_2 = anti_aim_state
        L2_2 = L2_2.holding_e
        if L2_2 then
            L2_2 = anti_aim_state
            L2_2.aa = 5
            return 
        else
            L2_2 = ui_get
            L3_2 = native_controls
            L3_2 = L3_2.slow
            L3_2 = L3_2[1]
            L2_2 = L2_2(L3_2)
            if L2_2 then
                L2_2 = ui_get
                L3_2 = native_controls
                L3_2 = L3_2.slow
                L3_2 = L3_2[2]
                L2_2 = L2_2(L3_2)
            end
            if L2_2 then
                L3_2 = anti_aim_state
                L3_2.aa = 3
                return 
            else
                L3_2 = bit_band
                L4_2 = get_prop
                L5_2 = A0_2
                L6_2 = "m_fFlags"
                L4_2 = L4_2(L5_2, L6_2)
                L5_2 = 1
                L3_2 = L3_2(L4_2, L5_2)
                if L3_2 == 1 then
                    L3_2 = A1_2.in_jump
                    if L3_2 == 0 then
                        L3_2 = true
                    else
                        L3_2 = false
                    end
                else
                    L3_2 = false
                end
                if not L3_2 then
                    L4_2 = anti_aim_state
                    L4_2.aa = 4
                    return 
                else
                    L4_2 = entity
                    L4_2 = L4_2.get_prop
                    L5_2 = entity
                    L5_2 = L5_2.get_local_player
                    L5_2 = L5_2()
                    L6_2 = "m_iTeamNum"
                    L4_2 = L4_2(L5_2, L6_2)
                    L5_2 = entity
                    L5_2 = L5_2.get_prop
                    L6_2 = entity
                    L6_2 = L6_2.get_local_player
                    L6_2 = L6_2()
                    L7_2 = "m_flDuckAmount"
                    L5_2 = L5_2(L6_2, L7_2)
                    if not (0.7 < L5_2) then
                        L5_2 = false
                    else
                        L5_2 = true
                    end
                    if L4_2 == 3 and L5_2 then
                        L6_2 = anti_aim_state
                        L6_2.aa = 6
                        return 
                    else
                        L6_2 = entity
                        L6_2 = L6_2.get_player_weapon
                        L7_2 = entity
                        L7_2 = L7_2.get_local_player
                        local returned_47_33 = __dec14_pack_results(L7_2())
                        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_33, 1, returned_47_33.n)
                        L6_2 = L6_2(unpack(returned_47_33, 1, returned_47_33.n))
                        L7_2 = bit_band
                        L8_2 = get_prop
                        L9_2 = L6_2
                        L10_2 = "m_iItemDefinitionIndex"
                        L8_2 = L8_2(L9_2, L10_2)
                        L9_2 = 65535
                        L7_2 = L7_2(L8_2, L9_2)
                        L8_2 = get_prop
                        L9_2 = A0_2
                        L10_2 = "m_vecVelocity"
                        L8_2, L9_2, L10_2 = L8_2(L9_2, L10_2)
                        L11_2 = math_sqrt
                        L12_2 = L8_2 ^ 2
                        L13_2 = L9_2 ^ 2
                        L12_2 = L12_2 + L13_2
                        L11_2 = L11_2(L12_2)
                        if 2 < L11_2 then
                            L11_2 = anti_aim_state
                            L11_2.aa = 2
                            return 
                        else
                            L11_2 = entity
                            L11_2 = L11_2.get_players
                            L12_2 = true
                            L11_2 = L11_2(L12_2)
                            L12_2 = nil
                            L13_2 = client
                            L13_2 = L13_2.camera_angles
                            L13_2, L14_2, L15_2 = L13_2()
                            L16_2 = Vector3
                            L17_2 = L13_2
                            L18_2 = L14_2
                            L19_2 = 0
                            L16_2 = L16_2(L17_2, L18_2, L19_2)
                            L17_2 = 180
                            L18_2 = Vector3
                            L19_2 = get_prop
                            L20_2 = A0_2
                            L21_2 = "m_vecAbsOrigin"
                            local returned_47_34 = __dec14_pack_results(L19_2(L20_2, L21_2))
                            L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_34, 1, returned_47_34.n)
                            L18_2 = L18_2(unpack(returned_47_34, 1, returned_47_34.n))
                            L19_2 = L18_2.x
                            if L19_2 ~= nil then
                                L19_2 = 1
                                L20_2 = #L11_2
                                L21_2 = 1
                                for L22_2 = L19_2, L20_2, L21_2 do
                                    L23_2 = L11_2[L22_2]
                                    L24_2 = is_enemy
                                    L25_2 = L23_2
                                    L24_2 = L24_2(L25_2)
                                    if L24_2 then
                                        L24_2 = is_alive
                                        L25_2 = L23_2
                                        L24_2 = L24_2(L25_2)
                                        if L24_2 then
                                            L24_2 = is_dormant
                                            L25_2 = L23_2
                                            L24_2 = L24_2(L25_2)
                                            if not L24_2 then
                                                L24_2 = Vector3
                                                L25_2 = entity
                                                L25_2 = L25_2.get_prop
                                                L26_2 = L23_2
                                                L27_2 = "m_vecOrigin"
                                                local returned_47_35 = __dec14_pack_results(L25_2(L26_2, L27_2))
                                                L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_35, 1, returned_47_35.n)
                                                L24_2 = L24_2(unpack(returned_47_35, 1, returned_47_35.n))
                                                L25_2 = get_FOV
                                                L26_2 = L16_2
                                                L27_2 = L18_2
                                                L28_2 = L24_2
                                                L25_2 = L25_2(L26_2, L27_2, L28_2)
                                                if L17_2 > L25_2 then
                                                    L17_2 = L25_2
                                                    L12_2 = L23_2
                                                end
                                            end
                                        end
                                    end
                                end
                                L19_2 = get_prop
                                L20_2 = A0_2
                                L21_2 = "m_vecOrigin"
                                L19_2, L20_2, L21_2 = L19_2(L20_2, L21_2)
                                L22_2 = get_prop
                                L23_2 = L12_2
                                L24_2 = "m_vecOrigin"
                                L22_2, L23_2, L24_2 = L22_2(L23_2, L24_2)
                                if L24_2 == nil or L21_2 == nil then
                                    return 
                                else
                                    if L4_2 == 2 then
                                        L25_2 = math_sqrt
                                        L26_2 = L8_2 ^ 2
                                        L27_2 = L9_2 ^ 2
                                        L26_2 = L26_2 + L27_2
                                        L25_2 = L25_2(L26_2)
                                        if L25_2 < 2 and (L7_2 == 40 or L7_2 == 38 or L7_2 == 11 or L7_2 == 9) then
                                            L25_2 = L21_2 - L24_2
                                            if 0 <= L25_2 then
                                                L25_2 = anti_aim_state
                                                L25_2 = L25_2.dir
                                                L25_2 = L25_2.manual
                                                if L25_2 ~= 90 then
                                                    L25_2 = anti_aim_state
                                                    L25_2 = L25_2.dir
                                                    L25_2 = L25_2.manual
                                                    if L25_2 ~= -90 then
                                                        L25_2 = anti_aim_state
                                                        L25_2.aa = 7
                                                        return 
                                                    else
                                                        L19_2 = math_sqrt
                                                        L20_2 = L8_2 ^ 2
                                                        L21_2 = L9_2 ^ 2
                                                        L20_2 = L20_2 + L21_2
                                                        L19_2 = L19_2(L20_2)
                                                        if L19_2 < 2 then
                                                            L19_2 = anti_aim_state
                                                            L19_2.aa = 1
                                                            return 
                                                        end
                                                    end
                                                else
                                                    L19_2 = math_sqrt
                                                    L20_2 = L8_2 ^ 2
                                                    L21_2 = L9_2 ^ 2
                                                    L20_2 = L20_2 + L21_2
                                                    L19_2 = L19_2(L20_2)
                                                    if L19_2 < 2 then
                                                        L19_2 = anti_aim_state
                                                        L19_2.aa = 1
                                                        return 
                                                    end
                                                end
                                            else
                                                L19_2 = math_sqrt
                                                L20_2 = L8_2 ^ 2
                                                L21_2 = L9_2 ^ 2
                                                L20_2 = L20_2 + L21_2
                                                L19_2 = L19_2(L20_2)
                                                if L19_2 < 2 then
                                                    L19_2 = anti_aim_state
                                                    L19_2.aa = 1
                                                    return 
                                                end
                                            end
                                        else
                                            L19_2 = math_sqrt
                                            L20_2 = L8_2 ^ 2
                                            L21_2 = L9_2 ^ 2
                                            L20_2 = L20_2 + L21_2
                                            L19_2 = L19_2(L20_2)
                                            if L19_2 < 2 then
                                                L19_2 = anti_aim_state
                                                L19_2.aa = 1
                                                return 
                                            end
                                        end
                                    else
                                        L19_2 = math_sqrt
                                        L20_2 = L8_2 ^ 2
                                        L21_2 = L9_2 ^ 2
                                        L20_2 = L20_2 + L21_2
                                        L19_2 = L19_2(L20_2)
                                        if L19_2 < 2 then
                                            L19_2 = anti_aim_state
                                            L19_2.aa = 1
                                            return 
                                        end
                                    end
                                end
                            else
                                L19_2 = math_sqrt
                                L20_2 = L8_2 ^ 2
                                L21_2 = L9_2 ^ 2
                                L20_2 = L20_2 + L21_2
                                L19_2 = L19_2(L20_2)
                                if L19_2 < 2 then
                                    L19_2 = anti_aim_state
                                    L19_2.aa = 1
                                    return 
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    vector_yaw = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2
        if A0_2 == 0 and A1_2 == 0 then
            L2_2 = 0
            return L2_2
        end
        L2_2 = math_deg
        L3_2 = math_atan2
        L4_2 = A1_2
        L5_2 = A0_2
        local returned_48_36 = __dec14_pack_results(L3_2(L4_2, L5_2))
        L3_2, L4_2, L5_2 = unpack(returned_48_36, 1, returned_48_36.n)
        return L2_2(unpack(returned_48_36, 1, returned_48_36.n))
    end
    scale_factor = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
        L1_2 = 155 * A0_2
        L1_2 = 255 - L1_2
        L2_2 = 240 * A0_2
        L3_2 = 0
        L4_2 = L1_2
        L5_2 = L2_2
        L6_2 = L3_2
        return L4_2, L5_2, L6_2
    end
    draw_circle_indicator = function(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, ...)
        local L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
        L7_2 = renderer
        L7_2 = L7_2.circle_outline
        L8_2 = A0_2
        L9_2 = A1_2
        L10_2 = 0
        L11_2 = 0
        L12_2 = 0
        L13_2 = 155
        L14_2 = 10
        L15_2 = 0
        L16_2 = 1
        L17_2 = 6
        L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
        L7_2 = renderer
        L7_2 = L7_2.circle_outline
        L8_2 = A0_2
        L9_2 = A1_2
        L10_2 = A2_2
        L11_2 = A3_2
        L12_2 = A4_2
        L13_2 = A5_2
        L14_2 = 9
        if 0 < A6_2 then
            L15_2 = 90
            if not (L15_2) then
                L15_2 = -90
            end
        else
            L15_2 = -90
        end
        L16_2 = 0.5
        L17_2 = 4
        L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
    end
    estimate_damage_at_offsets = function(A0_2, A1_2, A2_2, A3_2, A4_2, ...)
        local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
        L5_2 = {
        }
        L6_2 = {
        }
        L7_2 = {
        }
        L8_2 = head_coordinates
        L9_2 = A1_2
        L8_2, L9_2, L10_2 = L8_2(L9_2)
        L7_2[0] = L10_2
        L6_2[0] = L9_2
        L5_2[0] = L8_2
        L8_2 = L5_2[0]
        L8_2 = L8_2 + 40
        L9_2 = L6_2[0]
        L10_2 = L7_2[0]
        L7_2[1] = L10_2
        L6_2[1] = L9_2
        L5_2[1] = L8_2
        L8_2 = L5_2[0]
        L9_2 = L6_2[0]
        L9_2 = L9_2 + 40
        L10_2 = L7_2[0]
        L7_2[2] = L10_2
        L6_2[2] = L9_2
        L5_2[2] = L8_2
        L8_2 = L5_2[0]
        L8_2 = L8_2 - 40
        L9_2 = L6_2[0]
        L10_2 = L7_2[0]
        L7_2[3] = L10_2
        L6_2[3] = L9_2
        L5_2[3] = L8_2
        L8_2 = L5_2[0]
        L9_2 = L6_2[0]
        L9_2 = L9_2 - 40
        L10_2 = L7_2[0]
        L7_2[4] = L10_2
        L6_2[4] = L9_2
        L5_2[4] = L8_2
        L8_2 = L5_2[0]
        L9_2 = L6_2[0]
        L10_2 = L7_2[0]
        L10_2 = L10_2 + 40
        L7_2[5] = L10_2
        L6_2[5] = L9_2
        L5_2[5] = L8_2
        L8_2 = 0
        L9_2 = nil
        L10_2 = 0
        L11_2 = 5
        L12_2 = 1
        for L13_2 = L10_2, L11_2, L12_2 do
            if L9_2 == 0 or L9_2 == nil then
                L14_2 = trace_bullet
                L15_2 = A1_2
                L16_2 = L5_2[L13_2]
                L17_2 = L6_2[L13_2]
                L18_2 = L7_2[L13_2]
                L19_2 = A2_2
                L20_2 = A3_2
                L21_2 = A4_2
                L14_2, L15_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
                L9_2 = L15_2
                L8_2 = L14_2
            end
        end
        L10_2 = scale_damage
        L11_2 = A1_2
        L12_2 = 1
        if L8_2 == nil then
            L13_2 = scale_damage
            L14_2 = A1_2
            L15_2 = 2
            L16_2 = L9_2
            L13_2 = L13_2(L14_2, L15_2, L16_2)
            if not (L13_2) then
                L13_2 = L9_2
            end
        else
            L13_2 = L9_2
        end
        return L10_2(L11_2, L12_2, L13_2)
    end
    select_nearest_player = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
        L2_2 = get_players
        L3_2 = true
        L2_2 = L2_2(L3_2)
        L3_2 = #L2_2
        if L3_2 == 0 then
            L3_2 = 0
            return L3_2
        end
        L3_2 = 0
        L4_2 = 180
        L5_2 = 1
        L6_2 = #L2_2
        L7_2 = 1
        for L8_2 = L5_2, L6_2, L7_2 do
            L9_2 = get_prop
            L10_2 = L2_2[L8_2]
            L11_2 = "m_vecOrigin"
            L9_2, L10_2, L11_2 = L9_2(L10_2, L11_2)
            L12_2 = math_abs
            L13_2 = normalize_yaw
            L14_2 = vector_yaw
            L15_2 = A0_2[1]
            L15_2 = L15_2 - L9_2
            L16_2 = A0_2[2]
            L16_2 = L16_2 - L10_2
            L14_2 = L14_2(L15_2, L16_2)
            L15_2 = A1_2[2]
            L14_2 = L14_2 - L15_2
            L14_2 = L14_2 + 180
            local returned_52_37 = __dec14_pack_results(L13_2(L14_2))
            L13_2, L14_2, L15_2, L16_2 = unpack(returned_52_37, 1, returned_52_37.n)
            L12_2 = L12_2(unpack(returned_52_37, 1, returned_52_37.n))
            if L4_2 > L12_2 then
                L4_2 = L12_2
                L3_2 = L2_2[L8_2]
            end
        end
        return L3_2
    end
    is_valid_player = function(A0_2, ...)
        local L1_2, L2_2
        if A0_2 == 0 then
            L1_2 = false
            return L1_2
        end
        L1_2 = is_alive
        L2_2 = A0_2
        L1_2 = L1_2(L2_2)
        if not L1_2 then
            L1_2 = false
            return L1_2
        end
        L1_2 = is_dormant
        L2_2 = A0_2
        L1_2 = L1_2(L2_2)
        if L1_2 then
            L1_2 = false
            return L1_2
        end
        L1_2 = true
        return L1_2
    end
    L93_1 = false
    L94_1 = false
    update_target_anti_aim = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
        L1_2 = get_local_player
        L1_2 = L1_2()
        L2_2 = {
        }
        L3_2 = head_coordinates
        L4_2 = L1_2
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L3_2(L4_2)
        L2_2[1] = L3_2
        L2_2[2] = L4_2
        L2_2[3] = L5_2
        L2_2[4] = L6_2
        L2_2[5] = L7_2
        L2_2[6] = L8_2
        L2_2[7] = L9_2
        L2_2[8] = L10_2
        L2_2[9] = L11_2
        L2_2[10] = L12_2
        L2_2[11] = L13_2
        L2_2[12] = L14_2
        L2_2[13] = L15_2
        L2_2[14] = L16_2
        L2_2[15] = L17_2
        L2_2[16] = L18_2
        L2_2[17] = L19_2
        L2_2[18] = L20_2
        L2_2[19] = L21_2
        L2_2[20] = L22_2
        L2_2[21] = L23_2
        L2_2[22] = L24_2
        L2_2[23] = L25_2
        L2_2[24] = L26_2
        L2_2[25] = L27_2
        L2_2[26] = L28_2
        L3_2 = {
        }
        L4_2 = camera_angles
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L4_2()
        L3_2[1] = L4_2
        L3_2[2] = L5_2
        L3_2[3] = L6_2
        L3_2[4] = L7_2
        L3_2[5] = L8_2
        L3_2[6] = L9_2
        L3_2[7] = L10_2
        L3_2[8] = L11_2
        L3_2[9] = L12_2
        L3_2[10] = L13_2
        L3_2[11] = L14_2
        L3_2[12] = L15_2
        L3_2[13] = L16_2
        L3_2[14] = L17_2
        L3_2[15] = L18_2
        L3_2[16] = L19_2
        L3_2[17] = L20_2
        L3_2[18] = L21_2
        L3_2[19] = L22_2
        L3_2[20] = L23_2
        L3_2[21] = L24_2
        L3_2[22] = L25_2
        L3_2[23] = L26_2
        L3_2[24] = L27_2
        L3_2[25] = L28_2
        L4_2 = anti_aim_state
        L5_2 = is_valid_player
        L6_2 = anti_aim_state
        L6_2 = L6_2.target
        L5_2 = L5_2(L6_2)
        if L5_2 then
            L5_2 = anti_aim_state
            L5_2 = L5_2.target
            if not (L5_2) then
                L5_2 = select_nearest_player
                L6_2 = L2_2
                L7_2 = L3_2
                L5_2 = L5_2(L6_2, L7_2)
            end
        else
            L5_2 = select_nearest_player
            L6_2 = L2_2
            L7_2 = L3_2
            L5_2 = L5_2(L6_2, L7_2)
        end
        L4_2.target = L5_2
        L4_2 = anti_aim_state
        L4_2 = L4_2.target
        if L4_2 ~= 0 then
            L4_2 = player_records
            L5_2 = anti_aim_state
            L5_2 = L5_2.target
            L4_2 = L4_2[L5_2]
            L4_2 = L4_2.d
            if L4_2 == 0 then
                L4_2 = player_records
                L5_2 = anti_aim_state
                L5_2 = L5_2.target
                L4_2 = L4_2[L5_2]
                L4_2 = L4_2.l
                if L4_2 ~= 0 then
                    L4_2 = anti_aim_state
                    L5_2 = player_records
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.target
                    L5_2 = L5_2[L6_2]
                    L5_2 = L5_2.l
                    L4_2.desync = L5_2
                else
                    L4_2 = script_controls
                    L4_2 = L4_2.b
                    L5_2 = anti_aim_state
                    L5_2 = L5_2.s_i
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.aa
                    L5_2 = L5_2[L6_2]
                    L4_2 = L4_2[L5_2]
                    if L4_2 == "Off" then
                        L4_2 = anti_aim_state
                        L4_2.desync = 0
                    else
                        L4_2 = script_controls
                        L4_2 = L4_2.b
                        L5_2 = anti_aim_state
                        L5_2 = L5_2.s_i
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.aa
                        L5_2 = L5_2[L6_2]
                        L4_2 = L4_2[L5_2]
                        if L4_2 == "Jitter" then
                            L4_2 = anti_aim_state
                            L4_2.desync = 180
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.desync
                            if L4_2 ~= 0 then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.desync
                                if not (L4_2 ~= 180) then
                                    L4_2 = anti_aim_state
                                    L4_2.desync = 95
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2.desync = 95
                            end
                            L4_2 = {
                            }
                            L5_2 = head_coordinates
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.target
                            L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L5_2(L6_2)
                            L4_2[1] = L5_2
                            L4_2[2] = L6_2
                            L4_2[3] = L7_2
                            L4_2[4] = L8_2
                            L4_2[5] = L9_2
                            L4_2[6] = L10_2
                            L4_2[7] = L11_2
                            L4_2[8] = L12_2
                            L4_2[9] = L13_2
                            L4_2[10] = L14_2
                            L4_2[11] = L15_2
                            L4_2[12] = L16_2
                            L4_2[13] = L17_2
                            L4_2[14] = L18_2
                            L4_2[15] = L19_2
                            L4_2[16] = L20_2
                            L4_2[17] = L21_2
                            L4_2[18] = L22_2
                            L4_2[19] = L23_2
                            L4_2[20] = L24_2
                            L4_2[21] = L25_2
                            L4_2[22] = L26_2
                            L4_2[23] = L27_2
                            L4_2[24] = L28_2
                            L5_2 = yaw_between_points
                            L6_2 = L2_2[1]
                            L7_2 = L2_2[2]
                            L8_2 = L4_2[1]
                            L9_2 = L4_2[2]
                            L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2)
                            L6_2 = angles_to_direction
                            L7_2 = 0
                            L8_2 = L5_2 - 90
                            L6_2, L7_2, L8_2 = L6_2(L7_2, L8_2)
                            L9_2 = L2_2[1]
                            L10_2 = L6_2 * 10
                            L9_2 = L9_2 + L10_2
                            L10_2 = L2_2[2]
                            L11_2 = L7_2 * 10
                            L10_2 = L10_2 + L11_2
                            L11_2 = angles_to_direction
                            L12_2 = 0
                            L13_2 = L5_2 + 90
                            L11_2, L12_2, L13_2 = L11_2(L12_2, L13_2)
                            L14_2 = L2_2[1]
                            L15_2 = L11_2 * 10
                            L14_2 = L14_2 + L15_2
                            L15_2 = L2_2[2]
                            L16_2 = L12_2 * 10
                            L15_2 = L15_2 + L16_2
                            L16_2 = L2_2[1]
                            L17_2 = L6_2 * 80
                            L16_2 = L16_2 + L17_2
                            L17_2 = L2_2[2]
                            L18_2 = L7_2 * 80
                            L17_2 = L17_2 + L18_2
                            L18_2 = L2_2[1]
                            L19_2 = L11_2 * 80
                            L18_2 = L18_2 + L19_2
                            L19_2 = L2_2[2]
                            L20_2 = L12_2 * 80
                            L19_2 = L19_2 + L20_2
                            L20_2 = estimate_damage_at_offsets
                            L21_2 = L1_2
                            L22_2 = anti_aim_state
                            L22_2 = L22_2.target
                            L23_2 = L9_2
                            L24_2 = L10_2
                            L25_2 = L2_2[3]
                            L20_2 = L20_2(L21_2, L22_2, L23_2, L24_2, L25_2)
                            L21_2 = estimate_damage_at_offsets
                            L22_2 = L1_2
                            L23_2 = anti_aim_state
                            L23_2 = L23_2.target
                            L24_2 = L14_2
                            L25_2 = L15_2
                            L26_2 = L2_2[3]
                            L21_2 = L21_2(L22_2, L23_2, L24_2, L25_2, L26_2)
                            L22_2 = estimate_damage_at_offsets
                            L23_2 = L1_2
                            L24_2 = anti_aim_state
                            L24_2 = L24_2.target
                            L25_2 = L16_2
                            L26_2 = L17_2
                            L27_2 = L2_2[3]
                            L22_2 = L22_2(L23_2, L24_2, L25_2, L26_2, L27_2)
                            L23_2 = estimate_damage_at_offsets
                            L24_2 = L1_2
                            L25_2 = anti_aim_state
                            L25_2 = L25_2.target
                            L26_2 = L18_2
                            L27_2 = L19_2
                            L28_2 = L2_2[3]
                            L23_2 = L23_2(L24_2, L25_2, L26_2, L27_2, L28_2)
                            L24_2 = ""
                            if L22_2 < L23_2 or L20_2 < L21_2 or L21_2 < L23_2 then
                                L24_2 = "left"
                                L25_2 = anti_aim_state
                                L25_2 = L25_2.aa
                                if L25_2 == 1 then
                                    if L24_2 == "left" then
                                        L25_2 = anti_aim_state
                                        L26_2 = script_controls
                                        L26_2 = L26_2.b
                                        L27_2 = anti_aim_state
                                        L27_2 = L27_2.s_i
                                        L28_2 = anti_aim_state
                                        L28_2 = L28_2.aa
                                        L27_2 = L27_2[L28_2]
                                        L26_2 = L26_2[L27_2]
                                        if L26_2 == "Freestanding" then
                                            L26_2 = -95
                                            if not (L26_2) then
                                                L26_2 = 95
                                            end
                                        else
                                            L26_2 = 95
                                        end
                                        L25_2.desync = L26_2
                                    else
                                        if not (L24_2 ~= "right") then
                                            L25_2 = anti_aim_state
                                            L26_2 = script_controls
                                            L26_2 = L26_2.b
                                            L27_2 = anti_aim_state
                                            L27_2 = L27_2.s_i
                                            L28_2 = anti_aim_state
                                            L28_2 = L28_2.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                L26_2 = 95
                                                if not (L26_2) then
                                                    L26_2 = -95
                                                end
                                            else
                                                L26_2 = -95
                                            end
                                            L25_2.desync = L26_2
                                        end
                                    end
                                else
                                    L25_2 = anti_aim_state
                                    L25_2 = L25_2.aa
                                    if L25_2 == 2 then
                                        if L24_2 == "left" then
                                            L25_2 = anti_aim_state
                                            L26_2 = script_controls
                                            L26_2 = L26_2.b
                                            L27_2 = anti_aim_state
                                            L27_2 = L27_2.s_i
                                            L28_2 = anti_aim_state
                                            L28_2 = L28_2.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                L26_2 = L93_1
                                                if L26_2 then
                                                    L26_2 = -95
                                                    if not (L26_2) then
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                            else
                                                L26_2 = 95
                                            end
                                            L25_2.desync = L26_2
                                        else
                                            if not (L24_2 ~= "right") then
                                                L25_2 = anti_aim_state
                                                L26_2 = script_controls
                                                L26_2 = L26_2.b
                                                L27_2 = anti_aim_state
                                                L27_2 = L27_2.s_i
                                                L28_2 = anti_aim_state
                                                L28_2 = L28_2.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = L93_1
                                                    if L26_2 then
                                                        L26_2 = 95
                                                        if not (L26_2) then
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                else
                                                    L26_2 = -95
                                                end
                                                L25_2.desync = L26_2
                                            end
                                        end
                                    else
                                        L25_2 = anti_aim_state
                                        L25_2 = L25_2.aa
                                        if L25_2 == 3 then
                                            L25_2 = anti_aim_state
                                            L25_2.desync = 180
                                        else
                                            L25_2 = anti_aim_state
                                            L25_2 = L25_2.aa
                                            if L25_2 == 4 then
                                                if L24_2 == "left" then
                                                    L25_2 = anti_aim_state
                                                    L26_2 = script_controls
                                                    L26_2 = L26_2.b
                                                    L27_2 = anti_aim_state
                                                    L27_2 = L27_2.s_i
                                                    L28_2 = anti_aim_state
                                                    L28_2 = L28_2.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        L26_2 = L93_1
                                                        if L26_2 then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                    L25_2.desync = L26_2
                                                else
                                                    if not (L24_2 ~= "right") then
                                                        L25_2 = anti_aim_state
                                                        L26_2 = script_controls
                                                        L26_2 = L26_2.b
                                                        L27_2 = anti_aim_state
                                                        L27_2 = L27_2.s_i
                                                        L28_2 = anti_aim_state
                                                        L28_2 = L28_2.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = L93_1
                                                            if L26_2 then
                                                                L26_2 = 95
                                                                if not (L26_2) then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                        L25_2.desync = L26_2
                                                    end
                                                end
                                            else
                                                L25_2 = anti_aim_state
                                                L25_2 = L25_2.aa
                                                if L25_2 == 5 then
                                                    if L24_2 == "left" then
                                                        L25_2 = anti_aim_state
                                                        L26_2 = script_controls
                                                        L26_2 = L26_2.b
                                                        L27_2 = anti_aim_state
                                                        L27_2 = L27_2.s_i
                                                        L28_2 = anti_aim_state
                                                        L28_2 = L28_2.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                        L25_2.desync = L26_2
                                                    else
                                                        if not (L24_2 ~= "right") then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = 95
                                                                if not (L26_2) then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                            L25_2.desync = L26_2
                                                        end
                                                    end
                                                else
                                                    L25_2 = anti_aim_state
                                                    L25_2 = L25_2.aa
                                                    if L25_2 == 6 then
                                                        L25_2 = anti_aim_state
                                                        L26_2 = script_controls
                                                        L26_2 = L26_2.b
                                                        L27_2 = anti_aim_state
                                                        L27_2 = L27_2.s_i
                                                        L28_2 = anti_aim_state
                                                        L28_2 = L28_2.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = client
                                                            L26_2 = L26_2.random_int
                                                            L27_2 = -60
                                                            L28_2 = -20
                                                            L26_2 = L26_2(L27_2, L28_2)
                                                            if not (L26_2) then
                                                                L26_2 = client
                                                                L26_2 = L26_2.random_int
                                                                L27_2 = 20
                                                                L28_2 = 60
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                            end
                                                        else
                                                            L26_2 = client
                                                            L26_2 = L26_2.random_int
                                                            L27_2 = 20
                                                            L28_2 = 60
                                                            L26_2 = L26_2(L27_2, L28_2)
                                                        end
                                                        L25_2.desync = L26_2
                                                    else
                                                        L25_2 = anti_aim_state
                                                        L25_2 = L25_2.aa
                                                        if not (L25_2 ~= 7) then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = client
                                                                L26_2 = L26_2.random_int
                                                                L27_2 = -60
                                                                L28_2 = -40
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                                if not (L26_2) then
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = 40
                                                                    L28_2 = 60
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                end
                                                            else
                                                                L26_2 = client
                                                                L26_2 = L26_2.random_int
                                                                L27_2 = 40
                                                                L28_2 = 60
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                            end
                                                            L25_2.desync = L26_2
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            else
                                if L22_2 > L23_2 or L20_2 > L21_2 or L20_2 < L22_2 then
                                    L24_2 = "right"
                                    L25_2 = anti_aim_state
                                    L25_2 = L25_2.aa
                                    if L25_2 == 1 then
                                        if L24_2 == "left" then
                                            L25_2 = anti_aim_state
                                            L26_2 = script_controls
                                            L26_2 = L26_2.b
                                            L27_2 = anti_aim_state
                                            L27_2 = L27_2.s_i
                                            L28_2 = anti_aim_state
                                            L28_2 = L28_2.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                L26_2 = -95
                                                if not (L26_2) then
                                                    L26_2 = 95
                                                end
                                            else
                                                L26_2 = 95
                                            end
                                            L25_2.desync = L26_2
                                        else
                                            if not (L24_2 ~= "right") then
                                                L25_2 = anti_aim_state
                                                L26_2 = script_controls
                                                L26_2 = L26_2.b
                                                L27_2 = anti_aim_state
                                                L27_2 = L27_2.s_i
                                                L28_2 = anti_aim_state
                                                L28_2 = L28_2.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = 95
                                                    if not (L26_2) then
                                                        L26_2 = -95
                                                    end
                                                else
                                                    L26_2 = -95
                                                end
                                                L25_2.desync = L26_2
                                            end
                                        end
                                    else
                                        L25_2 = anti_aim_state
                                        L25_2 = L25_2.aa
                                        if L25_2 == 2 then
                                            if L24_2 == "left" then
                                                L25_2 = anti_aim_state
                                                L26_2 = script_controls
                                                L26_2 = L26_2.b
                                                L27_2 = anti_aim_state
                                                L27_2 = L27_2.s_i
                                                L28_2 = anti_aim_state
                                                L28_2 = L28_2.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = L93_1
                                                    if L26_2 then
                                                        L26_2 = -95
                                                        if not (L26_2) then
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                                L25_2.desync = L26_2
                                            else
                                                if not (L24_2 ~= "right") then
                                                    L25_2 = anti_aim_state
                                                    L26_2 = script_controls
                                                    L26_2 = L26_2.b
                                                    L27_2 = anti_aim_state
                                                    L27_2 = L27_2.s_i
                                                    L28_2 = anti_aim_state
                                                    L28_2 = L28_2.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        L26_2 = L93_1
                                                        if L26_2 then
                                                            L26_2 = 95
                                                            if not (L26_2) then
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                    L25_2.desync = L26_2
                                                end
                                            end
                                        else
                                            L25_2 = anti_aim_state
                                            L25_2 = L25_2.aa
                                            if L25_2 == 3 then
                                                L25_2 = anti_aim_state
                                                L25_2.desync = 180
                                            else
                                                L25_2 = anti_aim_state
                                                L25_2 = L25_2.aa
                                                if L25_2 == 4 then
                                                    if L24_2 == "left" then
                                                        L25_2 = anti_aim_state
                                                        L26_2 = script_controls
                                                        L26_2 = L26_2.b
                                                        L27_2 = anti_aim_state
                                                        L27_2 = L27_2.s_i
                                                        L28_2 = anti_aim_state
                                                        L28_2 = L28_2.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = L93_1
                                                            if L26_2 then
                                                                L26_2 = -95
                                                                if not (L26_2) then
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                        L25_2.desync = L26_2
                                                    else
                                                        if not (L24_2 ~= "right") then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = L93_1
                                                                if L26_2 then
                                                                    L26_2 = 95
                                                                    if not (L26_2) then
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                            L25_2.desync = L26_2
                                                        end
                                                    end
                                                else
                                                    L25_2 = anti_aim_state
                                                    L25_2 = L25_2.aa
                                                    if L25_2 == 5 then
                                                        if L24_2 == "left" then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = -95
                                                                if not (L26_2) then
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                            L25_2.desync = L26_2
                                                        else
                                                            if not (L24_2 ~= "right") then
                                                                L25_2 = anti_aim_state
                                                                L26_2 = script_controls
                                                                L26_2 = L26_2.b
                                                                L27_2 = anti_aim_state
                                                                L27_2 = L27_2.s_i
                                                                L28_2 = anti_aim_state
                                                                L28_2 = L28_2.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = 95
                                                                    if not (L26_2) then
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                                L25_2.desync = L26_2
                                                            end
                                                        end
                                                    else
                                                        L25_2 = anti_aim_state
                                                        L25_2 = L25_2.aa
                                                        if L25_2 == 6 then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = client
                                                                L26_2 = L26_2.random_int
                                                                L27_2 = -60
                                                                L28_2 = -20
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                                if not (L26_2) then
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = 20
                                                                    L28_2 = 60
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                end
                                                            else
                                                                L26_2 = client
                                                                L26_2 = L26_2.random_int
                                                                L27_2 = 20
                                                                L28_2 = 60
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                            end
                                                            L25_2.desync = L26_2
                                                        else
                                                            L25_2 = anti_aim_state
                                                            L25_2 = L25_2.aa
                                                            if not (L25_2 ~= 7) then
                                                                L25_2 = anti_aim_state
                                                                L26_2 = script_controls
                                                                L26_2 = L26_2.b
                                                                L27_2 = anti_aim_state
                                                                L27_2 = L27_2.s_i
                                                                L28_2 = anti_aim_state
                                                                L28_2 = L28_2.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = -60
                                                                    L28_2 = -40
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                    if not (L26_2) then
                                                                        L26_2 = client
                                                                        L26_2 = L26_2.random_int
                                                                        L27_2 = 40
                                                                        L28_2 = 60
                                                                        L26_2 = L26_2(L27_2, L28_2)
                                                                    end
                                                                else
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = 40
                                                                    L28_2 = 60
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                end
                                                                L25_2.desync = L26_2
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                else
                                    L25_2 = anti_aim_state
                                    L25_2 = L25_2.holding_e
                                    if not L25_2 then
                                        L25_2 = anti_aim_state
                                        L25_2.desync = 180
                                        return 
                                    else
                                        L25_2 = anti_aim_state
                                        L25_2 = L25_2.aa
                                        if L25_2 == 1 then
                                            if L24_2 == "left" then
                                                L25_2 = anti_aim_state
                                                L26_2 = script_controls
                                                L26_2 = L26_2.b
                                                L27_2 = anti_aim_state
                                                L27_2 = L27_2.s_i
                                                L28_2 = anti_aim_state
                                                L28_2 = L28_2.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = -95
                                                    if not (L26_2) then
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                                L25_2.desync = L26_2
                                            else
                                                if not (L24_2 ~= "right") then
                                                    L25_2 = anti_aim_state
                                                    L26_2 = script_controls
                                                    L26_2 = L26_2.b
                                                    L27_2 = anti_aim_state
                                                    L27_2 = L27_2.s_i
                                                    L28_2 = anti_aim_state
                                                    L28_2 = L28_2.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        L26_2 = 95
                                                        if not (L26_2) then
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                    L25_2.desync = L26_2
                                                end
                                            end
                                        else
                                            L25_2 = anti_aim_state
                                            L25_2 = L25_2.aa
                                            if L25_2 == 2 then
                                                if L24_2 == "left" then
                                                    L25_2 = anti_aim_state
                                                    L26_2 = script_controls
                                                    L26_2 = L26_2.b
                                                    L27_2 = anti_aim_state
                                                    L27_2 = L27_2.s_i
                                                    L28_2 = anti_aim_state
                                                    L28_2 = L28_2.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        L26_2 = L93_1
                                                        if L26_2 then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                    L25_2.desync = L26_2
                                                else
                                                    if not (L24_2 ~= "right") then
                                                        L25_2 = anti_aim_state
                                                        L26_2 = script_controls
                                                        L26_2 = L26_2.b
                                                        L27_2 = anti_aim_state
                                                        L27_2 = L27_2.s_i
                                                        L28_2 = anti_aim_state
                                                        L28_2 = L28_2.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = L93_1
                                                            if L26_2 then
                                                                L26_2 = 95
                                                                if not (L26_2) then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                        L25_2.desync = L26_2
                                                    end
                                                end
                                            else
                                                L25_2 = anti_aim_state
                                                L25_2 = L25_2.aa
                                                if L25_2 == 3 then
                                                    L25_2 = anti_aim_state
                                                    L25_2.desync = 180
                                                else
                                                    L25_2 = anti_aim_state
                                                    L25_2 = L25_2.aa
                                                    if L25_2 == 4 then
                                                        if L24_2 == "left" then
                                                            L25_2 = anti_aim_state
                                                            L26_2 = script_controls
                                                            L26_2 = L26_2.b
                                                            L27_2 = anti_aim_state
                                                            L27_2 = L27_2.s_i
                                                            L28_2 = anti_aim_state
                                                            L28_2 = L28_2.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = L93_1
                                                                if L26_2 then
                                                                    L26_2 = -95
                                                                    if not (L26_2) then
                                                                        L26_2 = 95
                                                                    end
                                                                else
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                            L25_2.desync = L26_2
                                                        else
                                                            if not (L24_2 ~= "right") then
                                                                L25_2 = anti_aim_state
                                                                L26_2 = script_controls
                                                                L26_2 = L26_2.b
                                                                L27_2 = anti_aim_state
                                                                L27_2 = L27_2.s_i
                                                                L28_2 = anti_aim_state
                                                                L28_2 = L28_2.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = L93_1
                                                                    if L26_2 then
                                                                        L26_2 = 95
                                                                        if not (L26_2) then
                                                                            L26_2 = -95
                                                                        end
                                                                    else
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                                L25_2.desync = L26_2
                                                            end
                                                        end
                                                    else
                                                        L25_2 = anti_aim_state
                                                        L25_2 = L25_2.aa
                                                        if L25_2 == 5 then
                                                            if L24_2 == "left" then
                                                                L25_2 = anti_aim_state
                                                                L26_2 = script_controls
                                                                L26_2 = L26_2.b
                                                                L27_2 = anti_aim_state
                                                                L27_2 = L27_2.s_i
                                                                L28_2 = anti_aim_state
                                                                L28_2 = L28_2.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = -95
                                                                    if not (L26_2) then
                                                                        L26_2 = 95
                                                                    end
                                                                else
                                                                    L26_2 = 95
                                                                end
                                                                L25_2.desync = L26_2
                                                            else
                                                                if not (L24_2 ~= "right") then
                                                                    L25_2 = anti_aim_state
                                                                    L26_2 = script_controls
                                                                    L26_2 = L26_2.b
                                                                    L27_2 = anti_aim_state
                                                                    L27_2 = L27_2.s_i
                                                                    L28_2 = anti_aim_state
                                                                    L28_2 = L28_2.aa
                                                                    L27_2 = L27_2[L28_2]
                                                                    L26_2 = L26_2[L27_2]
                                                                    if L26_2 == "Freestanding" then
                                                                        L26_2 = 95
                                                                        if not (L26_2) then
                                                                            L26_2 = -95
                                                                        end
                                                                    else
                                                                        L26_2 = -95
                                                                    end
                                                                    L25_2.desync = L26_2
                                                                end
                                                            end
                                                        else
                                                            L25_2 = anti_aim_state
                                                            L25_2 = L25_2.aa
                                                            if L25_2 == 6 then
                                                                L25_2 = anti_aim_state
                                                                L26_2 = script_controls
                                                                L26_2 = L26_2.b
                                                                L27_2 = anti_aim_state
                                                                L27_2 = L27_2.s_i
                                                                L28_2 = anti_aim_state
                                                                L28_2 = L28_2.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = -60
                                                                    L28_2 = -20
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                    if not (L26_2) then
                                                                        L26_2 = client
                                                                        L26_2 = L26_2.random_int
                                                                        L27_2 = 20
                                                                        L28_2 = 60
                                                                        L26_2 = L26_2(L27_2, L28_2)
                                                                    end
                                                                else
                                                                    L26_2 = client
                                                                    L26_2 = L26_2.random_int
                                                                    L27_2 = 20
                                                                    L28_2 = 60
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                end
                                                                L25_2.desync = L26_2
                                                            else
                                                                L25_2 = anti_aim_state
                                                                L25_2 = L25_2.aa
                                                                if not (L25_2 ~= 7) then
                                                                    L25_2 = anti_aim_state
                                                                    L26_2 = script_controls
                                                                    L26_2 = L26_2.b
                                                                    L27_2 = anti_aim_state
                                                                    L27_2 = L27_2.s_i
                                                                    L28_2 = anti_aim_state
                                                                    L28_2 = L28_2.aa
                                                                    L27_2 = L27_2[L28_2]
                                                                    L26_2 = L26_2[L27_2]
                                                                    if L26_2 == "Freestanding" then
                                                                        L26_2 = client
                                                                        L26_2 = L26_2.random_int
                                                                        L27_2 = -60
                                                                        L28_2 = -40
                                                                        L26_2 = L26_2(L27_2, L28_2)
                                                                        if not (L26_2) then
                                                                            L26_2 = client
                                                                            L26_2 = L26_2.random_int
                                                                            L27_2 = 40
                                                                            L28_2 = 60
                                                                            L26_2 = L26_2(L27_2, L28_2)
                                                                        end
                                                                    else
                                                                        L26_2 = client
                                                                        L26_2 = L26_2.random_int
                                                                        L27_2 = 40
                                                                        L28_2 = 60
                                                                        L26_2 = L26_2(L27_2, L28_2)
                                                                    end
                                                                    L25_2.desync = L26_2
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            else
                L4_2 = player_records
                L5_2 = anti_aim_state
                L5_2 = L5_2.target
                L4_2 = L4_2[L5_2]
                L4_2 = L4_2.m
                L5_2 = script_controls
                L5_2 = L5_2["Anti-resolver shot amount"]
                if L4_2 == L5_2 then
                    L4_2 = script_controls
                    L4_2 = L4_2["Anti-resolver on X shot"]
                    if L4_2 ~= "-" then
                        L4_2 = script_controls
                        L4_2 = L4_2["Anti-resolver on X shot"]
                        if L4_2 == "None" then
                            L4_2 = anti_aim_state
                            L4_2.desync = 0
                        else
                            L4_2 = script_controls
                            L4_2 = L4_2["Anti-resolver on X shot"]
                            if L4_2 == "Jitter" then
                                L4_2 = anti_aim_state
                                L4_2.desync = 180
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state
                    L5_2 = player_records
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.target
                    L5_2 = L5_2[L6_2]
                    L5_2 = L5_2.d
                    L4_2.desync = L5_2
                end
            end
        else
            L4_2 = script_controls
            L4_2 = L4_2.b
            L5_2 = anti_aim_state
            L5_2 = L5_2.s_i
            L6_2 = anti_aim_state
            L6_2 = L6_2.aa
            L5_2 = L5_2[L6_2]
            L4_2 = L4_2[L5_2]
            if L4_2 == "Off" then
                L4_2 = anti_aim_state
                L4_2.desync = 0
            else
                L4_2 = script_controls
                L4_2 = L4_2.b
                L5_2 = anti_aim_state
                L5_2 = L5_2.s_i
                L6_2 = anti_aim_state
                L6_2 = L6_2.aa
                L5_2 = L5_2[L6_2]
                L4_2 = L4_2[L5_2]
                if L4_2 == "Jitter" then
                    L4_2 = anti_aim_state
                    L4_2.desync = 180
                else
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.holding_e
                    if L4_2 then
                        L4_2 = anti_aim_state
                        L5_2 = anti_aim_state
                        L5_2 = L5_2.desync
                        if L5_2 ~= 0 then
                            L5_2 = anti_aim_state
                            L5_2 = L5_2.desync
                            if not (L5_2 ~= 180) then
                                L5_2 = 90
                            end
                        else
                            L5_2 = 90
                        end
                        if not L5_2 then
                            L5_2 = anti_aim_state
                            L5_2 = L5_2.desync
                        end
                        L4_2.desync = L5_2
                    else
                        L4_2 = anti_aim_state
                        L4_2.desync = 180
                    end
                end
            end
        end
    end
    reset_player_state = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        if A0_2 == nil then
            A0_2 = false
        end
        L1_2 = 1
        L2_2 = 64
        L3_2 = 1
        for L4_2 = L1_2, L2_2, L3_2 do
            L5_2 = player_records
            L5_2 = L5_2[L4_2]
            L5_2 = L5_2.d
            L6_2 = player_records
            L7_2 = {
            }
            L8_2 = {
            }
            L7_2.s = L8_2
            L8_2 = {
            }
            L7_2.h = L8_2
            L7_2.r = 0
            L7_2.d = 0
            L7_2.m = 0
            L8_2 = L5_2 or L8_2
            if not A0_2 or not L5_2 then
                L8_2 = 0
            end
            L7_2.l = L8_2
            L6_2[L4_2] = L7_2
        end
    end
    handle_use_key = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Custom Legit AA"
        L2_2 = L2_2(L3_2, L4_2)
        if L2_2 then
            L2_2 = key_state
            L3_2 = 69
            L2_2 = L2_2(L3_2)
            if L2_2 then
                return 
            else
                L2_2 = contains_value
                L3_2 = script_controls
                L3_2 = L3_2.s
                L4_2 = "Custom Legit AA"
                L2_2 = L2_2(L3_2, L4_2)
                if L2_2 then
                    L2_2 = ui_get
                    L3_2 = script_controls
                    L3_2 = L3_2.la
                    L2_2 = L2_2(L3_2)
                    if not (L2_2) then
                        L2_2 = key_state
                        L3_2 = 69
                        L2_2 = L2_2(L3_2)
                    end
                else
                    L2_2 = key_state
                    L3_2 = 69
                    L2_2 = L2_2(L3_2)
                end
                if L2_2 then
                    L2_2 = 100
                    L3_2 = get_all_entities
                    L4_2 = "CPlantedC4"
                    L3_2 = L3_2(L4_2)
                    L3_2 = L3_2[1]
                    if L3_2 ~= nil then
                        L4_2 = {
                        }
                        L5_2 = get_prop
                        L6_2 = L3_2
                        L7_2 = "m_vecOrigin"
                        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L5_2(L6_2, L7_2)
                        L4_2[1] = L5_2
                        L4_2[2] = L6_2
                        L4_2[3] = L7_2
                        L4_2[4] = L8_2
                        L4_2[5] = L9_2
                        L4_2[6] = L10_2
                        L4_2[7] = L11_2
                        L4_2[8] = L12_2
                        L4_2[9] = L13_2
                        L4_2[10] = L14_2
                        L4_2[11] = L15_2
                        L4_2[12] = L16_2
                        L4_2[13] = L17_2
                        L4_2[14] = L18_2
                        L4_2[15] = L19_2
                        L4_2[16] = L20_2
                        L4_2[17] = L21_2
                        L4_2[18] = L22_2
                        L4_2[19] = L23_2
                        L4_2[20] = L24_2
                        if L4_2 ~= nil then
                            L5_2 = {
                            }
                            L6_2 = get_prop
                            L7_2 = A0_2
                            L8_2 = "m_vecOrigin"
                            L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L6_2(L7_2, L8_2)
                            L5_2[1] = L6_2
                            L5_2[2] = L7_2
                            L5_2[3] = L8_2
                            L5_2[4] = L9_2
                            L5_2[5] = L10_2
                            L5_2[6] = L11_2
                            L5_2[7] = L12_2
                            L5_2[8] = L13_2
                            L5_2[9] = L14_2
                            L5_2[10] = L15_2
                            L5_2[11] = L16_2
                            L5_2[12] = L17_2
                            L5_2[13] = L18_2
                            L5_2[14] = L19_2
                            L5_2[15] = L20_2
                            L5_2[16] = L21_2
                            L5_2[17] = L22_2
                            L5_2[18] = L23_2
                            L5_2[19] = L24_2
                            L6_2 = math_abs
                            L7_2 = signed_coordinate_delta
                            L8_2 = L5_2
                            L9_2 = L4_2
                            local returned_56_38 = __dec14_pack_results(L7_2(L8_2, L9_2))
                            L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_38, 1, returned_56_38.n)
                            L6_2 = L6_2(unpack(returned_56_38, 1, returned_56_38.n))
                            L2_2 = L6_2
                        end
                    end
                    L4_2 = get_prop
                    L5_2 = A0_2
                    L6_2 = "m_iTeamNum"
                    L4_2 = L4_2(L5_2, L6_2)
                    if L4_2 ~= 3 or not (L2_2 < 62) then
                        L5_2 = false
                    else
                        L5_2 = true
                    end
                    L6_2 = eye_position
                    L6_2, L7_2, L8_2 = L6_2()
                    L9_2 = camera_angles
                    L9_2, L10_2 = L9_2()
                    L11_2 = math_sin
                    L12_2 = math_rad
                    L13_2 = L9_2
                    local returned_56_39 = __dec14_pack_results(L12_2(L13_2))
                    L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_39, 1, returned_56_39.n)
                    L11_2 = L11_2(unpack(returned_56_39, 1, returned_56_39.n))
                    L12_2 = math_cos
                    L13_2 = math_rad
                    L14_2 = L9_2
                    local returned_56_40 = __dec14_pack_results(L13_2(L14_2))
                    L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_40, 1, returned_56_40.n)
                    L12_2 = L12_2(unpack(returned_56_40, 1, returned_56_40.n))
                    L13_2 = math_sin
                    L14_2 = math_rad
                    L15_2 = L10_2
                    local returned_56_41 = __dec14_pack_results(L14_2(L15_2))
                    L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_41, 1, returned_56_41.n)
                    L13_2 = L13_2(unpack(returned_56_41, 1, returned_56_41.n))
                    L14_2 = math_cos
                    L15_2 = math_rad
                    L16_2 = L10_2
                    local returned_56_42 = __dec14_pack_results(L15_2(L16_2))
                    L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_42, 1, returned_56_42.n)
                    L14_2 = L14_2(unpack(returned_56_42, 1, returned_56_42.n))
                    L15_2 = {
                    }
                    L16_2 = L12_2 * L14_2
                    L17_2 = L12_2 * L13_2
                    L18_2 = -L11_2
                    L15_2[1] = L16_2
                    L15_2[2] = L17_2
                    L15_2[3] = L18_2
                    L16_2 = trace_line
                    L17_2 = A0_2
                    L18_2 = L6_2
                    L19_2 = L7_2
                    L20_2 = L8_2
                    L21_2 = L15_2[1]
                    L21_2 = L21_2 * 8192
                    L21_2 = L6_2 + L21_2
                    L22_2 = L15_2[2]
                    L22_2 = L22_2 * 8192
                    L22_2 = L7_2 + L22_2
                    L23_2 = L15_2[3]
                    L23_2 = L23_2 * 8192
                    L23_2 = L8_2 + L23_2
                    L16_2, L17_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
                    L18_2 = true
                    if L17_2 ~= nil then
                        L19_2 = 0
                        L20_2 = anti_aim_state
                        L20_2 = L20_2.classnames
                        L20_2 = #L20_2
                        L21_2 = 1
                        for L22_2 = L19_2, L20_2, L21_2 do
                            L23_2 = get_classname
                            L24_2 = L17_2
                            L23_2 = L23_2(L24_2)
                            L24_2 = anti_aim_state
                            L24_2 = L24_2.classnames
                            L24_2 = L24_2[L22_2]
                            if L23_2 == L24_2 then
                                L18_2 = false
                            end
                        end
                    end
                    if not L18_2 and not L5_2 then
                        A1_2.in_use = 0
                    end
                    L19_2 = true
                    return L19_2
                else
                    L2_2 = false
                    return L2_2
                end
            end
        else
            L2_2 = contains_value
            L3_2 = script_controls
            L3_2 = L3_2.s
            L4_2 = "Custom Legit AA"
            L2_2 = L2_2(L3_2, L4_2)
            if L2_2 then
                L2_2 = ui_get
                L3_2 = script_controls
                L3_2 = L3_2.la
                L2_2 = L2_2(L3_2)
                if not (L2_2) then
                    L2_2 = key_state
                    L3_2 = 69
                    L2_2 = L2_2(L3_2)
                end
            else
                L2_2 = key_state
                L3_2 = 69
                L2_2 = L2_2(L3_2)
            end
            if L2_2 then
                L2_2 = 100
                L3_2 = get_all_entities
                L4_2 = "CPlantedC4"
                L3_2 = L3_2(L4_2)
                L3_2 = L3_2[1]
                if L3_2 ~= nil then
                    L4_2 = {
                    }
                    L5_2 = get_prop
                    L6_2 = L3_2
                    L7_2 = "m_vecOrigin"
                    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L5_2(L6_2, L7_2)
                    L4_2[1] = L5_2
                    L4_2[2] = L6_2
                    L4_2[3] = L7_2
                    L4_2[4] = L8_2
                    L4_2[5] = L9_2
                    L4_2[6] = L10_2
                    L4_2[7] = L11_2
                    L4_2[8] = L12_2
                    L4_2[9] = L13_2
                    L4_2[10] = L14_2
                    L4_2[11] = L15_2
                    L4_2[12] = L16_2
                    L4_2[13] = L17_2
                    L4_2[14] = L18_2
                    L4_2[15] = L19_2
                    L4_2[16] = L20_2
                    L4_2[17] = L21_2
                    L4_2[18] = L22_2
                    L4_2[19] = L23_2
                    L4_2[20] = L24_2
                    if L4_2 ~= nil then
                        L5_2 = {
                        }
                        L6_2 = get_prop
                        L7_2 = A0_2
                        L8_2 = "m_vecOrigin"
                        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L6_2(L7_2, L8_2)
                        L5_2[1] = L6_2
                        L5_2[2] = L7_2
                        L5_2[3] = L8_2
                        L5_2[4] = L9_2
                        L5_2[5] = L10_2
                        L5_2[6] = L11_2
                        L5_2[7] = L12_2
                        L5_2[8] = L13_2
                        L5_2[9] = L14_2
                        L5_2[10] = L15_2
                        L5_2[11] = L16_2
                        L5_2[12] = L17_2
                        L5_2[13] = L18_2
                        L5_2[14] = L19_2
                        L5_2[15] = L20_2
                        L5_2[16] = L21_2
                        L5_2[17] = L22_2
                        L5_2[18] = L23_2
                        L5_2[19] = L24_2
                        L6_2 = math_abs
                        L7_2 = signed_coordinate_delta
                        L8_2 = L5_2
                        L9_2 = L4_2
                        local returned_56_38 = __dec14_pack_results(L7_2(L8_2, L9_2))
                        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_38, 1, returned_56_38.n)
                        L6_2 = L6_2(unpack(returned_56_38, 1, returned_56_38.n))
                        L2_2 = L6_2
                    end
                end
                L4_2 = get_prop
                L5_2 = A0_2
                L6_2 = "m_iTeamNum"
                L4_2 = L4_2(L5_2, L6_2)
                if L4_2 ~= 3 or not (L2_2 < 62) then
                    L5_2 = false
                else
                    L5_2 = true
                end
                L6_2 = eye_position
                L6_2, L7_2, L8_2 = L6_2()
                L9_2 = camera_angles
                L9_2, L10_2 = L9_2()
                L11_2 = math_sin
                L12_2 = math_rad
                L13_2 = L9_2
                local returned_56_39 = __dec14_pack_results(L12_2(L13_2))
                L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_39, 1, returned_56_39.n)
                L11_2 = L11_2(unpack(returned_56_39, 1, returned_56_39.n))
                L12_2 = math_cos
                L13_2 = math_rad
                L14_2 = L9_2
                local returned_56_40 = __dec14_pack_results(L13_2(L14_2))
                L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_40, 1, returned_56_40.n)
                L12_2 = L12_2(unpack(returned_56_40, 1, returned_56_40.n))
                L13_2 = math_sin
                L14_2 = math_rad
                L15_2 = L10_2
                local returned_56_41 = __dec14_pack_results(L14_2(L15_2))
                L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_41, 1, returned_56_41.n)
                L13_2 = L13_2(unpack(returned_56_41, 1, returned_56_41.n))
                L14_2 = math_cos
                L15_2 = math_rad
                L16_2 = L10_2
                local returned_56_42 = __dec14_pack_results(L15_2(L16_2))
                L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_42, 1, returned_56_42.n)
                L14_2 = L14_2(unpack(returned_56_42, 1, returned_56_42.n))
                L15_2 = {
                }
                L16_2 = L12_2 * L14_2
                L17_2 = L12_2 * L13_2
                L18_2 = -L11_2
                L15_2[1] = L16_2
                L15_2[2] = L17_2
                L15_2[3] = L18_2
                L16_2 = trace_line
                L17_2 = A0_2
                L18_2 = L6_2
                L19_2 = L7_2
                L20_2 = L8_2
                L21_2 = L15_2[1]
                L21_2 = L21_2 * 8192
                L21_2 = L6_2 + L21_2
                L22_2 = L15_2[2]
                L22_2 = L22_2 * 8192
                L22_2 = L7_2 + L22_2
                L23_2 = L15_2[3]
                L23_2 = L23_2 * 8192
                L23_2 = L8_2 + L23_2
                L16_2, L17_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2)
                L18_2 = true
                if L17_2 ~= nil then
                    L19_2 = 0
                    L20_2 = anti_aim_state
                    L20_2 = L20_2.classnames
                    L20_2 = #L20_2
                    L21_2 = 1
                    for L22_2 = L19_2, L20_2, L21_2 do
                        L23_2 = get_classname
                        L24_2 = L17_2
                        L23_2 = L23_2(L24_2)
                        L24_2 = anti_aim_state
                        L24_2 = L24_2.classnames
                        L24_2 = L24_2[L22_2]
                        if L23_2 == L24_2 then
                            L18_2 = false
                        end
                    end
                end
                if not L18_2 and not L5_2 then
                    A1_2.in_use = 0
                end
                L19_2 = true
                return L19_2
            else
                L2_2 = false
                return L2_2
            end
        end
    end
    L98_1 = 0
    update_manual_and_freestanding = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L1_2 = ui_set
        L2_2 = native_controls
        L2_2 = L2_2.yaw
        L2_2 = L2_2[1]
        L3_2 = anti_aim_state
        L3_2 = L3_2.holding_e
        if L3_2 then
            L3_2 = "Off"
            if not (L3_2) then
                L3_2 = "180"
            end
        else
            L3_2 = "180"
        end
        L1_2(L2_2, L3_2)
        L1_2 = ui_set
        L2_2 = native_controls
        L2_2 = L2_2.pitch
        L3_2 = anti_aim_state
        L3_2 = L3_2.holding_e
        if L3_2 then
            L3_2 = "Off"
            if not (L3_2) then
                L3_2 = "Default"
            end
        else
            L3_2 = "Default"
        end
        L1_2(L2_2, L3_2)
        L1_2 = ui_set
        L2_2 = native_controls
        L2_2 = L2_2.yawbase
        L3_2 = "At targets"
        L1_2(L2_2, L3_2)
        L1_2 = 0
        L2_2 = 0
        L3_2 = 0
        L4_2 = 0
        L5_2 = 0
        L6_2 = anti_aim_state
        L6_2 = L6_2.aa
        if L6_2 == 1 then
            L98_1 = L1_2
        else
            L6_2 = anti_aim_state
            L6_2 = L6_2.aa
            if L6_2 == 2 then
                L98_1 = L2_2
            else
                L6_2 = anti_aim_state
                L6_2 = L6_2.aa
                if L6_2 == 3 then
                    L98_1 = L3_2
                else
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.aa
                    if L6_2 == 4 then
                        L98_1 = L4_2
                    else
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.aa
                        if L6_2 == 6 then
                            L98_1 = L5_2
                        end
                    end
                end
            end
        end
        L6_2 = contains_value
        L7_2 = script_controls
        L7_2 = L7_2.s
        L8_2 = "Manual AA"
        L6_2 = L6_2(L7_2, L8_2)
        if L6_2 then
            L6_2 = ui_get
            L7_2 = script_controls
            L7_2 = L7_2.ml
            L6_2 = L6_2(L7_2)
            if L6_2 then
                L6_2 = anti_aim_state
                L6_2 = L6_2.dir
                L6_2 = L6_2.time
                L6_2 = L6_2 + 0.2
                L7_2 = curtime
                L7_2 = L7_2()
                if L6_2 < L7_2 then
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.dir
                    L7_2 = anti_aim_state
                    L7_2 = L7_2.dir
                    L7_2 = L7_2.manual
                    if L7_2 == -90 then
                        L7_2 = L98_1
                        if not (L7_2) then
                            L7_2 = -90
                        end
                    else
                        L7_2 = -90
                    end
                    L6_2.manual = L7_2
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.dir
                    L7_2 = curtime
                    L7_2 = L7_2()
                    L6_2.time = L7_2
                end
            else
                L6_2 = ui_get
                L7_2 = script_controls
                L7_2 = L7_2.mr
                L6_2 = L6_2(L7_2)
                if L6_2 then
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.dir
                    L6_2 = L6_2.time
                    L6_2 = L6_2 + 0.2
                    L7_2 = curtime
                    L7_2 = L7_2()
                    if L6_2 < L7_2 then
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.dir
                        L7_2 = anti_aim_state
                        L7_2 = L7_2.dir
                        L7_2 = L7_2.manual
                        if L7_2 == 90 then
                            L7_2 = L98_1
                            if not (L7_2) then
                                L7_2 = 90
                            end
                        else
                            L7_2 = 90
                        end
                        L6_2.manual = L7_2
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.dir
                        L7_2 = curtime
                        L7_2 = L7_2()
                        L6_2.time = L7_2
                    end
                else
                    L6_2 = ui_get
                    L7_2 = script_controls
                    L7_2 = L7_2.mf
                    L6_2 = L6_2(L7_2)
                    if L6_2 then
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.dir
                        L6_2 = L6_2.time
                        L6_2 = L6_2 + 0.2
                        L7_2 = curtime
                        L7_2 = L7_2()
                        if L6_2 < L7_2 then
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.dir
                            L7_2 = anti_aim_state
                            L7_2 = L7_2.dir
                            L7_2 = L7_2.manual
                            if L7_2 == 180 then
                                L7_2 = L98_1
                                if not (L7_2) then
                                    L7_2 = 180
                                end
                            else
                                L7_2 = 180
                            end
                            L6_2.manual = L7_2
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.dir
                            L7_2 = curtime
                            L7_2 = L7_2()
                            L6_2.time = L7_2
                        end
                    else
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.dir
                        L6_2 = L6_2.time
                        L7_2 = curtime
                        L7_2 = L7_2()
                        if L6_2 > L7_2 then
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.dir
                            L7_2 = curtime
                            L7_2 = L7_2()
                            L6_2.time = L7_2
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.dir
                            L6_2 = L6_2.manual
                            if L6_2 == -90 then
                                L6_2 = anti_aim_state
                                L6_2 = L6_2.dir
                                L6_2 = L6_2.manual
                                if L6_2 == 90 then
                                    L6_2 = anti_aim_state
                                    L6_2 = L6_2.dir
                                    L6_2 = L6_2.manual
                                    if not (L6_2 == 180) then
                                        L6_2 = anti_aim_state
                                        L6_2 = L6_2.dir
                                        L7_2 = L98_1
                                        L6_2.manual = L7_2
                                    end
                                else
                                    L6_2 = anti_aim_state
                                    L6_2 = L6_2.dir
                                    L7_2 = L98_1
                                    L6_2.manual = L7_2
                                end
                            else
                                L6_2 = anti_aim_state
                                L6_2 = L6_2.dir
                                L7_2 = L98_1
                                L6_2.manual = L7_2
                            end
                        end
                    end
                end
            end
            L6_2 = anti_aim_state
            L6_2 = L6_2.dir
            L6_2 = L6_2.manual
            L7_2 = anti_aim_state
            L7_2 = L7_2.stored_dir
            L7_2 = L7_2.manual
            if L6_2 ~= L7_2 then
                L6_2 = ui_set
                L7_2 = native_controls
                L7_2 = L7_2.yaw
                L7_2 = L7_2[2]
                L8_2 = anti_aim_state
                L8_2 = L8_2.dir
                L8_2 = L8_2.manual
                L6_2(L7_2, L8_2)
                L6_2 = anti_aim_state
                L6_2 = L6_2.stored_dir
                L7_2 = anti_aim_state
                L7_2 = L7_2.dir
                L7_2 = L7_2.manual
                L6_2.manual = L7_2
            end
        else
            L6_2 = anti_aim_state
            L6_2 = L6_2.dir
            L7_2 = L98_1
            L6_2.manual = L7_2
        end
        L6_2 = ui_set
        L7_2 = native_controls
        L7_2 = L7_2.yaw
        L7_2 = L7_2[2]
        L8_2 = anti_aim_state
        L8_2 = L8_2.dir
        L8_2 = L8_2.manual
        L6_2(L7_2, L8_2)
        L6_2 = anti_aim_state
        L6_2 = L6_2.dir
        L7_2 = contains_value
        L8_2 = script_controls
        L8_2 = L8_2.s
        L9_2 = "Edge yaw"
        L7_2 = L7_2(L8_2, L9_2)
        if L7_2 then
            L7_2 = ui_get
            L8_2 = script_controls
            L8_2 = L8_2.ey
            L7_2 = L7_2(L8_2)
            if L7_2 then
                L7_2 = anti_aim_state
                L7_2 = L7_2.holding_e
                L7_2 = not L7_2
            end
        end
        L6_2.edge = L7_2
        L6_2 = anti_aim_state
        L6_2 = L6_2.dir
        L7_2 = contains_value
        L8_2 = script_controls
        L8_2 = L8_2.s
        L9_2 = "Freestanding"
        L7_2 = L7_2(L8_2, L9_2)
        if L7_2 then
            L7_2 = ui_get
            L8_2 = script_controls
            L8_2 = L8_2.fs
            L7_2 = L7_2(L8_2)
            if L7_2 then
                L7_2 = anti_aim_state
                L7_2 = L7_2.holding_e
                L7_2 = not L7_2
            end
        end
        L6_2.freestand = L7_2
        L6_2 = anti_aim_state
        L6_2 = L6_2.dir
        L6_2 = L6_2.freestand
        L7_2 = anti_aim_state
        L7_2 = L7_2.stored_dir
        L7_2 = L7_2.freestand
        if L6_2 ~= L7_2 then
            L6_2 = ui_set
            L7_2 = native_controls
            L7_2 = L7_2.freestand
            L7_2 = L7_2[1]
            L8_2 = anti_aim_state
            L8_2 = L8_2.dir
            L8_2 = L8_2.freestand
            if L8_2 then
                L8_2 = "Default"
                if not (L8_2) then
                    L8_2 = "-"
                end
            else
                L8_2 = "-"
            end
            L6_2(L7_2, L8_2)
            L6_2 = ui_set
            L7_2 = native_controls
            L7_2 = L7_2.freestand
            L7_2 = L7_2[2]
            L8_2 = "Always on"
            L6_2(L7_2, L8_2)
            L6_2 = anti_aim_state
            L6_2 = L6_2.stored_dir
            L7_2 = anti_aim_state
            L7_2 = L7_2.dir
            L7_2 = L7_2.freestand
            L6_2.freestand = L7_2
        end
        L6_2 = anti_aim_state
        L6_2 = L6_2.dir
        L6_2 = L6_2.edge
        L7_2 = anti_aim_state
        L7_2 = L7_2.stored_dir
        L7_2 = L7_2.edge
        if L6_2 ~= L7_2 then
            L6_2 = ui_set
            L7_2 = native_controls
            L7_2 = L7_2.edgeyaw
            L8_2 = anti_aim_state
            L8_2 = L8_2.dir
            L8_2 = L8_2.edge
            L6_2(L7_2, L8_2)
            L6_2 = anti_aim_state
            L6_2 = L6_2.stored_dir
            L7_2 = anti_aim_state
            L7_2 = L7_2.dir
            L7_2 = L7_2.edge
            L6_2.edge = L7_2
        end
    end
    point_on_circle = function(A0_2, A1_2, A2_2, A3_2, ...)
        local L4_2, L5_2, L6_2, L7_2
        L4_2 = math_cos
        L5_2 = math_rad
        L6_2 = A2_2
        local returned_58_43 = __dec14_pack_results(L5_2(L6_2))
        L5_2, L6_2, L7_2 = unpack(returned_58_43, 1, returned_58_43.n)
        L4_2 = L4_2(unpack(returned_58_43, 1, returned_58_43.n))
        L4_2 = L4_2 * A3_2
        L4_2 = L4_2 + A0_2
        L5_2 = math_sin
        L6_2 = math_rad
        L7_2 = A2_2
        local returned_58_44 = __dec14_pack_results(L6_2(L7_2))
        L6_2, L7_2 = unpack(returned_58_44, 1, returned_58_44.n)
        L5_2 = L5_2(unpack(returned_58_44, 1, returned_58_44.n))
        L5_2 = L5_2 * A3_2
        L5_2 = L5_2 + A1_2
        return L4_2, L5_2
    end
    draw_indicator_triangle = function(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2, A11_2, A12_2, ...)
        local L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2
        L13_2 = point_on_circle
        L14_2 = A0_2
        L15_2 = A1_2 + 4
        L16_2 = A10_2
        L17_2 = 45
        L13_2, L14_2 = L13_2(L14_2, L15_2, L16_2, L17_2)
        L15_2 = point_on_circle
        L16_2 = A0_2
        L17_2 = A1_2 + 4
        L18_2 = A11_2 / 3
        L18_2 = A10_2 + L18_2
        L19_2 = A11_2 / 4
        L19_2 = 45 - L19_2
        L15_2, L16_2 = L15_2(L16_2, L17_2, L18_2, L19_2)
        L17_2 = point_on_circle
        L18_2 = A0_2
        L19_2 = A1_2 + 4
        L20_2 = A10_2
        L21_2 = A11_2 / 5
        L21_2 = 45 - L21_2
        L17_2, L18_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
        L19_2 = point_on_circle
        L20_2 = A0_2
        L21_2 = A1_2 + 4
        L22_2 = A10_2
        L23_2 = A11_2 / 5
        L23_2 = 45 - L23_2
        L19_2, L20_2 = L19_2(L20_2, L21_2, L22_2, L23_2)
        L21_2 = point_on_circle
        L22_2 = A0_2
        L23_2 = A1_2 + 4
        L24_2 = A11_2 / 3
        L24_2 = A10_2 - L24_2
        L25_2 = A11_2 / 4
        L25_2 = 45 - L25_2
        L21_2, L22_2 = L21_2(L22_2, L23_2, L24_2, L25_2)
        L23_2 = draw_triangle
        L24_2 = L13_2
        L25_2 = L14_2
        L26_2 = L15_2
        L27_2 = L16_2
        L28_2 = L17_2
        L29_2 = L18_2
        L30_2 = A6_2 or L30_2
        if not A12_2 or not A6_2 then
            L30_2 = A2_2
        end
        L31_2 = A7_2 or L31_2
        if not A12_2 or not A7_2 then
            L31_2 = A3_2
        end
        L32_2 = A8_2 or L32_2
        if not A12_2 or not A8_2 then
            L32_2 = A4_2
        end
        L33_2 = A9_2 or L33_2
        if not A12_2 or not A9_2 then
            L33_2 = A5_2
        end
        L23_2(L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2)
        L23_2 = draw_triangle
        L24_2 = L13_2
        L25_2 = L14_2
        L26_2 = L19_2
        L27_2 = L20_2
        L28_2 = L21_2
        L29_2 = L22_2
        L30_2 = A2_2 or L30_2
        if not A12_2 or not A2_2 then
            L30_2 = A6_2
        end
        L31_2 = A3_2 or L31_2
        if not A12_2 or not A3_2 then
            L31_2 = A7_2
        end
        L32_2 = A4_2 or L32_2
        if not A12_2 or not A4_2 then
            L32_2 = A8_2
        end
        L33_2 = A5_2 or L33_2
        if not A12_2 or not A5_2 then
            L33_2 = A9_2
        end
        L23_2(L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2)
        L23_2 = draw_line
        L24_2 = L13_2
        L25_2 = L14_2
        L26_2 = L19_2
        L27_2 = L20_2
        L28_2 = 0
        L29_2 = 0
        L30_2 = 0
        L31_2 = 200
        L23_2(L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2)
    end
    reset_clan_tag = function(...)
        local L0_2, L1_2
        L0_2 = L93_1
        if L0_2 then
            L0_2 = false
            L93_1 = L0_2
        else
            L0_2 = true
            L93_1 = L0_2
        end
        L0_2 = false
        L94_1 = L0_2
    end
    apply_body_yaw = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
        L1_2 = get_local_player
        L1_2 = L1_2()
        L2_2 = anti_aim_state
        L2_2 = L2_2.rec
        L3_2 = anti_aim_state
        L3_2 = L3_2.rec
        L3_2 = #L3_2
        L3_2 = L3_2 + 1
        L4_2 = {
        }
        L5_2 = head_coordinates
        L6_2 = L1_2
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L5_2(L6_2)
        L4_2[1] = L5_2
        L4_2[2] = L6_2
        L4_2[3] = L7_2
        L4_2[4] = L8_2
        L4_2[5] = L9_2
        L4_2[6] = L10_2
        L4_2[7] = L11_2
        L2_2[L3_2] = L4_2
        L2_2 = anti_aim_state
        L2_2 = L2_2.rec
        L2_2 = #L2_2
        if 28 < L2_2 then
            L2_2 = table_remove
            L3_2 = anti_aim_state
            L3_2 = L3_2.rec
            L4_2 = 1
            L2_2(L3_2, L4_2)
        end
        L2_2 = classify_movement
        L3_2 = L1_2
        L4_2 = A0_2
        L2_2(L3_2, L4_2)
        L2_2 = update_target_anti_aim
        L3_2 = L1_2
        L2_2(L3_2)
        L2_2 = anti_aim_state
        L3_2 = handle_use_key
        L4_2 = L1_2
        L5_2 = A0_2
        L3_2 = L3_2(L4_2, L5_2)
        L2_2.holding_e = L3_2
        L2_2 = update_manual_and_freestanding
        L3_2 = L1_2
        L4_2 = anti_aim_state
        L4_2 = L4_2.holding_e
        L2_2(L3_2, L4_2)
        L2_2 = ui_set
        L3_2 = native_controls
        L3_2 = L3_2.bodyyaw
        L3_2 = L3_2[1]
        L4_2 = fs
        if L4_2 then
            L4_2 = "Static"
            if not (L4_2) then
                L4_2 = anti_aim_state
                L4_2 = L4_2.desync
                if L4_2 == 180 then
                    L4_2 = contains_value
                    L5_2 = script_controls
                    L5_2 = L5_2.s
                    L6_2 = "Jitter when not networked"
                    L4_2 = L4_2(L5_2, L6_2)
                    if L4_2 then
                        L4_2 = "Jitter"
                        if not (L4_2) then
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 3 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 2 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = anti_aim_state
                                            L4_2 = L4_2.aa
                                            if L4_2 == 4 then
                                                L4_2 = "Jitter"
                                                if not (L4_2) then
                                                    L4_2 = "Static"
                                                end
                                            else
                                                L4_2 = "Static"
                                            end
                                        end
                                    else
                                        L4_2 = anti_aim_state
                                        L4_2 = L4_2.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not (L4_2) then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = anti_aim_state
                                        L4_2 = L4_2.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not (L4_2) then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 3 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = anti_aim_state
                                        L4_2 = L4_2.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not (L4_2) then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.aa
                    if L4_2 == 3 then
                        L4_2 = "Jitter"
                        if not (L4_2) then
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                end
            end
        else
            L4_2 = anti_aim_state
            L4_2 = L4_2.desync
            if L4_2 == 180 then
                L4_2 = contains_value
                L5_2 = script_controls
                L5_2 = L5_2.s
                L6_2 = "Jitter when not networked"
                L4_2 = L4_2(L5_2, L6_2)
                if L4_2 then
                    L4_2 = "Jitter"
                    if not (L4_2) then
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 3 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = anti_aim_state
                                        L4_2 = L4_2.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not (L4_2) then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.aa
                    if L4_2 == 3 then
                        L4_2 = "Jitter"
                        if not (L4_2) then
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = anti_aim_state
                                    L4_2 = L4_2.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not (L4_2) then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                end
            else
                L4_2 = anti_aim_state
                L4_2 = L4_2.aa
                if L4_2 == 3 then
                    L4_2 = "Jitter"
                    if not (L4_2) then
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = anti_aim_state
                                L4_2 = L4_2.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not (L4_2) then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.aa
                    if L4_2 == 2 then
                        L4_2 = "Jitter"
                        if not (L4_2) then
                            L4_2 = anti_aim_state
                            L4_2 = L4_2.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not (L4_2) then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    else
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.aa
                        if L4_2 == 4 then
                            L4_2 = "Jitter"
                            if not (L4_2) then
                                L4_2 = "Static"
                            end
                        else
                            L4_2 = "Static"
                        end
                    end
                end
            end
        end
        L2_2(L3_2, L4_2)
        L2_2 = ui_set
        L3_2 = native_controls
        L3_2 = L3_2.bodyyaw
        L3_2 = L3_2[2]
        L4_2 = anti_aim_state
        L4_2 = L4_2.desync
        if L4_2 == 180 then
            L4_2 = 0
            if not (L4_2) then
                L4_2 = anti_aim_state
                L4_2 = L4_2.holding_e
                if L4_2 then
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.desync
                    L4_2 = -L4_2
                    if not (L4_2) then
                        L4_2 = anti_aim_state
                        L4_2 = L4_2.desync
                    end
                else
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.desync
                end
            end
        else
            L4_2 = anti_aim_state
            L4_2 = L4_2.holding_e
            if L4_2 then
                L4_2 = anti_aim_state
                L4_2 = L4_2.desync
                L4_2 = -L4_2
                if not (L4_2) then
                    L4_2 = anti_aim_state
                    L4_2 = L4_2.desync
                end
            else
                L4_2 = anti_aim_state
                L4_2 = L4_2.desync
            end
        end
        L2_2(L3_2, L4_2)
        L2_2 = anti_aim_state
        L2_2 = L2_2.aa
        if L2_2 == 1 then
            L2_2 = ui_set
            L3_2 = native_controls
            L3_2 = L3_2.yawjitter
            L3_2 = L3_2[1]
            L4_2 = "Random"
            L2_2(L3_2, L4_2)
            L2_2 = ui_set
            L3_2 = native_controls
            L3_2 = L3_2.yawjitter
            L3_2 = L3_2[2]
            L4_2 = 7
            L2_2(L3_2, L4_2)
        else
            L2_2 = anti_aim_state
            L2_2 = L2_2.aa
            if L2_2 == 2 then
                L2_2 = ui_set
                L3_2 = native_controls
                L3_2 = L3_2.yawjitter
                L3_2 = L3_2[1]
                L4_2 = "Center"
                L2_2(L3_2, L4_2)
                L2_2 = ui_set
                L3_2 = native_controls
                L3_2 = L3_2.yawjitter
                L3_2 = L3_2[2]
                L4_2 = 60
                L2_2(L3_2, L4_2)
            else
                L2_2 = anti_aim_state
                L2_2 = L2_2.aa
                if L2_2 == 3 then
                    L2_2 = ui_set
                    L3_2 = native_controls
                    L3_2 = L3_2.yawjitter
                    L3_2 = L3_2[1]
                    L4_2 = "Offset"
                    L2_2(L3_2, L4_2)
                    L2_2 = ui_set
                    L3_2 = native_controls
                    L3_2 = L3_2.yawjitter
                    L3_2 = L3_2[2]
                    L4_2 = client
                    L4_2 = L4_2.random_int
                    L5_2 = 0
                    L6_2 = 60
                    local returned_61_45 = __dec14_pack_results(L4_2(L5_2, L6_2))
                    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = unpack(returned_61_45, 1, returned_61_45.n)
                    L2_2(L3_2, unpack(returned_61_45, 1, returned_61_45.n))
                else
                    L2_2 = anti_aim_state
                    L2_2 = L2_2.aa
                    if L2_2 == 4 then
                        L2_2 = ui_set
                        L3_2 = native_controls
                        L3_2 = L3_2.yawjitter
                        L3_2 = L3_2[1]
                        L4_2 = "Center"
                        L2_2(L3_2, L4_2)
                        L2_2 = ui_set
                        L3_2 = native_controls
                        L3_2 = L3_2.yawjitter
                        L3_2 = L3_2[2]
                        L4_2 = 35
                        L2_2(L3_2, L4_2)
                    else
                        L2_2 = anti_aim_state
                        L2_2 = L2_2.aa
                        if L2_2 == 5 then
                            L2_2 = ui_set
                            L3_2 = native_controls
                            L3_2 = L3_2.yawjitter
                            L3_2 = L3_2[1]
                            L4_2 = "Off"
                            L2_2(L3_2, L4_2)
                            L2_2 = ui_set
                            L3_2 = native_controls
                            L3_2 = L3_2.yawjitter
                            L3_2 = L3_2[2]
                            L4_2 = 0
                            L2_2(L3_2, L4_2)
                        else
                            L2_2 = anti_aim_state
                            L2_2 = L2_2.aa
                            if L2_2 == 6 then
                                L2_2 = ui_set
                                L3_2 = native_controls
                                L3_2 = L3_2.yawjitter
                                L3_2 = L3_2[1]
                                L4_2 = "Off"
                                L2_2(L3_2, L4_2)
                                L2_2 = ui_set
                                L3_2 = native_controls
                                L3_2 = L3_2.yawjitter
                                L3_2 = L3_2[2]
                                L4_2 = 20
                                L2_2(L3_2, L4_2)
                            else
                                L2_2 = anti_aim_state
                                L2_2 = L2_2.aa
                                if L2_2 == 7 then
                                    L2_2 = ui_set
                                    L3_2 = native_controls
                                    L3_2 = L3_2.yawjitter
                                    L3_2 = L3_2[1]
                                    L4_2 = "Center"
                                    L2_2(L3_2, L4_2)
                                    L2_2 = ui_set
                                    L3_2 = native_controls
                                    L3_2 = L3_2.yawjitter
                                    L3_2 = L3_2[2]
                                    L4_2 = 10
                                    L2_2(L3_2, L4_2)
                                end
                            end
                        end
                    end
                end
            end
        end
        L2_2 = L94_1
        if not L2_2 then
            L2_2 = client
            L2_2 = L2_2.delay_call
            L3_2 = 0.25
            L4_2 = reset_clan_tag
            L2_2(L3_2, L4_2)
            L2_2 = true
            L94_1 = L2_2
        end
        L2_2 = 60
        L3_2 = 60
        L4_2 = 60
        L5_2 = 60
        L6_2 = 60
        L7_2 = client
        L7_2 = L7_2.random_int
        L8_2 = 45
        L9_2 = 60
        L7_2 = L7_2(L8_2, L9_2)
        L8_2 = client
        L8_2 = L8_2.random_int
        L9_2 = 45
        L10_2 = 60
        L8_2 = L8_2(L9_2, L10_2)
        L9_2 = anti_aim_state
        L9_2 = L9_2.aa
        if L9_2 == 1 then
            L9_2 = ui_set
            L10_2 = native_controls
            L10_2 = L10_2.fakeyawlimit
            L11_2 = L2_2
            L9_2(L10_2, L11_2)
        else
            L9_2 = anti_aim_state
            L9_2 = L9_2.aa
            if L9_2 == 2 then
                L9_2 = ui_set
                L10_2 = native_controls
                L10_2 = L10_2.fakeyawlimit
                L11_2 = L3_2
                L9_2(L10_2, L11_2)
            else
                L9_2 = anti_aim_state
                L9_2 = L9_2.aa
                if L9_2 == 3 then
                    L9_2 = ui_set
                    L10_2 = native_controls
                    L10_2 = L10_2.fakeyawlimit
                    L11_2 = L4_2
                    L9_2(L10_2, L11_2)
                else
                    L9_2 = anti_aim_state
                    L9_2 = L9_2.aa
                    if L9_2 == 4 then
                        L9_2 = ui_set
                        L10_2 = native_controls
                        L10_2 = L10_2.fakeyawlimit
                        L11_2 = L5_2
                        L9_2(L10_2, L11_2)
                    else
                        L9_2 = anti_aim_state
                        L9_2 = L9_2.aa
                        if L9_2 == 5 then
                            L9_2 = ui_set
                            L10_2 = native_controls
                            L10_2 = L10_2.fakeyawlimit
                            L11_2 = L6_2
                            L9_2(L10_2, L11_2)
                        else
                            L9_2 = anti_aim_state
                            L9_2 = L9_2.aa
                            if L9_2 == 6 then
                                L9_2 = ui_set
                                L10_2 = native_controls
                                L10_2 = L10_2.fakeyawlimit
                                L11_2 = L7_2
                                L9_2(L10_2, L11_2)
                            else
                                L9_2 = anti_aim_state
                                L9_2 = L9_2.aa
                                if L9_2 == 7 then
                                    L9_2 = ui_set
                                    L10_2 = native_controls
                                    L10_2 = L10_2.fakeyawlimit
                                    L11_2 = L8_2
                                    L9_2(L10_2, L11_2)
                                end
                            end
                        end
                    end
                end
            end
        end
        L9_2 = set_native_ui_visible
        L10_2 = false
        L9_2(L10_2)
    end
    on_bullet_impact = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L1_2 = get_local_player
        L1_2 = L1_2()
        L2_2 = userid_to_entindex
        L3_2 = A0_2.userid
        L2_2 = L2_2(L3_2)
        L3_2 = is_enemy
        L4_2 = L2_2
        L3_2 = L3_2(L4_2)
        if L3_2 then
            L3_2 = is_alive
            L4_2 = L1_2
            L3_2 = L3_2(L4_2)
            if L3_2 then
                L3_2 = is_valid_player
                L4_2 = L2_2
                L3_2 = L3_2(L4_2)
                if L3_2 then
                    L3_2 = target_info
                    L4_2 = L2_2
                    L5_2 = A0_2
                    L3_2 = L3_2(L4_2, L5_2)
                    L4_2 = target_record_info
                    L5_2 = L3_2
                    L6_2 = anti_aim_state
                    L6_2 = L6_2.ls
                    L7_2 = L2_2
                    L8_2 = L1_2
                    L9_2 = A0_2
                    L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
                    if L4_2 then
                        L4_2 = player_records
                        L4_2 = L4_2[L2_2]
                        L4_2 = L4_2.s
                        L4_2 = #L4_2
                        if 0 < L4_2 then
                            L4_2 = player_records
                            L4_2 = L4_2[L2_2]
                            L4_2 = L4_2.s
                            L5_2 = player_records
                            L5_2 = L5_2[L2_2]
                            L5_2 = L5_2.s
                            L5_2 = #L5_2
                            L4_2 = L4_2[L5_2]
                            L4_2 = L4_2.t
                            L5_2 = curtime
                            L5_2 = L5_2()
                            if L4_2 == L5_2 then
                                L4_2 = player_records
                                L4_2 = L4_2[L2_2]
                                L4_2 = L4_2.s
                                L4_2 = #L4_2
                                if not (L4_2) then
                                    L4_2 = player_records
                                    L4_2 = L4_2[L2_2]
                                    L4_2 = L4_2.s
                                    L4_2 = #L4_2
                                    L4_2 = L4_2 + 1
                                end
                            else
                                L4_2 = player_records
                                L4_2 = L4_2[L2_2]
                                L4_2 = L4_2.s
                                L4_2 = #L4_2
                                L4_2 = L4_2 + 1
                            end
                        else
                            L4_2 = player_records
                            L4_2 = L4_2[L2_2]
                            L4_2 = L4_2.s
                            L4_2 = #L4_2
                            L4_2 = L4_2 + 1
                        end
                        L5_2 = anti_aim_state
                        L5_2 = L5_2.desync
                        if L5_2 ~= 0 then
                            L5_2 = anti_aim_state
                            L5_2 = L5_2.desync
                            if L5_2 ~= 180 then
                                L5_2 = script_controls
                                L5_2 = L5_2["Detect missed angle"]
                            end
                        else
                            L5_2 = true
                        end
                        L6_2 = anti_aim_state
                        L6_2 = L6_2.desync
                        L7_2 = anti_aim_state
                        L7_2 = L7_2.desync
                        if L6_2 == L7_2 then
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.desync
                            L6_2 = -L6_2
                            if not (L6_2) then
                                L6_2 = anti_aim_state
                                L6_2 = L6_2.desync
                            end
                        else
                            L6_2 = anti_aim_state
                            L6_2 = L6_2.desync
                        end
                        if L5_2 then
                            L7_2 = math_abs
                            L8_2 = L3_2
                            L7_2 = L7_2(L8_2)
                            if L7_2 < 3 then
                                L7_2 = anti_aim_state
                                L7_2 = L7_2.desync
                                if L7_2 then
                                    L7_2 = anti_aim_state
                                    L7_2 = L7_2.desync
                                    L6_2 = L7_2 or L6_2
                                end
                                if not L7_2 then
                                    L7_2 = anti_aim_state
                                    L7_2 = L7_2.desync
                                    L6_2 = -L7_2
                                end
                            else
                                if 0 < L3_2 then
                                    L7_2 = anti_aim_state
                                    L7_2 = L7_2.desync
                                    L7_2 = -L7_2
                                    if not (L7_2) then
                                        L7_2 = anti_aim_state
                                        L6_2 = L7_2.desync
                                    end
                                else
                                    L7_2 = anti_aim_state
                                    L6_2 = L7_2.desync
                                end
                            end
                        end
                        L7_2 = player_records
                        L7_2 = L7_2[L2_2]
                        L7_2 = L7_2.s
                        L8_2 = {
                        }
                        L9_2 = tickcount
                        L9_2 = L9_2()
                        L8_2.t = L9_2
                        L8_2.d = L6_2
                        L8_2.dis = L3_2
                        L7_2[L4_2] = L8_2
                    end
                else
                    do
                        return 
                    end
                end
            else
                do
                    return 
                end
            end
        else
            do
                return 
            end
        end
    end
    on_player_hurt = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L1_2 = get_local_player
        L1_2 = L1_2()
        L2_2 = userid_to_entindex
        L3_2 = A0_2.userid
        L2_2 = L2_2(L3_2)
        L3_2 = userid_to_entindex
        L4_2 = A0_2.attacker
        L3_2 = L3_2(L4_2)
        L4_2 = is_enemy
        L5_2 = L3_2
        L4_2 = L4_2(L5_2)
        if L4_2 then
            L4_2 = is_alive
            L5_2 = L1_2
            L4_2 = L4_2(L5_2)
            if L4_2 then
                L4_2 = 1
                L5_2 = anti_aim_state
                L5_2 = L5_2.nonweapons
                L5_2 = #L5_2
                L6_2 = 1
                for L7_2 = L4_2, L5_2, L6_2 do
                    L8_2 = A0_2.weapon
                    L9_2 = anti_aim_state
                    L9_2 = L9_2.nonweapons
                    L9_2 = L9_2[L7_2]
                    if L8_2 == L9_2 then
                        return 
                    end
                end
                L4_2 = player_records
                L4_2 = L4_2[L3_2]
                L4_2 = L4_2.h
                L4_2 = #L4_2
                if 0 < L4_2 then
                    L4_2 = player_records
                    L4_2 = L4_2[L3_2]
                    L4_2 = L4_2.h
                    L4_2 = #L4_2
                    if not (L4_2) then
                        L4_2 = player_records
                        L4_2 = L4_2[L3_2]
                        L4_2 = L4_2.h
                        L4_2 = #L4_2
                        L4_2 = L4_2 + 1
                    end
                else
                    L4_2 = player_records
                    L4_2 = L4_2[L3_2]
                    L4_2 = L4_2.h
                    L4_2 = #L4_2
                    L4_2 = L4_2 + 1
                end
                L5_2 = player_records
                L5_2 = L5_2[L3_2]
                L5_2 = L5_2.h
                L6_2 = {
                }
                L7_2 = tickcount
                L7_2 = L7_2()
                L6_2.t = L7_2
                L7_2 = new_angle
                L6_2.d = L7_2
                L7_2 = A0_2.hitgroup
                L6_2.h = L7_2
                L6_2.v = L2_2
                L5_2[L4_2] = L6_2
            else
                do
                    return 
                end
            end
        else
            do
                return 
            end
        end
    end
    on_player_spawn = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2
        L1_2 = get_local_player
        L1_2 = L1_2()
        L2_2 = userid_to_entindex
        L3_2 = A0_2.userid
        L2_2 = L2_2(L3_2)
        if L2_2 == L1_2 then
            L3_2 = reset_player_state
            L4_2 = true
            L3_2(L4_2)
        end
    end
    L107_1 = {
    }
    L108_1 = ""
    L109_1 = "p"
    L110_1 = "pr"
    L111_1 = "pre"
    clear_clan_tag = "pred"
    draw_indicators = "predi"
    update_ui_visibility = "predic"
    whitelisted = "predict"
    panorama_api = "predicti"
    register_events_if_whitelisted = "predictio"
    request_whitelist = "prediction.lua"
    fake_yaw_limit = ""
    screen_dimensions = "prediction.lua"
    screen_center = ""
    draw_branding = "prediction.lua"
    L123_1 = ""
    L124_1 = "prediction.lua"
    L125_1 = ""
    L126_1 = "predictio"
    L127_1 = "predicti"
    L128_1 = "predict"
    L129_1 = "predic"
    L130_1 = "predi"
    L131_1 = "pred"
    L132_1 = "pre"
    L133_1 = "pr"
    L134_1 = "p"
    L135_1 = ""
    L107_1[1] = L108_1
    L107_1[2] = L109_1
    L107_1[3] = L110_1
    L107_1[4] = L111_1
    L107_1[5] = clear_clan_tag
    L107_1[6] = draw_indicators
    L107_1[7] = update_ui_visibility
    L107_1[8] = whitelisted
    L107_1[9] = panorama_api
    L107_1[10] = register_events_if_whitelisted
    L107_1[11] = request_whitelist
    L107_1[12] = fake_yaw_limit
    L107_1[13] = screen_dimensions
    L107_1[14] = screen_center
    L107_1[15] = draw_branding
    L107_1[16] = L123_1
    L107_1[17] = L124_1
    L107_1[18] = L125_1
    L107_1[19] = L126_1
    L107_1[20] = L127_1
    L107_1[21] = L128_1
    L107_1[22] = L129_1
    L107_1[23] = L130_1
    L107_1[24] = L131_1
    L107_1[25] = L132_1
    L107_1[26] = L133_1
    L107_1[27] = L134_1
    L107_1[28] = L135_1
    L108_1 = {
    }
    L109_1 = "nemesis"
    L110_1 = "n3m3sis"
    L108_1[1] = L109_1
    L108_1[2] = L110_1
    L109_1 = 1
    L110_1 = 0
    L111_1 = false
    clear_clan_tag = client
    clear_clan_tag = clear_clan_tag.set_event_callback
    draw_indicators = "player_connect_full"
    update_ui_visibility = function(A0_2, ...)
        local L1_2, L2_2
        L1_2 = globals
        L1_2 = L1_2.tickcount
        L1_2 = L1_2()
        L110_1 = L1_2
    end
    clear_clan_tag(draw_indicators, update_ui_visibility)
    clear_clan_tag = function(...)
        local L0_2, L1_2
        L0_2 = client
        L0_2 = L0_2.set_clan_tag
        L1_2 = ""
        L0_2(L1_2)
    end
    draw_indicators = client
    draw_indicators = draw_indicators.set_event_callback
    update_ui_visibility = "shutdown"
    whitelisted = function(...)
        local L0_2, L1_2, L2_2
        L0_2 = L111_1
        if L0_2 then
            L0_2 = client
            L0_2 = L0_2.delay_call
            L1_2 = 0.15
            L2_2 = clear_clan_tag
            L0_2(L1_2, L2_2)
        end
    end
    draw_indicators(update_ui_visibility, whitelisted)
    draw_indicators = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2
        L0_2 = get_local_player
        L0_2 = L0_2()
        L1_2 = update_shot_history
        L2_2 = L0_2
        L1_2(L2_2)
        L1_2 = contains_value
        L2_2 = script_controls
        L2_2 = L2_2.s
        L3_2 = "Adaptive clantag"
        L1_2 = L1_2(L2_2, L3_2)
        if L1_2 then
            L1_2 = entity
            L1_2 = L1_2.get_all
            L2_2 = "CCSPlayerResource"
            L1_2 = L1_2(L2_2)
            L1_2 = L1_2[1]
            L2_2 = entity
            L2_2 = L2_2.get_prop
            L3_2 = L1_2
            L4_2 = "m_iKills"
            L5_2 = entity
            L5_2 = L5_2.get_local_player
            local returned_68_46 = __dec14_pack_results(L5_2())
            L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_46, 1, returned_68_46.n)
            L2_2 = L2_2(L3_2, L4_2, unpack(returned_68_46, 1, returned_68_46.n))
            L3_2 = entity
            L3_2 = L3_2.get_prop
            L4_2 = L1_2
            L5_2 = "m_iDeaths"
            L6_2 = entity
            L6_2 = L6_2.get_local_player
            local returned_68_47 = __dec14_pack_results(L6_2())
            L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_47, 1, returned_68_47.n)
            L3_2 = L3_2(L4_2, L5_2, unpack(returned_68_47, 1, returned_68_47.n))
            L4_2 = L2_2 / L3_2
            if L4_2 < 1.5 or L2_2 == nil and L3_2 == nil then
                L4_2 = globals
                L4_2 = L4_2.tickcount
                L4_2 = L4_2()
                L5_2 = L110_1
                L4_2 = L4_2 - L5_2
                if 10 < L4_2 then
                    L4_2 = math
                    L4_2 = L4_2.floor
                    L5_2 = globals
                    L5_2 = L5_2.curtime
                    L5_2 = L5_2()
                    L5_2 = L5_2 * 1
                    L5_2 = L5_2 % 2
                    L5_2 = L5_2 + 1
                    L4_2 = L4_2(L5_2)
                    L109_1 = L4_2
                    L4_2 = client
                    L4_2 = L4_2.set_clan_tag
                    L5_2 = L108_1
                    L6_2 = L109_1
                    L5_2 = L5_2[L6_2]
                    L4_2(L5_2)
                    L4_2 = globals
                    L4_2 = L4_2.tickcount
                    L4_2 = L4_2()
                    L110_1 = L4_2
                end
            else
                L4_2 = globals
                L4_2 = L4_2.tickcount
                L4_2 = L4_2()
                L5_2 = L110_1
                L4_2 = L4_2 - L5_2
                if 10 < L4_2 then
                    L4_2 = math
                    L4_2 = L4_2.floor
                    L5_2 = globals
                    L5_2 = L5_2.curtime
                    L5_2 = L5_2()
                    L5_2 = L5_2 * 2
                    L5_2 = L5_2 % 24
                    L5_2 = L5_2 + 1
                    L4_2 = L4_2(L5_2)
                    L109_1 = L4_2
                    L4_2 = client
                    L4_2 = L4_2.set_clan_tag
                    L5_2 = L107_1
                    L6_2 = L109_1
                    L5_2 = L5_2[L6_2]
                    L4_2(L5_2)
                    L4_2 = globals
                    L4_2 = L4_2.tickcount
                    L4_2 = L4_2()
                    L110_1 = L4_2
                end
            end
            L4_2 = L111_1
            if not L4_2 then
                L4_2 = true
                L111_1 = L4_2
            end
        else
            L1_2 = L111_1
            if L1_2 then
                L1_2 = client
                L1_2 = L1_2.delay_call
                L2_2 = 0.15
                L3_2 = clear_clan_tag
                L1_2(L2_2, L3_2)
                L1_2 = false
                L111_1 = L1_2
            end
        end
        L1_2 = is_alive
        L2_2 = L0_2
        L1_2 = L1_2(L2_2)
        if not L1_2 then
            return 
        else
            L1_2 = {
            }
            L2_2 = screen_size
            L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = L2_2()
            L1_2[1] = L2_2
            L1_2[2] = L3_2
            L1_2[3] = L4_2
            L1_2[4] = L5_2
            L1_2[5] = L6_2
            L1_2[6] = L7_2
            L1_2[7] = L8_2
            L1_2[8] = L9_2
            L1_2[9] = L10_2
            L1_2[10] = L11_2
            L1_2[11] = L12_2
            L1_2[12] = L13_2
            L1_2[13] = L14_2
            L1_2[14] = L15_2
            L1_2[15] = L16_2
            L1_2[16] = L17_2
            L1_2[17] = L18_2
            L1_2[18] = L19_2
            L1_2[19] = L20_2
            L1_2[20] = L21_2
            L1_2[21] = L22_2
            L1_2[22] = L23_2
            L1_2[23] = L24_2
            L1_2[24] = L25_2
            L1_2[25] = L26_2
            L1_2[26] = L27_2
            L1_2[27] = L28_2
            L1_2[28] = L29_2
            L1_2[29] = L30_2
            L1_2[30] = L31_2
            L1_2[31] = L32_2
            L1_2[32] = L33_2
            L2_2 = {
            }
            L3_2 = L1_2[1]
            L3_2 = L3_2 / 2
            L4_2 = L1_2[2]
            L4_2 = L4_2 / 2
            L2_2[1] = L3_2
            L2_2[2] = L4_2
            L3_2 = ui_get
            L4_2 = script_controls
            L4_2 = L4_2.clr
            L4_2 = L4_2[2]
            L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
            L7_2 = ui_get
            L8_2 = script_controls
            L8_2 = L8_2.clr2
            L8_2 = L8_2[2]
            L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
            L11_2 = get_prop
            L12_2 = L0_2
            L13_2 = "m_flPoseParameter"
            L14_2 = 11
            L11_2 = L11_2(L12_2, L13_2, L14_2)
            L11_2 = L11_2 * 120
            L11_2 = L11_2 - 60
            L12_2 = anti_aim_state
            L12_2 = L12_2.holding_e
            if L12_2 then
                L12_2 = -1
                if not (L12_2) then
                    L12_2 = 1
                end
            else
                L12_2 = 1
            end
            L11_2 = L11_2 * L12_2
            L12_2 = 20
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "AA indicator"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = contains_value
                L14_2 = script_controls
                L14_2 = L14_2.s
                L15_2 = "Legacy arrows"
                L13_2 = L13_2(L14_2, L15_2)
                if not L13_2 then
                    L13_2 = {
                    }
                    L14_2 = camera_angles
                    L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = L14_2()
                    L13_2[1] = L14_2
                    L13_2[2] = L15_2
                    L13_2[3] = L16_2
                    L13_2[4] = L17_2
                    L13_2[5] = L18_2
                    L13_2[6] = L19_2
                    L13_2[7] = L20_2
                    L13_2[8] = L21_2
                    L13_2[9] = L22_2
                    L13_2[10] = L23_2
                    L13_2[11] = L24_2
                    L13_2[12] = L25_2
                    L13_2[13] = L26_2
                    L13_2[14] = L27_2
                    L13_2[15] = L28_2
                    L13_2[16] = L29_2
                    L13_2[17] = L30_2
                    L13_2[18] = L31_2
                    L13_2[19] = L32_2
                    L13_2[20] = L33_2
                    L14_2 = {
                    }
                    L15_2 = hitbox_position
                    L16_2 = L0_2
                    L17_2 = "head_0"
                    L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = L15_2(L16_2, L17_2)
                    L14_2[1] = L15_2
                    L14_2[2] = L16_2
                    L14_2[3] = L17_2
                    L14_2[4] = L18_2
                    L14_2[5] = L19_2
                    L14_2[6] = L20_2
                    L14_2[7] = L21_2
                    L14_2[8] = L22_2
                    L14_2[9] = L23_2
                    L14_2[10] = L24_2
                    L14_2[11] = L25_2
                    L14_2[12] = L26_2
                    L14_2[13] = L27_2
                    L14_2[14] = L28_2
                    L14_2[15] = L29_2
                    L14_2[16] = L30_2
                    L14_2[17] = L31_2
                    L14_2[18] = L32_2
                    L14_2[19] = L33_2
                    L15_2 = {
                    }
                    L16_2 = hitbox_position
                    L17_2 = L0_2
                    L18_2 = "pelvis"
                    L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = L16_2(L17_2, L18_2)
                    L15_2[1] = L16_2
                    L15_2[2] = L17_2
                    L15_2[3] = L18_2
                    L15_2[4] = L19_2
                    L15_2[5] = L20_2
                    L15_2[6] = L21_2
                    L15_2[7] = L22_2
                    L15_2[8] = L23_2
                    L15_2[9] = L24_2
                    L15_2[10] = L25_2
                    L15_2[11] = L26_2
                    L15_2[12] = L27_2
                    L15_2[13] = L28_2
                    L15_2[14] = L29_2
                    L15_2[15] = L30_2
                    L15_2[16] = L31_2
                    L15_2[17] = L32_2
                    L15_2[18] = L33_2
                    L16_2 = normalize_yaw
                    L17_2 = yaw_between_points
                    L18_2 = L15_2[1]
                    L19_2 = L15_2[2]
                    L20_2 = L14_2[1]
                    L21_2 = L14_2[2]
                    L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
                    L18_2 = L11_2 / 2
                    L17_2 = L17_2 - L18_2
                    L18_2 = L13_2[2]
                    L17_2 = L17_2 - L18_2
                    L17_2 = L17_2 + 120
                    L16_2 = L16_2(L17_2)
                    L17_2 = draw_indicator_triangle
                    L18_2 = L2_2[1]
                    L19_2 = L2_2[2]
                    L20_2 = L3_2
                    L21_2 = L4_2
                    L22_2 = L5_2
                    L23_2 = L6_2
                    L24_2 = L7_2
                    L25_2 = L8_2
                    L26_2 = L9_2
                    L27_2 = 255
                    L28_2 = L11_2 / 1.5
                    L28_2 = L16_2 + L28_2
                    L28_2 = L28_2 * -1
                    L29_2 = 60
                    if not (L11_2 < 0) then
                        L30_2 = false
                    else
                        L30_2 = true
                    end
                    L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2)
                    L12_2 = 42
                end
            end
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "Legacy arrows"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = anti_aim_state
                L13_2 = L13_2.dir
                L13_2 = L13_2.manual
                if L13_2 == 90 then
                    L13_2 = draw_text
                    L14_2 = L2_2[1]
                    L14_2 = L14_2 + 60
                    L15_2 = L2_2[2]
                    L16_2 = L3_2
                    L17_2 = L4_2
                    L18_2 = L5_2
                    L19_2 = L6_2
                    L20_2 = "c+"
                    L21_2 = 0
                    L22_2 = base64_module
                    L22_2 = L22_2.decode
                    L23_2 = "4oC6"
                    local returned_68_48 = __dec14_pack_results(L22_2(L23_2))
                    L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_48, 1, returned_68_48.n)
                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_48, 1, returned_68_48.n))
                    L13_2 = draw_text
                    L14_2 = L2_2[1]
                    L14_2 = L14_2 - 60
                    L15_2 = L2_2[2]
                    L16_2 = L7_2
                    L17_2 = L8_2
                    L18_2 = L9_2
                    L19_2 = L10_2
                    L20_2 = "c+"
                    L21_2 = 0
                    L22_2 = base64_module
                    L22_2 = L22_2.decode
                    L23_2 = "4oC5"
                    local returned_68_49 = __dec14_pack_results(L22_2(L23_2))
                    L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_49, 1, returned_68_49.n)
                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_49, 1, returned_68_49.n))
                else
                    L13_2 = anti_aim_state
                    L13_2 = L13_2.dir
                    L13_2 = L13_2.manual
                    if L13_2 == -90 then
                        L13_2 = draw_text
                        L14_2 = L2_2[1]
                        L14_2 = L14_2 - 60
                        L15_2 = L2_2[2]
                        L16_2 = L3_2
                        L17_2 = L4_2
                        L18_2 = L5_2
                        L19_2 = L6_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module
                        L22_2 = L22_2.decode
                        L23_2 = "4oC5"
                        local returned_68_50 = __dec14_pack_results(L22_2(L23_2))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_50, 1, returned_68_50.n)
                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_50, 1, returned_68_50.n))
                        L13_2 = draw_text
                        L14_2 = L2_2[1]
                        L14_2 = L14_2 + 60
                        L15_2 = L2_2[2]
                        L16_2 = L7_2
                        L17_2 = L8_2
                        L18_2 = L9_2
                        L19_2 = L10_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module
                        L22_2 = L22_2.decode
                        L23_2 = "4oC6"
                        local returned_68_51 = __dec14_pack_results(L22_2(L23_2))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_51, 1, returned_68_51.n)
                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_51, 1, returned_68_51.n))
                    else
                        L13_2 = draw_text
                        L14_2 = L2_2[1]
                        L14_2 = L14_2 - 60
                        L15_2 = L2_2[2]
                        L16_2 = L7_2
                        L17_2 = L8_2
                        L18_2 = L9_2
                        L19_2 = L10_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module
                        L22_2 = L22_2.decode
                        L23_2 = "4oC5"
                        local returned_68_52 = __dec14_pack_results(L22_2(L23_2))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_52, 1, returned_68_52.n)
                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_52, 1, returned_68_52.n))
                        L13_2 = draw_text
                        L14_2 = L2_2[1]
                        L14_2 = L14_2 + 60
                        L15_2 = L2_2[2]
                        L16_2 = L7_2
                        L17_2 = L8_2
                        L18_2 = L9_2
                        L19_2 = L10_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module
                        L22_2 = L22_2.decode
                        L23_2 = "4oC6"
                        local returned_68_53 = __dec14_pack_results(L22_2(L23_2))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_53, 1, returned_68_53.n)
                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, unpack(returned_68_53, 1, returned_68_53.n))
                    end
                end
            end
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "Name indicator"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = draw_text
                L14_2 = L2_2[1]
                L14_2 = L14_2 - 30
                L15_2 = L2_2[2]
                L15_2 = L15_2 + 20
                L16_2 = L3_2 or L16_2
                if not (0 < L11_2) or not L3_2 then
                    L16_2 = L7_2
                end
                L17_2 = L4_2 or L17_2
                if not (0 < L11_2) or not L4_2 then
                    L17_2 = L8_2
                end
                L18_2 = L5_2 or L18_2
                if not (0 < L11_2) or not L5_2 then
                    L18_2 = L9_2
                end
                L19_2 = L6_2 or L19_2
                if not (0 < L11_2) or not L6_2 then
                    L19_2 = 255
                end
                L20_2 = "b"
                L21_2 = 0
                L22_2 = "predi"
                L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                L13_2 = draw_text
                L14_2 = L2_2[1]
                L14_2 = L14_2 - 4
                L15_2 = L2_2[2]
                L15_2 = L15_2 + 20
                L16_2 = L3_2 or L16_2
                if not (L11_2 < 0) or not L3_2 then
                    L16_2 = L7_2
                end
                L17_2 = L4_2 or L17_2
                if not (L11_2 < 0) or not L4_2 then
                    L17_2 = L8_2
                end
                L18_2 = L5_2 or L18_2
                if not (L11_2 < 0) or not L5_2 then
                    L18_2 = L9_2
                end
                L19_2 = L6_2 or L19_2
                if not (L11_2 < 0) or not L6_2 then
                    L19_2 = 255
                end
                L20_2 = "b"
                L21_2 = 0
                L22_2 = "ction.lua"
                L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            end
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "Status Indicator"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = anti_aim_state
                L13_2 = L13_2.aa
                if L13_2 == 1 then
                    L13_2 = draw_text
                    L14_2 = L2_2[1]
                    L14_2 = L14_2 - 8
                    L15_2 = L2_2[2]
                    L15_2 = L15_2 + 15
                    L15_2 = L15_2 + L12_2
                    L16_2 = L3_2
                    L17_2 = L4_2
                    L18_2 = L5_2
                    L19_2 = L6_2 * 0.75
                    L20_2 = "-c"
                    L21_2 = 0
                    L22_2 = "+/- ADAPTIVE"
                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                else
                    L13_2 = anti_aim_state
                    L13_2 = L13_2.aa
                    if L13_2 == 2 then
                        L13_2 = draw_text
                        L14_2 = L2_2[1]
                        L14_2 = L14_2 - 12
                        L15_2 = L2_2[2]
                        L15_2 = L15_2 + 15
                        L15_2 = L15_2 + L12_2
                        L16_2 = L3_2
                        L17_2 = L4_2
                        L18_2 = L5_2
                        L19_2 = L6_2 * 0.75
                        L20_2 = "-c"
                        L21_2 = 0
                        L22_2 = "+/- MOVING"
                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                    else
                        L13_2 = anti_aim_state
                        L13_2 = L13_2.aa
                        if L13_2 == 3 then
                            L13_2 = draw_text
                            L14_2 = L2_2[1]
                            L14_2 = L14_2 - 4
                            L15_2 = L2_2[2]
                            L15_2 = L15_2 + 15
                            L15_2 = L15_2 + L12_2
                            L16_2 = 255
                            L17_2 = 111
                            L18_2 = 111
                            L19_2 = L6_2 * 0.75
                            L20_2 = "-c"
                            L21_2 = 0
                            L22_2 = "+/- DANGEROUS"
                            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                        else
                            L13_2 = anti_aim_state
                            L13_2 = L13_2.aa
                            if L13_2 == 4 then
                                L13_2 = draw_text
                                L14_2 = L2_2[1]
                                L14_2 = L14_2 - 21
                                L15_2 = L2_2[2]
                                L15_2 = L15_2 + 15
                                L15_2 = L15_2 + L12_2
                                L16_2 = L3_2
                                L17_2 = L4_2
                                L18_2 = L5_2
                                L19_2 = L6_2 * 0.75
                                L20_2 = "-c"
                                L21_2 = 0
                                L22_2 = "+/- AIR"
                                L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                            else
                                L13_2 = anti_aim_state
                                L13_2 = L13_2.aa
                                if L13_2 == 5 then
                                    L13_2 = draw_text
                                    L14_2 = L2_2[1]
                                    L14_2 = L14_2 - 20
                                    L15_2 = L2_2[2]
                                    L15_2 = L15_2 + 15
                                    L15_2 = L15_2 + L12_2
                                    L16_2 = L3_2
                                    L17_2 = L4_2
                                    L18_2 = L5_2
                                    L19_2 = L6_2 * 0.75
                                    L20_2 = "-c"
                                    L21_2 = 0
                                    L22_2 = "+/- USE"
                                    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                                else
                                    L13_2 = anti_aim_state
                                    L13_2 = L13_2.aa
                                    if L13_2 == 6 then
                                        L13_2 = draw_text
                                        L14_2 = L2_2[1]
                                        L14_2 = L14_2 - 9
                                        L15_2 = L2_2[2]
                                        L15_2 = L15_2 + 15
                                        L15_2 = L15_2 + L12_2
                                        L16_2 = L3_2
                                        L17_2 = L4_2
                                        L18_2 = L5_2
                                        L19_2 = L6_2 * 0.75
                                        L20_2 = "-c"
                                        L21_2 = 0
                                        L22_2 = "+/- HALFMAX"
                                        L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                                    else
                                        L13_2 = anti_aim_state
                                        L13_2 = L13_2.aa
                                        if L13_2 == 7 then
                                            L13_2 = draw_text
                                            L14_2 = L2_2[1]
                                            L14_2 = L14_2 - 10
                                            L15_2 = L2_2[2]
                                            L15_2 = L15_2 + 15
                                            L15_2 = L15_2 + L12_2
                                            L16_2 = L3_2
                                            L17_2 = L4_2
                                            L18_2 = L5_2
                                            L19_2 = L6_2 * 0.75
                                            L20_2 = "-c"
                                            L21_2 = 0
                                            L22_2 = "+/- ABUSE 0*"
                                            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                L13_2 = contains_value
                L14_2 = script_controls
                L14_2 = L14_2.s
                L15_2 = "AA indicator"
                L13_2 = L13_2(L14_2, L15_2)
                if L13_2 then
                    L13_2 = contains_value
                    L14_2 = script_controls
                    L14_2 = L14_2.s
                    L15_2 = "Legacy arrows"
                    L13_2 = L13_2(L14_2, L15_2)
                    if not L13_2 then
                        L12_2 = 45
                    end
                end
            end
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "Legacy OG Circle"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = vector_module
                L14_2 = client
                L14_2 = L14_2.camera_angles
                local returned_68_54 = __dec14_pack_results(L14_2())
                L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_54, 1, returned_68_54.n)
                L13_2 = L13_2(unpack(returned_68_54, 1, returned_68_54.n))
                L14_2 = vector_module
                L15_2 = entity
                L15_2 = L15_2.hitbox_position
                L16_2 = L0_2
                L17_2 = "head_0"
                local returned_68_55 = __dec14_pack_results(L15_2(L16_2, L17_2))
                L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_55, 1, returned_68_55.n)
                L14_2 = L14_2(unpack(returned_68_55, 1, returned_68_55.n))
                L15_2 = vector_module
                L16_2 = entity
                L16_2 = L16_2.hitbox_position
                L17_2 = L0_2
                L18_2 = "pelvis"
                local returned_68_56 = __dec14_pack_results(L16_2(L17_2, L18_2))
                L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_56, 1, returned_68_56.n)
                L15_2 = L15_2(unpack(returned_68_56, 1, returned_68_56.n))
                L16_2 = normalize_yaw
                L17_2 = yaw_between_points
                L18_2 = L15_2.x
                L19_2 = L15_2.y
                L20_2 = L14_2.x
                L21_2 = L14_2.y
                L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2)
                L18_2 = L13_2.y
                L17_2 = L17_2 - L18_2
                L17_2 = L17_2 + 120
                L16_2 = L16_2(L17_2)
                L17_2 = entity
                L17_2 = L17_2.get_prop
                L18_2 = L0_2
                L19_2 = "m_flPoseParameter"
                L20_2 = 11
                L17_2 = L17_2(L18_2, L19_2, L20_2)
                L18_2 = L17_2 * 120
                L17_2 = L18_2 - 60
                L18_2 = normalize_yaw
                L19_2 = L16_2 + L17_2
                L18_2 = L18_2(L19_2)
                L19_2 = math
                L19_2 = L19_2.abs
                L20_2 = L17_2
                L19_2 = L19_2(L20_2)
                L19_2 = L19_2 / 60
                L20_2 = scale_factor
                L21_2 = L19_2
                L20_2, L21_2, L22_2 = L20_2(L21_2)
                L23_2 = draw_circle_indicator
                L24_2 = L2_2[1]
                L25_2 = L2_2[2]
                L26_2 = L20_2
                L27_2 = L21_2
                L28_2 = L22_2
                L29_2 = 255
                L30_2 = L17_2 / 60
                L23_2(L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2)
                L23_2 = renderer
                L23_2 = L23_2.circle_outline
                L24_2 = L2_2[1]
                L25_2 = L2_2[2]
                L26_2 = L20_2
                L27_2 = L21_2
                L28_2 = L22_2
                L29_2 = 255
                L30_2 = 18
                L31_2 = L16_2 * -1
                L31_2 = L31_2 - 15
                L32_2 = 0.2
                L33_2 = 4
                L23_2(L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2)
            end
            L13_2 = contains_value
            L14_2 = script_controls
            L14_2 = L14_2.s
            L15_2 = "Keybind indicator"
            L13_2 = L13_2(L14_2, L15_2)
            if L13_2 then
                L13_2 = {
                }
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Double tap"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "DT"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.dt
                    L17_2 = L17_2[1]
                    L16_2 = L16_2(L17_2)
                    if L16_2 then
                        L16_2 = ui_get
                        L17_2 = native_controls
                        L17_2 = L17_2.dt
                        L17_2 = L17_2[2]
                        L16_2 = L16_2(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Onshot Anti-Aim"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "OS"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.os
                    L17_2 = L17_2[1]
                    L16_2 = L16_2(L17_2)
                    if L16_2 then
                        L16_2 = ui_get
                        L17_2 = native_controls
                        L17_2 = L17_2.os
                        L17_2 = L17_2[2]
                        L16_2 = L16_2(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Force body aim"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "FB"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.forcebaim
                    L16_2 = L16_2(L17_2)
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Force safe point"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "SP"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.safepoint
                    L16_2 = L16_2(L17_2)
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Edge yaw"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "EY"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.edgeyaw
                    L16_2 = L16_2(L17_2)
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Freestanding"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "FS"
                    L16_2 = contains_value
                    L17_2 = native_controls
                    L17_2 = L17_2.freestand
                    L17_2 = L17_2[1]
                    L18_2 = "Default"
                    L16_2 = L16_2(L17_2, L18_2)
                    if L16_2 then
                        L16_2 = ui_get
                        L17_2 = native_controls
                        L17_2 = L17_2.freestand
                        L17_2 = L17_2[2]
                        L16_2 = L16_2(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.k
                L16_2 = "Quick peek"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = #L13_2
                    L14_2 = L14_2 + 1
                    L15_2 = {
                    }
                    L15_2.t = "QP"
                    L16_2 = ui_get
                    L17_2 = native_controls
                    L17_2 = L17_2.quickpeek
                    L17_2 = L17_2[1]
                    L16_2 = L16_2(L17_2)
                    if L16_2 then
                        L16_2 = ui_get
                        L17_2 = native_controls
                        L17_2 = L17_2.quickpeek
                        L17_2 = L17_2[2]
                        L16_2 = L16_2(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L14_2 = contains_value
                L15_2 = script_controls
                L15_2 = L15_2.s
                L16_2 = "Status Indicator"
                L14_2 = L14_2(L15_2, L16_2)
                if L14_2 then
                    L14_2 = 1
                    L15_2 = #L13_2
                    L16_2 = 1
                    for L17_2 = L14_2, L15_2, L16_2 do
                        L18_2 = draw_text
                        L19_2 = L2_2[1]
                        L19_2 = L19_2 - 30
                        L20_2 = L2_2[2]
                        L20_2 = L20_2 + L12_2
                        L20_2 = L20_2 + 10
                        L21_2 = L17_2 * 8
                        L20_2 = L20_2 + L21_2
                        L21_2 = L13_2[L17_2]
                        L21_2 = L21_2.e
                        L21_2 = L3_2 or L21_2
                        if not L21_2 or not L3_2 then
                            L21_2 = L7_2
                        end
                        L22_2 = L13_2[L17_2]
                        L22_2 = L22_2.e
                        L22_2 = L4_2 or L22_2
                        if not L22_2 or not L4_2 then
                            L22_2 = L8_2
                        end
                        L23_2 = L13_2[L17_2]
                        L23_2 = L23_2.e
                        L23_2 = L5_2 or L23_2
                        if not L23_2 or not L5_2 then
                            L23_2 = L9_2
                        end
                        L24_2 = L13_2[L17_2]
                        L24_2 = L24_2.e
                        L24_2 = L6_2 or L24_2
                        if not L24_2 or not L6_2 then
                            L24_2 = L10_2 * 0.75
                        end
                        L25_2 = "-"
                        L26_2 = 0
                        L27_2 = L13_2[L17_2]
                        L27_2 = L27_2.t
                        L18_2(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2)
                    end
                else
                    L14_2 = 1
                    L15_2 = #L13_2
                    L16_2 = 1
                    for L17_2 = L14_2, L15_2, L16_2 do
                        L18_2 = draw_text
                        L19_2 = L2_2[1]
                        L19_2 = L19_2 - 1
                        L20_2 = L2_2[2]
                        L20_2 = L20_2 + L12_2
                        L20_2 = L20_2 + 7
                        L21_2 = L17_2 * 8
                        L20_2 = L20_2 + L21_2
                        L21_2 = L13_2[L17_2]
                        L21_2 = L21_2.e
                        L21_2 = L3_2 or L21_2
                        if not L21_2 or not L3_2 then
                            L21_2 = L7_2
                        end
                        L22_2 = L13_2[L17_2]
                        L22_2 = L22_2.e
                        L22_2 = L4_2 or L22_2
                        if not L22_2 or not L4_2 then
                            L22_2 = L8_2
                        end
                        L23_2 = L13_2[L17_2]
                        L23_2 = L23_2.e
                        L23_2 = L5_2 or L23_2
                        if not L23_2 or not L5_2 then
                            L23_2 = L9_2
                        end
                        L24_2 = L13_2[L17_2]
                        L24_2 = L24_2.e
                        L24_2 = L6_2 or L24_2
                        if not L24_2 or not L6_2 then
                            L24_2 = L10_2 * 0.75
                        end
                        L25_2 = "c-"
                        L26_2 = 0
                        L27_2 = L13_2[L17_2]
                        L27_2 = L27_2.t
                        L18_2(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2)
                    end
                end
            end
        end
    end
    update_ui_visibility = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.la
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Custom Legit AA"
        local returned_69_57 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_57, 1, returned_69_57.n)
        L0_2(L1_2, unpack(returned_69_57, 1, returned_69_57.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.ml
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Manual AA"
        local returned_69_58 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_58, 1, returned_69_58.n)
        L0_2(L1_2, unpack(returned_69_58, 1, returned_69_58.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.mr
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Manual AA"
        local returned_69_59 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_59, 1, returned_69_59.n)
        L0_2(L1_2, unpack(returned_69_59, 1, returned_69_59.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.mf
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Manual AA"
        local returned_69_60 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_60, 1, returned_69_60.n)
        L0_2(L1_2, unpack(returned_69_60, 1, returned_69_60.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.fs
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Freestanding"
        local returned_69_61 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_61, 1, returned_69_61.n)
        L0_2(L1_2, unpack(returned_69_61, 1, returned_69_61.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.ey
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Edge yaw"
        local returned_69_62 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_62, 1, returned_69_62.n)
        L0_2(L1_2, unpack(returned_69_62, 1, returned_69_62.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.k
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "Keybind indicator"
        local returned_69_63 = __dec14_pack_results(L2_2(L3_2, L4_2))
        L2_2, L3_2, L4_2 = unpack(returned_69_63, 1, returned_69_63.n)
        L0_2(L1_2, unpack(returned_69_63, 1, returned_69_63.n))
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.clr
        L1_2 = L1_2[1]
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "AA indicator"
        L2_2 = L2_2(L3_2, L4_2)
        if not L2_2 then
            L2_2 = contains_value
            L3_2 = script_controls
            L3_2 = L3_2.s
            L4_2 = "Keybind indicator"
            L2_2 = L2_2(L3_2, L4_2)
            if not L2_2 then
                L2_2 = contains_value
                L3_2 = script_controls
                L3_2 = L3_2.s
                L4_2 = "Name indicator"
                L2_2 = L2_2(L3_2, L4_2)
            end
        end
        L0_2(L1_2, L2_2)
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.clr
        L1_2 = L1_2[2]
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "AA indicator"
        L2_2 = L2_2(L3_2, L4_2)
        if not L2_2 then
            L2_2 = contains_value
            L3_2 = script_controls
            L3_2 = L3_2.s
            L4_2 = "Keybind indicator"
            L2_2 = L2_2(L3_2, L4_2)
            if not L2_2 then
                L2_2 = contains_value
                L3_2 = script_controls
                L3_2 = L3_2.s
                L4_2 = "Name indicator"
                L2_2 = L2_2(L3_2, L4_2)
            end
        end
        L0_2(L1_2, L2_2)
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.clr2
        L1_2 = L1_2[1]
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "AA indicator"
        L2_2 = L2_2(L3_2, L4_2)
        if not L2_2 then
            L2_2 = contains_value
            L3_2 = script_controls
            L3_2 = L3_2.s
            L4_2 = "Keybind indicator"
            L2_2 = L2_2(L3_2, L4_2)
            if not L2_2 then
                L2_2 = contains_value
                L3_2 = script_controls
                L3_2 = L3_2.s
                L4_2 = "Name indicator"
                L2_2 = L2_2(L3_2, L4_2)
            end
        end
        L0_2(L1_2, L2_2)
        L0_2 = ui_set_visible
        L1_2 = script_controls
        L1_2 = L1_2.clr2
        L1_2 = L1_2[2]
        L2_2 = contains_value
        L3_2 = script_controls
        L3_2 = L3_2.s
        L4_2 = "AA indicator"
        L2_2 = L2_2(L3_2, L4_2)
        if not L2_2 then
            L2_2 = contains_value
            L3_2 = script_controls
            L3_2 = L3_2.s
            L4_2 = "Keybind indicator"
            L2_2 = L2_2(L3_2, L4_2)
            if not L2_2 then
                L2_2 = contains_value
                L3_2 = script_controls
                L3_2 = L3_2.s
                L4_2 = "Name indicator"
                L2_2 = L2_2(L3_2, L4_2)
            end
        end
        L0_2(L1_2, L2_2)
        L0_2 = set_native_ui_visible
        L1_2 = false
        L0_2(L1_2)
    end
    whitelisted = false
    panorama_api = panorama
    register_events_if_whitelisted = "open"
    panorama_api = panorama_api[register_events_if_whitelisted]
    panorama_api = panorama_api()
    register_events_if_whitelisted = function(...)
        local L0_2, L1_2, L2_2
        L0_2 = whitelisted
        if not L0_2 then
            L0_2 = client
            L0_2 = L0_2.set_event_callback
            L1_2 = "paint_ui"
            L2_2 = function(...)
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
                L0_3 = renderer
                L0_3 = L0_3.indicator
                L1_3 = 255
                L2_3 = 0
                L3_3 = 0
                L4_3 = 255
                L5_3 = "[amgis corporations] prediction not whitelisted on this account - check console"
                L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
            end
            L0_2(L1_2, L2_2)
            L0_2 = panorama_api
            L0_2 = L0_2.MyPersonaAPI
            L0_2 = L0_2.GetXuid
            L0_2 = L0_2()
            steam = L0_2
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            L0_2 = client
            L0_2 = L0_2.log
            L1_2 = "You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> "
            L2_2 = steam
            L1_2 = L1_2..L2_2
            L0_2(L1_2)
            return 
        end
        L0_2 = client
        L0_2 = L0_2.log
        L1_2 = "[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"
        L0_2(L1_2)
        L0_2 = client
        L0_2 = L0_2.log
        L1_2 = "[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"
        L0_2(L1_2)
        L0_2 = client
        L0_2 = L0_2.log
        L1_2 = "[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"
        L0_2(L1_2)
        L0_2 = client
        L0_2 = L0_2.log
        L1_2 = "[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"
        L0_2(L1_2)
        L0_2 = update_ui_visibility
        L0_2()
        L0_2 = ui_set_callback
        L1_2 = script_controls
        L1_2 = L1_2.s
        L2_2 = update_ui_visibility
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "shutdown"
        L2_2 = set_native_ui_visible
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "paint"
        L2_2 = draw_indicators
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "bullet_impact"
        L2_2 = on_bullet_impact
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "player_hurt"
        L2_2 = on_player_hurt
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "setup_command"
        L2_2 = apply_body_yaw
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "player_spawn"
        L2_2 = on_player_spawn
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "client_disconnect"
        L2_2 = reset_player_state
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "cs_game_disconnected"
        L2_2 = reset_player_state
        L0_2(L1_2, L2_2)
        L0_2 = set_event_callback
        L1_2 = "game_newmap"
        L2_2 = reset_player_state
        L0_2(L1_2, L2_2)
    end
    request_whitelist = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2
        L0_2 = http_module
        L0_2 = L0_2.get
        L1_2 = string
        L1_2 = L1_2.format
        L2_2 = "https://gs.shav.it/check?auth=%s&id=%s"
        L3_2 = database
        L3_2 = L3_2.read
        L4_2 = "prediction_auth"
        L3_2 = L3_2(L4_2)
        if not L3_2 then
            L3_2 = ""
        end
        L4_2 = panorama_api
        L4_2 = L4_2.MyPersonaAPI
        L4_2 = L4_2.GetXuid
        L4_2 = L4_2()
        L1_2 = L1_2(L2_2, L3_2, L4_2)
        L2_2 = function(A0_3, A1_3, ...)
            local L2_3, L3_3, L4_3
            if not A0_3 then
                return 
            else
                L2_3 = A1_3.status
                if L2_3 ~= 200 then
                    L2_3 = A1_3.status
                    if not (L2_3 ~= 201) then
                        L2_3 = true
                        whitelisted = L2_3
                    end
                else
                    L2_3 = true
                    whitelisted = L2_3
                end
                L2_3 = A1_3.status
                if L2_3 == 201 then
                    L2_3 = database
                    L2_3 = L2_3.write
                    L3_3 = "prediction_auth"
                    L4_3 = A1_3.body
                    L2_3(L3_3, L4_3)
                end
                L2_3 = register_events_if_whitelisted
                L2_3()
            end
        end
        L0_2(L1_2, L2_2)
        L0_2 = false
        return L0_2
    end
    fake_yaw_limit = request_whitelist
    fake_yaw_limit()
    fake_yaw_limit = ui
    fake_yaw_limit = fake_yaw_limit.reference
    screen_dimensions = "aa"
    screen_center = "Anti-aimbot angles"
    draw_branding = "Fake yaw limit"
    fake_yaw_limit = fake_yaw_limit(screen_dimensions, screen_center, draw_branding)
    screen_dimensions = {
    }
    screen_center = client
    screen_center = screen_center.screen_size
    screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = screen_center()
    screen_dimensions[1] = screen_center
    screen_dimensions[2] = draw_branding
    screen_dimensions[3] = L123_1
    screen_dimensions[4] = L124_1
    screen_dimensions[5] = L125_1
    screen_dimensions[6] = L126_1
    screen_dimensions[7] = L127_1
    screen_dimensions[8] = L128_1
    screen_dimensions[9] = L129_1
    screen_dimensions[10] = L130_1
    screen_dimensions[11] = L131_1
    screen_dimensions[12] = L132_1
    screen_dimensions[13] = L133_1
    screen_dimensions[14] = L134_1
    screen_dimensions[15] = L135_1
    screen_center = {
    }
    draw_branding = 1
    draw_branding = screen_dimensions[draw_branding]
    L123_1 = 2
    draw_branding = draw_branding / L123_1
    L123_1 = 2
    L123_1 = screen_dimensions[L123_1]
    L124_1 = 2
    L123_1 = L123_1 / L124_1
    screen_center[1] = draw_branding
    screen_center[2] = L123_1
    draw_branding = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L0_2 = renderer
        L0_2 = L0_2.text
        L1_2 = screen_dimensions
        L1_2 = L1_2[1]
        L1_2 = L1_2 - 92
        L2_2 = 0
        L3_2 = 255
        L4_2 = 255
        L5_2 = 255
        L6_2 = 255
        L7_2 = nil
        L8_2 = 0
        L9_2 = "shoppy.gg/"
        L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
        L0_2 = renderer
        L0_2 = L0_2.text
        L1_2 = screen_dimensions
        L1_2 = L1_2[1]
        L1_2 = L1_2 - 40
        L2_2 = 0
        L3_2 = 50
        L4_2 = 255
        L5_2 = 50
        L6_2 = 255
        L7_2 = nil
        L8_2 = 0
        L9_2 = "@amgis"
        L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    end
    L123_1 = client
    L123_1 = L123_1.set_event_callback
    L124_1 = "paint"
    L125_1 = draw_branding
    L123_1(L124_1, L125_1)
end
return main(...)
