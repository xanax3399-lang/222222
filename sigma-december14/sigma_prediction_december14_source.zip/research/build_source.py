from pathlib import Path
import json,hashlib,re
R=Path(__file__).resolve().parent
original=(R/'original.lua').read_text()
prefix=original.split('return(function(S,e,Q,',1)[0]
body=(R/'recovered.editable.lua').read_text().split('\n',1)[1]
body='\n'.join(line.rstrip()for line in body.splitlines())+'\n'
def alpha_names(text):
 def token(m):
  word=m[0]
  match=re.fullmatch(r'([LA])(\d+)_(\d+)',word)
  if match:return ('value_'if match[1]=='L'else 'argument_')+match[2]+'_'+match[3]
  return word
 return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*',token,text)
body=alpha_names(body)
(R/'final.helper_instrumented.lua').write_text(alpha_names((R/'recovered.editable_instrumented.lua').read_text()))
text='-- Sigma Prediction Dec. 14, 2021: all 75 recovered application bodies.\n-- PSU VM and byte stream removed; names inferred. See README_RU.txt.\n'+prefix+'''local function __dec14_pack_results(...)
    return {n = select('#', ...), ...}
end

'''+body
(R/'sigma_prediction_december14_source.lua').write_text(text)
print('Built',len(text.splitlines()),'lines; SHA256',hashlib.sha256(text.encode()).hexdigest())
