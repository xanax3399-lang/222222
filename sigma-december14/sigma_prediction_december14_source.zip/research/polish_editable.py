from pathlib import Path
import readability as O,json
R=Path(__file__).resolve().parent
O.transform(R/'recovered.lexical.lua',R/'recovered.editable.lua')
O.transform(R/'recovered.test_instrumented.lua',R/'recovered.editable_instrumented.lua')
(R/'readability_report.json').write_text(json.dumps(O.statistics,indent=2)+'\n')
