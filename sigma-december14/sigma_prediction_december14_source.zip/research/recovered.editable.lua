-- Reconstructed editable Lua. Names inferred from use; see README_EDITABLE_RU.txt.
local function main(...)
    local http_module, vector_module, get_value_type, set_metatable, to_string, math_pi, math_min, math_max, math_degrees, math_radians, math_square_root, math_sine, math_cosine, math_arctangent, math_arccosine, math_remainder, vector_metatable, base64_module, extract_bits, base64_encoder, base64_decoder, string_char, table_concat, bit_band, camera_angles, eye_position, key_state, scale_damage, screen_size, set_event_callback, trace_bullet, trace_line, userid_to_entindex, get_all_entities, get_classname, get_local_player, get_player_resource, get_players, get_prop, hitbox_position, is_alive, is_dormant, is_enemy, curtime, tickcount, tickinterval, math_abs, math_atan, math_atan2, math_cos, math_deg, math_rad, math_sin, math_sqrt, draw_gradient, draw_line, draw_text, draw_triangle, table_remove, ui_get, ui_new_color_picker, ui_new_hotkey, ui_new_label, ui_new_multiselect, ui_reference, ui_set, ui_set_callback, ui_set_visible, type_alias, ui_new_slider, native_controls, set_native_ui_visible, script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1
    http_module = require(("gamesense/http"))
    vector_module = require(("vector"))
    get_value_type = type
    set_metatable = setmetatable
    to_string = tostring
    math_pi = math.pi
    math_min = math.min
    math_max = math.max
    math_degrees = math.deg
    math_radians = math.rad
    math_square_root = math.sqrt
    math_sine = math.sin
    math_cosine = math.cos
    math_arctangent = math.atan
    math_arccosine = math.acos
    math_remainder = math.fmod
    vector_metatable = {
    }
    vector_metatable.__index = vector_metatable
    Vector3 = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2
        L3_2 = get_value_type(A0_2)
        if L3_2 ~= "number" then
            A0_2 = 0
        end
        L3_2 = get_value_type(A1_2)
        if L3_2 ~= "number" then
            A1_2 = 0
        end
        L3_2 = get_value_type(A2_2)
        if L3_2 ~= "number" then
            A2_2 = 0
        end
        if not A0_2 then
            A0_2 = 0
        end
        if not A1_2 then
            A1_2 = 0
        end
        if not A2_2 then
            A2_2 = 0
        end
        L4_2 = {
        }
        L4_2.x = A0_2
        L4_2.y = A1_2
        L4_2.z = A2_2
        return set_metatable(L4_2, vector_metatable)
    end
    vector_metatable.__eq = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        L2_2 = A0_2.x
        L3_2 = A1_2.x
        if L2_2 == L3_2 then
            L2_2 = A0_2.y
            L3_2 = A1_2.y
            if L2_2 == L3_2 then
                L2_2 = A0_2.z
                L3_2 = A1_2.z
                if L2_2 == L3_2 then
                    L2_2 = true
                else
                    L2_2 = false
                end
            else
                L2_2 = false
            end
        else
            L2_2 = false
        end
        return L2_2
    end
    vector_metatable.__unm = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2
        L1_2 = Vector3
        L2_2 = -(A0_2.x)
        L3_2 = -(A0_2.y)
        L4_2 = -(A0_2.z)
        return L1_2(L2_2, L3_2, L4_2)
    end
    vector_metatable.__add = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type(A0_2)
        L3_2 = get_value_type(A1_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 + L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 + L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 + L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = (A0_2.x) + A1_2
            L6_2 = (A0_2.y) + A1_2
            L7_2 = (A0_2.z) + A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 + L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 + L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 + L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__sub = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type(A0_2)
        L3_2 = get_value_type(A1_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 - L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 - L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 - L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = (A0_2.x) - A1_2
            L6_2 = (A0_2.y) - A1_2
            L7_2 = (A0_2.z) - A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 - L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 - L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 - L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__mul = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type(A0_2)
        L3_2 = get_value_type(A1_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 * L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 * L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 * L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = (A0_2.x) * A1_2
            L6_2 = (A0_2.y) * A1_2
            L7_2 = (A0_2.z) * A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 * L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 * L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 * L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__div = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L2_2 = get_value_type(A0_2)
        L3_2 = get_value_type(A1_2)
        if L2_2 == "table" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A0_2.x
            L6_2 = A1_2.x
            L5_2 = L5_2 / L6_2
            L6_2 = A0_2.y
            L7_2 = A1_2.y
            L6_2 = L6_2 / L7_2
            L7_2 = A0_2.z
            L8_2 = A1_2.z
            L7_2 = L7_2 / L8_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "table" and L3_2 == "number" then
            L4_2 = Vector3
            L5_2 = (A0_2.x) / A1_2
            L6_2 = (A0_2.y) / A1_2
            L7_2 = (A0_2.z) / A1_2
            return L4_2(L5_2, L6_2, L7_2)
        end
        if L2_2 == "number" and L3_2 == "table" then
            L4_2 = Vector3
            L5_2 = A1_2.x
            L5_2 = A0_2 / L5_2
            L6_2 = A1_2.y
            L6_2 = A0_2 / L6_2
            L7_2 = A1_2.z
            L7_2 = A0_2 / L7_2
            return L4_2(L5_2, L6_2, L7_2)
        end
    end
    vector_metatable.__tostring = function(A0_2, ...)
        local L1_2, L2_2, L4_2, L6_2
        L2_2 = A0_2.x
        L4_2 = A0_2.y
        L6_2 = A0_2.z
        L1_2 = ("( ")..L2_2..(", ")..L4_2..(", ")..L6_2..(" )")
        return L1_2
    end
    vector_metatable.clear = function(A0_2, ...)
        A0_2.x = 0
        A0_2.y = 0
        A0_2.z = 0
    end
    vector_metatable.unpack = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.y
        L3_2 = A0_2.z
        return L1_2, L2_2, L3_2
    end
    vector_metatable.length_2d_sqr = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.x
        L1_2 = L1_2 * L2_2
        L2_2 = A0_2.y
        L3_2 = A0_2.y
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        return L1_2
    end
    vector_metatable.length_sqr = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = A0_2.x
        L2_2 = A0_2.x
        L1_2 = L1_2 * L2_2
        L2_2 = A0_2.y
        L3_2 = A0_2.y
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        L2_2 = A0_2.z
        L3_2 = A0_2.z
        L2_2 = L2_2 * L3_2
        L1_2 = L1_2 + L2_2
        return L1_2
    end
    vector_metatable.length_2d = function(A0_2, ...)
        local L2_2, L3_2
        L2_2 = A0_2.length_2d_sqr
        local returned_13_0 = __dec14_pack_results(L2_2(A0_2))
        L2_2, L3_2 = unpack(returned_13_0, 1, returned_13_0.n)
        return math_square_root(unpack(returned_13_0, 1, returned_13_0.n))
    end
    vector_metatable.length = function(A0_2, ...)
        local L2_2, L3_2
        L2_2 = A0_2.length_sqr
        local returned_14_1 = __dec14_pack_results(L2_2(A0_2))
        L2_2, L3_2 = unpack(returned_14_1, 1, returned_14_1.n)
        return math_square_root(unpack(returned_14_1, 1, returned_14_1.n))
    end
    vector_metatable.dot = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2
        L2_2 = A0_2.x
        L3_2 = A1_2.x
        L2_2 = L2_2 * L3_2
        L3_2 = A0_2.y
        L4_2 = A1_2.y
        L3_2 = L3_2 * L4_2
        L2_2 = L2_2 + L3_2
        L3_2 = A0_2.z
        L4_2 = A1_2.z
        L3_2 = L3_2 * L4_2
        L2_2 = L2_2 + L3_2
        return L2_2
    end
    vector_metatable.cross = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
        L2_2 = Vector3
        L3_2 = A0_2.y
        L4_2 = A1_2.z
        L3_2 = L3_2 * L4_2
        L4_2 = A0_2.z
        L5_2 = A1_2.y
        L4_2 = L4_2 * L5_2
        L3_2 = L3_2 - L4_2
        L4_2 = A0_2.z
        L5_2 = A1_2.x
        L4_2 = L4_2 * L5_2
        L5_2 = A0_2.x
        L6_2 = A1_2.z
        L5_2 = L5_2 * L6_2
        L4_2 = L4_2 - L5_2
        L5_2 = A0_2.x
        L6_2 = A1_2.y
        L5_2 = L5_2 * L6_2
        L6_2 = A0_2.y
        L7_2 = A1_2.x
        L6_2 = L6_2 * L7_2
        L5_2 = L5_2 - L6_2
        return L2_2(L3_2, L4_2, L5_2)
    end
    vector_metatable.dist_to = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        L2_2 = A1_2 - A0_2
        L3_2 = L2_2
        L2_2 = L2_2.length
        return L2_2(L3_2)
    end
    vector_metatable.is_zero = function(A0_2, A1_2, ...)
        local L2_2, L3_2
        if not A1_2 then
            A1_2 = 0.001
        end
        L2_2 = A0_2.x
        if A1_2 > L2_2 then
            L2_2 = A0_2.x
            L3_2 = -A1_2
            if L2_2 > L3_2 then
                L2_2 = A0_2.y
                if A1_2 > L2_2 then
                    L2_2 = A0_2.y
                    L3_2 = -A1_2
                    if L2_2 > L3_2 then
                        L2_2 = A0_2.z
                        if A1_2 > L2_2 then
                            L2_2 = A0_2.z
                            L3_2 = -A1_2
                            if L2_2 > L3_2 then
                                return true
                            end
                        end
                    end
                end
            end
        end
        return false
    end
    vector_metatable.normalize = function(A0_2, ...)
        local L1_2
        L1_2 = (A0_2.length)(A0_2)
        if L1_2 <= 0 then
            return 0
        end
        A0_2.x = (A0_2.x) / L1_2
        A0_2.y = (A0_2.y) / L1_2
        A0_2.z = (A0_2.z) / L1_2
        return L1_2
    end
    vector_metatable.normalize_no_len = function(A0_2, ...)
        local L1_2
        L1_2 = (A0_2.length)(A0_2)
        if L1_2 <= 0 then
            return 
        end
        A0_2.x = (A0_2.x) / L1_2
        A0_2.y = (A0_2.y) / L1_2
        A0_2.z = (A0_2.z) / L1_2
    end
    vector_metatable.normalized = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2
        L1_2 = (A0_2.length)(A0_2)
        if L1_2 <= 0 then
            return Vector3()
        end
        L2_2 = Vector3
        L3_2 = (A0_2.x) / L1_2
        L4_2 = (A0_2.y) / L1_2
        L5_2 = (A0_2.z) / L1_2
        return L2_2(L3_2, L4_2, L5_2)
    end
    clamp = function(A0_2, A1_2, A2_2, ...)
        if A0_2 < A1_2 then
            return A1_2
        end
        if A2_2 < A0_2 then
            return A2_2
        end
        return A0_2
    end
    normalize_angle = function(A0_2, ...)
        local L1_2, L3_2, L4_2, L5_2
        L3_2 = to_string(A0_2)
        if L3_2 == "nan" or L3_2 == "inf" then
            return 0
        end
        if -180 <= A0_2 and A0_2 <= 180 then
            return A0_2
        end
        L5_2 = A0_2 + 360
        L4_2 = math_remainder(L5_2, 360)
        L3_2 = math_remainder(L4_2, 360)
        L1_2 = L3_2
        if 180 < L3_2 then
            L1_2 = L3_2 - 360
        end
        return L1_2
    end
    vector_to_angle = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
        L4_2 = (A0_2.length)(A0_2)
        L1_2 = L4_2
        if 0 < L4_2 then
            L6_2 = -(A0_2.z)
            local returned_24_2 = __dec14_pack_results(math_arctangent(L6_2, L1_2))
            L5_2, L6_2, L7_2 = unpack(returned_24_2, 1, returned_24_2.n)
            L2_2 = math_degrees(unpack(returned_24_2, 1, returned_24_2.n))
            L6_2 = A0_2.y
            L7_2 = A0_2.x
            local returned_24_3 = __dec14_pack_results(math_arctangent(L6_2, L7_2))
            L5_2, L6_2, L7_2 = unpack(returned_24_3, 1, returned_24_3.n)
            L3_2 = math_degrees(unpack(returned_24_3, 1, returned_24_3.n))
        else
            L4_2 = A0_2.x
            if 0 < L4_2 then
                L2_2 = 270
            else
                L2_2 = 90
            end
            L3_2 = 0
        end
        return Vector3(L2_2, L3_2, 0)
    end
    angle_forward = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L3_2 = A0_2.x
        local returned_25_4 = __dec14_pack_results(math_radians(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_4, 1, returned_25_4.n)
        L1_2 = math_sine(unpack(returned_25_4, 1, returned_25_4.n))
        L4_2 = A0_2.x
        local returned_25_5 = __dec14_pack_results(math_radians(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_5, 1, returned_25_5.n)
        L2_2 = math_cosine(unpack(returned_25_5, 1, returned_25_5.n))
        L5_2 = A0_2.y
        local returned_25_6 = __dec14_pack_results(math_radians(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_6, 1, returned_25_6.n)
        L3_2 = math_sine(unpack(returned_25_6, 1, returned_25_6.n))
        L6_2 = A0_2.y
        local returned_25_7 = __dec14_pack_results(math_radians(L6_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_25_7, 1, returned_25_7.n)
        L4_2 = math_cosine(unpack(returned_25_7, 1, returned_25_7.n))
        L5_2 = Vector3
        L6_2 = L2_2 * L4_2
        L7_2 = L2_2 * L3_2
        L8_2 = -L1_2
        return L5_2(L6_2, L7_2, L8_2)
    end
    angle_right = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L3_2 = A0_2.x
        local returned_26_8 = __dec14_pack_results(math_radians(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_8, 1, returned_26_8.n)
        L1_2 = math_sine(unpack(returned_26_8, 1, returned_26_8.n))
        L4_2 = A0_2.x
        local returned_26_9 = __dec14_pack_results(math_radians(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_9, 1, returned_26_9.n)
        L2_2 = math_cosine(unpack(returned_26_9, 1, returned_26_9.n))
        L5_2 = A0_2.y
        local returned_26_10 = __dec14_pack_results(math_radians(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_10, 1, returned_26_10.n)
        L3_2 = math_sine(unpack(returned_26_10, 1, returned_26_10.n))
        L6_2 = A0_2.y
        local returned_26_11 = __dec14_pack_results(math_radians(L6_2))
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_11, 1, returned_26_11.n)
        L4_2 = math_cosine(unpack(returned_26_11, 1, returned_26_11.n))
        L7_2 = A0_2.z
        local returned_26_12 = __dec14_pack_results(math_radians(L7_2))
        L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_12, 1, returned_26_12.n)
        L5_2 = math_sine(unpack(returned_26_12, 1, returned_26_12.n))
        L8_2 = A0_2.z
        local returned_26_13 = __dec14_pack_results(math_radians(L8_2))
        L7_2, L8_2, L9_2, L10_2 = unpack(returned_26_13, 1, returned_26_13.n)
        L6_2 = math_cosine(unpack(returned_26_13, 1, returned_26_13.n))
        L7_2 = Vector3
        L8_2 = ((-1 * L5_2) * L1_2) * L4_2
        L9_2 = -1 * L6_2
        L10_2 = -L3_2
        L9_2 = L9_2 * L10_2
        L8_2 = L8_2 + L9_2
        L9_2 = ((-1 * L5_2) * L1_2) * L3_2
        L10_2 = (-1 * L6_2) * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = (-1 * L5_2) * L2_2
        return L7_2(L8_2, L9_2, L10_2)
    end
    angle_up = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L3_2 = A0_2.x
        local returned_27_14 = __dec14_pack_results(math_radians(L3_2))
        L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_14, 1, returned_27_14.n)
        L1_2 = math_sine(unpack(returned_27_14, 1, returned_27_14.n))
        L4_2 = A0_2.x
        local returned_27_15 = __dec14_pack_results(math_radians(L4_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_15, 1, returned_27_15.n)
        L2_2 = math_cosine(unpack(returned_27_15, 1, returned_27_15.n))
        L5_2 = A0_2.y
        local returned_27_16 = __dec14_pack_results(math_radians(L5_2))
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_16, 1, returned_27_16.n)
        L3_2 = math_sine(unpack(returned_27_16, 1, returned_27_16.n))
        L6_2 = A0_2.y
        local returned_27_17 = __dec14_pack_results(math_radians(L6_2))
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_17, 1, returned_27_17.n)
        L4_2 = math_cosine(unpack(returned_27_17, 1, returned_27_17.n))
        L7_2 = A0_2.z
        local returned_27_18 = __dec14_pack_results(math_radians(L7_2))
        L6_2, L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_18, 1, returned_27_18.n)
        L5_2 = math_sine(unpack(returned_27_18, 1, returned_27_18.n))
        L8_2 = A0_2.z
        local returned_27_19 = __dec14_pack_results(math_radians(L8_2))
        L7_2, L8_2, L9_2, L10_2 = unpack(returned_27_19, 1, returned_27_19.n)
        L6_2 = math_cosine(unpack(returned_27_19, 1, returned_27_19.n))
        L7_2 = Vector3
        L8_2 = (L6_2 * L1_2) * L4_2
        L9_2 = -L5_2
        L10_2 = -L3_2
        L9_2 = L9_2 * L10_2
        L8_2 = L8_2 + L9_2
        L9_2 = (L6_2 * L1_2) * L3_2
        L10_2 = (-L5_2) * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = L6_2 * L2_2
        return L7_2(L8_2, L9_2, L10_2)
    end
    get_FOV = function(A0_2, A1_2, A2_2, ...)
        local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
        L4_2 = angle_forward(A0_2)
        L7_2 = A2_2 - A1_2
        L8_2 = L7_2
        L5_2 = (L7_2.normalized)(L8_2)
        L8_2 = (L4_2.dot)(L4_2, L5_2)
        L9_2 = (L5_2.length)(L5_2)
        L8_2 = L8_2 / L9_2
        L6_2 = math_arccosine(L8_2)
        local returned_28_20 = __dec14_pack_results(math_degrees(L6_2))
        L9_2, L10_2 = unpack(returned_28_20, 1, returned_28_20.n)
        return math_max(0, unpack(returned_28_20, 1, returned_28_20.n))
    end
    base64_module = {
    }
    extract_bits = _G.bit32
    if extract_bits then
        extract_bits = (_G.bit32).extract
    end
    if not extract_bits then
        base64_encoder = _G.bit
        if base64_encoder then
            local captured_bit_lshift, captured_bit_rshift, captured_bit_band
            captured_bit_lshift = (_G.bit).lshift
            captured_bit_rshift = (_G.bit).rshift
            captured_bit_band = (_G.bit).band
            extract_bits = function(A0_2, A1_2, A2_2, ...)
                local L4_2, L5_2
                L4_2 = captured_bit_rshift(A0_2, A1_2)
                L5_2 = (captured_bit_lshift(1, A2_2)) - 1
                return captured_bit_band(L4_2, L5_2)
            end
        else
            base64_encoder = _G._VERSION
            if base64_encoder == "Lua 5.1" then
                extract_bits = function(A0_2, A1_2, A2_2, ...)
                    local L3_2, L4_2, L6_2, L8_2, L9_2, L10_2
                    L3_2 = 0
                    L4_2 = 2 ^ A1_2
                    L6_2 = A2_2 - 1
                    for L8_2 = 0, L6_2, 1 do
                        L9_2 = L4_2 + L4_2
                        L10_2 = A0_2 % L9_2
                        if L4_2 <= L10_2 then
                            L10_2 = 2 ^ L8_2
                            L3_2 = L3_2 + L10_2
                        end
                        L4_2 = L9_2
                    end
                    return L3_2
                end
            else
                extract_bits = (load(("return function( v, from, width ) return ( v >> from ) & ((1 << width) - 1) end")))()
            end
        end
    end
    base64_module.makeencoder = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L17_2, L18_2, L19_2
        L3_2 = {
        }
        L4_2 = pairs
        L5_2 = {
        }
        L5_2[0] = "A"
        L5_2[1] = ("B")
        L5_2[2] = ("C")
        L5_2[3] = ("D")
        L5_2[4] = ("E")
        L5_2[5] = ("F")
        L5_2[6] = ("G")
        L5_2[7] = ("H")
        L5_2[8] = ("I")
        L5_2[9] = ("J")
        L5_2[10] = ("K")
        L5_2[11] = ("L")
        L5_2[12] = ("M")
        L5_2[13] = ("N")
        L5_2[14] = ("O")
        L5_2[15] = ("P")
        L5_2[16] = ("Q")
        L5_2[17] = ("R")
        L5_2[18] = ("S")
        L5_2[19] = ("T")
        L5_2[20] = ("U")
        L5_2[21] = ("V")
        L5_2[22] = ("W")
        L5_2[23] = ("X")
        L5_2[24] = ("Y")
        L5_2[25] = ("Z")
        L5_2[26] = ("a")
        L5_2[27] = ("b")
        L5_2[28] = ("c")
        L5_2[29] = ("d")
        L5_2[30] = ("e")
        L5_2[31] = ("f")
        L5_2[32] = ("g")
        L5_2[33] = ("h")
        L5_2[34] = ("i")
        L5_2[35] = ("j")
        L5_2[36] = ("k")
        L5_2[37] = ("l")
        L5_2[38] = ("m")
        L5_2[39] = ("n")
        L5_2[40] = ("o")
        L5_2[41] = ("p")
        L5_2[42] = ("q")
        L5_2[43] = ("r")
        L5_2[44] = ("s")
        L5_2[45] = ("t")
        L5_2[46] = ("u")
        L5_2[47] = ("v")
        L5_2[48] = ("w")
        L5_2[49] = ("x")
        L5_2[50] = ("y")
        L7_2 = "0"
        L8_2 = "1"
        L9_2 = "2"
        L10_2 = "3"
        L17_2 = A0_2 or ("M")
        if not A0_2 then
            L17_2 = "+"
        end
        L18_2 = A1_2 or ("N")
        if not A1_2 then
            L18_2 = "/"
        end
        L19_2 = A2_2 or ("O")
        if not A2_2 then
            L19_2 = "="
        end
        L5_2[51] = ("z")
        L5_2[52] = ("0")
        L5_2[53] = ("1")
        L5_2[54] = ("2")
        L5_2[55] = ("3")
        L5_2[56] = ("4")
        L5_2[57] = ("5")
        L5_2[58] = ("6")
        L5_2[59] = ("7")
        L5_2[60] = ("8")
        L5_2[61] = ("9")
        L5_2[62] = L17_2
        L5_2[63] = L18_2
        L5_2[64] = L19_2
        L4_2, L5_2, L6_2 = L4_2(L5_2)
        for L7_2, L8_2 in L4_2, L5_2, L6_2 do
            if not L7_2 then
                break
            end
            L10_2 = L8_2
            L9_2 = (L8_2.byte)(L8_2)
            L3_2[L7_2] = L9_2
        end
        return L3_2
    end
    base64_module.makedecoder = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L3_2 = {
        }
        L4_2 = pairs
        L5_2 = base64_module.makeencoder
        local returned_32_21 = __dec14_pack_results(L5_2(A0_2, A1_2, A2_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_32_21, 1, returned_32_21.n)
        L4_2, L5_2, L6_2 = L4_2(unpack(returned_32_21, 1, returned_32_21.n))
        for L7_2, L8_2 in L4_2, L5_2, L6_2 do
            if not L7_2 then
                break
            end
            L3_2[L8_2] = L7_2
        end
        return L3_2
    end
    base64_encoder = (base64_module.makeencoder)()
    base64_decoder = (base64_module.makedecoder)()
    string_char = string.char
    table_concat = table.concat
    base64_module.encode = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
        if not A1_2 then
            A1_2 = base64_encoder
        end
        L3_2 = {
        }
        L4_2 = 1
        L5_2 = #A0_2
        L6_2 = L5_2 % 3
        L7_2 = {
        }
        L9_2 = L5_2 - L6_2
        for L11_2 = 1, L9_2, 3 do
            L12_2 = A0_2.byte
            L15_2 = L11_2 + 2
            L12_2, L13_2, L14_2 = L12_2(A0_2, L11_2, L15_2)
            L15_2 = L12_2 * 65536
            L16_2 = L13_2 * 256
            L15_2 = (L15_2 + L16_2) + L14_2
            if A2_2 then
                L16_2 = L7_2[L15_2]
                if not L16_2 then
                    L18_2 = extract_bits(L15_2, 18, 6)
                    L18_2 = A1_2[L18_2]
                    L19_2 = extract_bits(L15_2, 12, 6)
                    L19_2 = A1_2[L19_2]
                    L20_2 = extract_bits(L15_2, 6, 6)
                    L20_2 = A1_2[L20_2]
                    L22_2 = L15_2
                    L23_2 = 0
                    L24_2 = 6
                    L21_2 = extract_bits(L15_2, 0, 6)
                    L21_2 = A1_2[L21_2]
                    L17_2 = string_char(L18_2, L19_2, L20_2, L21_2)
                    L16_2 = L17_2
                    L7_2[L15_2] = L17_2
                end
            else
                L18_2 = extract_bits(L15_2, 18, 6)
                L18_2 = A1_2[L18_2]
                L19_2 = extract_bits(L15_2, 12, 6)
                L19_2 = A1_2[L19_2]
                L20_2 = extract_bits(L15_2, 6, 6)
                L20_2 = A1_2[L20_2]
                L22_2 = L15_2
                L23_2 = 0
                L24_2 = 6
                L21_2 = extract_bits(L15_2, 0, 6)
                L21_2 = A1_2[L21_2]
                L17_2 = string_char(L18_2, L19_2, L20_2, L21_2)
                L16_2 = L17_2
            end
            L3_2[L4_2] = L16_2
            L4_2 = L4_2 + 1
        end
        if L6_2 == 2 then
            L8_2 = A0_2.byte
            L10_2 = L5_2 - 1
            L8_2, L9_2 = L8_2(A0_2, L10_2, L5_2)
            L10_2 = L8_2 * 65536
            L11_2 = L9_2 * 256
            L10_2 = L10_2 + L11_2
            L12_2 = extract_bits(L10_2, 18, 6)
            L12_2 = A1_2[L12_2]
            L13_2 = extract_bits(L10_2, 12, 6)
            L13_2 = A1_2[L13_2]
            L14_2 = extract_bits(L10_2, 6, 6)
            L14_2 = A1_2[L14_2]
            L15_2 = A1_2[64]
            L11_2 = string_char(L12_2, L13_2, L14_2, L15_2)
            L3_2[L4_2] = L11_2
        else
            if L6_2 == 1 then
                L8_2 = ((A0_2.byte)(A0_2, L5_2)) * 65536
                L10_2 = extract_bits(L8_2, 18, 6)
                L10_2 = A1_2[L10_2]
                L11_2 = extract_bits(L8_2, 12, 6)
                L11_2 = A1_2[L11_2]
                L12_2 = A1_2[64]
                L13_2 = A1_2[64]
                L9_2 = string_char(L10_2, L11_2, L12_2, L13_2)
                L3_2[L4_2] = L9_2
            end
        end
        return table_concat(L3_2)
    end
    base64_module.decode = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2
        if not A1_2 then
            A1_2 = base64_decoder
        end
        L3_2 = "[^%w%+%/%=]"
        if A1_2 then
            L4_2 = nil
            L5_2 = nil
            L6_2, L7_2, L8_2 = pairs(A1_2)
            for L9_2, L10_2 in L6_2, L7_2, L8_2 do
                if not L9_2 then
                    break
                end
                if L10_2 == 62 then
                    L4_2 = L9_2
                else
                    if L10_2 == 63 then
                        L5_2 = L9_2
                    end
                end
            end
            L6_2 = ("[^%%w%%%s%%%s%%=]").format
            L8_2 = string_char(L4_2)
            local returned_34_22 = __dec14_pack_results(string_char(L5_2))
            L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_22, 1, returned_34_22.n)
            L3_2 = L6_2(("[^%%w%%%s%%%s%%=]"), L8_2, unpack(returned_34_22, 1, returned_34_22.n))
        end
        L4_2 = (A0_2.gsub)(A0_2, L3_2, (""))
        A0_2 = L4_2
        L4_2 = A2_2 or L4_2
        if A2_2 then
            L4_2 = {
            }
        end
        L5_2 = {
        }
        L6_2 = 1
        L7_2 = #A0_2
        L8_2 = A0_2.sub
        L10_2 = -2
        L8_2 = L8_2(A0_2, L10_2)
        if L8_2 == "==" then
            L8_2 = 2
            if not 2 then
                L8_2 = A0_2.sub
                L10_2 = -1
                L8_2 = L8_2(A0_2, L10_2)
                if L8_2 == "=" then
                    L8_2 = 1
                    if not 1 then
                        L8_2 = 0
                    end
                else
                    L8_2 = 0
                end
            end
        else
            L8_2 = A0_2.sub
            L10_2 = -1
            L8_2 = L8_2(A0_2, L10_2)
            if L8_2 == "=" then
                L8_2 = 1
                if not 1 then
                    L8_2 = 0
                end
            else
                L8_2 = 0
            end
        end
        if 0 < L8_2 then
            L10_2 = L7_2 - 4
            if not (L10_2) then
                L10_2 = L7_2
            end
        else
            L10_2 = L7_2
        end
        for L12_2 = 1, L10_2, 4 do
            L13_2 = A0_2.byte
            L16_2 = L12_2 + 3
            L13_2, L14_2, L15_2, L16_2 = L13_2(A0_2, L12_2, L16_2)
            if A2_2 then
                L18_2 = L13_2 * 16777216
                L19_2 = L14_2 * 65536
                L18_2 = L18_2 + L19_2
                L19_2 = L15_2 * 256
                L18_2 = (L18_2 + L19_2) + L16_2
                L17_2 = L4_2[L18_2]
                if not L17_2 then
                    L19_2 = (A1_2[L13_2]) * 262144
                    L20_2 = (A1_2[L14_2]) * 4096
                    L19_2 = L19_2 + L20_2
                    L20_2 = (A1_2[L15_2]) * 64
                    L19_2 = L19_2 + L20_2
                    L20_2 = A1_2[L16_2]
                    L19_2 = L19_2 + L20_2
                    L21_2 = extract_bits(L19_2, 16, 8)
                    L22_2 = extract_bits(L19_2, 8, 8)
                    local returned_34_23 = __dec14_pack_results(extract_bits(L19_2, 0, 8))
                    L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_23, 1, returned_34_23.n)
                    L20_2 = string_char(L21_2, L22_2, unpack(returned_34_23, 1, returned_34_23.n))
                    L17_2 = L20_2
                    L4_2[L18_2] = L20_2
                end
            else
                L18_2 = (A1_2[L13_2]) * 262144
                L19_2 = (A1_2[L14_2]) * 4096
                L18_2 = L18_2 + L19_2
                L19_2 = (A1_2[L15_2]) * 64
                L18_2 = L18_2 + L19_2
                L19_2 = A1_2[L16_2]
                L18_2 = L18_2 + L19_2
                L20_2 = extract_bits(L18_2, 16, 8)
                L21_2 = extract_bits(L18_2, 8, 8)
                local returned_34_24 = __dec14_pack_results(extract_bits(L18_2, 0, 8))
                L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_24, 1, returned_34_24.n)
                L19_2 = string_char(L20_2, L21_2, unpack(returned_34_24, 1, returned_34_24.n))
                L17_2 = L19_2
            end
            L5_2[L6_2] = L17_2
            L6_2 = L6_2 + 1
        end
        if L8_2 == 1 then
            L9_2 = A0_2.byte
            L11_2 = L7_2 - 3
            L12_2 = L7_2 - 1
            L9_2, L10_2, L11_2 = L9_2(A0_2, L11_2, L12_2)
            L12_2 = (A1_2[L9_2]) * 262144
            L13_2 = (A1_2[L10_2]) * 4096
            L12_2 = L12_2 + L13_2
            L13_2 = (A1_2[L11_2]) * 64
            L12_2 = L12_2 + L13_2
            L14_2 = extract_bits(L12_2, 16, 8)
            local returned_34_25 = __dec14_pack_results(extract_bits(L12_2, 8, 8))
            L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_25, 1, returned_34_25.n)
            L13_2 = string_char(L14_2, unpack(returned_34_25, 1, returned_34_25.n))
            L5_2[L6_2] = L13_2
        else
            if L8_2 == 2 then
                L9_2 = A0_2.byte
                L11_2 = L7_2 - 3
                L12_2 = L7_2 - 2
                L9_2, L10_2 = L9_2(A0_2, L11_2, L12_2)
                L11_2 = (A1_2[L9_2]) * 262144
                L12_2 = (A1_2[L10_2]) * 4096
                L11_2 = L11_2 + L12_2
                local returned_34_26 = __dec14_pack_results(extract_bits(L11_2, 16, 8))
                L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = unpack(returned_34_26, 1, returned_34_26.n)
                L12_2 = string_char(unpack(returned_34_26, 1, returned_34_26.n))
                L5_2[L6_2] = L12_2
            end
        end
        return table_concat(L5_2)
    end
    bit_band = bit.band
    camera_angles = client.camera_angles
    eye_position = client.eye_position
    key_state = client.key_state
    scale_damage = client.scale_damage
    screen_size = client.screen_size
    set_event_callback = client.set_event_callback
    trace_bullet = client.trace_bullet
    trace_line = client.trace_line
    userid_to_entindex = client.userid_to_entindex
    get_all_entities = entity.get_all
    get_classname = entity.get_classname
    get_local_player = entity.get_local_player
    get_player_resource = entity.get_player_resource
    get_players = entity.get_players
    get_prop = entity.get_prop
    hitbox_position = entity.hitbox_position
    is_alive = entity.is_alive
    is_dormant = entity.is_dormant
    is_enemy = entity.is_enemy
    curtime = globals.curtime
    tickcount = globals.tickcount
    tickinterval = globals.tickinterval
    math_abs = math.abs
    math_atan = math.atan
    math_atan2 = math.atan2
    math_cos = math.cos
    math_deg = math.deg
    math_rad = math.rad
    math_sin = math.sin
    math_sqrt = math.sqrt
    draw_gradient = renderer.gradient
    draw_line = renderer.line
    draw_text = renderer.text
    draw_triangle = renderer.triangle
    table_remove = table.remove
    ui_get = ui.get
    ui_new_color_picker = ui.new_color_picker
    ui_new_hotkey = ui.new_hotkey
    ui_new_label = ui.new_label
    ui_new_multiselect = ui.new_multiselect
    ui_reference = ui.reference
    ui_set = ui.set
    ui_set_callback = ui.set_callback
    ui_set_visible = ui.set_visible
    type_alias = get_value_type
    ui_new_slider = ui.new_slider
    native_controls = {
    }
    native_controls.enabled = ui_reference(("AA"), ("Anti-aimbot angles"), ("Enabled"))
    native_controls.pitch = ui_reference(("AA"), ("Anti-aimbot angles"), ("pitch"))
    native_controls.yawbase = ui_reference(("AA"), ("Anti-aimbot angles"), ("Yaw base"))
    native_controls.fakeyawlimit = ui_reference(("AA"), ("anti-aimbot angles"), ("Fake yaw limit"))
    native_controls.fsbodyyaw = ui_reference(("AA"), ("anti-aimbot angles"), ("Freestanding body yaw"))
    native_controls.edgeyaw = ui_reference(("AA"), ("Anti-aimbot angles"), ("Edge yaw"))
    native_controls.maxprocticks = ui_reference(("MISC"), ("Settings"), ("sv_maxusrcmdprocessticks"))
    native_controls.fakeduck = ui_reference(("RAGE"), ("Other"), ("Duck peek assist"))
    native_controls.safepoint = ui_reference(("RAGE"), ("Aimbot"), ("Force safe point"))
    native_controls.forcebaim = ui_reference(("RAGE"), ("Other"), ("Force body aim"))
    native_controls.player_list = ui_reference(("PLAYERS"), ("Players"), ("Player list"))
    native_controls.reset_all = ui_reference(("PLAYERS"), ("Players"), ("Reset all"))
    native_controls.apply_all = ui_reference(("PLAYERS"), ("Adjustments"), ("Apply to all"))
    native_controls.load_cfg = ui_reference(("Config"), ("Presets"), ("Load"))
    native_controls.fl_limit = ui_reference(("AA"), ("Fake lag"), ("Limit"))
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Anti-aimbot angles"), ("Yaw"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.yaw = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("RAGE"), ("Other"), ("Quick peek assist"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.quickpeek = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Anti-aimbot angles"), ("Yaw jitter"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.yawjitter = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Anti-aimbot angles"), ("Body yaw"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.bodyyaw = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Anti-aimbot angles"), ("Freestanding"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.freestand = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Other"), ("On shot anti-aim"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.os = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Other"), ("Slow motion"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.slow = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("RAGE"), ("Other"), ("Double tap"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.dt = set_native_ui_visible
    set_native_ui_visible = {
    }
    script_controls, anti_aim_state, player_records, contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_reference(("AA"), ("Fake lag"), ("Enabled"))
    set_native_ui_visible[1] = script_controls
    set_native_ui_visible[2] = anti_aim_state
    set_native_ui_visible[3] = player_records
    set_native_ui_visible[4] = contains_value
    set_native_ui_visible[5] = head_coordinates
    set_native_ui_visible[6] = normalize_yaw
    set_native_ui_visible[7] = yaw_between_points
    set_native_ui_visible[8] = signed_coordinate_delta
    set_native_ui_visible[9] = target_info
    set_native_ui_visible[10] = signed_line_distance
    set_native_ui_visible[11] = target_record_info
    set_native_ui_visible[12] = pose_desync_side
    set_native_ui_visible[13] = update_shot_history
    set_native_ui_visible[14] = angles_to_direction
    set_native_ui_visible[15] = classify_movement
    set_native_ui_visible[16] = vector_yaw
    set_native_ui_visible[17] = scale_factor
    set_native_ui_visible[18] = draw_circle_indicator
    set_native_ui_visible[19] = estimate_damage_at_offsets
    set_native_ui_visible[20] = select_nearest_player
    set_native_ui_visible[21] = is_valid_player
    set_native_ui_visible[22] = L93_1
    set_native_ui_visible[23] = L94_1
    set_native_ui_visible[24] = update_target_anti_aim
    set_native_ui_visible[25] = reset_player_state
    set_native_ui_visible[26] = handle_use_key
    set_native_ui_visible[27] = L98_1
    set_native_ui_visible[28] = update_manual_and_freestanding
    set_native_ui_visible[29] = point_on_circle
    set_native_ui_visible[30] = draw_indicator_triangle
    set_native_ui_visible[31] = reset_clan_tag
    set_native_ui_visible[32] = apply_body_yaw
    set_native_ui_visible[33] = on_bullet_impact
    set_native_ui_visible[34] = on_player_hurt
    set_native_ui_visible[35] = on_player_spawn
    set_native_ui_visible[36] = L107_1
    set_native_ui_visible[37] = L108_1
    set_native_ui_visible[38] = L109_1
    set_native_ui_visible[39] = L110_1
    set_native_ui_visible[40] = L111_1
    set_native_ui_visible[41] = clear_clan_tag
    set_native_ui_visible[42] = draw_indicators
    set_native_ui_visible[43] = update_ui_visibility
    set_native_ui_visible[44] = whitelisted
    set_native_ui_visible[45] = panorama_api
    set_native_ui_visible[46] = register_events_if_whitelisted
    set_native_ui_visible[47] = request_whitelist
    set_native_ui_visible[48] = fake_yaw_limit
    set_native_ui_visible[49] = screen_dimensions
    set_native_ui_visible[50] = screen_center
    set_native_ui_visible[51] = draw_branding
    set_native_ui_visible[52] = L123_1
    set_native_ui_visible[53] = L124_1
    set_native_ui_visible[54] = L125_1
    set_native_ui_visible[55] = L126_1
    set_native_ui_visible[56] = L127_1
    set_native_ui_visible[57] = L128_1
    set_native_ui_visible[58] = L129_1
    set_native_ui_visible[59] = L130_1
    set_native_ui_visible[60] = L131_1
    set_native_ui_visible[61] = L132_1
    set_native_ui_visible[62] = L133_1
    set_native_ui_visible[63] = L134_1
    set_native_ui_visible[64] = L135_1
    native_controls.fakelag = set_native_ui_visible
    set_native_ui_visible = function(A0_2, ...)
        local L2_2
        if A0_2 == nil then
            A0_2 = true
        end
        L2_2 = native_controls.pitch
        ui_set_visible(L2_2, A0_2)
        L2_2 = native_controls.yawbase
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.yaw)[1]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.yaw)[2]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.yawjitter)[1]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.yawjitter)[2]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.bodyyaw)[1]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.bodyyaw)[2]
        ui_set_visible(L2_2, A0_2)
        L2_2 = native_controls.fakeyawlimit
        ui_set_visible(L2_2, A0_2)
        L2_2 = native_controls.fsbodyyaw
        ui_set_visible(L2_2, A0_2)
        L2_2 = native_controls.edgeyaw
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.freestand)[1]
        ui_set_visible(L2_2, A0_2)
        L2_2 = (native_controls.freestand)[2]
        ui_set_visible(L2_2, A0_2)
    end
    set_native_ui_visible(false)
    script_controls = {
    }
    anti_aim_state = {
    }
    anti_aim_state.Standing = "Reversed Freestanding"
    anti_aim_state.Moving = "Reversed Freestanding"
    anti_aim_state["Slow walk"] = "Reversed Freestanding"
    anti_aim_state["In air"] = "Reversed Freestanding"
    anti_aim_state["On E"] = "Freestanding"
    anti_aim_state.Crouched = "Reversed  Freestanding"
    anti_aim_state["Standing 2"] = "Reversed Freestanding"
    script_controls.b = anti_aim_state
    script_controls["Detect missed angle"] = false
    script_controls["Anti-resolver on X shot"] = "-"
    script_controls["Anti-resolver shot amount"] = 0
    script_controls.w = ui_new_label(("AA"), ("Anti-aimbot angles"), ("----------------------------------------------------"))
    script_controls.ww = ui_new_label(("AA"), ("Anti-aimbot angles"), ("+                 LIVE [Dec. 14, 2021]"))
    script_controls.www = ui_new_label(("AA"), ("Anti-aimbot angles"), ("----------------------------------------------------"))
    normalize_yaw = {
    }
    normalize_yaw[1] = ("Manual AA")
    normalize_yaw[2] = ("Custom Legit AA")
    normalize_yaw[3] = ("Jitter when not networked")
    normalize_yaw[4] = ("Freestanding")
    normalize_yaw[5] = ("Edge yaw")
    normalize_yaw[6] = ("Keybind indicator")
    normalize_yaw[7] = ("Name indicator")
    normalize_yaw[8] = ("Status Indicator")
    normalize_yaw[9] = ("Legacy arrows")
    normalize_yaw[10] = ("Legacy OG Circle")
    normalize_yaw[11] = ("Adaptive clantag")
    script_controls.s = ui_new_multiselect(("AA"), ("Anti-aimbot angles"), ("Anti-aim settings"), normalize_yaw)
    script_controls.la = ui_new_hotkey(("AA"), ("Anti-Aimbot angles"), ("Legit AA on key"))
    script_controls.ml = ui_new_hotkey(("AA"), ("Anti-aimbot angles"), ("Manual left\010Manual Prediction"))
    script_controls.mr = ui_new_hotkey(("AA"), ("Anti-aimbot angles"), ("Manual right\010Manual Prediction"))
    script_controls.mf = ui_new_hotkey(("AA"), ("Anti-aimbot angles"), ("Manual forwards\010Manual Prediction"))
    script_controls.fs = ui_new_hotkey(("AA"), ("Anti-aimbot angles"), ("Freestanding\010Manual Prediction"))
    script_controls.ey = ui_new_hotkey(("AA"), ("Anti-aimbot angles"), ("Edye yaw\010Manual Prediction"))
    normalize_yaw = {
    }
    normalize_yaw[1] = ("Double tap")
    normalize_yaw[2] = ("Onshot Anti-Aim")
    normalize_yaw[3] = ("Force body aim")
    normalize_yaw[4] = ("Force safe point")
    normalize_yaw[5] = ("Quick peek")
    normalize_yaw[6] = ("Edge yaw")
    normalize_yaw[7] = ("Freestanding")
    script_controls.k = ui_new_multiselect(("AA"), ("Anti-aimbot angles"), ("Keybinds"), normalize_yaw)
    anti_aim_state = {
    }
    player_records = ui_new_label(("AA"), ("Anti-aimbot angles"), ("Main color"))
    contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_new_color_picker(("AA"), ("Anti-aimbot angles"), ("Main colorpicker"))
    anti_aim_state[1] = player_records
    anti_aim_state[2] = contains_value
    anti_aim_state[3] = head_coordinates
    anti_aim_state[4] = normalize_yaw
    anti_aim_state[5] = yaw_between_points
    anti_aim_state[6] = signed_coordinate_delta
    anti_aim_state[7] = target_info
    anti_aim_state[8] = signed_line_distance
    anti_aim_state[9] = target_record_info
    anti_aim_state[10] = pose_desync_side
    anti_aim_state[11] = update_shot_history
    anti_aim_state[12] = angles_to_direction
    anti_aim_state[13] = classify_movement
    anti_aim_state[14] = vector_yaw
    anti_aim_state[15] = scale_factor
    anti_aim_state[16] = draw_circle_indicator
    anti_aim_state[17] = estimate_damage_at_offsets
    anti_aim_state[18] = select_nearest_player
    anti_aim_state[19] = is_valid_player
    anti_aim_state[20] = L93_1
    anti_aim_state[21] = L94_1
    anti_aim_state[22] = update_target_anti_aim
    anti_aim_state[23] = reset_player_state
    anti_aim_state[24] = handle_use_key
    anti_aim_state[25] = L98_1
    anti_aim_state[26] = update_manual_and_freestanding
    anti_aim_state[27] = point_on_circle
    anti_aim_state[28] = draw_indicator_triangle
    anti_aim_state[29] = reset_clan_tag
    anti_aim_state[30] = apply_body_yaw
    anti_aim_state[31] = on_bullet_impact
    anti_aim_state[32] = on_player_hurt
    anti_aim_state[33] = on_player_spawn
    anti_aim_state[34] = L107_1
    anti_aim_state[35] = L108_1
    anti_aim_state[36] = L109_1
    anti_aim_state[37] = L110_1
    anti_aim_state[38] = L111_1
    anti_aim_state[39] = clear_clan_tag
    anti_aim_state[40] = draw_indicators
    anti_aim_state[41] = update_ui_visibility
    anti_aim_state[42] = whitelisted
    anti_aim_state[43] = panorama_api
    anti_aim_state[44] = register_events_if_whitelisted
    anti_aim_state[45] = request_whitelist
    anti_aim_state[46] = fake_yaw_limit
    anti_aim_state[47] = screen_dimensions
    anti_aim_state[48] = screen_center
    anti_aim_state[49] = draw_branding
    anti_aim_state[50] = L123_1
    anti_aim_state[51] = L124_1
    anti_aim_state[52] = L125_1
    anti_aim_state[53] = L126_1
    anti_aim_state[54] = L127_1
    anti_aim_state[55] = L128_1
    anti_aim_state[56] = L129_1
    anti_aim_state[57] = L130_1
    anti_aim_state[58] = L131_1
    anti_aim_state[59] = L132_1
    anti_aim_state[60] = L133_1
    anti_aim_state[61] = L134_1
    anti_aim_state[62] = L135_1
    script_controls.clr = anti_aim_state
    anti_aim_state = {
    }
    player_records = ui_new_label(("AA"), ("Anti-aimbot angles"), ("Accent color"))
    contains_value, head_coordinates, normalize_yaw, yaw_between_points, signed_coordinate_delta, target_info, signed_line_distance, target_record_info, pose_desync_side, update_shot_history, angles_to_direction, classify_movement, vector_yaw, scale_factor, draw_circle_indicator, estimate_damage_at_offsets, select_nearest_player, is_valid_player, L93_1, L94_1, update_target_anti_aim, reset_player_state, handle_use_key, L98_1, update_manual_and_freestanding, point_on_circle, draw_indicator_triangle, reset_clan_tag, apply_body_yaw, on_bullet_impact, on_player_hurt, on_player_spawn, L107_1, L108_1, L109_1, L110_1, L111_1, clear_clan_tag, draw_indicators, update_ui_visibility, whitelisted, panorama_api, register_events_if_whitelisted, request_whitelist, fake_yaw_limit, screen_dimensions, screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = ui_new_color_picker(("AA"), ("Anti-aimbot angles"), ("Accent colorpicker"))
    anti_aim_state[1] = player_records
    anti_aim_state[2] = contains_value
    anti_aim_state[3] = head_coordinates
    anti_aim_state[4] = normalize_yaw
    anti_aim_state[5] = yaw_between_points
    anti_aim_state[6] = signed_coordinate_delta
    anti_aim_state[7] = target_info
    anti_aim_state[8] = signed_line_distance
    anti_aim_state[9] = target_record_info
    anti_aim_state[10] = pose_desync_side
    anti_aim_state[11] = update_shot_history
    anti_aim_state[12] = angles_to_direction
    anti_aim_state[13] = classify_movement
    anti_aim_state[14] = vector_yaw
    anti_aim_state[15] = scale_factor
    anti_aim_state[16] = draw_circle_indicator
    anti_aim_state[17] = estimate_damage_at_offsets
    anti_aim_state[18] = select_nearest_player
    anti_aim_state[19] = is_valid_player
    anti_aim_state[20] = L93_1
    anti_aim_state[21] = L94_1
    anti_aim_state[22] = update_target_anti_aim
    anti_aim_state[23] = reset_player_state
    anti_aim_state[24] = handle_use_key
    anti_aim_state[25] = L98_1
    anti_aim_state[26] = update_manual_and_freestanding
    anti_aim_state[27] = point_on_circle
    anti_aim_state[28] = draw_indicator_triangle
    anti_aim_state[29] = reset_clan_tag
    anti_aim_state[30] = apply_body_yaw
    anti_aim_state[31] = on_bullet_impact
    anti_aim_state[32] = on_player_hurt
    anti_aim_state[33] = on_player_spawn
    anti_aim_state[34] = L107_1
    anti_aim_state[35] = L108_1
    anti_aim_state[36] = L109_1
    anti_aim_state[37] = L110_1
    anti_aim_state[38] = L111_1
    anti_aim_state[39] = clear_clan_tag
    anti_aim_state[40] = draw_indicators
    anti_aim_state[41] = update_ui_visibility
    anti_aim_state[42] = whitelisted
    anti_aim_state[43] = panorama_api
    anti_aim_state[44] = register_events_if_whitelisted
    anti_aim_state[45] = request_whitelist
    anti_aim_state[46] = fake_yaw_limit
    anti_aim_state[47] = screen_dimensions
    anti_aim_state[48] = screen_center
    anti_aim_state[49] = draw_branding
    anti_aim_state[50] = L123_1
    anti_aim_state[51] = L124_1
    anti_aim_state[52] = L125_1
    anti_aim_state[53] = L126_1
    anti_aim_state[54] = L127_1
    anti_aim_state[55] = L128_1
    anti_aim_state[56] = L129_1
    anti_aim_state[57] = L130_1
    anti_aim_state[58] = L131_1
    anti_aim_state[59] = L132_1
    anti_aim_state[60] = L133_1
    anti_aim_state[61] = L134_1
    anti_aim_state[62] = L135_1
    script_controls.clr2 = anti_aim_state
    anti_aim_state = {
    }
    anti_aim_state.aa = 1
    player_records = {
    }
    player_records[1] = ("Standing")
    player_records[2] = ("Moving")
    player_records[3] = ("Slow walk")
    player_records[4] = ("In air")
    player_records[5] = ("On E")
    player_records[6] = ("Crouched")
    player_records[7] = ("Standing 2")
    anti_aim_state.s_i = player_records
    player_records = {
    }
    player_records[1] = 0
    player_records[2] = 0
    player_records[3] = 0
    anti_aim_state.l_s = player_records
    anti_aim_state.rec = {
    }
    anti_aim_state.desync = 0
    anti_aim_state.holding_e = false
    anti_aim_state.target = 0
    player_records = {
    }
    player_records.manual = 0
    player_records.fs = false
    player_records.edge = false
    player_records.time = 0
    anti_aim_state.dir = player_records
    player_records = {
    }
    player_records.manual = 0
    player_records.fs = false
    player_records.edge = false
    player_records.time = 0
    anti_aim_state.stored_dir = player_records
    anti_aim_state.old_dsy = true
    player_records = {
    }
    player_records[1] = ("CWorld")
    player_records[2] = ("CCSPlayer")
    player_records[3] = ("CFuncBrush")
    anti_aim_state.classnames = player_records
    player_records = {
    }
    yaw_between_points = "flashbang"
    signed_coordinate_delta = "decoy"
    target_info = "smokegrenade"
    signed_line_distance = "taser"
    player_records[1] = ("knife")
    player_records[2] = ("hegrenade")
    player_records[3] = ("inferno")
    player_records[4] = ("flashbang")
    player_records[5] = ("decoy")
    player_records[6] = ("smokegrenade")
    player_records[7] = ("taser")
    anti_aim_state.nonweapons = player_records
    player_records = {
    }
    for yaw_between_points = 1, 64, 1 do
        signed_coordinate_delta = {
        }
        signed_coordinate_delta.s = {
        }
        signed_coordinate_delta.h = {
        }
        signed_coordinate_delta.m = 0
        signed_coordinate_delta.r = 0
        signed_coordinate_delta[("d")] = 0
        target_info = "l"
        signed_line_distance = 0
        signed_coordinate_delta[("l")] = 0
        player_records[yaw_between_points] = signed_coordinate_delta
    end
    contains_value = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L5_2, L6_2
        if A0_2 == nil then
            return false
        end
        L2_2 = type_alias(A0_2)
        if L2_2 == "number" then
            A0_2 = ui_get(A0_2)
        end
        L3_2 = #A0_2
        for L5_2 = 0, L3_2, 1 do
            L6_2 = A0_2[L5_2]
            if L6_2 == A1_2 then
                return true
            end
        end
        return false
    end
    head_coordinates = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
        L1_2, L2_2, L3_2 = hitbox_position(A0_2, 0)
        L4_2, L5_2, L6_2 = get_prop(A0_2, ("m_vecOrigin"))
        return L4_2, L5_2, L3_2
    end
    normalize_yaw = function(A0_2, ...)
        while 180 < A0_2 do
            A0_2 = A0_2 - 360
        end
        while A0_2 < -180 do
            A0_2 = A0_2 + 360
        end
        return A0_2
    end
    yaw_between_points = function(A0_2, A1_2, A2_2, A3_2, ...)
        local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L4_2 = A1_2 - A3_2
        L5_2 = A0_2 - A2_2
        L7_2 = L4_2 / L5_2
        L6_2 = math_atan(L7_2)
        L8_2 = L6_2 * 180
        L9_2 = math.pi
        L8_2 = L8_2 / L9_2
        L7_2 = normalize_yaw(L8_2)
        L6_2 = L7_2
        if 0 <= L5_2 then
            L8_2 = L6_2 + 180
            L7_2 = normalize_yaw(L8_2)
        end
        return L7_2
    end
    signed_coordinate_delta = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2
        if A2_2 == nil then
            A2_2 = false
        end
        if A2_2 then
            L3_2 = {
            }
            L4_2 = A1_2[1]
            L5_2 = A1_2[2]
            L6_2 = A0_2[3]
            L3_2[1] = L4_2
            L3_2[2] = L5_2
            L3_2[3] = L6_2
            A1_2 = L3_2
        end
        L3_2 = A0_2[1]
        L4_2 = A1_2[1]
        L3_2 = L3_2 - L4_2
        L4_2 = A0_2[2]
        L5_2 = A1_2[2]
        L4_2 = L4_2 - L5_2
        L3_2 = L3_2 + L4_2
        L4_2 = A0_2[3]
        L5_2 = A1_2[3]
        L4_2 = L4_2 - L5_2
        L3_2 = L3_2 + L4_2
        if L3_2 < 0 then
            L3_2 = L3_2 * 0.75
        end
        return L3_2
    end
    target_info = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
        L2_2, L3_2, L4_2 = head_coordinates(A0_2)
        local returned_41_27 = __dec14_pack_results(get_local_player())
        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = unpack(returned_41_27, 1, returned_41_27.n)
        L5_2, L6_2, L7_2 = head_coordinates(unpack(returned_41_27, 1, returned_41_27.n))
        L8_2 = {
        }
        L8_2[1] = L5_2
        L8_2[2] = L6_2
        L8_2[3] = L7_2
        L9_2 = {
        }
        L9_2[1] = L2_2
        L9_2[2] = L3_2
        L9_2[3] = L4_2
        L10_2 = {
        }
        L11_2 = A1_2.x
        L12_2 = A1_2.y
        L13_2 = A1_2.z
        L10_2[1] = L11_2
        L10_2[2] = L12_2
        L10_2[3] = L13_2
        L11_2 = {
        }
        L12_2 = L10_2[1]
        L13_2 = L9_2[1]
        L12_2 = L12_2 - L13_2
        L13_2 = L10_2[2]
        L14_2 = L9_2[2]
        L13_2 = L13_2 - L14_2
        L14_2 = L10_2[3]
        L15_2 = L9_2[3]
        L14_2 = L14_2 - L15_2
        L11_2[1] = L12_2
        L11_2[2] = L13_2
        L11_2[3] = L14_2
        L13_2 = (L11_2[1]) ^ 2
        L14_2 = (L11_2[2]) ^ 2
        L13_2 = L13_2 + L14_2
        L14_2 = (L11_2[3]) ^ 2
        L13_2 = L13_2 + L14_2
        L12_2 = math_sqrt(L13_2)
        L13_2 = {
        }
        L14_2 = (L11_2[1]) / L12_2
        L15_2 = (L11_2[2]) / L12_2
        L16_2 = (L11_2[3]) / L12_2
        L13_2[1] = L14_2
        L13_2[2] = L15_2
        L13_2[3] = L16_2
        L14_2 = {
        }
        L15_2 = L8_2[1]
        L16_2 = L9_2[1]
        L15_2 = L15_2 - L16_2
        L16_2 = L8_2[2]
        L17_2 = L9_2[2]
        L16_2 = L16_2 - L17_2
        L17_2 = L8_2[3]
        L18_2 = L9_2[3]
        L17_2 = L17_2 - L18_2
        L14_2[1] = L15_2
        L14_2[2] = L16_2
        L14_2[3] = L17_2
        L15_2 = L13_2[1]
        L16_2 = L14_2[1]
        L15_2 = L15_2 * L16_2
        L16_2 = L13_2[2]
        L17_2 = L14_2[2]
        L16_2 = L16_2 * L17_2
        L15_2 = L15_2 + L16_2
        L16_2 = L13_2[3]
        L17_2 = L14_2[3]
        L16_2 = L16_2 * L17_2
        L15_2 = L15_2 + L16_2
        L17_2 = {
        }
        L18_2 = L9_2[1]
        L19_2 = L13_2[1]
        L19_2 = L15_2 * L19_2
        L18_2 = L18_2 + L19_2
        L19_2 = L9_2[2]
        L20_2 = L13_2[2]
        L20_2 = L15_2 * L20_2
        L19_2 = L19_2 + L20_2
        L20_2 = L9_2[3]
        L21_2 = L13_2[3]
        L21_2 = L15_2 * L21_2
        L20_2 = L20_2 + L21_2
        L17_2[1] = L18_2
        L17_2[2] = L19_2
        L17_2[3] = L20_2
        anti_aim_state.ls = L17_2
        L17_2 = anti_aim_state.ls
        return signed_coordinate_delta(L17_2, L8_2, true)
    end
    signed_line_distance = function(A0_2, A1_2, A2_2, ...)
        local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
        L3_2, L4_2, L5_2 = head_coordinates(A0_2)
        L6_2, L7_2, L8_2 = head_coordinates(A1_2)
        L9_2 = ((A2_2.y) - L4_2) * L6_2
        L10_2 = ((A2_2.x) - L3_2) * L7_2
        L9_2 = L9_2 - L10_2
        L10_2 = (A2_2.x) * L4_2
        L9_2 = L9_2 + L10_2
        L10_2 = (A2_2.y) * L3_2
        L9_2 = L9_2 - L10_2
        L11_2 = ((A2_2.y) - L4_2) ^ 2
        L12_2 = ((A2_2.x) - L3_2) ^ 2
        L11_2 = L11_2 + L12_2
        L10_2 = math_sqrt(L11_2)
        L9_2 = L9_2 / L10_2
        return L9_2
    end
    target_record_info = function(A0_2, A1_2, A2_2, A3_2, A4_2, ...)
        local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
        L5_2 = {
        }
        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = head_coordinates(A3_2)
        L5_2[1] = L6_2
        L5_2[2] = L7_2
        L5_2[3] = L8_2
        L5_2[4] = L9_2
        L5_2[5] = L10_2
        L5_2[6] = L11_2
        L5_2[7] = L12_2
        L5_2[8] = L13_2
        L6_2 = {
        }
        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = get_prop(A3_2, ("m_vecOrigin"))
        L6_2[1] = L7_2
        L6_2[2] = L8_2
        L6_2[3] = L9_2
        L6_2[4] = L10_2
        L6_2[5] = L11_2
        L6_2[6] = L12_2
        L6_2[7] = L13_2
        L7_2 = A1_2[3]
        L8_2 = (L5_2[3]) + 10
        if not (L7_2 > L8_2) then
            L7_2 = A1_2[3]
            L8_2 = L6_2[3]
            if not (L7_2 < L8_2) then
                local returned_43_28 = __dec14_pack_results(signed_line_distance(A2_2, A3_2, A4_2))
                L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = unpack(returned_43_28, 1, returned_43_28.n)
                L7_2 = math_abs(unpack(returned_43_28, 1, returned_43_28.n))
                if 300 < L7_2 then
                    return false
                else
                    L7_2 = math_abs(A0_2)
                    if L7_2 < 30 then
                        return true
                    else
                        L8_2 = get_player_resource()
                        L7_2 = get_prop(L8_2, ("m_iPing"), A2_2)
                        L8_2 = tickinterval()
                        L8_2 = L7_2 * L8_2
                        L8_2 = 14 - L8_2
                        L9_2 = #(anti_aim_state.rec)
                        if L8_2 <= L9_2 then
                            L9_2 = (anti_aim_state.rec)[L8_2]
                            if L9_2 == nil then
                                return false
                            else
                                L10_2 = signed_coordinate_delta(L9_2, L5_2, true)
                                if A0_2 < 0 and A0_2 > L10_2 or A0_2 < L10_2 then
                                    L11_2 = math_abs(A0_2)
                                    L12_2 = math_abs(L10_2)
                                    if L11_2 < L12_2 then
                                        L11_2 = true
                                    else
                                        L11_2 = math_abs(A0_2)
                                        L12_2 = math_abs(L10_2)
                                        if not (L11_2 > L12_2) then
                                            L11_2 = false
                                        else
                                            L11_2 = true
                                        end
                                    end
                                else
                                    L11_2 = math_abs(A0_2)
                                    L12_2 = math_abs(L10_2)
                                    if not (L11_2 > L12_2) then
                                        L11_2 = false
                                    else
                                        L11_2 = true
                                    end
                                end
                                return L11_2
                            end
                        else
                            return false
                        end
                    end
                end
            else
                do
                    return false
                end
            end
        else
            do
                return false
            end
        end
    end
    pose_desync_side = function(A0_2, ...)
        local L1_2, L2_2
        L1_2 = anti_aim_state.desync
        if L1_2 == 0 then
            return 0
        else
            L1_2 = ((get_prop(A0_2, ("m_flPoseParameter"), 11)) * 120) - 60
            if L1_2 < 0 then
                L2_2 = anti_aim_state.desync
                if not (L2_2) then
                    L2_2 = -(anti_aim_state.desync)
                end
            else
                L2_2 = -(anti_aim_state.desync)
            end
            return L2_2
        end
    end
    update_shot_history = function(A0_2, ...)
        local L4_2, L5_2, L6_2, L7_2, L8_2
        for L4_2 = 1, 64, 1 do
            L5_2 = (player_records[L4_2]).r
            L6_2 = #((player_records[L4_2]).s)
            if L5_2 < L6_2 then
                L5_2 = #((player_records[L4_2]).h)
                if 0 < L5_2 then
                    L5_2 = (player_records[L4_2]).s
                    L6_2 = #((player_records[L4_2]).s)
                    L5_2 = (L5_2[L6_2]).t
                    L6_2 = (player_records[L4_2]).h
                    L7_2 = #((player_records[L4_2]).h)
                    L6_2 = (L6_2[L7_2]).t
                    if L5_2 == L6_2 then
                        L5_2 = true
                    else
                        L5_2 = false
                    end
                else
                    L5_2 = false
                end
                if L5_2 then
                    L6_2 = (player_records[L4_2]).h
                    L7_2 = #((player_records[L4_2]).h)
                    L6_2 = (L6_2[L7_2]).v
                    if not (L6_2 ~= A0_2) then
                        L6_2 = player_records[L4_2]
                        if L5_2 then
                            L7_2 = (player_records[L4_2]).h
                            L8_2 = #((player_records[L4_2]).h)
                            L7_2 = (L7_2[L8_2]).h
                            if L7_2 == 1 then
                                L7_2 = pose_desync_side(A0_2)
                                if not (L7_2) then
                                    L7_2 = 0
                                end
                            else
                                L7_2 = 0
                            end
                        else
                            L7_2 = 0
                        end
                        L6_2.l = L7_2
                        if not L5_2 then
                            L6_2 = (player_records[L4_2]).m
                            L7_2 = script_controls["Anti-resolver shot amount"]
                            if L6_2 < L7_2 then
                                L6_2 = player_records[L4_2]
                                L6_2.m = ((player_records[L4_2]).m) + 1
                            end
                        else
                            L6_2 = player_records[L4_2]
                            L6_2.m = 0
                        end
                        if L5_2 then
                            L6_2 = (player_records[L4_2]).s
                            L7_2 = #((player_records[L4_2]).s)
                            L6_2 = L6_2[L7_2]
                            L6_2.d = pose_desync_side(A0_2)
                        end
                        L6_2 = player_records[L4_2]
                        L7_2 = (player_records[L4_2]).s
                        L8_2 = #((player_records[L4_2]).s)
                        L6_2.d = (L7_2[L8_2]).d
                        anti_aim_state.target = L4_2
                    end
                else
                    L6_2 = player_records[L4_2]
                    if L5_2 then
                        L7_2 = (player_records[L4_2]).h
                        L8_2 = #((player_records[L4_2]).h)
                        L7_2 = (L7_2[L8_2]).h
                        if L7_2 == 1 then
                            L7_2 = pose_desync_side(A0_2)
                            if not (L7_2) then
                                L7_2 = 0
                            end
                        else
                            L7_2 = 0
                        end
                    else
                        L7_2 = 0
                    end
                    L6_2.l = L7_2
                    if not L5_2 then
                        L6_2 = (player_records[L4_2]).m
                        L7_2 = script_controls["Anti-resolver shot amount"]
                        if L6_2 < L7_2 then
                            L6_2 = player_records[L4_2]
                            L6_2.m = ((player_records[L4_2]).m) + 1
                        end
                    else
                        L6_2 = player_records[L4_2]
                        L6_2.m = 0
                    end
                    if L5_2 then
                        L6_2 = (player_records[L4_2]).s
                        L7_2 = #((player_records[L4_2]).s)
                        L6_2 = L6_2[L7_2]
                        L6_2.d = pose_desync_side(A0_2)
                    end
                    L6_2 = player_records[L4_2]
                    L7_2 = (player_records[L4_2]).s
                    L8_2 = #((player_records[L4_2]).s)
                    L6_2.d = (L7_2[L8_2]).d
                    anti_aim_state.target = L4_2
                end
                L6_2 = player_records[L4_2]
                L7_2 = #((player_records[L4_2]).s)
                L6_2.r = L7_2
            else
                L5_2 = (player_records[L4_2]).r
                L6_2 = #((player_records[L4_2]).s)
                if L5_2 > L6_2 then
                    L5_2 = player_records[L4_2]
                    L6_2 = #((player_records[L4_2]).s)
                    L5_2.r = L6_2
                end
            end
        end
    end
    angles_to_direction = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        local returned_46_29 = __dec14_pack_results(math_rad(A1_2))
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_29, 1, returned_46_29.n)
        L2_2 = math_sin(unpack(returned_46_29, 1, returned_46_29.n))
        local returned_46_30 = __dec14_pack_results(math_rad(A1_2))
        L4_2, L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_30, 1, returned_46_30.n)
        L3_2 = math_cos(unpack(returned_46_30, 1, returned_46_30.n))
        local returned_46_31 = __dec14_pack_results(math_rad(A0_2))
        L5_2, L6_2, L7_2, L8_2 = unpack(returned_46_31, 1, returned_46_31.n)
        L4_2 = math_sin(unpack(returned_46_31, 1, returned_46_31.n))
        local returned_46_32 = __dec14_pack_results(math_rad(A0_2))
        L6_2, L7_2, L8_2 = unpack(returned_46_32, 1, returned_46_32.n)
        L5_2 = math_cos(unpack(returned_46_32, 1, returned_46_32.n))
        L6_2 = L5_2 * L3_2
        L7_2 = L5_2 * L2_2
        L8_2 = -L4_2
        return L6_2, L7_2, L8_2
    end
    classify_movement = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
        L2_2 = anti_aim_state.holding_e
        if L2_2 then
            anti_aim_state.aa = 5
            return 
        else
            L3_2 = (native_controls.slow)[1]
            L2_2 = ui_get(L3_2)
            if L2_2 then
                L3_2 = (native_controls.slow)[2]
                L2_2 = ui_get(L3_2)
            end
            if L2_2 then
                anti_aim_state.aa = 3
                return 
            else
                L4_2 = get_prop(A0_2, ("m_fFlags"))
                L3_2 = bit_band(L4_2, 1)
                if L3_2 == 1 then
                    L3_2 = A1_2.in_jump
                    if L3_2 == 0 then
                        L3_2 = true
                    else
                        L3_2 = false
                    end
                else
                    L3_2 = false
                end
                if not L3_2 then
                    anti_aim_state.aa = 4
                    return 
                else
                    L4_2 = entity.get_prop
                    L5_2 = (entity.get_local_player)()
                    L4_2 = L4_2(L5_2, ("m_iTeamNum"))
                    L5_2 = entity.get_prop
                    L6_2 = (entity.get_local_player)()
                    L5_2 = L5_2(L6_2, ("m_flDuckAmount"))
                    if not (0.7 < L5_2) then
                        L5_2 = false
                    else
                        L5_2 = true
                    end
                    if L4_2 == 3 and L5_2 then
                        anti_aim_state.aa = 6
                        return 
                    else
                        L6_2 = entity.get_player_weapon
                        L7_2 = entity.get_local_player
                        local returned_47_33 = __dec14_pack_results(L7_2())
                        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_33, 1, returned_47_33.n)
                        L6_2 = L6_2(unpack(returned_47_33, 1, returned_47_33.n))
                        L8_2 = get_prop(L6_2, ("m_iItemDefinitionIndex"))
                        L7_2 = bit_band(L8_2, 65535)
                        L8_2, L9_2, L10_2 = get_prop(A0_2, ("m_vecVelocity"))
                        L12_2 = L8_2 ^ 2
                        L13_2 = L9_2 ^ 2
                        L12_2 = L12_2 + L13_2
                        L11_2 = math_sqrt(L12_2)
                        if 2 < L11_2 then
                            anti_aim_state.aa = 2
                            return 
                        else
                            L11_2 = (entity.get_players)(true)
                            L12_2 = nil
                            L13_2 = client.camera_angles
                            L13_2, L14_2, L15_2 = L13_2()
                            L16_2 = Vector3(L13_2, L14_2, 0)
                            L17_2 = 180
                            L18_2 = Vector3
                            local returned_47_34 = __dec14_pack_results(get_prop(A0_2, ("m_vecAbsOrigin")))
                            L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_34, 1, returned_47_34.n)
                            L18_2 = L18_2(unpack(returned_47_34, 1, returned_47_34.n))
                            L19_2 = L18_2.x
                            if L19_2 ~= nil then
                                L20_2 = #L11_2
                                for L22_2 = 1, L20_2, 1 do
                                    L23_2 = L11_2[L22_2]
                                    L25_2 = L23_2
                                    L24_2 = is_enemy(L23_2)
                                    if L24_2 then
                                        L25_2 = L23_2
                                        L24_2 = is_alive(L23_2)
                                        if L24_2 then
                                            L25_2 = L23_2
                                            L24_2 = is_dormant(L23_2)
                                            if not L24_2 then
                                                L24_2 = Vector3
                                                L25_2 = entity.get_prop
                                                local returned_47_35 = __dec14_pack_results(L25_2(L23_2, ("m_vecOrigin")))
                                                L25_2, L26_2, L27_2, L28_2 = unpack(returned_47_35, 1, returned_47_35.n)
                                                L24_2 = L24_2(unpack(returned_47_35, 1, returned_47_35.n))
                                                L26_2 = L16_2
                                                L27_2 = L18_2
                                                L28_2 = L24_2
                                                L25_2 = get_FOV(L16_2, L18_2, L24_2)
                                                if L17_2 > L25_2 then
                                                    L17_2 = L25_2
                                                    L12_2 = L23_2
                                                end
                                            end
                                        end
                                    end
                                end
                                L19_2, L20_2, L21_2 = get_prop(A0_2, ("m_vecOrigin"))
                                L22_2, L23_2, L24_2 = get_prop(L12_2, ("m_vecOrigin"))
                                if L24_2 == nil or L21_2 == nil then
                                    return 
                                else
                                    if L4_2 == 2 then
                                        L26_2 = L8_2 ^ 2
                                        L27_2 = L9_2 ^ 2
                                        L26_2 = L26_2 + L27_2
                                        L25_2 = math_sqrt(L26_2)
                                        if L25_2 < 2 and (L7_2 == 40 or L7_2 == 38 or L7_2 == 11 or L7_2 == 9) then
                                            L25_2 = L21_2 - L24_2
                                            if 0 <= L25_2 then
                                                L25_2 = (anti_aim_state.dir).manual
                                                if L25_2 ~= 90 then
                                                    L25_2 = (anti_aim_state.dir).manual
                                                    if L25_2 ~= -90 then
                                                        anti_aim_state.aa = 7
                                                        return 
                                                    else
                                                        L20_2 = L8_2 ^ 2
                                                        L21_2 = L9_2 ^ 2
                                                        L20_2 = L20_2 + L21_2
                                                        L19_2 = math_sqrt(L20_2)
                                                        if L19_2 < 2 then
                                                            anti_aim_state.aa = 1
                                                            return 
                                                        end
                                                    end
                                                else
                                                    L20_2 = L8_2 ^ 2
                                                    L21_2 = L9_2 ^ 2
                                                    L20_2 = L20_2 + L21_2
                                                    L19_2 = math_sqrt(L20_2)
                                                    if L19_2 < 2 then
                                                        anti_aim_state.aa = 1
                                                        return 
                                                    end
                                                end
                                            else
                                                L20_2 = L8_2 ^ 2
                                                L21_2 = L9_2 ^ 2
                                                L20_2 = L20_2 + L21_2
                                                L19_2 = math_sqrt(L20_2)
                                                if L19_2 < 2 then
                                                    anti_aim_state.aa = 1
                                                    return 
                                                end
                                            end
                                        else
                                            L20_2 = L8_2 ^ 2
                                            L21_2 = L9_2 ^ 2
                                            L20_2 = L20_2 + L21_2
                                            L19_2 = math_sqrt(L20_2)
                                            if L19_2 < 2 then
                                                anti_aim_state.aa = 1
                                                return 
                                            end
                                        end
                                    else
                                        L20_2 = L8_2 ^ 2
                                        L21_2 = L9_2 ^ 2
                                        L20_2 = L20_2 + L21_2
                                        L19_2 = math_sqrt(L20_2)
                                        if L19_2 < 2 then
                                            anti_aim_state.aa = 1
                                            return 
                                        end
                                    end
                                end
                            else
                                L20_2 = L8_2 ^ 2
                                L21_2 = L9_2 ^ 2
                                L20_2 = L20_2 + L21_2
                                L19_2 = math_sqrt(L20_2)
                                if L19_2 < 2 then
                                    anti_aim_state.aa = 1
                                    return 
                                end
                            end
                        end
                    end
                end
            end
        end
    end
    vector_yaw = function(A0_2, A1_2, ...)
        local L3_2, L4_2, L5_2
        if A0_2 == 0 and A1_2 == 0 then
            return 0
        end
        local returned_48_36 = __dec14_pack_results(math_atan2(A1_2, A0_2))
        L3_2, L4_2, L5_2 = unpack(returned_48_36, 1, returned_48_36.n)
        return math_deg(unpack(returned_48_36, 1, returned_48_36.n))
    end
    scale_factor = function(A0_2, ...)
        local L1_2, L2_2
        L1_2 = 155 * A0_2
        L1_2 = 255 - L1_2
        L2_2 = 240 * A0_2
        return L1_2, L2_2, 0
    end
    draw_circle_indicator = function(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, ...)
        local L7_2, L15_2
        L7_2 = renderer.circle_outline
        L7_2(A0_2, A1_2, 0, 0, 0, 155, 10, 0, 1, 6)
        L7_2 = renderer.circle_outline
        if 0 < A6_2 then
            L15_2 = 90
            if not 90 then
                L15_2 = -90
            end
        else
            L15_2 = -90
        end
        L7_2(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, 9, L15_2, 0.5, 4)
    end
    estimate_damage_at_offsets = function(A0_2, A1_2, A2_2, A3_2, A4_2, ...)
        local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
        L5_2 = {
        }
        L6_2 = {
        }
        L7_2 = {
        }
        L8_2, L9_2, L10_2 = head_coordinates(A1_2)
        L7_2[0] = L10_2
        L6_2[0] = L9_2
        L5_2[0] = L8_2
        L8_2 = (L5_2[0]) + 40
        L9_2 = L6_2[0]
        L7_2[1] = L7_2[0]
        L6_2[1] = L9_2
        L5_2[1] = L8_2
        L8_2 = L5_2[0]
        L9_2 = (L6_2[0]) + 40
        L7_2[2] = L7_2[0]
        L6_2[2] = L9_2
        L5_2[2] = L8_2
        L8_2 = (L5_2[0]) - 40
        L9_2 = L6_2[0]
        L7_2[3] = L7_2[0]
        L6_2[3] = L9_2
        L5_2[3] = L8_2
        L8_2 = L5_2[0]
        L9_2 = (L6_2[0]) - 40
        L7_2[4] = L7_2[0]
        L6_2[4] = L9_2
        L5_2[4] = L8_2
        L8_2 = L5_2[0]
        L9_2 = L6_2[0]
        L7_2[5] = (L7_2[0]) + 40
        L6_2[5] = L9_2
        L5_2[5] = L8_2
        L8_2 = 0
        L9_2 = nil
        for L13_2 = 0, 5, 1 do
            if L9_2 == 0 or L9_2 == nil then
                L16_2 = L5_2[L13_2]
                L17_2 = L6_2[L13_2]
                L18_2 = L7_2[L13_2]
                L19_2 = A2_2
                L20_2 = A3_2
                L21_2 = A4_2
                L14_2, L15_2 = trace_bullet(A1_2, L16_2, L17_2, L18_2, A2_2, A3_2, A4_2)
                L9_2 = L15_2
                L8_2 = L14_2
            end
        end
        if L8_2 == nil then
            L13_2 = scale_damage(A1_2, 2, L9_2)
            if not (L13_2) then
                L13_2 = L9_2
            end
        else
            L13_2 = L9_2
        end
        return scale_damage(A1_2, 1, L13_2)
    end
    select_nearest_player = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L6_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
        L2_2 = get_players(true)
        L3_2 = #L2_2
        if L3_2 == 0 then
            return 0
        end
        L3_2 = 0
        L4_2 = 180
        L6_2 = #L2_2
        for L8_2 = 1, L6_2, 1 do
            L10_2 = L2_2[L8_2]
            L9_2, L10_2, L11_2 = get_prop(L10_2, ("m_vecOrigin"))
            L15_2 = (A0_2[1]) - L9_2
            L16_2 = (A0_2[2]) - L10_2
            L14_2 = vector_yaw(L15_2, L16_2)
            L15_2 = A1_2[2]
            L14_2 = (L14_2 - L15_2) + 180
            local returned_52_37 = __dec14_pack_results(normalize_yaw(L14_2))
            L13_2, L14_2, L15_2, L16_2 = unpack(returned_52_37, 1, returned_52_37.n)
            L12_2 = math_abs(unpack(returned_52_37, 1, returned_52_37.n))
            if L4_2 > L12_2 then
                L4_2 = L12_2
                L3_2 = L2_2[L8_2]
            end
        end
        return L3_2
    end
    is_valid_player = function(A0_2, ...)
        local L1_2
        if A0_2 == 0 then
            return false
        end
        L1_2 = is_alive(A0_2)
        if not L1_2 then
            return false
        end
        L1_2 = is_dormant(A0_2)
        if L1_2 then
            return false
        end
        return true
    end
    L93_1 = false
    L94_1 = false
    update_target_anti_aim = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
        L1_2 = get_local_player()
        L2_2 = {
        }
        L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = head_coordinates(L1_2)
        L2_2[1] = L3_2
        L2_2[2] = L4_2
        L2_2[3] = L5_2
        L2_2[4] = L6_2
        L2_2[5] = L7_2
        L2_2[6] = L8_2
        L2_2[7] = L9_2
        L2_2[8] = L10_2
        L2_2[9] = L11_2
        L2_2[10] = L12_2
        L2_2[11] = L13_2
        L2_2[12] = L14_2
        L2_2[13] = L15_2
        L2_2[14] = L16_2
        L2_2[15] = L17_2
        L2_2[16] = L18_2
        L2_2[17] = L19_2
        L2_2[18] = L20_2
        L2_2[19] = L21_2
        L2_2[20] = L22_2
        L2_2[21] = L23_2
        L2_2[22] = L24_2
        L2_2[23] = L25_2
        L2_2[24] = L26_2
        L2_2[25] = L27_2
        L2_2[26] = L28_2
        L3_2 = {
        }
        L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = camera_angles()
        L3_2[1] = L4_2
        L3_2[2] = L5_2
        L3_2[3] = L6_2
        L3_2[4] = L7_2
        L3_2[5] = L8_2
        L3_2[6] = L9_2
        L3_2[7] = L10_2
        L3_2[8] = L11_2
        L3_2[9] = L12_2
        L3_2[10] = L13_2
        L3_2[11] = L14_2
        L3_2[12] = L15_2
        L3_2[13] = L16_2
        L3_2[14] = L17_2
        L3_2[15] = L18_2
        L3_2[16] = L19_2
        L3_2[17] = L20_2
        L3_2[18] = L21_2
        L3_2[19] = L22_2
        L3_2[20] = L23_2
        L3_2[21] = L24_2
        L3_2[22] = L25_2
        L3_2[23] = L26_2
        L3_2[24] = L27_2
        L3_2[25] = L28_2
        L6_2 = anti_aim_state.target
        L5_2 = is_valid_player(L6_2)
        if L5_2 then
            L5_2 = anti_aim_state.target
            if not (L5_2) then
                L5_2 = select_nearest_player(L2_2, L3_2)
            end
        else
            L5_2 = select_nearest_player(L2_2, L3_2)
        end
        anti_aim_state.target = L5_2
        L4_2 = anti_aim_state.target
        if L4_2 ~= 0 then
            L5_2 = anti_aim_state.target
            L4_2 = (player_records[L5_2]).d
            if L4_2 == 0 then
                L5_2 = anti_aim_state.target
                L4_2 = (player_records[L5_2]).l
                if L4_2 ~= 0 then
                    L6_2 = anti_aim_state.target
                    L5_2 = (player_records[L6_2]).l
                    anti_aim_state.desync = L5_2
                else
                    L4_2 = script_controls.b
                    L5_2 = anti_aim_state.s_i
                    L6_2 = anti_aim_state.aa
                    L5_2 = L5_2[L6_2]
                    L4_2 = L4_2[L5_2]
                    if L4_2 == "Off" then
                        anti_aim_state.desync = 0
                    else
                        L4_2 = script_controls.b
                        L5_2 = anti_aim_state.s_i
                        L6_2 = anti_aim_state.aa
                        L5_2 = L5_2[L6_2]
                        L4_2 = L4_2[L5_2]
                        if L4_2 == "Jitter" then
                            anti_aim_state.desync = 180
                        else
                            L4_2 = anti_aim_state.desync
                            if L4_2 ~= 0 then
                                L4_2 = anti_aim_state.desync
                                if not (L4_2 ~= 180) then
                                    anti_aim_state.desync = 95
                                end
                            else
                                anti_aim_state.desync = 95
                            end
                            L4_2 = {
                            }
                            L6_2 = anti_aim_state.target
                            L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = head_coordinates(L6_2)
                            L4_2[1] = L5_2
                            L4_2[2] = L6_2
                            L4_2[3] = L7_2
                            L4_2[4] = L8_2
                            L4_2[5] = L9_2
                            L4_2[6] = L10_2
                            L4_2[7] = L11_2
                            L4_2[8] = L12_2
                            L4_2[9] = L13_2
                            L4_2[10] = L14_2
                            L4_2[11] = L15_2
                            L4_2[12] = L16_2
                            L4_2[13] = L17_2
                            L4_2[14] = L18_2
                            L4_2[15] = L19_2
                            L4_2[16] = L20_2
                            L4_2[17] = L21_2
                            L4_2[18] = L22_2
                            L4_2[19] = L23_2
                            L4_2[20] = L24_2
                            L4_2[21] = L25_2
                            L4_2[22] = L26_2
                            L4_2[23] = L27_2
                            L4_2[24] = L28_2
                            L6_2 = L2_2[1]
                            L7_2 = L2_2[2]
                            L8_2 = L4_2[1]
                            L9_2 = L4_2[2]
                            L5_2 = yaw_between_points(L6_2, L7_2, L8_2, L9_2)
                            L8_2 = L5_2 - 90
                            L6_2, L7_2, L8_2 = angles_to_direction(0, L8_2)
                            L9_2 = L2_2[1]
                            L10_2 = L6_2 * 10
                            L9_2 = L9_2 + L10_2
                            L10_2 = L2_2[2]
                            L11_2 = L7_2 * 10
                            L10_2 = L10_2 + L11_2
                            L13_2 = L5_2 + 90
                            L11_2, L12_2, L13_2 = angles_to_direction(0, L13_2)
                            L14_2 = L2_2[1]
                            L15_2 = L11_2 * 10
                            L14_2 = L14_2 + L15_2
                            L15_2 = L2_2[2]
                            L16_2 = L12_2 * 10
                            L15_2 = L15_2 + L16_2
                            L16_2 = L2_2[1]
                            L17_2 = L6_2 * 80
                            L16_2 = L16_2 + L17_2
                            L17_2 = L2_2[2]
                            L18_2 = L7_2 * 80
                            L17_2 = L17_2 + L18_2
                            L18_2 = L2_2[1]
                            L19_2 = L11_2 * 80
                            L18_2 = L18_2 + L19_2
                            L19_2 = L2_2[2]
                            L20_2 = L12_2 * 80
                            L19_2 = L19_2 + L20_2
                            L22_2 = anti_aim_state.target
                            L25_2 = L2_2[3]
                            L20_2 = estimate_damage_at_offsets(L1_2, L22_2, L9_2, L10_2, L25_2)
                            L23_2 = anti_aim_state.target
                            L26_2 = L2_2[3]
                            L21_2 = estimate_damage_at_offsets(L1_2, L23_2, L14_2, L15_2, L26_2)
                            L24_2 = anti_aim_state.target
                            L27_2 = L2_2[3]
                            L22_2 = estimate_damage_at_offsets(L1_2, L24_2, L16_2, L17_2, L27_2)
                            L25_2 = anti_aim_state.target
                            L28_2 = L2_2[3]
                            L23_2 = estimate_damage_at_offsets(L1_2, L25_2, L18_2, L19_2, L28_2)
                            if L22_2 < L23_2 or L20_2 < L21_2 or L21_2 < L23_2 then
                                L25_2 = anti_aim_state.aa
                                if L25_2 == 1 then
                                    if ("left") == "left" then
                                        L26_2 = script_controls.b
                                        L27_2 = anti_aim_state.s_i
                                        L28_2 = anti_aim_state.aa
                                        L27_2 = L27_2[L28_2]
                                        L26_2 = L26_2[L27_2]
                                        if L26_2 == "Freestanding" then
                                            L26_2 = -95
                                            if not (L26_2) then
                                                L26_2 = 95
                                            end
                                        else
                                            L26_2 = 95
                                        end
                                        anti_aim_state.desync = L26_2
                                    else
                                        if not (("left") ~= "right") then
                                            L26_2 = script_controls.b
                                            L27_2 = anti_aim_state.s_i
                                            L28_2 = anti_aim_state.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                L26_2 = 95
                                                if not 95 then
                                                    L26_2 = -95
                                                end
                                            else
                                                L26_2 = -95
                                            end
                                            anti_aim_state.desync = L26_2
                                        end
                                    end
                                else
                                    L25_2 = anti_aim_state.aa
                                    if L25_2 == 2 then
                                        if ("left") == "left" then
                                            L26_2 = script_controls.b
                                            L27_2 = anti_aim_state.s_i
                                            L28_2 = anti_aim_state.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                if L93_1 then
                                                    L26_2 = -95
                                                    if not (L26_2) then
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                            else
                                                L26_2 = 95
                                            end
                                            anti_aim_state.desync = L26_2
                                        else
                                            if not (("left") ~= "right") then
                                                L26_2 = script_controls.b
                                                L27_2 = anti_aim_state.s_i
                                                L28_2 = anti_aim_state.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    if L93_1 then
                                                        L26_2 = 95
                                                        if not 95 then
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                else
                                                    L26_2 = -95
                                                end
                                                anti_aim_state.desync = L26_2
                                            end
                                        end
                                    else
                                        L25_2 = anti_aim_state.aa
                                        if L25_2 == 3 then
                                            anti_aim_state.desync = 180
                                        else
                                            L25_2 = anti_aim_state.aa
                                            if L25_2 == 4 then
                                                if ("left") == "left" then
                                                    L26_2 = script_controls.b
                                                    L27_2 = anti_aim_state.s_i
                                                    L28_2 = anti_aim_state.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        if L93_1 then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                    anti_aim_state.desync = L26_2
                                                else
                                                    if not (("left") ~= "right") then
                                                        L26_2 = script_controls.b
                                                        L27_2 = anti_aim_state.s_i
                                                        L28_2 = anti_aim_state.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            if L93_1 then
                                                                L26_2 = 95
                                                                if not 95 then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                        anti_aim_state.desync = L26_2
                                                    end
                                                end
                                            else
                                                L25_2 = anti_aim_state.aa
                                                if L25_2 == 5 then
                                                    if ("left") == "left" then
                                                        L26_2 = script_controls.b
                                                        L27_2 = anti_aim_state.s_i
                                                        L28_2 = anti_aim_state.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                        anti_aim_state.desync = L26_2
                                                    else
                                                        if not (("left") ~= "right") then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = 95
                                                                if not 95 then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        end
                                                    end
                                                else
                                                    L25_2 = anti_aim_state.aa
                                                    if L25_2 == 6 then
                                                        L26_2 = script_controls.b
                                                        L27_2 = anti_aim_state.s_i
                                                        L28_2 = anti_aim_state.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            L26_2 = client.random_int
                                                            L27_2 = -60
                                                            L28_2 = -20
                                                            L26_2 = L26_2(L27_2, L28_2)
                                                            if not (L26_2) then
                                                                L26_2 = (client.random_int)(20, 60)
                                                            end
                                                        else
                                                            L26_2 = (client.random_int)(20, 60)
                                                        end
                                                        anti_aim_state.desync = L26_2
                                                    else
                                                        L25_2 = anti_aim_state.aa
                                                        if not (L25_2 ~= 7) then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = client.random_int
                                                                L27_2 = -60
                                                                L28_2 = -40
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                                if not (L26_2) then
                                                                    L26_2 = (client.random_int)(40, 60)
                                                                end
                                                            else
                                                                L26_2 = (client.random_int)(40, 60)
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            else
                                if L22_2 > L23_2 or L20_2 > L21_2 or L20_2 < L22_2 then
                                    L25_2 = anti_aim_state.aa
                                    if L25_2 == 1 then
                                        if ("right") == "left" then
                                            L26_2 = script_controls.b
                                            L27_2 = anti_aim_state.s_i
                                            L28_2 = anti_aim_state.aa
                                            L27_2 = L27_2[L28_2]
                                            L26_2 = L26_2[L27_2]
                                            if L26_2 == "Freestanding" then
                                                L26_2 = -95
                                                if not (L26_2) then
                                                    L26_2 = 95
                                                end
                                            else
                                                L26_2 = 95
                                            end
                                            anti_aim_state.desync = L26_2
                                        else
                                            if not (("right") ~= "right") then
                                                L26_2 = script_controls.b
                                                L27_2 = anti_aim_state.s_i
                                                L28_2 = anti_aim_state.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = 95
                                                    if not 95 then
                                                        L26_2 = -95
                                                    end
                                                else
                                                    L26_2 = -95
                                                end
                                                anti_aim_state.desync = L26_2
                                            end
                                        end
                                    else
                                        L25_2 = anti_aim_state.aa
                                        if L25_2 == 2 then
                                            if ("right") == "left" then
                                                L26_2 = script_controls.b
                                                L27_2 = anti_aim_state.s_i
                                                L28_2 = anti_aim_state.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    if L93_1 then
                                                        L26_2 = -95
                                                        if not (L26_2) then
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                                anti_aim_state.desync = L26_2
                                            else
                                                if not (("right") ~= "right") then
                                                    L26_2 = script_controls.b
                                                    L27_2 = anti_aim_state.s_i
                                                    L28_2 = anti_aim_state.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        if L93_1 then
                                                            L26_2 = 95
                                                            if not 95 then
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                    anti_aim_state.desync = L26_2
                                                end
                                            end
                                        else
                                            L25_2 = anti_aim_state.aa
                                            if L25_2 == 3 then
                                                anti_aim_state.desync = 180
                                            else
                                                L25_2 = anti_aim_state.aa
                                                if L25_2 == 4 then
                                                    if ("right") == "left" then
                                                        L26_2 = script_controls.b
                                                        L27_2 = anti_aim_state.s_i
                                                        L28_2 = anti_aim_state.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            if L93_1 then
                                                                L26_2 = -95
                                                                if not (L26_2) then
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                        anti_aim_state.desync = L26_2
                                                    else
                                                        if not (("right") ~= "right") then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                if L93_1 then
                                                                    L26_2 = 95
                                                                    if not 95 then
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        end
                                                    end
                                                else
                                                    L25_2 = anti_aim_state.aa
                                                    if L25_2 == 5 then
                                                        if ("right") == "left" then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = -95
                                                                if not (L26_2) then
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        else
                                                            if not (("right") ~= "right") then
                                                                L26_2 = script_controls.b
                                                                L27_2 = anti_aim_state.s_i
                                                                L28_2 = anti_aim_state.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = 95
                                                                    if not 95 then
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                                anti_aim_state.desync = L26_2
                                                            end
                                                        end
                                                    else
                                                        L25_2 = anti_aim_state.aa
                                                        if L25_2 == 6 then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                L26_2 = client.random_int
                                                                L27_2 = -60
                                                                L28_2 = -20
                                                                L26_2 = L26_2(L27_2, L28_2)
                                                                if not (L26_2) then
                                                                    L26_2 = (client.random_int)(20, 60)
                                                                end
                                                            else
                                                                L26_2 = (client.random_int)(20, 60)
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        else
                                                            L25_2 = anti_aim_state.aa
                                                            if not (L25_2 ~= 7) then
                                                                L26_2 = script_controls.b
                                                                L27_2 = anti_aim_state.s_i
                                                                L28_2 = anti_aim_state.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = client.random_int
                                                                    L27_2 = -60
                                                                    L28_2 = -40
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                    if not (L26_2) then
                                                                        L26_2 = (client.random_int)(40, 60)
                                                                    end
                                                                else
                                                                    L26_2 = (client.random_int)(40, 60)
                                                                end
                                                                anti_aim_state.desync = L26_2
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                else
                                    L25_2 = anti_aim_state.holding_e
                                    if not L25_2 then
                                        anti_aim_state.desync = 180
                                        return 
                                    else
                                        L25_2 = anti_aim_state.aa
                                        if L25_2 == 1 then
                                            if ("") == "left" then
                                                L26_2 = script_controls.b
                                                L27_2 = anti_aim_state.s_i
                                                L28_2 = anti_aim_state.aa
                                                L27_2 = L27_2[L28_2]
                                                L26_2 = L26_2[L27_2]
                                                if L26_2 == "Freestanding" then
                                                    L26_2 = -95
                                                    if not (L26_2) then
                                                        L26_2 = 95
                                                    end
                                                else
                                                    L26_2 = 95
                                                end
                                                anti_aim_state.desync = L26_2
                                            else
                                                if not (("") ~= "right") then
                                                    L26_2 = script_controls.b
                                                    L27_2 = anti_aim_state.s_i
                                                    L28_2 = anti_aim_state.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        L26_2 = 95
                                                        if not 95 then
                                                            L26_2 = -95
                                                        end
                                                    else
                                                        L26_2 = -95
                                                    end
                                                    anti_aim_state.desync = L26_2
                                                end
                                            end
                                        else
                                            L25_2 = anti_aim_state.aa
                                            if L25_2 == 2 then
                                                if ("") == "left" then
                                                    L26_2 = script_controls.b
                                                    L27_2 = anti_aim_state.s_i
                                                    L28_2 = anti_aim_state.aa
                                                    L27_2 = L27_2[L28_2]
                                                    L26_2 = L26_2[L27_2]
                                                    if L26_2 == "Freestanding" then
                                                        if L93_1 then
                                                            L26_2 = -95
                                                            if not (L26_2) then
                                                                L26_2 = 95
                                                            end
                                                        else
                                                            L26_2 = 95
                                                        end
                                                    else
                                                        L26_2 = 95
                                                    end
                                                    anti_aim_state.desync = L26_2
                                                else
                                                    if not (("") ~= "right") then
                                                        L26_2 = script_controls.b
                                                        L27_2 = anti_aim_state.s_i
                                                        L28_2 = anti_aim_state.aa
                                                        L27_2 = L27_2[L28_2]
                                                        L26_2 = L26_2[L27_2]
                                                        if L26_2 == "Freestanding" then
                                                            if L93_1 then
                                                                L26_2 = 95
                                                                if not 95 then
                                                                    L26_2 = -95
                                                                end
                                                            else
                                                                L26_2 = -95
                                                            end
                                                        else
                                                            L26_2 = -95
                                                        end
                                                        anti_aim_state.desync = L26_2
                                                    end
                                                end
                                            else
                                                L25_2 = anti_aim_state.aa
                                                if L25_2 == 3 then
                                                    anti_aim_state.desync = 180
                                                else
                                                    L25_2 = anti_aim_state.aa
                                                    if L25_2 == 4 then
                                                        if ("") == "left" then
                                                            L26_2 = script_controls.b
                                                            L27_2 = anti_aim_state.s_i
                                                            L28_2 = anti_aim_state.aa
                                                            L27_2 = L27_2[L28_2]
                                                            L26_2 = L26_2[L27_2]
                                                            if L26_2 == "Freestanding" then
                                                                if L93_1 then
                                                                    L26_2 = -95
                                                                    if not (L26_2) then
                                                                        L26_2 = 95
                                                                    end
                                                                else
                                                                    L26_2 = 95
                                                                end
                                                            else
                                                                L26_2 = 95
                                                            end
                                                            anti_aim_state.desync = L26_2
                                                        else
                                                            if not (("") ~= "right") then
                                                                L26_2 = script_controls.b
                                                                L27_2 = anti_aim_state.s_i
                                                                L28_2 = anti_aim_state.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    if L93_1 then
                                                                        L26_2 = 95
                                                                        if not 95 then
                                                                            L26_2 = -95
                                                                        end
                                                                    else
                                                                        L26_2 = -95
                                                                    end
                                                                else
                                                                    L26_2 = -95
                                                                end
                                                                anti_aim_state.desync = L26_2
                                                            end
                                                        end
                                                    else
                                                        L25_2 = anti_aim_state.aa
                                                        if L25_2 == 5 then
                                                            if ("") == "left" then
                                                                L26_2 = script_controls.b
                                                                L27_2 = anti_aim_state.s_i
                                                                L28_2 = anti_aim_state.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = -95
                                                                    if not (L26_2) then
                                                                        L26_2 = 95
                                                                    end
                                                                else
                                                                    L26_2 = 95
                                                                end
                                                                anti_aim_state.desync = L26_2
                                                            else
                                                                if not (("") ~= "right") then
                                                                    L26_2 = script_controls.b
                                                                    L27_2 = anti_aim_state.s_i
                                                                    L28_2 = anti_aim_state.aa
                                                                    L27_2 = L27_2[L28_2]
                                                                    L26_2 = L26_2[L27_2]
                                                                    if L26_2 == "Freestanding" then
                                                                        L26_2 = 95
                                                                        if not 95 then
                                                                            L26_2 = -95
                                                                        end
                                                                    else
                                                                        L26_2 = -95
                                                                    end
                                                                    anti_aim_state.desync = L26_2
                                                                end
                                                            end
                                                        else
                                                            L25_2 = anti_aim_state.aa
                                                            if L25_2 == 6 then
                                                                L26_2 = script_controls.b
                                                                L27_2 = anti_aim_state.s_i
                                                                L28_2 = anti_aim_state.aa
                                                                L27_2 = L27_2[L28_2]
                                                                L26_2 = L26_2[L27_2]
                                                                if L26_2 == "Freestanding" then
                                                                    L26_2 = client.random_int
                                                                    L27_2 = -60
                                                                    L28_2 = -20
                                                                    L26_2 = L26_2(L27_2, L28_2)
                                                                    if not (L26_2) then
                                                                        L26_2 = (client.random_int)(20, 60)
                                                                    end
                                                                else
                                                                    L26_2 = (client.random_int)(20, 60)
                                                                end
                                                                anti_aim_state.desync = L26_2
                                                            else
                                                                L25_2 = anti_aim_state.aa
                                                                if not (L25_2 ~= 7) then
                                                                    L26_2 = script_controls.b
                                                                    L27_2 = anti_aim_state.s_i
                                                                    L28_2 = anti_aim_state.aa
                                                                    L27_2 = L27_2[L28_2]
                                                                    L26_2 = L26_2[L27_2]
                                                                    if L26_2 == "Freestanding" then
                                                                        L26_2 = client.random_int
                                                                        L27_2 = -60
                                                                        L28_2 = -40
                                                                        L26_2 = L26_2(L27_2, L28_2)
                                                                        if not (L26_2) then
                                                                            L26_2 = (client.random_int)(40, 60)
                                                                        end
                                                                    else
                                                                        L26_2 = (client.random_int)(40, 60)
                                                                    end
                                                                    anti_aim_state.desync = L26_2
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            else
                L5_2 = anti_aim_state.target
                L4_2 = (player_records[L5_2]).m
                L5_2 = script_controls["Anti-resolver shot amount"]
                if L4_2 == L5_2 then
                    L4_2 = script_controls["Anti-resolver on X shot"]
                    if L4_2 ~= "-" then
                        L4_2 = script_controls["Anti-resolver on X shot"]
                        if L4_2 == "None" then
                            anti_aim_state.desync = 0
                        else
                            L4_2 = script_controls["Anti-resolver on X shot"]
                            if L4_2 == "Jitter" then
                                anti_aim_state.desync = 180
                            end
                        end
                    end
                else
                    L6_2 = anti_aim_state.target
                    L5_2 = (player_records[L6_2]).d
                    anti_aim_state.desync = L5_2
                end
            end
        else
            L4_2 = script_controls.b
            L5_2 = anti_aim_state.s_i
            L6_2 = anti_aim_state.aa
            L5_2 = L5_2[L6_2]
            L4_2 = L4_2[L5_2]
            if L4_2 == "Off" then
                anti_aim_state.desync = 0
            else
                L4_2 = script_controls.b
                L5_2 = anti_aim_state.s_i
                L6_2 = anti_aim_state.aa
                L5_2 = L5_2[L6_2]
                L4_2 = L4_2[L5_2]
                if L4_2 == "Jitter" then
                    anti_aim_state.desync = 180
                else
                    L4_2 = anti_aim_state.holding_e
                    if L4_2 then
                        L5_2 = anti_aim_state.desync
                        if L5_2 ~= 0 then
                            L5_2 = anti_aim_state.desync
                            if not (L5_2 ~= 180) then
                                L5_2 = 90
                            end
                        else
                            L5_2 = 90
                        end
                        if not L5_2 then
                            L5_2 = anti_aim_state.desync
                        end
                        anti_aim_state.desync = L5_2
                    else
                        anti_aim_state.desync = 180
                    end
                end
            end
        end
    end
    reset_player_state = function(A0_2, ...)
        local L4_2, L5_2, L6_2, L7_2, L8_2
        if A0_2 == nil then
            A0_2 = false
        end
        for L4_2 = 1, 64, 1 do
            L5_2 = (player_records[L4_2]).d
            L6_2 = player_records
            L7_2 = {
            }
            L7_2.s = {
            }
            L8_2 = {
            }
            L7_2.h = L8_2
            L7_2.r = 0
            L7_2.d = 0
            L7_2.m = 0
            L8_2 = L5_2 or L8_2
            if not A0_2 or not L5_2 then
                L8_2 = 0
            end
            L7_2.l = L8_2
            player_records[L4_2] = L7_2
        end
    end
    handle_use_key = function(A0_2, A1_2, ...)
        local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
        L3_2 = script_controls.s
        L2_2 = contains_value(L3_2, ("Custom Legit AA"))
        if L2_2 then
            L2_2 = key_state(69)
            if L2_2 then
                return 
            else
                L3_2 = script_controls.s
                L2_2 = contains_value(L3_2, ("Custom Legit AA"))
                if L2_2 then
                    L3_2 = script_controls.la
                    L2_2 = ui_get(L3_2)
                    if not (L2_2) then
                        L2_2 = key_state(69)
                    end
                else
                    L2_2 = key_state(69)
                end
                if L2_2 then
                    L2_2 = 100
                    L3_2 = (get_all_entities(("CPlantedC4")))[1]
                    if L3_2 ~= nil then
                        L4_2 = {
                        }
                        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = get_prop(L3_2, ("m_vecOrigin"))
                        L4_2[1] = L5_2
                        L4_2[2] = L6_2
                        L4_2[3] = L7_2
                        L4_2[4] = L8_2
                        L4_2[5] = L9_2
                        L4_2[6] = L10_2
                        L4_2[7] = L11_2
                        L4_2[8] = L12_2
                        L4_2[9] = L13_2
                        L4_2[10] = L14_2
                        L4_2[11] = L15_2
                        L4_2[12] = L16_2
                        L4_2[13] = L17_2
                        L4_2[14] = L18_2
                        L4_2[15] = L19_2
                        L4_2[16] = L20_2
                        L4_2[17] = L21_2
                        L4_2[18] = L22_2
                        L4_2[19] = L23_2
                        L4_2[20] = L24_2
                        if L4_2 ~= nil then
                            L5_2 = {
                            }
                            L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = get_prop(A0_2, ("m_vecOrigin"))
                            L5_2[1] = L6_2
                            L5_2[2] = L7_2
                            L5_2[3] = L8_2
                            L5_2[4] = L9_2
                            L5_2[5] = L10_2
                            L5_2[6] = L11_2
                            L5_2[7] = L12_2
                            L5_2[8] = L13_2
                            L5_2[9] = L14_2
                            L5_2[10] = L15_2
                            L5_2[11] = L16_2
                            L5_2[12] = L17_2
                            L5_2[13] = L18_2
                            L5_2[14] = L19_2
                            L5_2[15] = L20_2
                            L5_2[16] = L21_2
                            L5_2[17] = L22_2
                            L5_2[18] = L23_2
                            L5_2[19] = L24_2
                            local returned_56_38 = __dec14_pack_results(signed_coordinate_delta(L5_2, L4_2))
                            L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_38, 1, returned_56_38.n)
                            L2_2 = math_abs(unpack(returned_56_38, 1, returned_56_38.n))
                        end
                    end
                    L4_2 = get_prop(A0_2, ("m_iTeamNum"))
                    if L4_2 ~= 3 or not (L2_2 < 62) then
                        L5_2 = false
                    else
                        L5_2 = true
                    end
                    L6_2, L7_2, L8_2 = eye_position()
                    L9_2, L10_2 = camera_angles()
                    local returned_56_39 = __dec14_pack_results(math_rad(L9_2))
                    L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_39, 1, returned_56_39.n)
                    L11_2 = math_sin(unpack(returned_56_39, 1, returned_56_39.n))
                    local returned_56_40 = __dec14_pack_results(math_rad(L9_2))
                    L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_40, 1, returned_56_40.n)
                    L12_2 = math_cos(unpack(returned_56_40, 1, returned_56_40.n))
                    local returned_56_41 = __dec14_pack_results(math_rad(L10_2))
                    L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_41, 1, returned_56_41.n)
                    L13_2 = math_sin(unpack(returned_56_41, 1, returned_56_41.n))
                    local returned_56_42 = __dec14_pack_results(math_rad(L10_2))
                    L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_42, 1, returned_56_42.n)
                    L14_2 = math_cos(unpack(returned_56_42, 1, returned_56_42.n))
                    L15_2 = {
                    }
                    L16_2 = L12_2 * L14_2
                    L17_2 = L12_2 * L13_2
                    L18_2 = -L11_2
                    L15_2[1] = L16_2
                    L15_2[2] = L17_2
                    L15_2[3] = L18_2
                    L21_2 = (L15_2[1]) * 8192
                    L21_2 = L6_2 + L21_2
                    L22_2 = (L15_2[2]) * 8192
                    L22_2 = L7_2 + L22_2
                    L23_2 = (L15_2[3]) * 8192
                    L23_2 = L8_2 + L23_2
                    L16_2, L17_2 = trace_line(A0_2, L6_2, L7_2, L8_2, L21_2, L22_2, L23_2)
                    L18_2 = true
                    if L17_2 ~= nil then
                        L20_2 = #(anti_aim_state.classnames)
                        for L22_2 = 0, L20_2, 1 do
                            L23_2 = get_classname(L17_2)
                            L24_2 = (anti_aim_state.classnames)[L22_2]
                            if L23_2 == L24_2 then
                                L18_2 = false
                            end
                        end
                    end
                    if not L18_2 and not L5_2 then
                        A1_2.in_use = 0
                    end
                    return true
                else
                    return false
                end
            end
        else
            L3_2 = script_controls.s
            L2_2 = contains_value(L3_2, ("Custom Legit AA"))
            if L2_2 then
                L3_2 = script_controls.la
                L2_2 = ui_get(L3_2)
                if not (L2_2) then
                    L2_2 = key_state(69)
                end
            else
                L2_2 = key_state(69)
            end
            if L2_2 then
                L2_2 = 100
                L3_2 = (get_all_entities(("CPlantedC4")))[1]
                if L3_2 ~= nil then
                    L4_2 = {
                    }
                    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = get_prop(L3_2, ("m_vecOrigin"))
                    L4_2[1] = L5_2
                    L4_2[2] = L6_2
                    L4_2[3] = L7_2
                    L4_2[4] = L8_2
                    L4_2[5] = L9_2
                    L4_2[6] = L10_2
                    L4_2[7] = L11_2
                    L4_2[8] = L12_2
                    L4_2[9] = L13_2
                    L4_2[10] = L14_2
                    L4_2[11] = L15_2
                    L4_2[12] = L16_2
                    L4_2[13] = L17_2
                    L4_2[14] = L18_2
                    L4_2[15] = L19_2
                    L4_2[16] = L20_2
                    L4_2[17] = L21_2
                    L4_2[18] = L22_2
                    L4_2[19] = L23_2
                    L4_2[20] = L24_2
                    if L4_2 ~= nil then
                        L5_2 = {
                        }
                        L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = get_prop(A0_2, ("m_vecOrigin"))
                        L5_2[1] = L6_2
                        L5_2[2] = L7_2
                        L5_2[3] = L8_2
                        L5_2[4] = L9_2
                        L5_2[5] = L10_2
                        L5_2[6] = L11_2
                        L5_2[7] = L12_2
                        L5_2[8] = L13_2
                        L5_2[9] = L14_2
                        L5_2[10] = L15_2
                        L5_2[11] = L16_2
                        L5_2[12] = L17_2
                        L5_2[13] = L18_2
                        L5_2[14] = L19_2
                        L5_2[15] = L20_2
                        L5_2[16] = L21_2
                        L5_2[17] = L22_2
                        L5_2[18] = L23_2
                        L5_2[19] = L24_2
                        local returned_56_38 = __dec14_pack_results(signed_coordinate_delta(L5_2, L4_2))
                        L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_38, 1, returned_56_38.n)
                        L2_2 = math_abs(unpack(returned_56_38, 1, returned_56_38.n))
                    end
                end
                L4_2 = get_prop(A0_2, ("m_iTeamNum"))
                if L4_2 ~= 3 or not (L2_2 < 62) then
                    L5_2 = false
                else
                    L5_2 = true
                end
                L6_2, L7_2, L8_2 = eye_position()
                L9_2, L10_2 = camera_angles()
                local returned_56_39 = __dec14_pack_results(math_rad(L9_2))
                L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_39, 1, returned_56_39.n)
                L11_2 = math_sin(unpack(returned_56_39, 1, returned_56_39.n))
                local returned_56_40 = __dec14_pack_results(math_rad(L9_2))
                L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_40, 1, returned_56_40.n)
                L12_2 = math_cos(unpack(returned_56_40, 1, returned_56_40.n))
                local returned_56_41 = __dec14_pack_results(math_rad(L10_2))
                L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_41, 1, returned_56_41.n)
                L13_2 = math_sin(unpack(returned_56_41, 1, returned_56_41.n))
                local returned_56_42 = __dec14_pack_results(math_rad(L10_2))
                L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = unpack(returned_56_42, 1, returned_56_42.n)
                L14_2 = math_cos(unpack(returned_56_42, 1, returned_56_42.n))
                L15_2 = {
                }
                L16_2 = L12_2 * L14_2
                L17_2 = L12_2 * L13_2
                L18_2 = -L11_2
                L15_2[1] = L16_2
                L15_2[2] = L17_2
                L15_2[3] = L18_2
                L21_2 = (L15_2[1]) * 8192
                L21_2 = L6_2 + L21_2
                L22_2 = (L15_2[2]) * 8192
                L22_2 = L7_2 + L22_2
                L23_2 = (L15_2[3]) * 8192
                L23_2 = L8_2 + L23_2
                L16_2, L17_2 = trace_line(A0_2, L6_2, L7_2, L8_2, L21_2, L22_2, L23_2)
                L18_2 = true
                if L17_2 ~= nil then
                    L20_2 = #(anti_aim_state.classnames)
                    for L22_2 = 0, L20_2, 1 do
                        L23_2 = get_classname(L17_2)
                        L24_2 = (anti_aim_state.classnames)[L22_2]
                        if L23_2 == L24_2 then
                            L18_2 = false
                        end
                    end
                end
                if not L18_2 and not L5_2 then
                    A1_2.in_use = 0
                end
                return true
            else
                return false
            end
        end
    end
    L98_1 = 0
    update_manual_and_freestanding = function(A0_2, ...)
        local L2_2, L3_2, L6_2, L7_2, L8_2
        L2_2 = (native_controls.yaw)[1]
        L3_2 = anti_aim_state.holding_e
        if L3_2 then
            L3_2 = "Off"
            if not ("Off") then
                L3_2 = "180"
            end
        else
            L3_2 = "180"
        end
        ui_set(L2_2, L3_2)
        L2_2 = native_controls.pitch
        L3_2 = anti_aim_state.holding_e
        if L3_2 then
            L3_2 = "Off"
            if not ("Off") then
                L3_2 = "Default"
            end
        else
            L3_2 = "Default"
        end
        ui_set(L2_2, L3_2)
        L2_2 = native_controls.yawbase
        ui_set(L2_2, ("At targets"))
        L6_2 = anti_aim_state.aa
        if L6_2 == 1 then
            L98_1 = 0
        else
            L6_2 = anti_aim_state.aa
            if L6_2 == 2 then
                L98_1 = 0
            else
                L6_2 = anti_aim_state.aa
                if L6_2 == 3 then
                    L98_1 = 0
                else
                    L6_2 = anti_aim_state.aa
                    if L6_2 == 4 then
                        L98_1 = 0
                    else
                        L6_2 = anti_aim_state.aa
                        if L6_2 == 6 then
                            L98_1 = 0
                        end
                    end
                end
            end
        end
        L7_2 = script_controls.s
        L6_2 = contains_value(L7_2, ("Manual AA"))
        if L6_2 then
            L7_2 = script_controls.ml
            L6_2 = ui_get(L7_2)
            if L6_2 then
                L6_2 = ((anti_aim_state.dir).time) + 0.2
                L7_2 = curtime()
                if L6_2 < L7_2 then
                    L6_2 = anti_aim_state.dir
                    L7_2 = (anti_aim_state.dir).manual
                    if L7_2 == -90 then
                        L7_2 = L98_1
                        if not L98_1 then
                            L7_2 = -90
                        end
                    else
                        L7_2 = -90
                    end
                    L6_2.manual = L7_2
                    L6_2 = anti_aim_state.dir
                    L6_2.time = curtime()
                end
            else
                L7_2 = script_controls.mr
                L6_2 = ui_get(L7_2)
                if L6_2 then
                    L6_2 = ((anti_aim_state.dir).time) + 0.2
                    L7_2 = curtime()
                    if L6_2 < L7_2 then
                        L6_2 = anti_aim_state.dir
                        L7_2 = (anti_aim_state.dir).manual
                        if L7_2 == 90 then
                            L7_2 = L98_1
                            if not L98_1 then
                                L7_2 = 90
                            end
                        else
                            L7_2 = 90
                        end
                        L6_2.manual = L7_2
                        L6_2 = anti_aim_state.dir
                        L6_2.time = curtime()
                    end
                else
                    L7_2 = script_controls.mf
                    L6_2 = ui_get(L7_2)
                    if L6_2 then
                        L6_2 = ((anti_aim_state.dir).time) + 0.2
                        L7_2 = curtime()
                        if L6_2 < L7_2 then
                            L6_2 = anti_aim_state.dir
                            L7_2 = (anti_aim_state.dir).manual
                            if L7_2 == 180 then
                                L7_2 = L98_1
                                if not L98_1 then
                                    L7_2 = 180
                                end
                            else
                                L7_2 = 180
                            end
                            L6_2.manual = L7_2
                            L6_2 = anti_aim_state.dir
                            L6_2.time = curtime()
                        end
                    else
                        L6_2 = (anti_aim_state.dir).time
                        L7_2 = curtime()
                        if L6_2 > L7_2 then
                            L6_2 = anti_aim_state.dir
                            L6_2.time = curtime()
                            L6_2 = (anti_aim_state.dir).manual
                            if L6_2 == -90 then
                                L6_2 = (anti_aim_state.dir).manual
                                if L6_2 == 90 then
                                    L6_2 = (anti_aim_state.dir).manual
                                    if not (L6_2 == 180) then
                                        L6_2 = anti_aim_state.dir
                                        L6_2.manual = L98_1
                                    end
                                else
                                    L6_2 = anti_aim_state.dir
                                    L6_2.manual = L98_1
                                end
                            else
                                L6_2 = anti_aim_state.dir
                                L6_2.manual = L98_1
                            end
                        end
                    end
                end
            end
            L6_2 = (anti_aim_state.dir).manual
            L7_2 = (anti_aim_state.stored_dir).manual
            if L6_2 ~= L7_2 then
                L7_2 = (native_controls.yaw)[2]
                L8_2 = (anti_aim_state.dir).manual
                ui_set(L7_2, L8_2)
                L6_2 = anti_aim_state.stored_dir
                L6_2.manual = (anti_aim_state.dir).manual
            end
        else
            L6_2 = anti_aim_state.dir
            L6_2.manual = L98_1
        end
        L7_2 = (native_controls.yaw)[2]
        L8_2 = (anti_aim_state.dir).manual
        ui_set(L7_2, L8_2)
        L6_2 = anti_aim_state.dir
        L8_2 = script_controls.s
        L7_2 = contains_value(L8_2, ("Edge yaw"))
        if L7_2 then
            L8_2 = script_controls.ey
            L7_2 = ui_get(L8_2)
            if L7_2 then
                L7_2 = not (anti_aim_state.holding_e)
            end
        end
        L6_2.edge = L7_2
        L6_2 = anti_aim_state.dir
        L8_2 = script_controls.s
        L7_2 = contains_value(L8_2, ("Freestanding"))
        if L7_2 then
            L8_2 = script_controls.fs
            L7_2 = ui_get(L8_2)
            if L7_2 then
                L7_2 = not (anti_aim_state.holding_e)
            end
        end
        L6_2.freestand = L7_2
        L6_2 = (anti_aim_state.dir).freestand
        L7_2 = (anti_aim_state.stored_dir).freestand
        if L6_2 ~= L7_2 then
            L7_2 = (native_controls.freestand)[1]
            L8_2 = (anti_aim_state.dir).freestand
            if L8_2 then
                L8_2 = "Default"
                if not ("Default") then
                    L8_2 = "-"
                end
            else
                L8_2 = "-"
            end
            ui_set(L7_2, L8_2)
            L7_2 = (native_controls.freestand)[2]
            ui_set(L7_2, ("Always on"))
            L6_2 = anti_aim_state.stored_dir
            L6_2.freestand = (anti_aim_state.dir).freestand
        end
        L6_2 = (anti_aim_state.dir).edge
        L7_2 = (anti_aim_state.stored_dir).edge
        if L6_2 ~= L7_2 then
            L7_2 = native_controls.edgeyaw
            L8_2 = (anti_aim_state.dir).edge
            ui_set(L7_2, L8_2)
            L6_2 = anti_aim_state.stored_dir
            L6_2.edge = (anti_aim_state.dir).edge
        end
    end
    point_on_circle = function(A0_2, A1_2, A2_2, A3_2, ...)
        local L4_2, L5_2, L6_2, L7_2
        local returned_58_43 = __dec14_pack_results(math_rad(A2_2))
        L5_2, L6_2, L7_2 = unpack(returned_58_43, 1, returned_58_43.n)
        L4_2 = ((math_cos(unpack(returned_58_43, 1, returned_58_43.n))) * A3_2) + A0_2
        local returned_58_44 = __dec14_pack_results(math_rad(A2_2))
        L6_2, L7_2 = unpack(returned_58_44, 1, returned_58_44.n)
        L5_2 = ((math_sin(unpack(returned_58_44, 1, returned_58_44.n))) * A3_2) + A1_2
        return L4_2, L5_2
    end
    draw_indicator_triangle = function(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2, A11_2, A12_2, ...)
        local L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L30_2, L31_2, L32_2, L33_2
        L15_2 = A1_2 + 4
        L13_2, L14_2 = point_on_circle(A0_2, L15_2, A10_2, 45)
        L17_2 = A1_2 + 4
        L18_2 = A11_2 / 3
        L18_2 = A10_2 + L18_2
        L19_2 = A11_2 / 4
        L19_2 = 45 - L19_2
        L15_2, L16_2 = point_on_circle(A0_2, L17_2, L18_2, L19_2)
        L19_2 = A1_2 + 4
        L21_2 = A11_2 / 5
        L21_2 = 45 - L21_2
        L17_2, L18_2 = point_on_circle(A0_2, L19_2, A10_2, L21_2)
        L21_2 = A1_2 + 4
        L23_2 = A11_2 / 5
        L23_2 = 45 - L23_2
        L19_2, L20_2 = point_on_circle(A0_2, L21_2, A10_2, L23_2)
        L23_2 = A1_2 + 4
        L24_2 = A11_2 / 3
        L24_2 = A10_2 - L24_2
        L25_2 = A11_2 / 4
        L25_2 = 45 - L25_2
        L21_2, L22_2 = point_on_circle(A0_2, L23_2, L24_2, L25_2)
        L30_2 = A6_2 or nil
        if not A12_2 or not A6_2 then
            L30_2 = A2_2
        end
        L31_2 = A7_2 or nil
        if not A12_2 or not A7_2 then
            L31_2 = A3_2
        end
        L32_2 = A8_2 or nil
        if not A12_2 or not A8_2 then
            L32_2 = A4_2
        end
        L33_2 = A9_2 or nil
        if not A12_2 or not A9_2 then
            L33_2 = A5_2
        end
        draw_triangle(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L30_2, L31_2, L32_2, L33_2)
        L30_2 = A2_2 or L30_2
        if not A12_2 or not A2_2 then
            L30_2 = A6_2
        end
        L31_2 = A3_2 or L31_2
        if not A12_2 or not A3_2 then
            L31_2 = A7_2
        end
        L32_2 = A4_2 or L32_2
        if not A12_2 or not A4_2 then
            L32_2 = A8_2
        end
        L33_2 = A5_2 or L33_2
        if not A12_2 or not A5_2 then
            L33_2 = A9_2
        end
        draw_triangle(L13_2, L14_2, L19_2, L20_2, L21_2, L22_2, L30_2, L31_2, L32_2, L33_2)
        draw_line(L13_2, L14_2, L19_2, L20_2, 0, 0, 0, 200)
    end
    reset_clan_tag = function(...)
        if L93_1 then

        else

        end
    end
    apply_body_yaw = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
        L1_2 = get_local_player()
        L2_2 = anti_aim_state.rec
        L3_2 = (#(anti_aim_state.rec)) + 1
        L4_2 = {
        }
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = head_coordinates(L1_2)
        L4_2[1] = L5_2
        L4_2[2] = L6_2
        L4_2[3] = L7_2
        L4_2[4] = L8_2
        L4_2[5] = L9_2
        L4_2[6] = L10_2
        L4_2[7] = L11_2
        L2_2[L3_2] = L4_2
        L2_2 = #(anti_aim_state.rec)
        if 28 < L2_2 then
            L3_2 = anti_aim_state.rec
            table_remove(L3_2, 1)
        end
        classify_movement(L1_2, A0_2)
        update_target_anti_aim(L1_2)
        L3_2 = handle_use_key(L1_2, A0_2)
        anti_aim_state.holding_e = L3_2
        L4_2 = anti_aim_state.holding_e
        update_manual_and_freestanding(L1_2, L4_2)
        L3_2 = (native_controls.bodyyaw)[1]
        if fs then
            L4_2 = "Static"
            if not ("Static") then
                L4_2 = anti_aim_state.desync
                if L4_2 == 180 then
                    L5_2 = script_controls.s
                    L4_2 = contains_value(L5_2, ("Jitter when not networked"))
                    if L4_2 then
                        L4_2 = "Jitter"
                        if not ("Jitter") then
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 3 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 2 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = anti_aim_state.aa
                                            if L4_2 == 4 then
                                                L4_2 = "Jitter"
                                                if not ("Jitter") then
                                                    L4_2 = "Static"
                                                end
                                            else
                                                L4_2 = "Static"
                                            end
                                        end
                                    else
                                        L4_2 = anti_aim_state.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not ("Jitter") then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                end
                            else
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = anti_aim_state.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not ("Jitter") then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 3 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = anti_aim_state.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not ("Jitter") then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        else
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state.aa
                    if L4_2 == 3 then
                        L4_2 = "Jitter"
                        if not ("Jitter") then
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                end
            end
        else
            L4_2 = anti_aim_state.desync
            if L4_2 == 180 then
                L5_2 = script_controls.s
                L4_2 = contains_value(L5_2, ("Jitter when not networked"))
                if L4_2 then
                    L4_2 = "Jitter"
                    if not ("Jitter") then
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 3 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 2 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = anti_aim_state.aa
                                        if L4_2 == 4 then
                                            L4_2 = "Jitter"
                                            if not ("Jitter") then
                                                L4_2 = "Static"
                                            end
                                        else
                                            L4_2 = "Static"
                                        end
                                    end
                                else
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            end
                        else
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state.aa
                    if L4_2 == 3 then
                        L4_2 = "Jitter"
                        if not ("Jitter") then
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 2 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = anti_aim_state.aa
                                    if L4_2 == 4 then
                                        L4_2 = "Jitter"
                                        if not ("Jitter") then
                                            L4_2 = "Static"
                                        end
                                    else
                                        L4_2 = "Static"
                                    end
                                end
                            else
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        end
                    else
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                end
            else
                L4_2 = anti_aim_state.aa
                if L4_2 == 3 then
                    L4_2 = "Jitter"
                    if not ("Jitter") then
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 2 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = anti_aim_state.aa
                                if L4_2 == 4 then
                                    L4_2 = "Jitter"
                                    if not ("Jitter") then
                                        L4_2 = "Static"
                                    end
                                else
                                    L4_2 = "Static"
                                end
                            end
                        else
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    end
                else
                    L4_2 = anti_aim_state.aa
                    if L4_2 == 2 then
                        L4_2 = "Jitter"
                        if not ("Jitter") then
                            L4_2 = anti_aim_state.aa
                            if L4_2 == 4 then
                                L4_2 = "Jitter"
                                if not ("Jitter") then
                                    L4_2 = "Static"
                                end
                            else
                                L4_2 = "Static"
                            end
                        end
                    else
                        L4_2 = anti_aim_state.aa
                        if L4_2 == 4 then
                            L4_2 = "Jitter"
                            if not ("Jitter") then
                                L4_2 = "Static"
                            end
                        else
                            L4_2 = "Static"
                        end
                    end
                end
            end
        end
        ui_set(L3_2, L4_2)
        L3_2 = (native_controls.bodyyaw)[2]
        L4_2 = anti_aim_state.desync
        if L4_2 == 180 then
            L4_2 = 0
            if not 0 then
                L4_2 = anti_aim_state.holding_e
                if L4_2 then
                    L4_2 = -(anti_aim_state.desync)
                    if not (L4_2) then
                        L4_2 = anti_aim_state.desync
                    end
                else
                    L4_2 = anti_aim_state.desync
                end
            end
        else
            L4_2 = anti_aim_state.holding_e
            if L4_2 then
                L4_2 = -(anti_aim_state.desync)
                if not (L4_2) then
                    L4_2 = anti_aim_state.desync
                end
            else
                L4_2 = anti_aim_state.desync
            end
        end
        ui_set(L3_2, L4_2)
        L2_2 = anti_aim_state.aa
        if L2_2 == 1 then
            L3_2 = (native_controls.yawjitter)[1]
            ui_set(L3_2, ("Random"))
            L3_2 = (native_controls.yawjitter)[2]
            ui_set(L3_2, 7)
        else
            L2_2 = anti_aim_state.aa
            if L2_2 == 2 then
                L3_2 = (native_controls.yawjitter)[1]
                ui_set(L3_2, ("Center"))
                L3_2 = (native_controls.yawjitter)[2]
                ui_set(L3_2, 60)
            else
                L2_2 = anti_aim_state.aa
                if L2_2 == 3 then
                    L3_2 = (native_controls.yawjitter)[1]
                    ui_set(L3_2, ("Offset"))
                    L3_2 = (native_controls.yawjitter)[2]
                    L4_2 = client.random_int
                    local returned_61_45 = __dec14_pack_results(L4_2(0, 60))
                    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = unpack(returned_61_45, 1, returned_61_45.n)
                    ui_set(L3_2, unpack(returned_61_45, 1, returned_61_45.n))
                else
                    L2_2 = anti_aim_state.aa
                    if L2_2 == 4 then
                        L3_2 = (native_controls.yawjitter)[1]
                        ui_set(L3_2, ("Center"))
                        L3_2 = (native_controls.yawjitter)[2]
                        ui_set(L3_2, 35)
                    else
                        L2_2 = anti_aim_state.aa
                        if L2_2 == 5 then
                            L3_2 = (native_controls.yawjitter)[1]
                            ui_set(L3_2, ("Off"))
                            L3_2 = (native_controls.yawjitter)[2]
                            ui_set(L3_2, 0)
                        else
                            L2_2 = anti_aim_state.aa
                            if L2_2 == 6 then
                                L3_2 = (native_controls.yawjitter)[1]
                                ui_set(L3_2, ("Off"))
                                L3_2 = (native_controls.yawjitter)[2]
                                ui_set(L3_2, 20)
                            else
                                L2_2 = anti_aim_state.aa
                                if L2_2 == 7 then
                                    L3_2 = (native_controls.yawjitter)[1]
                                    ui_set(L3_2, ("Center"))
                                    L3_2 = (native_controls.yawjitter)[2]
                                    ui_set(L3_2, 10)
                                end
                            end
                        end
                    end
                end
            end
        end
        if not L94_1 then
            L2_2 = client.delay_call
            L2_2(0.25, reset_clan_tag)
            L94_1 = true
        end
        L7_2 = (client.random_int)(45, 60)
        L8_2 = (client.random_int)(45, 60)
        L9_2 = anti_aim_state.aa
        if L9_2 == 1 then
            L10_2 = native_controls.fakeyawlimit
            ui_set(L10_2, 60)
        else
            L9_2 = anti_aim_state.aa
            if L9_2 == 2 then
                L10_2 = native_controls.fakeyawlimit
                ui_set(L10_2, 60)
            else
                L9_2 = anti_aim_state.aa
                if L9_2 == 3 then
                    L10_2 = native_controls.fakeyawlimit
                    ui_set(L10_2, 60)
                else
                    L9_2 = anti_aim_state.aa
                    if L9_2 == 4 then
                        L10_2 = native_controls.fakeyawlimit
                        ui_set(L10_2, 60)
                    else
                        L9_2 = anti_aim_state.aa
                        if L9_2 == 5 then
                            L10_2 = native_controls.fakeyawlimit
                            ui_set(L10_2, 60)
                        else
                            L9_2 = anti_aim_state.aa
                            if L9_2 == 6 then
                                L10_2 = native_controls.fakeyawlimit
                                ui_set(L10_2, L7_2)
                            else
                                L9_2 = anti_aim_state.aa
                                if L9_2 == 7 then
                                    L10_2 = native_controls.fakeyawlimit
                                    ui_set(L10_2, L8_2)
                                end
                            end
                        end
                    end
                end
            end
        end
        set_native_ui_visible(false)
    end
    on_bullet_impact = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
        L1_2 = get_local_player()
        L3_2 = A0_2.userid
        L2_2 = userid_to_entindex(L3_2)
        L3_2 = is_enemy(L2_2)
        if L3_2 then
            L3_2 = is_alive(L1_2)
            if L3_2 then
                L3_2 = is_valid_player(L2_2)
                if L3_2 then
                    L3_2 = target_info(L2_2, A0_2)
                    L6_2 = anti_aim_state.ls
                    L4_2 = target_record_info(L3_2, L6_2, L2_2, L1_2, A0_2)
                    if L4_2 then
                        L4_2 = #((player_records[L2_2]).s)
                        if 0 < L4_2 then
                            L4_2 = (player_records[L2_2]).s
                            L5_2 = #((player_records[L2_2]).s)
                            L4_2 = (L4_2[L5_2]).t
                            L5_2 = curtime()
                            if L4_2 == L5_2 then
                                L4_2 = #((player_records[L2_2]).s)
                                if not (L4_2) then
                                    L4_2 = (#((player_records[L2_2]).s)) + 1
                                end
                            else
                                L4_2 = (#((player_records[L2_2]).s)) + 1
                            end
                        else
                            L4_2 = (#((player_records[L2_2]).s)) + 1
                        end
                        L5_2 = anti_aim_state.desync
                        if L5_2 ~= 0 then
                            L5_2 = anti_aim_state.desync
                            if L5_2 ~= 180 then
                                L5_2 = script_controls["Detect missed angle"]
                            end
                        else
                            L5_2 = true
                        end
                        L6_2 = anti_aim_state.desync
                        L7_2 = anti_aim_state.desync
                        if L6_2 == L7_2 then
                            L6_2 = -(anti_aim_state.desync)
                            if not (L6_2) then
                                L6_2 = anti_aim_state.desync
                            end
                        else
                            L6_2 = anti_aim_state.desync
                        end
                        if L5_2 then
                            L7_2 = math_abs(L3_2)
                            if L7_2 < 3 then
                                L7_2 = anti_aim_state.desync
                                if L7_2 then
                                    L7_2 = anti_aim_state.desync
                                    L6_2 = L7_2 or L6_2
                                end
                                if not L7_2 then
                                    L7_2 = anti_aim_state.desync
                                    L6_2 = -L7_2
                                end
                            else
                                if 0 < L3_2 then
                                    L7_2 = -(anti_aim_state.desync)
                                    if not (L7_2) then
                                        L6_2 = anti_aim_state.desync
                                    end
                                else
                                    L6_2 = anti_aim_state.desync
                                end
                            end
                        end
                        L7_2 = (player_records[L2_2]).s
                        L8_2 = {
                        }
                        L8_2.t = tickcount()
                        L8_2.d = L6_2
                        L8_2.dis = L3_2
                        L7_2[L4_2] = L8_2
                    end
                else
                    do
                        return 
                    end
                end
            else
                do
                    return 
                end
            end
        else
            do
                return 
            end
        end
    end
    on_player_hurt = function(A0_2, ...)
        local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
        L1_2 = get_local_player()
        L3_2 = A0_2.userid
        L2_2 = userid_to_entindex(L3_2)
        L4_2 = A0_2.attacker
        L3_2 = userid_to_entindex(L4_2)
        L4_2 = is_enemy(L3_2)
        if L4_2 then
            L4_2 = is_alive(L1_2)
            if L4_2 then
                L5_2 = #(anti_aim_state.nonweapons)
                for L7_2 = 1, L5_2, 1 do
                    L8_2 = A0_2.weapon
                    L9_2 = (anti_aim_state.nonweapons)[L7_2]
                    if L8_2 == L9_2 then
                        return 
                    end
                end
                L4_2 = #((player_records[L3_2]).h)
                if 0 < L4_2 then
                    L4_2 = #((player_records[L3_2]).h)
                    if not (L4_2) then
                        L4_2 = (#((player_records[L3_2]).h)) + 1
                    end
                else
                    L4_2 = (#((player_records[L3_2]).h)) + 1
                end
                L5_2 = (player_records[L3_2]).h
                L6_2 = {
                }
                L6_2.t = tickcount()
                L6_2.d = new_angle
                L6_2.h = A0_2.hitgroup
                L6_2.v = L2_2
                L5_2[L4_2] = L6_2
            else
                do
                    return 
                end
            end
        else
            do
                return 
            end
        end
    end
    on_player_spawn = function(A0_2, ...)
        local L1_2, L2_2, L3_2
        L1_2 = get_local_player()
        L3_2 = A0_2.userid
        L2_2 = userid_to_entindex(L3_2)
        if L2_2 == L1_2 then
            reset_player_state(true)
        end
    end
    L107_1 = {
    }
    L107_1[1] = ("")
    L107_1[2] = ("p")
    L107_1[3] = ("pr")
    L107_1[4] = ("pre")
    L107_1[5] = ("pred")
    L107_1[6] = ("predi")
    L107_1[7] = ("predic")
    L107_1[8] = ("predict")
    L107_1[9] = ("predicti")
    L107_1[10] = ("predictio")
    L107_1[11] = ("prediction.lua")
    L107_1[12] = ("")
    L107_1[13] = ("prediction.lua")
    L107_1[14] = ("")
    L107_1[15] = ("prediction.lua")
    L107_1[16] = ("")
    L107_1[17] = ("prediction.lua")
    L107_1[18] = ("")
    L107_1[19] = ("predictio")
    L107_1[20] = ("predicti")
    L107_1[21] = ("predict")
    L107_1[22] = ("predic")
    L107_1[23] = ("predi")
    L107_1[24] = ("pred")
    L107_1[25] = ("pre")
    L107_1[26] = ("pr")
    L107_1[27] = ("p")
    L107_1[28] = ("")
    L108_1 = {
    }
    L108_1[1] = ("nemesis")
    L108_1[2] = ("n3m3sis")
    L109_1 = 1
    L110_1 = 0
    L111_1 = false
    clear_clan_tag = client.set_event_callback
    update_ui_visibility = function(A0_2, ...)
        local L1_2
        L1_2 = (globals.tickcount)()
    end
    clear_clan_tag(("player_connect_full"), update_ui_visibility)
    clear_clan_tag = function(...)
        local L0_2
        L0_2 = client.set_clan_tag
        L0_2((""))
    end
    draw_indicators = client.set_event_callback
    whitelisted = function(...)
        local L0_2
        if L111_1 then
            L0_2 = client.delay_call
            L0_2(0.15, clear_clan_tag)
        end
    end
    draw_indicators(("shutdown"), whitelisted)
    draw_indicators = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2
        L0_2 = get_local_player()
        update_shot_history(L0_2)
        L2_2 = script_controls.s
        L1_2 = contains_value(L2_2, ("Adaptive clantag"))
        if L1_2 then
            L1_2 = ((entity.get_all)(("CCSPlayerResource")))[1]
            L2_2 = entity.get_prop
            L5_2 = entity.get_local_player
            local returned_68_46 = __dec14_pack_results(L5_2())
            L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_46, 1, returned_68_46.n)
            L2_2 = L2_2(L1_2, ("m_iKills"), unpack(returned_68_46, 1, returned_68_46.n))
            L3_2 = entity.get_prop
            L6_2 = entity.get_local_player
            local returned_68_47 = __dec14_pack_results(L6_2())
            L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_47, 1, returned_68_47.n)
            L3_2 = L3_2(L1_2, ("m_iDeaths"), unpack(returned_68_47, 1, returned_68_47.n))
            L4_2 = L2_2 / L3_2
            if L4_2 < 1.5 or L2_2 == nil and L3_2 == nil then
                L4_2 = ((globals.tickcount)()) - L110_1
                if 10 < L4_2 then
                    L4_2 = math.floor
                    L5_2 = ((((globals.curtime)()) * 1) % 2) + 1
                    L109_1 = L4_2(L5_2)
                    L4_2 = client.set_clan_tag
                    L5_2 = L108_1[L109_1]
                    L4_2(L5_2)
                    L110_1 = (globals.tickcount)()
                end
            else
                L4_2 = ((globals.tickcount)()) - L110_1
                if 10 < L4_2 then
                    L4_2 = math.floor
                    L5_2 = ((((globals.curtime)()) * 2) % 24) + 1
                    L109_1 = L4_2(L5_2)
                    L4_2 = client.set_clan_tag
                    L5_2 = L107_1[L109_1]
                    L4_2(L5_2)
                    L110_1 = (globals.tickcount)()
                end
            end
            if not L111_1 then
                L111_1 = true
            end
        else
            if L111_1 then
                L1_2 = client.delay_call
                L1_2(0.15, clear_clan_tag)
                L111_1 = false
            end
        end
        L1_2 = is_alive(L0_2)
        if not L1_2 then
            return 
        else
            L1_2 = {
            }
            L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = screen_size()
            L1_2[1] = L2_2
            L1_2[2] = L3_2
            L1_2[3] = L4_2
            L1_2[4] = L5_2
            L1_2[5] = L6_2
            L1_2[6] = L7_2
            L1_2[7] = L8_2
            L1_2[8] = L9_2
            L1_2[9] = L10_2
            L1_2[10] = L11_2
            L1_2[11] = L12_2
            L1_2[12] = L13_2
            L1_2[13] = L14_2
            L1_2[14] = L15_2
            L1_2[15] = L16_2
            L1_2[16] = L17_2
            L1_2[17] = L18_2
            L1_2[18] = L19_2
            L1_2[19] = L20_2
            L1_2[20] = L21_2
            L1_2[21] = L22_2
            L1_2[22] = L23_2
            L1_2[23] = L24_2
            L1_2[24] = L25_2
            L1_2[25] = L26_2
            L1_2[26] = L27_2
            L1_2[27] = L28_2
            L1_2[28] = L29_2
            L1_2[29] = L30_2
            L1_2[30] = L31_2
            L1_2[31] = L32_2
            L1_2[32] = L33_2
            L2_2 = {
            }
            L3_2 = (L1_2[1]) / 2
            L4_2 = (L1_2[2]) / 2
            L2_2[1] = L3_2
            L2_2[2] = L4_2
            L4_2 = (script_controls.clr)[2]
            L3_2, L4_2, L5_2, L6_2 = ui_get(L4_2)
            L8_2 = (script_controls.clr2)[2]
            L7_2, L8_2, L9_2, L10_2 = ui_get(L8_2)
            L11_2 = ((get_prop(L0_2, ("m_flPoseParameter"), 11)) * 120) - 60
            L12_2 = anti_aim_state.holding_e
            if L12_2 then
                L12_2 = -1
                if not (L12_2) then
                    L12_2 = 1
                end
            else
                L12_2 = 1
            end
            L11_2 = L11_2 * L12_2
            L12_2 = 20
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("AA indicator"))
            if L13_2 then
                L14_2 = script_controls.s
                L13_2 = contains_value(L14_2, ("Legacy arrows"))
                if not L13_2 then
                    L13_2 = {
                    }
                    L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = camera_angles()
                    L13_2[1] = L14_2
                    L13_2[2] = L15_2
                    L13_2[3] = L16_2
                    L13_2[4] = L17_2
                    L13_2[5] = L18_2
                    L13_2[6] = L19_2
                    L13_2[7] = L20_2
                    L13_2[8] = L21_2
                    L13_2[9] = L22_2
                    L13_2[10] = L23_2
                    L13_2[11] = L24_2
                    L13_2[12] = L25_2
                    L13_2[13] = L26_2
                    L13_2[14] = L27_2
                    L13_2[15] = L28_2
                    L13_2[16] = L29_2
                    L13_2[17] = L30_2
                    L13_2[18] = L31_2
                    L13_2[19] = L32_2
                    L13_2[20] = L33_2
                    L14_2 = {
                    }
                    L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = hitbox_position(L0_2, ("head_0"))
                    L14_2[1] = L15_2
                    L14_2[2] = L16_2
                    L14_2[3] = L17_2
                    L14_2[4] = L18_2
                    L14_2[5] = L19_2
                    L14_2[6] = L20_2
                    L14_2[7] = L21_2
                    L14_2[8] = L22_2
                    L14_2[9] = L23_2
                    L14_2[10] = L24_2
                    L14_2[11] = L25_2
                    L14_2[12] = L26_2
                    L14_2[13] = L27_2
                    L14_2[14] = L28_2
                    L14_2[15] = L29_2
                    L14_2[16] = L30_2
                    L14_2[17] = L31_2
                    L14_2[18] = L32_2
                    L14_2[19] = L33_2
                    L15_2 = {
                    }
                    L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = hitbox_position(L0_2, ("pelvis"))
                    L15_2[1] = L16_2
                    L15_2[2] = L17_2
                    L15_2[3] = L18_2
                    L15_2[4] = L19_2
                    L15_2[5] = L20_2
                    L15_2[6] = L21_2
                    L15_2[7] = L22_2
                    L15_2[8] = L23_2
                    L15_2[9] = L24_2
                    L15_2[10] = L25_2
                    L15_2[11] = L26_2
                    L15_2[12] = L27_2
                    L15_2[13] = L28_2
                    L15_2[14] = L29_2
                    L15_2[15] = L30_2
                    L15_2[16] = L31_2
                    L15_2[17] = L32_2
                    L15_2[18] = L33_2
                    L18_2 = L15_2[1]
                    L19_2 = L15_2[2]
                    L20_2 = L14_2[1]
                    L21_2 = L14_2[2]
                    L17_2 = yaw_between_points(L18_2, L19_2, L20_2, L21_2)
                    L18_2 = L11_2 / 2
                    L17_2 = L17_2 - L18_2
                    L18_2 = L13_2[2]
                    L17_2 = (L17_2 - L18_2) + 120
                    L16_2 = normalize_yaw(L17_2)
                    L17_2 = draw_indicator_triangle
                    L18_2 = L2_2[1]
                    L19_2 = L2_2[2]
                    L20_2 = L3_2
                    L21_2 = L4_2
                    L22_2 = L5_2
                    L23_2 = L6_2
                    L24_2 = L7_2
                    L25_2 = L8_2
                    L26_2 = L9_2
                    L27_2 = 255
                    L28_2 = L11_2 / 1.5
                    L28_2 = (L16_2 + L28_2) * -1
                    if not (L11_2 < 0) then
                        L30_2 = false
                    else
                        L30_2 = true
                    end
                    draw_indicator_triangle(L18_2, L19_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, 255, L28_2, 60, L30_2)
                    L12_2 = 42
                end
            end
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("Legacy arrows"))
            if L13_2 then
                L13_2 = (anti_aim_state.dir).manual
                if L13_2 == 90 then
                    L14_2 = (L2_2[1]) + 60
                    L15_2 = L2_2[2]
                    L22_2 = base64_module.decode
                    local returned_68_48 = __dec14_pack_results(L22_2(("4oC6")))
                    L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_48, 1, returned_68_48.n)
                    draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L6_2, ("c+"), 0, unpack(returned_68_48, 1, returned_68_48.n))
                    L14_2 = (L2_2[1]) - 60
                    L15_2 = L2_2[2]
                    L16_2 = L7_2
                    L17_2 = L8_2
                    L18_2 = L9_2
                    L19_2 = L10_2
                    L20_2 = "c+"
                    L21_2 = 0
                    L22_2 = base64_module.decode
                    local returned_68_49 = __dec14_pack_results(L22_2(("4oC5")))
                    L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_49, 1, returned_68_49.n)
                    draw_text(L14_2, L15_2, L7_2, L8_2, L9_2, L10_2, ("c+"), 0, unpack(returned_68_49, 1, returned_68_49.n))
                else
                    L13_2 = (anti_aim_state.dir).manual
                    if L13_2 == -90 then
                        L14_2 = (L2_2[1]) - 60
                        L15_2 = L2_2[2]
                        L22_2 = base64_module.decode
                        local returned_68_50 = __dec14_pack_results(L22_2(("4oC5")))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_50, 1, returned_68_50.n)
                        draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L6_2, ("c+"), 0, unpack(returned_68_50, 1, returned_68_50.n))
                        L14_2 = (L2_2[1]) + 60
                        L15_2 = L2_2[2]
                        L16_2 = L7_2
                        L17_2 = L8_2
                        L18_2 = L9_2
                        L19_2 = L10_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module.decode
                        local returned_68_51 = __dec14_pack_results(L22_2(("4oC6")))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_51, 1, returned_68_51.n)
                        draw_text(L14_2, L15_2, L7_2, L8_2, L9_2, L10_2, ("c+"), 0, unpack(returned_68_51, 1, returned_68_51.n))
                    else
                        L14_2 = (L2_2[1]) - 60
                        L15_2 = L2_2[2]
                        L22_2 = base64_module.decode
                        local returned_68_52 = __dec14_pack_results(L22_2(("4oC5")))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_52, 1, returned_68_52.n)
                        draw_text(L14_2, L15_2, L7_2, L8_2, L9_2, L10_2, ("c+"), 0, unpack(returned_68_52, 1, returned_68_52.n))
                        L14_2 = (L2_2[1]) + 60
                        L15_2 = L2_2[2]
                        L16_2 = L7_2
                        L17_2 = L8_2
                        L18_2 = L9_2
                        L19_2 = L10_2
                        L20_2 = "c+"
                        L21_2 = 0
                        L22_2 = base64_module.decode
                        local returned_68_53 = __dec14_pack_results(L22_2(("4oC6")))
                        L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_53, 1, returned_68_53.n)
                        draw_text(L14_2, L15_2, L7_2, L8_2, L9_2, L10_2, ("c+"), 0, unpack(returned_68_53, 1, returned_68_53.n))
                    end
                end
            end
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("Name indicator"))
            if L13_2 then
                L14_2 = (L2_2[1]) - 30
                L15_2 = (L2_2[2]) + 20
                L16_2 = L3_2 or L16_2
                if not (0 < L11_2) or not L3_2 then
                    L16_2 = L7_2
                end
                L17_2 = L4_2 or L17_2
                if not (0 < L11_2) or not L4_2 then
                    L17_2 = L8_2
                end
                L18_2 = L5_2 or L18_2
                if not (0 < L11_2) or not L5_2 then
                    L18_2 = L9_2
                end
                L19_2 = L6_2 or L19_2
                if not (0 < L11_2) or not L6_2 then
                    L19_2 = 255
                end
                draw_text(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, ("b"), 0, ("predi"))
                L14_2 = (L2_2[1]) - 4
                L15_2 = (L2_2[2]) + 20
                L16_2 = L3_2 or L16_2
                if not (L11_2 < 0) or not L3_2 then
                    L16_2 = L7_2
                end
                L17_2 = L4_2 or L17_2
                if not (L11_2 < 0) or not L4_2 then
                    L17_2 = L8_2
                end
                L18_2 = L5_2 or L18_2
                if not (L11_2 < 0) or not L5_2 then
                    L18_2 = L9_2
                end
                L19_2 = L6_2 or L19_2
                if not (L11_2 < 0) or not L6_2 then
                    L19_2 = 255
                end
                L20_2 = "b"
                L21_2 = 0
                L22_2 = "ction.lua"
                draw_text(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, ("b"), 0, ("ction.lua"))
            end
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("Status Indicator"))
            if L13_2 then
                L13_2 = anti_aim_state.aa
                if L13_2 == 1 then
                    L14_2 = (L2_2[1]) - 8
                    L15_2 = ((L2_2[2]) + 15) + L12_2
                    L17_2 = L4_2
                    L18_2 = L5_2
                    L19_2 = L6_2 * 0.75
                    L20_2 = "-c"
                    L21_2 = 0
                    L22_2 = "+/- ADAPTIVE"
                    draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- ADAPTIVE"))
                else
                    L13_2 = anti_aim_state.aa
                    if L13_2 == 2 then
                        L14_2 = (L2_2[1]) - 12
                        L15_2 = ((L2_2[2]) + 15) + L12_2
                        L17_2 = L4_2
                        L18_2 = L5_2
                        L19_2 = L6_2 * 0.75
                        L20_2 = "-c"
                        L21_2 = 0
                        L22_2 = "+/- MOVING"
                        draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- MOVING"))
                    else
                        L13_2 = anti_aim_state.aa
                        if L13_2 == 3 then
                            L14_2 = (L2_2[1]) - 4
                            L15_2 = ((L2_2[2]) + 15) + L12_2
                            L17_2 = 111
                            L18_2 = 111
                            L19_2 = L6_2 * 0.75
                            L20_2 = "-c"
                            L21_2 = 0
                            L22_2 = "+/- DANGEROUS"
                            draw_text(L14_2, L15_2, 255, 111, 111, L19_2, ("-c"), 0, ("+/- DANGEROUS"))
                        else
                            L13_2 = anti_aim_state.aa
                            if L13_2 == 4 then
                                L14_2 = (L2_2[1]) - 21
                                L15_2 = ((L2_2[2]) + 15) + L12_2
                                L17_2 = L4_2
                                L18_2 = L5_2
                                L19_2 = L6_2 * 0.75
                                L20_2 = "-c"
                                L21_2 = 0
                                L22_2 = "+/- AIR"
                                draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- AIR"))
                            else
                                L13_2 = anti_aim_state.aa
                                if L13_2 == 5 then
                                    L14_2 = (L2_2[1]) - 20
                                    L15_2 = ((L2_2[2]) + 15) + L12_2
                                    L17_2 = L4_2
                                    L18_2 = L5_2
                                    L19_2 = L6_2 * 0.75
                                    L20_2 = "-c"
                                    L21_2 = 0
                                    L22_2 = "+/- USE"
                                    draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- USE"))
                                else
                                    L13_2 = anti_aim_state.aa
                                    if L13_2 == 6 then
                                        L14_2 = (L2_2[1]) - 9
                                        L15_2 = ((L2_2[2]) + 15) + L12_2
                                        L17_2 = L4_2
                                        L18_2 = L5_2
                                        L19_2 = L6_2 * 0.75
                                        L20_2 = "-c"
                                        L21_2 = 0
                                        L22_2 = "+/- HALFMAX"
                                        draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- HALFMAX"))
                                    else
                                        L13_2 = anti_aim_state.aa
                                        if L13_2 == 7 then
                                            L14_2 = (L2_2[1]) - 10
                                            L15_2 = ((L2_2[2]) + 15) + L12_2
                                            L17_2 = L4_2
                                            L18_2 = L5_2
                                            L19_2 = L6_2 * 0.75
                                            L20_2 = "-c"
                                            L21_2 = 0
                                            L22_2 = "+/- ABUSE 0*"
                                            draw_text(L14_2, L15_2, L3_2, L4_2, L5_2, L19_2, ("-c"), 0, ("+/- ABUSE 0*"))
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
                L14_2 = script_controls.s
                L13_2 = contains_value(L14_2, ("AA indicator"))
                if L13_2 then
                    L14_2 = script_controls.s
                    L13_2 = contains_value(L14_2, ("Legacy arrows"))
                    if not L13_2 then
                        L12_2 = 45
                    end
                end
            end
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("Legacy OG Circle"))
            if L13_2 then
                L14_2 = client.camera_angles
                local returned_68_54 = __dec14_pack_results(L14_2())
                L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_54, 1, returned_68_54.n)
                L13_2 = vector_module(unpack(returned_68_54, 1, returned_68_54.n))
                L15_2 = entity.hitbox_position
                local returned_68_55 = __dec14_pack_results(L15_2(L0_2, ("head_0")))
                L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_55, 1, returned_68_55.n)
                L14_2 = vector_module(unpack(returned_68_55, 1, returned_68_55.n))
                L16_2 = entity.hitbox_position
                local returned_68_56 = __dec14_pack_results(L16_2(L0_2, ("pelvis")))
                L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2, L31_2, L32_2, L33_2 = unpack(returned_68_56, 1, returned_68_56.n)
                L15_2 = vector_module(unpack(returned_68_56, 1, returned_68_56.n))
                L18_2 = L15_2.x
                L19_2 = L15_2.y
                L20_2 = L14_2.x
                L21_2 = L14_2.y
                L17_2 = yaw_between_points(L18_2, L19_2, L20_2, L21_2)
                L18_2 = L13_2.y
                L17_2 = (L17_2 - L18_2) + 120
                L16_2 = normalize_yaw(L17_2)
                L17_2 = (entity.get_prop)(L0_2, ("m_flPoseParameter"), 11)
                L18_2 = L17_2 * 120
                L17_2 = L18_2 - 60
                L19_2 = L16_2 + L17_2
                L18_2 = normalize_yaw(L19_2)
                L19_2 = ((math.abs)(L17_2)) / 60
                L20_2, L21_2, L22_2 = scale_factor(L19_2)
                L24_2 = L2_2[1]
                L25_2 = L2_2[2]
                L30_2 = L17_2 / 60
                draw_circle_indicator(L24_2, L25_2, L20_2, L21_2, L22_2, 255, L30_2)
                L23_2 = renderer.circle_outline
                L24_2 = L2_2[1]
                L25_2 = L2_2[2]
                L26_2 = L20_2
                L27_2 = L21_2
                L31_2 = (L16_2 * -1) - 15
                L23_2(L24_2, L25_2, L20_2, L21_2, L22_2, 255, 18, L31_2, 0.2, 4)
            end
            L14_2 = script_controls.s
            L13_2 = contains_value(L14_2, ("Keybind indicator"))
            if L13_2 then
                L13_2 = {
                }
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Double tap"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "DT"
                    L17_2 = (native_controls.dt)[1]
                    L16_2 = ui_get(L17_2)
                    if L16_2 then
                        L17_2 = (native_controls.dt)[2]
                        L16_2 = ui_get(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Onshot Anti-Aim"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "OS"
                    L17_2 = (native_controls.os)[1]
                    L16_2 = ui_get(L17_2)
                    if L16_2 then
                        L17_2 = (native_controls.os)[2]
                        L16_2 = ui_get(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Force body aim"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "FB"
                    L17_2 = native_controls.forcebaim
                    L15_2.e = ui_get(L17_2)
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Force safe point"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "SP"
                    L17_2 = native_controls.safepoint
                    L15_2.e = ui_get(L17_2)
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Edge yaw"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "EY"
                    L17_2 = native_controls.edgeyaw
                    L15_2.e = ui_get(L17_2)
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Freestanding"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "FS"
                    L17_2 = (native_controls.freestand)[1]
                    L18_2 = "Default"
                    L16_2 = contains_value(L17_2, ("Default"))
                    if L16_2 then
                        L17_2 = (native_controls.freestand)[2]
                        L16_2 = ui_get(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.k
                L14_2 = contains_value(L15_2, ("Quick peek"))
                if L14_2 then
                    L14_2 = (#L13_2) + 1
                    L15_2 = {
                    }
                    L15_2.t = "QP"
                    L17_2 = (native_controls.quickpeek)[1]
                    L16_2 = ui_get(L17_2)
                    if L16_2 then
                        L17_2 = (native_controls.quickpeek)[2]
                        L16_2 = ui_get(L17_2)
                    end
                    L15_2.e = L16_2
                    L13_2[L14_2] = L15_2
                end
                L15_2 = script_controls.s
                L14_2 = contains_value(L15_2, ("Status Indicator"))
                if L14_2 then
                    L15_2 = #L13_2
                    for L17_2 = 1, L15_2, 1 do
                        L18_2 = draw_text
                        L19_2 = (L2_2[1]) - 30
                        L20_2 = ((L2_2[2]) + L12_2) + 10
                        L21_2 = L17_2 * 8
                        L20_2 = L20_2 + L21_2
                        L21_2 = (L13_2[L17_2]).e
                        L21_2 = L3_2 or L21_2
                        if not L21_2 or not L3_2 then
                            L21_2 = L7_2
                        end
                        L22_2 = (L13_2[L17_2]).e
                        L22_2 = L4_2 or L22_2
                        if not L22_2 or not L4_2 then
                            L22_2 = L8_2
                        end
                        L23_2 = (L13_2[L17_2]).e
                        L23_2 = L5_2 or L23_2
                        if not L23_2 or not L5_2 then
                            L23_2 = L9_2
                        end
                        L24_2 = (L13_2[L17_2]).e
                        L24_2 = L6_2 or L24_2
                        if not L24_2 or not L6_2 then
                            L24_2 = L10_2 * 0.75
                        end
                        L25_2 = "-"
                        L26_2 = 0
                        L27_2 = (L13_2[L17_2]).t
                        draw_text(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, ("-"), 0, L27_2)
                    end
                else
                    L15_2 = #L13_2
                    for L17_2 = 1, L15_2, 1 do
                        L18_2 = draw_text
                        L19_2 = (L2_2[1]) - 1
                        L20_2 = ((L2_2[2]) + L12_2) + 7
                        L21_2 = L17_2 * 8
                        L20_2 = L20_2 + L21_2
                        L21_2 = (L13_2[L17_2]).e
                        L21_2 = L3_2 or L21_2
                        if not L21_2 or not L3_2 then
                            L21_2 = L7_2
                        end
                        L22_2 = (L13_2[L17_2]).e
                        L22_2 = L4_2 or L22_2
                        if not L22_2 or not L4_2 then
                            L22_2 = L8_2
                        end
                        L23_2 = (L13_2[L17_2]).e
                        L23_2 = L5_2 or L23_2
                        if not L23_2 or not L5_2 then
                            L23_2 = L9_2
                        end
                        L24_2 = (L13_2[L17_2]).e
                        L24_2 = L6_2 or L24_2
                        if not L24_2 or not L6_2 then
                            L24_2 = L10_2 * 0.75
                        end
                        L25_2 = "c-"
                        L26_2 = 0
                        L27_2 = (L13_2[L17_2]).t
                        draw_text(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, ("c-"), 0, L27_2)
                    end
                end
            end
        end
    end
    update_ui_visibility = function(...)
        local L1_2, L2_2, L3_2, L4_2
        L1_2 = script_controls.la
        L3_2 = script_controls.s
        local returned_69_57 = __dec14_pack_results(contains_value(L3_2, ("Custom Legit AA")))
        L2_2, L3_2, L4_2 = unpack(returned_69_57, 1, returned_69_57.n)
        ui_set_visible(L1_2, unpack(returned_69_57, 1, returned_69_57.n))
        L1_2 = script_controls.ml
        L3_2 = script_controls.s
        local returned_69_58 = __dec14_pack_results(contains_value(L3_2, ("Manual AA")))
        L2_2, L3_2, L4_2 = unpack(returned_69_58, 1, returned_69_58.n)
        ui_set_visible(L1_2, unpack(returned_69_58, 1, returned_69_58.n))
        L1_2 = script_controls.mr
        L3_2 = script_controls.s
        local returned_69_59 = __dec14_pack_results(contains_value(L3_2, ("Manual AA")))
        L2_2, L3_2, L4_2 = unpack(returned_69_59, 1, returned_69_59.n)
        ui_set_visible(L1_2, unpack(returned_69_59, 1, returned_69_59.n))
        L1_2 = script_controls.mf
        L3_2 = script_controls.s
        local returned_69_60 = __dec14_pack_results(contains_value(L3_2, ("Manual AA")))
        L2_2, L3_2, L4_2 = unpack(returned_69_60, 1, returned_69_60.n)
        ui_set_visible(L1_2, unpack(returned_69_60, 1, returned_69_60.n))
        L1_2 = script_controls.fs
        L3_2 = script_controls.s
        local returned_69_61 = __dec14_pack_results(contains_value(L3_2, ("Freestanding")))
        L2_2, L3_2, L4_2 = unpack(returned_69_61, 1, returned_69_61.n)
        ui_set_visible(L1_2, unpack(returned_69_61, 1, returned_69_61.n))
        L1_2 = script_controls.ey
        L3_2 = script_controls.s
        local returned_69_62 = __dec14_pack_results(contains_value(L3_2, ("Edge yaw")))
        L2_2, L3_2, L4_2 = unpack(returned_69_62, 1, returned_69_62.n)
        ui_set_visible(L1_2, unpack(returned_69_62, 1, returned_69_62.n))
        L1_2 = script_controls.k
        L3_2 = script_controls.s
        local returned_69_63 = __dec14_pack_results(contains_value(L3_2, ("Keybind indicator")))
        L2_2, L3_2, L4_2 = unpack(returned_69_63, 1, returned_69_63.n)
        ui_set_visible(L1_2, unpack(returned_69_63, 1, returned_69_63.n))
        L1_2 = (script_controls.clr)[1]
        L3_2 = script_controls.s
        L2_2 = contains_value(L3_2, ("AA indicator"))
        if not L2_2 then
            L3_2 = script_controls.s
            L2_2 = contains_value(L3_2, ("Keybind indicator"))
            if not L2_2 then
                L3_2 = script_controls.s
                L2_2 = contains_value(L3_2, ("Name indicator"))
            end
        end
        ui_set_visible(L1_2, L2_2)
        L1_2 = (script_controls.clr)[2]
        L3_2 = script_controls.s
        L2_2 = contains_value(L3_2, ("AA indicator"))
        if not L2_2 then
            L3_2 = script_controls.s
            L2_2 = contains_value(L3_2, ("Keybind indicator"))
            if not L2_2 then
                L3_2 = script_controls.s
                L2_2 = contains_value(L3_2, ("Name indicator"))
            end
        end
        ui_set_visible(L1_2, L2_2)
        L1_2 = (script_controls.clr2)[1]
        L3_2 = script_controls.s
        L2_2 = contains_value(L3_2, ("AA indicator"))
        if not L2_2 then
            L3_2 = script_controls.s
            L2_2 = contains_value(L3_2, ("Keybind indicator"))
            if not L2_2 then
                L3_2 = script_controls.s
                L2_2 = contains_value(L3_2, ("Name indicator"))
            end
        end
        ui_set_visible(L1_2, L2_2)
        L1_2 = (script_controls.clr2)[2]
        L3_2 = script_controls.s
        L2_2 = contains_value(L3_2, ("AA indicator"))
        if not L2_2 then
            L3_2 = script_controls.s
            L2_2 = contains_value(L3_2, ("Keybind indicator"))
            if not L2_2 then
                L3_2 = script_controls.s
                L2_2 = contains_value(L3_2, ("Name indicator"))
            end
        end
        ui_set_visible(L1_2, L2_2)
        set_native_ui_visible(false)
    end
    whitelisted = false
    panorama_api = (panorama[("open")])()
    register_events_if_whitelisted = function(...)
        local L0_2, L1_2, L2_2
        if not whitelisted then
            L0_2 = client.set_event_callback
            L2_2 = function(...)
                local L0_3
                L0_3 = renderer.indicator
                L0_3(255, 0, 0, 255, ("[amgis corporations] prediction not whitelisted on this account - check console"))
            end
            L0_2(("paint_ui"), L2_2)
            steam = ((panorama_api.MyPersonaAPI).GetXuid)()
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            L0_2 = client.log
            L1_2 = ("You are not whitelisted, send this steamid in the prediction chat for whitelist & tag a staff! -> ")..steam
            L0_2(L1_2)
            return 
        end
        L0_2 = client.log
        L0_2(("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        L0_2 = client.log
        L0_2(("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        L0_2 = client.log
        L0_2(("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        L0_2 = client.log
        L0_2(("[amgis corporations] sigma's prediction anti-aim lua loaded successfully!"))
        update_ui_visibility()
        L1_2 = script_controls.s
        ui_set_callback(L1_2, update_ui_visibility)
        set_event_callback(("shutdown"), set_native_ui_visible)
        set_event_callback(("paint"), draw_indicators)
        set_event_callback(("bullet_impact"), on_bullet_impact)
        set_event_callback(("player_hurt"), on_player_hurt)
        set_event_callback(("setup_command"), apply_body_yaw)
        set_event_callback(("player_spawn"), on_player_spawn)
        set_event_callback(("client_disconnect"), reset_player_state)
        set_event_callback(("cs_game_disconnected"), reset_player_state)
        set_event_callback(("game_newmap"), reset_player_state)
    end
    request_whitelist = function(...)
        local L0_2, L1_2, L2_2, L3_2, L4_2
        L0_2 = http_module.get
        L1_2 = string.format
        L3_2 = (database.read)(("prediction_auth"))
        if not L3_2 then
            L3_2 = ""
        end
        L4_2 = ((panorama_api.MyPersonaAPI).GetXuid)()
        L1_2 = L1_2(("https://gs.shav.it/check?auth=%s&id=%s"), L3_2, L4_2)
        L2_2 = function(A0_3, A1_3, ...)
            local L2_3, L4_3
            if not A0_3 then
                return 
            else
                L2_3 = A1_3.status
                if L2_3 ~= 200 then
                    L2_3 = A1_3.status
                    if not (L2_3 ~= 201) then
                        whitelisted = true
                    end
                else
                    whitelisted = true
                end
                L2_3 = A1_3.status
                if L2_3 == 201 then
                    L2_3 = database.write
                    L4_3 = A1_3.body
                    L2_3(("prediction_auth"), L4_3)
                end
                register_events_if_whitelisted()
            end
        end
        L0_2(L1_2, L2_2)
        return false
    end
    request_whitelist()
    fake_yaw_limit = (ui.reference)(("aa"), ("Anti-aimbot angles"), ("Fake yaw limit"))
    screen_dimensions = {
    }
    screen_center = client.screen_size
    screen_center, draw_branding, L123_1, L124_1, L125_1, L126_1, L127_1, L128_1, L129_1, L130_1, L131_1, L132_1, L133_1, L134_1, L135_1 = screen_center()
    screen_dimensions[1] = screen_center
    screen_dimensions[2] = draw_branding
    screen_dimensions[3] = L123_1
    screen_dimensions[4] = L124_1
    screen_dimensions[5] = L125_1
    screen_dimensions[6] = L126_1
    screen_dimensions[7] = L127_1
    screen_dimensions[8] = L128_1
    screen_dimensions[9] = L129_1
    screen_dimensions[10] = L130_1
    screen_dimensions[11] = L131_1
    screen_dimensions[12] = L132_1
    screen_dimensions[13] = L133_1
    screen_dimensions[14] = L134_1
    screen_dimensions[15] = L135_1
    screen_center = {
    }
    draw_branding = (screen_dimensions[1]) / 2
    L123_1 = (screen_dimensions[2]) / 2
    screen_center[1] = draw_branding
    screen_center[2] = L123_1
    draw_branding = function(...)
        local L0_2, L1_2
        L0_2 = renderer.text
        L1_2 = (screen_dimensions[1]) - 92
        L0_2(L1_2, 0, 255, 255, 255, 255, nil, 0, ("shoppy.gg/"))
        L0_2 = renderer.text
        L1_2 = (screen_dimensions[1]) - 40
        L0_2(L1_2, 0, 50, 255, 50, 255, nil, 0, ("@amgis"))
    end
    L123_1 = client.set_event_callback
    L123_1(("paint"), draw_branding)
end
return main(...)
