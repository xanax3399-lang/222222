from pathlib import Path
import json,hashlib
from lupa import lua51,luajit21
R=Path(__file__).resolve().parent;s=(R/'bluhgang_v2_galaxy_fixed.lua').read_bytes()
for module in [lua51,luajit21]:
 l=module.LuaRuntime(encoding=None);assert l.eval(b'function(s)return assert(loadstring(s))end')(s)
chunk=s[s.index(b'-- Compatibility helpers'):s.index(b'--[MENU ELEMENTS]')]
# Trailing separator before the marker is a comment and does not affect exports.
chunk+=b'\nreturn {refs=ref,set_freestanding=set_freestanding}\n'
reports={}
for mode in ['checkbox','multiselect']:
 l=luajit21.LuaRuntime(encoding=None)
 l.execute((R/'gamesense_fixture.lua').read_bytes())
 l.globals().freestanding_kind=mode.encode()
 l.execute(b'''
local original=ui.reference
ui.reference=function(tab,group,name)
 if name=='Fake yaw limit' or name=='sv_maxusrcmdprocessticks'then error('not found')end
 if tab:lower()=='rage' and group:lower()=='other' and (name=='Double tap'or name=='Force body aim')then error('not found')end
 local a,b=original(tab,group,name)
 if name=='Freestanding'then local c=sigma_controls()[a];c.kind=freestanding_kind;if freestanding_kind=='checkbox'then c.value=false else c.value={}end end
 return a,b
end
local set=ui.set
ui.set=function(handle,value,...)
 local c=assert(sigma_controls()[handle])
 if c.name=='Freestanding' and c.kind=='checkbox'then assert(type(value)=='boolean')end
 return set(handle,value,...)
end
''')
 result=l.execute(chunk);refs=result[b'refs']
 assert refs[b'fakeyawlimit']is None and refs[b'maxusrcmdprocessticks']is None
 assert refs[b'dt'][1]is not None and refs[b'dt'][2]is not None and refs[b'forcebaim']is not None
 for value in [b'Default',b'-',b'',True,False]:result[b'set_freestanding'](value)
 reports[mode]={'missing_optional_handles':True,'rage_aimbot_fallback':True,'freestanding_writes_checked':5}
(R/'validation.json').write_text(json.dumps({'source_sha256':hashlib.sha256(s).hexdigest(),'syntax':['Lua 5.1','LuaJIT 2.1'],'reference_and_freestanding_tests':reports,'full_script_runtime_or_gameplay_tested':False},indent=2)+'\n')
print('Syntax, native reference compatibility, Freestanding types passed')
