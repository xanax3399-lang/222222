from pathlib import Path
import re
R=Path(__file__).resolve().parent
s=(R/'original.lua').read_text(encoding='utf-8-sig')
compat='''-- Compatibility helpers are local to this script; native APIs are not replaced globally.
local original_ui = ui
local function native_reference(tab, container, name)
    local results = {pcall(original_ui.reference, tab, container, name)}
    if results[1] then return unpack(results, 2) end
    if not tostring(results[2]):find('not found', 1, true) then error(results[2], 2) end
    if tab:lower() == 'rage' and container:lower() == 'other' and (name == 'Double tap' or name == 'Force body aim') then
        return original_ui.reference(tab, 'Aimbot', name)
    end
    error(results[2], 2)
end
local warned_references = {}
local function optional_reference(tab, container, name)
    local results = {pcall(native_reference, tab, container, name)}
    if results[1] then return unpack(results, 2) end
    if not tostring(results[2]):find('not found', 1, true) then error(results[2], 2) end
    if not warned_references[name] then
        client.log('[bluhgang] Unavailable: ' .. name .. '; its dependent feature is skipped.')
        warned_references[name] = true
    end
    return nil
end
local ui = setmetatable({reference = native_reference}, {__index = original_ui})
'''
s=s.replace('local ref = {',compat+'\nlocal ref = {',1)
for key in ['maxprocticks','player_list','reset_all','apply_all','dt_limit']:
 assert len(re.findall(r'\bref\.'+key+r'\b',s))==0,key
 s,n=re.subn(r'(?m)^\s*'+key+r' = ui.reference\([^\n]+\n','',s);assert n==1,key
for name in ['Fake yaw limit','sv_maxusrcmdprocessticks','Force body aim','Double tap','Load']:
 s=re.sub(r'ui.reference\(([^\n]*?[\'"]'+re.escape(name)+r'[\'"][^\n]*?)\)',r'optional_reference(\1)',s)
s=s.replace("'Freestanding', 'Default'", "'Freestanding'")
# All optional writes are deliberately guarded; no placeholder handles are made.
s=re.sub(r'(?m)^(\s*)(ui\.(?:set|set_visible|set_callback)\(ref\.(fakeyawlimit|maxusrcmdprocessticks|load_cfg),[^\n]+\))\s*$',r'\1if ref.\3 ~= nil then \2 end',s)
for handle in ['ref.dt[1]','ref.dt[2]','ref.forcebaim']:
 s=s.replace('ui.get('+handle+')','('+handle+' ~= nil and ui.get('+handle+'))')
helper='''local function set_freestanding(value)
    local handle = ref.freestand[1]
    if type(ui.get(handle)) == 'boolean' then
        ui.set(handle, value == true or value == 'Default')
    else
        ui.set(handle, value)
    end
end

'''
# Preserve the old call's evaluation order and hotkey-mode calls.
s=s.replace('ui.set(ref.freestand[1], ', 'set_freestanding(')
pos=s.index('--[MENU ELEMENTS]');pos=s.rfind('---------------------------------------------',0,pos)
s=s[:pos]+helper+s[pos:]
(R/'bluhgang_v2_galaxy_fixed.lua').write_text(s)
